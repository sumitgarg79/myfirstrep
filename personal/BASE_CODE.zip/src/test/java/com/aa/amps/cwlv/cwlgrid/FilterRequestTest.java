package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.util.Constants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Neelabh Tripathi(847697) on 9/25/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class FilterRequestTest {

    FilterRequest filterRequest = new FilterRequest();

    @Before
    public void setup() {

        filterRequest.setStations(new String[]{"DFW", "CLT"});
        filterRequest.setFleets(new String[]{"737", "319"});
        filterRequest.setFromDate("09/25/2019");
        filterRequest.setToDate("09/26/2019");
        filterRequest.setAircraftNumber("980");
        filterRequest.setDescKey("Coffee maker");
        filterRequest.setRodRon(new String[]{"ROD"});
        filterRequest.setTaskId("UI8348i89980");
        filterRequest.setTypeCd(new String[]{"CHK", "SIC"});
        filterRequest.setUserId("847697");
        filterRequest.setSmSession("dsIKknvsd8jYOoiuj89uiy8789hhshfkjsdUDASJfhsHAuuMNVvhjhsdjkf");
    }

    @Test
    public void getSearchCriteriaAsMap_StationsWithValue() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.STATION_PLANNED);
        List<String> stations = (List<String>) searchCriteria.get(Constants.STATION_PLANNED);

        assertThat(stations).contains("DFW");
        assertThat(stations).contains("CLT");
    }

    @Test
    public void getSearchCriteriaAsMap_StationsWithOutValue() {
        FilterRequest filterRequest = new FilterRequest();
        filterRequest.setFleets(new String[]{"737", "319"});//setup a non-station value

        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(1);
        assertThat(searchCriteria).doesNotContainKeys(Constants.STATION_PLANNED);
    }

    @Test
    public void getSearchCriteriaAsMap_Fleet() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.FLEET_CODE);
        List<String> stations = (List<String>) searchCriteria.get(Constants.FLEET_CODE);

        assertThat(stations).contains("737");
        assertThat(stations).contains("319");
    }

    @Test
    public void getSearchCriteriaAsMap_FleetWithOutValue() {
        FilterRequest filterRequest = new FilterRequest();
        filterRequest.setStations(new String[]{"DFW", "CLT"});//setup a non-fleets value
        filterRequest.setFleets(new String[]{});

        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(1);
        assertThat(searchCriteria).doesNotContainKeys(Constants.FLEET_CODE);
    }

    @Test
    public void getSearchCriteriaAsMap_FromDate() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.PLANNED_DATE_FROM);
        assertThat((String) searchCriteria.get(Constants.PLANNED_DATE_FROM)).isNotEmpty()
            .isEqualToIgnoringCase("09/25/2019");
    }

    @Test
    public void getSearchCriteriaAsMap_ToDate() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.PLANNED_DATE_TO);
        assertThat((String) searchCriteria.get(Constants.PLANNED_DATE_TO)).isNotEmpty()
            .isEqualToIgnoringCase("09/26/2019");
    }

    @Test
    public void getSearchCriteriaAsMap_AircraftNumber() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.AIRCRAFT_NO);
        assertThat((String) searchCriteria.get(Constants.AIRCRAFT_NO)).isNotEmpty()
            .isEqualToIgnoringCase("980");
    }

    @Test
    public void getSearchCriteriaAsMap_DescKey() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.TASK_KEYWORD);
        assertThat((String) searchCriteria.get(Constants.TASK_KEYWORD)).isNotEmpty()
            .isEqualToIgnoringCase("Coffee maker");
    }

    @Test
    public void getSearchCriteriaAsMap_RodRon() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.ROD_RON);
        assertThat((String) searchCriteria.get(Constants.ROD_RON)).isNotEmpty()
            .isEqualToIgnoringCase("ROD");
    }

    @Test
    public void getSearchCriteriaAsMap_RodRonWithOutValue() {
        FilterRequest filterRequest = new FilterRequest();
        filterRequest.setRodRon(new String[]{});

        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(0);
        assertThat(searchCriteria).doesNotContainKeys(Constants.ROD_RON);
    }

    @Test
    public void getSearchCriteriaAsMap_TaskId() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.MNTNC_ID);
        assertThat((String) searchCriteria.get(Constants.MNTNC_ID)).isNotEmpty()
            .isEqualToIgnoringCase("UI8348i89980");
    }

    @Test
    public void getSearchCriteriaAsMap_TypeCd() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.MNTNC_TYPE);
        List<String> mntncType = (List<String>) searchCriteria.get(Constants.MNTNC_TYPE);

        assertThat(mntncType).contains("CHK");
        assertThat(mntncType).contains("SIC");
    }

    @Test
    public void getSearchCriteriaAsMap_UserId() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.USERID);
        assertThat((String) searchCriteria.get(Constants.USERID)).isNotEmpty()
            .isEqualToIgnoringCase("847697");
    }

    @Test
    public void getSearchCriteriaAsMap_SmSession() {
        Map<String, Object> searchCriteria = filterRequest.getSearchCriteriaAsMap();

        assertThat(searchCriteria).hasSize(11);

        assertThat(searchCriteria).containsKeys(Constants.SMSESSION);
        assertThat((String) searchCriteria.get(Constants.SMSESSION)).isNotEmpty()
            .isEqualToIgnoringCase("dsIKknvsd8jYOoiuj89uiy8789hhshfkjsdUDASJfhsHAuuMNVvhjhsdjkf");
    }
}
