package com.aa.amps.base.task;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.util.sysparam.SysParamService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code TaskService}.
 *
 * @author Paul Verner
 * @since on 6/10/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TaskServiceTest {
    private WorkPackageEntity wrkPkgEntity;
    @Autowired
    private TaskService taskService;
    private List<TaskEntity> taskEntityList;
    private String equipmentCode;
    @MockBean
    private TaskRepository taskRepository;
    @MockBean
    private SysParamService sysParamService;

    private Map<String, Integer> paramMap;

    @Before
    public void setUp() {
        taskEntityList = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setAircraftNbr("723");
        taskEntity.setAtaCode("05-38");
        taskEntity.setDeferralLockInd(false);
        taskEntity.setDescription("REP, 26L00038001, POTABLE WATER DISINFECT");
        taskEntity.setDni(false);
        taskEntity.setFleetCode("319");
        taskEntity.setForecastDateAsString("6/19/2018");
        taskEntity.setManHours(6);
        taskEntity.setPriority("3");
        taskEntity.setRouteControlCode("U");
        taskEntity.setStatus("Open");
        taskEntity.setTaskId("26-0538-8-0004 0723");
        taskEntity.setTaskTypeCode("ME8");
        taskEntity.setTtgCycles(8);
        taskEntity.setTtgDays(5);
        taskEntity.setTtgHours(89);
        taskEntity.setWorkControl(3456);
        taskEntity.setPlannedStation("BOS");

        taskEntityList.add(taskEntity);
        equipmentCode = "23";


        //Setup for Save/Merge/update Draft and tasks of draft .
        wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("826");
        wrkPkgEntity.setPkgSchdDt("2018-07-18");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntityForDraft = new TaskEntity();
        taskEntityForDraft.setTaskId("8421656");
        taskEntityForDraft.setAircraftNbr("826");
        taskEntityForDraft.setRouteControlCode("M");
        taskEntityForDraft.setDni(true);
        taskEntityForDraft.setDeferralLockInd(true);
        taskEntityForDraft.setWrkPkgTaskStatus("C");
        taskEntityForDraft.setUserId("292147");
        taskEntityForDraft.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntityForDraft);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        paramMap = new HashMap<>();
        paramMap.put("ME8", 1);
    }

    @Test
    public void getTasksBySearchCriteriaTest() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        given(this.taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap())).willReturn(taskEntityList);
        given(this.taskRepository.getAircraftEquipmentType(searchCriteria.getAircraftNumber())).willReturn
                (equipmentCode);
        TaskContainerResponse taskContainer = taskService.getTaskContainerBySearchCriteria(searchCriteria
                .getSearchCriteriaAsMap());
        assertNotNull(taskContainer.getTaskList());
    }

    /**
     * saveBaseDraft / Create Base Draft
     * Test case for saving New Base Draft
     */
    @Test
    public void saveBaseDraft_TestNewDraft() throws BaseServiceException {
        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(null);
        given(this.taskRepository.getWorkPackageSeqId()).willReturn(101L);
        given(this.taskRepository.saveBaseDraft(wrkPkgEntity, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(wrkPkgEntity.getTaskEntityList(), 101L)).willReturn(true);
        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * saveBaseDraft / Create Base Draft
     * Test case for save Base Draft exception in case of draft save get failed
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestSaveExceptionDraft() throws BaseServiceException {
        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(null);
        given(this.taskRepository.getWorkPackageSeqId()).willReturn(101L);
        given(this.taskRepository.saveBaseDraft(wrkPkgEntity, 101L)).willReturn(false);
        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * saveBaseDraft / Create Base Draft
     * Test case for save Base Draft exception in case of tasks of draft save get failed
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestSaveExceptionTasks() throws BaseServiceException {
        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(null);
        given(this.taskRepository.getWorkPackageSeqId()).willReturn(101L);
        given(this.taskRepository.saveBaseDraft(wrkPkgEntity, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(wrkPkgEntity.getTaskEntityList(), 101L)).willReturn(false);
        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * saveBaseDraft / Create Base Draft
     * Test case for save Base Draft exception in case of draft exist and user doesn't select merge/override
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestExistException() throws BaseServiceException {
        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(102));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_STATUS_CD", "DRAFT");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * saveBaseDraft / Create Base Draft
     * Test case for save Base Draft when it's already deleted in database
     */
    @Test
    public void saveBaseDraft_TestUpdateDeleted() throws BaseServiceException {

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_STATUS_CD", "DELETED");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * saveBaseDraft / Edit Base Draft
     * Test case for save Base Draft exception in case of draft exist and user select Edit
     */
    @Test
    public void saveBaseDraft_TestEdit() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * saveBaseDraft / Edit Base Draft
     * Test case for save Base Draft exception in case of draft don't exist and user select Edit
     */
    @Test
    public void saveBaseDraft_TestEditWithoutExist() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(null);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * saveBaseDraft / Edit Base Draft  / Update Base Draft
     * Test case for Edit Base Draft exception in case user change work package but that work package already exist.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestEditExistException() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(102));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_STATUS_CD", "DRAFT");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        taskService.saveBaseDraft(wrkPkgEntity);
    }


    /**
     * SaveBaseDraft / Edit Base Draft / Update Base Draft
     * Test case for update base draft and not inserting any task
     */
    @Test
    public void saveBaseDraft_UpdateWithoutInsert() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");
        List<TaskEntity> updateTaskEntities = new ArrayList<>();
        updateTaskEntities.add(wrkPkgEntity.getTaskEntityList().get(0));

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421656");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Edit Base Draft / Update Base Draft
     * Test case for update base draft and not deleting any task
     */
    @Test
    public void saveBaseDraft_UpdateWithoutDelete() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Edit Base Draft / Update Base Draft
     * Test case for update base draft and get the Exception
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_DbExceptionDraftSave() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(false);

        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * SaveBaseDraft / Edit Base Draft/ Update Base Draft
     * Test case for Exception when inserting the task for draft.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_ExceptionWhenInsert() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();

        insertTaskEntities.add(taskEntities.get(0));

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(false);

        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * SaveBaseDraft / Edit Base Draft / Update Base Draft
     * Test case for Exception when deleting the task for draft.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_ExceptionWhenDelete() throws BaseServiceException {
        wrkPkgEntity.setUserAction("EDIT");

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421656");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(false);

        taskService.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * SaveBaseDraft / Update (Merge) Base Draft
     * Test case for merge Base Draft
     */
    @Test
    public void saveBaseDraft_TestMerge() throws BaseServiceException {
        wrkPkgEntity.setUserAction("MERGE");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Update (Merge) Base Draft
     * Test case for merge Base Draft to delete the old draft.
     */
    @Test
    public void saveBaseDraft_TestMergeDeleteOld() throws BaseServiceException {
        wrkPkgEntity.setUserAction("MERGE");
        wrkPkgEntity.setWorkPkgId(102L);

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteWorkPackageEntity(102L, "292147")).willReturn(true);
        given(this.taskRepository.deleteAllTasksForWorkPkg(102L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Update (Merge) Base Draft
     * Test case for merge Base Draft to delete the old draft Exception in deleting the draft.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestMergeDeleteOldExceptionDraft() throws BaseServiceException {
        wrkPkgEntity.setUserAction("MERGE");
        wrkPkgEntity.setWorkPkgId(102L);

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteWorkPackageEntity(102L, "292147")).willReturn(false);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Update (Merge) Base Draft
     * Test case for merge Base Draft to delete the old draft Exception in deleting the tasks of draft.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraft_TestMergeDeleteOldExceptionTasks() throws BaseServiceException {
        wrkPkgEntity.setUserAction("MERGE");
        wrkPkgEntity.setWorkPkgId(102L);

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);
        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteWorkPackageEntity(102L, "292147")).willReturn(true);
        given(this.taskRepository.deleteAllTasksForWorkPkg(102L, "292147")).willReturn(false);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * SaveBaseDraft / Update Base Draft
     * Test case for override Base Draft
     */
    @Test
    public void saveBaseDraft_TestOverride() throws BaseServiceException {
        wrkPkgEntity.setUserAction("OVERRIDE");

        List<TaskEntity> taskEntities = wrkPkgEntity.getTaskEntityList();
        List<TaskEntity> insertTaskEntities = new ArrayList<>();
        List<TaskEntity> updateTaskEntities = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("826");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        insertTaskEntities.add(taskEntities.get(0));
        taskEntities.add(taskEntity);
        updateTaskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        List<Map<String, Object>> dbTaskEntities = new ArrayList<>();
        Map<String, Object> dbTaskEntity = new HashMap<>();
        dbTaskEntity.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity.put("AIRCFT_MNTNC_TASK_ID", "8421657");
        dbTaskEntity.put("AIRCFT_NBR", "826");
        dbTaskEntity.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity);

        Map<String, Object> dbTaskEntity2 = new HashMap<>();
        dbTaskEntity2.put("DRAFT_WORK_PKG_ID", 101L);
        dbTaskEntity2.put("AIRCFT_MNTNC_TASK_ID", "8421658");
        dbTaskEntity2.put("AIRCFT_NBR", "826");
        dbTaskEntity2.put("DRAFT_WORK_PKG_TASK_STATUS", "C");
        dbTaskEntities.add(dbTaskEntity2);

        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        dbTaskEntityMap.put("8421658", dbTaskEntity2);

        Map<String, Object> dbWorkPkgEntity = new HashMap<>();
        dbWorkPkgEntity.put("DRAFT_WORK_PKG_ID", new BigDecimal(101));
        dbWorkPkgEntity.put("AIRCFT_NBR", "826");
        dbWorkPkgEntity.put("DRAFT_PKG_SCHD_DT", "2018-07-18");
        dbWorkPkgEntity.put("DRAFT_PLAN_STN_CD", "BOS");

        given(this.taskRepository.checkWorkPackageExists(wrkPkgEntity)).willReturn(dbWorkPkgEntity);

        given(this.taskRepository.updateWorkPackageEntity(wrkPkgEntity)).willReturn(true);
        given(this.taskRepository.getTaskEntitiesForDraft(101L)).willReturn(dbTaskEntities);
        given(this.taskRepository.saveWorkPkgDraftTasks(insertTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.updateWorkPkgDraftTasks(updateTaskEntities, 101L)).willReturn(true);
        given(this.taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, 101L, "292147")).willReturn(true);

        boolean result = taskService.saveBaseDraft(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * Test case for getTaskDetails()
     */
    @Test
    public void getTaskDetailsTest() throws TaskDetailException {
        String[] taskIds = {"25-0525-8-0088 0723"};
        String[] aircraftNbrs = {"723"};

        TaskDetailRequest taskDetailRequest = new TaskDetailRequest();
        taskDetailRequest.setAircraftNbrs(aircraftNbrs);
        taskDetailRequest.setTaskIds(taskIds);

        given(this.taskRepository.getTaskDetails(BDDMockito.anyMap())).willReturn(taskEntityList);

        List<TaskEntity> taskDetails = this.taskService.getTaskDetails(taskDetailRequest.getTaskDetailRequestAsMap());
        assertThat(taskDetails).isNotNull();
        assertTrue(taskDetails.size() > 0);
    }

    /**
     * Test Case for getTotalManHoursTest.
     */
    @Test
    public void getTotalManHoursTest() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        given(this.taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap())).willReturn(taskEntityList);
        given(this.taskRepository.getAircraftEquipmentType(searchCriteria.getAircraftNumber())).willReturn
                (equipmentCode);
        TaskContainerResponse taskContainer = taskService.getTaskContainerBySearchCriteria(searchCriteria
                .getSearchCriteriaAsMap());
        assertTrue(taskContainer.getGrandTotalManHours() > 0);
    }

    /**
     * Test case for getWorkPackageTasks()
     *
     * @throws BaseServiceException in case of any Exception
     */
    @Test
    public void getWorkPackageTasksTest() throws BaseServiceException {
        given(this.taskRepository.getWorkPackageTasks((long) 2024)).willReturn(taskEntityList);
        given(this.sysParamService.getTaskTypeOrder()).willReturn(paramMap);

        List<TaskEntity> taskDetails = this.taskService.getWorkPackageTasks((long) 2024);
        for (TaskEntity taskEntity : taskDetails) {
            assertTrue(taskEntity.getTaskTypeSorting().equals(1));
        }
        assertThat(taskDetails).isNotNull();
        assertTrue(taskDetails.size() > 0);
    }

    /**
     * Test case for getWorkPackageTasks()
     *
     * @throws BaseServiceException in case of any Exception
     */
    @Test(expected = BaseServiceException.class)
    public void getWorkPackageTasksTestException() throws BaseServiceException {
        given(this.taskRepository.getWorkPackageTasks((long) 2024)).willThrow();

        this.taskService.getWorkPackageTasks((long) 2024);
    }
}