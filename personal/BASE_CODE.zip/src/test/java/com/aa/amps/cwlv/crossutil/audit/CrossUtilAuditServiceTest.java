package com.aa.amps.cwlv.crossutil.audit;

import com.aa.amps.cwlv.exception.CrossUtilAuditException;
import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Created by Neelabh Tripathi(847697) on 6/19/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CrossUtilAuditServiceTest {

    @Autowired
    private CrossUtilAuditService crossUtilAuditService;

    @MockBean
    private CrossUtilAuditRepository crossUtilAuditRepository;

    @Test
    public void audit_Success() {
        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setMntncStnCode("DFW");
        recordToAudit.setActiveFlag('Y');
        recordToAudit.setCrossUtilFlag('Y');
        recordToAudit.setRodCapacity(400L);
        recordToAudit.setRonCapacity(900L);
        recordToAudit.setUserId("847697");

        given(crossUtilAuditRepository.addAuditRecord(recordToAudit)).willReturn(1);

        boolean auditResult = crossUtilAuditService.audit(recordToAudit);

        assertThat(auditResult).isTrue();
    }

    @Test
    public void audit_Success_StnCodeAndUserIdOnly() {
        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setMntncStnCode("DFW");
        recordToAudit.setUserId("847697");

        given(crossUtilAuditRepository.addAuditRecord(recordToAudit)).willReturn(1);

        boolean auditResult = crossUtilAuditService.audit(recordToAudit);

        assertThat(auditResult).isTrue();
    }

    @Test(expected = CrossUtilAuditException.class)
    public void audit_MissingUserId() {
        String exceptionMessage = "Either station code or User Id or both not provided";

        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setMntncStnCode("DFW");
        recordToAudit.setActiveFlag('Y');
        recordToAudit.setCrossUtilFlag('Y');
        recordToAudit.setRodCapacity(400L);
        recordToAudit.setRonCapacity(900L);

        try {
            crossUtilAuditService.audit(recordToAudit);
        } catch (CrossUtilAuditException ex) {
            assertThat(ex).isNotNull();
            assertThat(ex.getMessage()).isNotBlank().isEqualToIgnoringCase(exceptionMessage);

            throw ex; //making sure the exception is thrown as it is expected for this scenario.
        }
    }

    @Test(expected = CrossUtilAuditException.class)
    public void audit_MissingStationCode() {
        String exceptionMessage = "Either station code or User Id or both not provided";

        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setActiveFlag('Y');
        recordToAudit.setCrossUtilFlag('Y');
        recordToAudit.setRodCapacity(400L);
        recordToAudit.setRonCapacity(900L);
        recordToAudit.setUserId("847697");

        try {
            crossUtilAuditService.audit(recordToAudit);
        } catch (CrossUtilAuditException ex) {
            assertThat(ex).isNotNull();
            assertThat(ex.getMessage()).isNotBlank().isEqualToIgnoringCase(exceptionMessage);

            throw ex; //making sure the exception is thrown as it is expected for this scenario.
        }
    }

    @Test(expected = CrossUtilAuditException.class)
    public void audit_NullRecord() {
        String exceptionMessage = "Exception while auditing the cross util transaction. Null record received";

        CrossUtilEntity recordToAudit = null;

        try {
            crossUtilAuditService.audit(recordToAudit);
        } catch (CrossUtilAuditException ex) {
            assertThat(ex).isNotNull();
            assertThat(ex.getMessage()).isNotBlank().isEqualToIgnoringCase(exceptionMessage);

            throw ex; //making sure the exception is thrown as it is expected for this scenario.
        }
    }
}
