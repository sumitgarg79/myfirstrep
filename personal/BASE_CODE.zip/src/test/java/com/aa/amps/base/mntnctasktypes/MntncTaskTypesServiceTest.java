package com.aa.amps.base.mntnctasktypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * @author 842019
 * @since 5/22/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MntncTaskTypesServiceTest {
    @Autowired
    private MntncTaskTypesService mntncTaskTypesService;

    private List<MntncTaskTypeEntity> mntncTaskTypeEntityList;

    @MockBean
    private MntncTaskTypeRepository mntncTaskTypeRepository;

    @Before
    public void setUp() {
        mntncTaskTypeEntityList = new ArrayList<>();
        MntncTaskTypeEntity lineBase = new MntncTaskTypeEntity();
        lineBase.setAcftMntncTaskType("CDL");
        lineBase.setAcftMntncTaskType("ESI");
        lineBase.setAcftMntncTaskType("ME8-M");
        lineBase.setAcftMntncTaskType("ME8-TC");
        lineBase.setAcftMntncTaskType("ME8-EO");
        lineBase.setAcftMntncTaskType("ME8-CKC");

        MntncTaskTypeEntity line = new MntncTaskTypeEntity();
        line.setAcftMntncTaskType("CDL");
        line.setAcftMntncTaskType("ESI");

        mntncTaskTypeEntityList.add(lineBase);

    }

    @Test
    public void getAllMaintenanceTaskTypes() {
        String appType = "";
        given(this.mntncTaskTypeRepository.getAllMntncTaskTypes(appType)).willReturn(mntncTaskTypeEntityList);
        List<MntncTaskTypeEntity> result = mntncTaskTypesService.getMaintenanceTaskTypes(appType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAcftMntncTaskType()).isEqualToIgnoringCase("ME8-CKC");
    }

    @Test
    public void getLineBaseMaintenanceTaskTypes() {
        String appType = "LB";
        given(this.mntncTaskTypeRepository.getAllMntncTaskTypes(appType)).willReturn(mntncTaskTypeEntityList);
        List<MntncTaskTypeEntity> result = mntncTaskTypesService.getMaintenanceTaskTypes(appType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAcftMntncTaskType()).isEqualToIgnoringCase("ME8-CKC");
    }

    @Test
    public void getBaseMaintenanceTaskTypes() {
        String appType = "B";
        given(this.mntncTaskTypeRepository.getAllMntncTaskTypes(appType)).willReturn(mntncTaskTypeEntityList);
        List<MntncTaskTypeEntity> result = mntncTaskTypesService.getMaintenanceTaskTypes(appType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAcftMntncTaskType()).isEqualToIgnoringCase("ME8-CKC");
    }
}