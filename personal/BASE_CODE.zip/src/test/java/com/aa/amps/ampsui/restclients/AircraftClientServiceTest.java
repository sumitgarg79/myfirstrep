package com.aa.amps.ampsui.restclients;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Unit test class for {@link AircraftClientService}.
 *
 * @author Neelabh Tripathi
 * @since 04/18/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class AircraftClientServiceTest {

    @Value("${ampsui.aircraft.api.url}")
    private String aircraftApiUrl;

    @Autowired
    private AircraftClientService aircraftClientService;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void init() {
        mockServer = MockRestServiceServer.createServer(aircraftClientService.getRestTemplate());
    }

    private List<AircraftResponseEntity> getAircraftData() {
        AircraftResponseEntity aircraft1 = new AircraftResponseEntity();
        aircraft1.setAircraftNumber("3AB");
        aircraft1.setAirlineCode("LAA");
        aircraft1.setFleet("737");
        aircraft1.setSubfleet("737-200");

        AircraftResponseEntity aircraft2 = new AircraftResponseEntity();
        aircraft2.setAircraftNumber("3AH");
        aircraft2.setAirlineCode("LAA");
        aircraft2.setFleet("737");
        aircraft2.setSubfleet("737-300");

        List<AircraftResponseEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);
        aircraftData.add(aircraft2);

        return aircraftData;
    }

    @Test
    public void getAllAircraft() throws URISyntaxException, JsonProcessingException {
        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftApiUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(getAircraftData()))
                );

        List<AircraftResponseEntity> aircraftEntities = aircraftClientService.getAllAircraft();

        mockServer.verify();

        assertThat(aircraftEntities).isNotEmpty().hasSize(2);
        assertThat(aircraftEntities.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AB");
        assertThat(aircraftEntities.get(1).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AH");
    }


    @Test
    public void getAllAircraft_NullResponseBody() throws URISyntaxException, JsonProcessingException {
        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftApiUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(null))
                );

        List<AircraftResponseEntity> aircraftEntities = aircraftClientService.getAllAircraft();

        mockServer.verify();

        assertThat(aircraftEntities).isEmpty();

    }


    @Test
    public void getAircraft() throws URISyntaxException, JsonProcessingException {
        final String AIRLINE_LAA = "LAA";
        String aircraftUrlWithAirline = aircraftApiUrl + "?airlineCd=" + AIRLINE_LAA;

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftUrlWithAirline)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(getAircraftData()))
                );

        List<AircraftResponseEntity> aircraftEntities = aircraftClientService.getAircraft(AIRLINE_LAA);

        mockServer.verify();

        assertThat(aircraftEntities).isNotEmpty().hasSize(2);
        assertThat(aircraftEntities.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AB");
        assertThat(aircraftEntities.get(1).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AH");
    }


    @Test
    public void getAircraft_NullResponseBody() throws URISyntaxException, JsonProcessingException {
        final String AIRLINE_LAA = "LAA";
        String aircraftUrlWithAirline = aircraftApiUrl + "?airlineCd=" + AIRLINE_LAA;

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftUrlWithAirline)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(null))
                );

        List<AircraftResponseEntity> aircraftEntities = aircraftClientService.getAircraft(AIRLINE_LAA);

        mockServer.verify();

        assertThat(aircraftEntities).isEmpty();
    }
}