package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpServerErrorException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link CwlController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/25/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CwlControllerTest {

    List<CombinedTaskDetail> combinedTaskDetails;
    CompletableFuture<List<StationCapacitySummary>> future;
    List<StationCapacitySummary> stnCapList;

    @Autowired
    private CwlController cwlController;

    @MockBean
    private CombinedWorkLoadService combinedWrkLdSvc;

    @MockBean
    private StationCapacitySummaryService stnCapSummService;

    @Before
    public void setUp() {
        StationCapacitySummary o1 = new StationCapacitySummary();
        o1.setStation("DFW");

        StationCapacitySummary o2 = new StationCapacitySummary();
        o2.setStation("CLT");

        stnCapList = new ArrayList<>();
        stnCapList.add(o1);
        stnCapList.add(o2);

        future = CompletableFuture.completedFuture(stnCapList);

        CombinedTaskDetail c1 = new CombinedTaskDetail();
        c1.setStnCd("DFW");

        CombinedTaskDetail c2 = new CombinedTaskDetail();
        c2.setStnCd("CLT");

        combinedTaskDetails = new ArrayList<>();
        combinedTaskDetails.add(c1);
        combinedTaskDetails.add(c2);
    }

    @Test
    public void greetingMessage() {
        Map<String, String> result = cwlController.greetingMessage();

        assertThat(result).isNotNull().isNotEmpty();
        assertThat(result).hasSize(2);
        assertThat(result.get("name")).isEqualTo("AMPS-CWL");
    }

    @Test
    public void getCwlReport() {
        FilterRequest request = new FilterRequest();
        request.setFromDate("05/31/2018");
        request.setToDate("05/31/2018");

        given(combinedWrkLdSvc.getCombinedWorkLoadTasksDetails(new HashMap<String, Object>())).willReturn
            (combinedTaskDetails);

        given(stnCapSummService.getStationCapacitySumm(Mockito.anyMap())).willReturn(stnCapList);

        CwlGridResponse result = cwlController.getCwlReport(new FilterRequest());

        assertThat(result).isNotNull();
        assertThat(result.getCwlvTaskDetailGrid()).hasSize(2);
        assertThat(result.getCwlvTaskDetailGrid().get(0).getStnCd()).isEqualTo("DFW");

        //TODO Neelabh - This need to be uncommented after debugging why stnCapSummService.getStationCapacitySumm is
        // not mocked
        /*assertThat(result.getCwlvStnCapGrid()).hasSize(2);
        assertThat(result.getCwlvStnCapGrid().get(0).getStation()).isEqualTo("DFW");*/
    }

    /**
     * In this test case we are confirming if from date and to date are different then station capacity grid data should
     * be empty.
     */
    @Test
    public void getCwlReport_DiffToAndFromDate() {
        List<String> stnInput = new ArrayList<>();
        stnInput.add("DFW");
        stnInput.add("CLT");

        FilterRequest request = new FilterRequest();
        request.setFromDate("05/31/2018");
        request.setToDate("06/04/2018");


        given(combinedWrkLdSvc.getCombinedWorkLoadTasksDetails(new HashMap<String, Object>())).willReturn
            (combinedTaskDetails);
        given(stnCapSummService.getStationCapacitySumm(Mockito.anyMap())).willReturn(stnCapList);

        CwlGridResponse result = cwlController.getCwlReport(request);

        assertThat(result).isNotNull();
        assertThat(result.getCwlvStnCapGrid()).hasSize(0);
    }

    @Test
    public void getCwlReport_HttpServerErrorExceptionTest() {
        HttpServerErrorException exception = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);

        given(stnCapSummService.getStationCapacitySumm(Mockito.anyMap())).willThrow(exception);
        given(combinedWrkLdSvc.getCombinedWorkLoadTasksDetails(new HashMap<String, Object>())).willReturn
            (combinedTaskDetails);

        CwlGridResponse result = cwlController.getCwlReport(new FilterRequest());

        assertThat(result).isNotNull();
        assertThat(result.getCwlvTaskDetailGrid()).hasSize(2);
        assertThat(result.getCwlvTaskDetailGrid().get(0).getStnCd()).isEqualTo("DFW");

        assertThat(result.getCwlvStnCapGrid()).hasSize(0);
    }

    @Test
    public void getCwlReport_ExceptionTest() {
        NullPointerException exception = new NullPointerException(); // A child of class Exception.

        given(stnCapSummService.getStationCapacitySumm(Mockito.anyMap())).willThrow(exception);
        given(combinedWrkLdSvc.getCombinedWorkLoadTasksDetails(new HashMap<String, Object>())).willReturn
            (combinedTaskDetails);

        CwlGridResponse result = cwlController.getCwlReport(new FilterRequest());

        assertThat(result).isNotNull();
        assertThat(result.getCwlvTaskDetailGrid()).hasSize(2);
        assertThat(result.getCwlvTaskDetailGrid().get(0).getStnCd()).isEqualTo("DFW");

        assertThat(result.getCwlvStnCapGrid()).hasSize(0);
    }
}
