package com.aa.amps.sharedapi.aircraft;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link AircraftRepository}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/3/2019.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AircraftRepositoryTest {

    @Autowired
    private AircraftRepository aircraftRepository;

    @Test
    public void getAllAircraftDetails() {
        List<AircraftEntity> aircraftDetails = aircraftRepository.getAllAircraftDetails();

        assertThat(aircraftDetails).isNotNull().isNotEmpty().hasSize(6);
        assertThat(aircraftDetails.get(0).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("161");
        assertThat(aircraftDetails.get(0).getFleet()).isNotEmpty().isEqualToIgnoringCase("321");
        assertThat(aircraftDetails.get(0).getSubfleet()).isNotEmpty().isEqualToIgnoringCase("321");
        assertThat(aircraftDetails.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase("LUS");
        assertThat(aircraftDetails.get(0).getSceptreFleetCode()).isNotEmpty().isEqualToIgnoringCase("29");
    }
}
