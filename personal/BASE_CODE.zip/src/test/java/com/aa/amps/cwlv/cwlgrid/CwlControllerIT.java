package com.aa.amps.cwlv.cwlgrid;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Test class for {@link CwlController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/29/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class CwlControllerIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                                                  MediaType.APPLICATION_JSON.getSubtype(),
                                                  Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
            .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
            .findAny()
            .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                      this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void getCwlvGridDetails() throws Exception {
        FilterRequest request = new FilterRequest();

        //TODO Neelabh: below request data needs to change once TEST DB is setup for this functionality.
        request.setFromDate("05/29/2018");
        request.setToDate("05/29/2018");

        String requestJson = json(request);

        mockMvc.perform(post("/cwlv")
            .contentType(contentType)
            .content(requestJson))
            .andExpect(status().isOk());
    }

    /**
     * In this test we are verifying if input Station list is empty then station capacity data in response is empty.
     *
     * @throws Exception if there is any error while making POST call
     */
    @Test
    public void getCwlvGridDetails_EmptyStnList() throws Exception {
        FilterRequest request = new FilterRequest();

        request.setFromDate("05/29/2018");
        request.setToDate("05/29/2018");

        String requestJson = json(request);

        mockMvc.perform(post("/cwlv")
                            .contentType(contentType)
                            .content(requestJson))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.cwlvStnCapGrid", notNullValue()))
            .andExpect(jsonPath("$.cwlvStnCapGrid", hasSize(0)));
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
            o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }
}
