package com.aa.amps.cwlv.accessControl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test Class for AccessController
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AccessControllerTest {

    @Autowired
    private AccessController accessController;

    @MockBean
    private AccessControlService accessControlService;

    private String appList;
    private String roleAppAccess;
    private int roleId = 1;

    @Before
    public void setUp() {
        appList = "[{\"text\":\"AMPS CWLV\",\"url\":\"cwlv\"}]";
        roleAppAccess = "[{\"text\":\"BASE_PLANNER\",\"items\":[{\"text\":\"CLWV\",\"state\":\"enabled\",\"items\":[{\"text\":\"clwv-tab\",\"state\":\"enabled\",\"items\":[{\"text\":\"filter-panel\",\"state\":\"enabled\",\"items\":[{\"text\":\"cwvFilterAircraftCtrl\",\"state\":\"disabled\"}]}]}]}]}]";
    }

    @Test
    public void getAppList() throws Exception {
        given(this.accessControlService.getAppList(roleId)).willReturn(appList);
        String result = accessController.getAppList(roleId);
        assertThat(result).isNotNull();
        assertThat(result.contains("AMPS CWLV")).isTrue();
    }

    @Test
    public void getRoleAccess() throws Exception {
        String appName = "CWLV";
        given(this.accessControlService.getRoleAccess(roleId, appName)).willReturn(roleAppAccess);
        String result = accessController.getRoleAccess(roleId, appName);
        assertThat(result).isNotNull();
        assertThat(result.contains("BASE_PLANNER")).isTrue();
    }
}