package com.aa.amps.base.util;

import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

/**
 * Created by Neelabh Tripathi(847697) on 9/6/2018.
 */
public class DateUtilTest {

    @Test
    public void getDateFromString() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString("09/06/2018");

        Date inputDate = dateResult.get();
        LocalDate date = inputDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        assertThat(date.getDayOfMonth()).isEqualTo(6);
        assertThat(date.getMonth()).isEqualTo(Month.SEPTEMBER);
        assertThat(date.getYear()).isEqualTo(2018);
    }

    @Test
    public void getDateFromString_NullInput() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString(null);

        assertThat(dateResult).isNotNull();
        assertThat(dateResult.isPresent()).isFalse();
    }

    @Test
    public void getDateFromString_EmptyInput() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString("");

        assertThat(dateResult).isNotNull();
        assertThat(dateResult.isPresent()).isFalse();
    }

    @Test
    public void getFormattedDate() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString("09/06/2018");
        String formattedDate = DateUtil.getFormattedDate(dateResult.get(), "dd-MMM-YYYY", true);

        assertThat(formattedDate).isNotEmpty();
        assertThat(formattedDate).isEqualTo("06-SEP-2018");
    }

    @Test
    public void getFormattedDate_Lowercase() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString("09/06/2018");
        String formattedDate = DateUtil.getFormattedDate(dateResult.get(), "dd-MMM-YYYY", false);

        assertThat(formattedDate).isNotEmpty();
        assertThat(formattedDate).isEqualTo("06-Sep-2018");
    }

    @Test
    public void getFormattedDate_NullDate() throws ParseException {
        String formattedDate = DateUtil.getFormattedDate(null, "dd-MMM-YYYY", true);

        assertThat(formattedDate).isEmpty();
    }

    @Test
    public void getFormattedDate_NullRequiredFormat() throws ParseException {
        Optional<Date> dateResult = DateUtil.getDateFromString("09/06/2018");
        String formattedDate = DateUtil.getFormattedDate(dateResult.get(), null, true);

        assertThat(formattedDate).isEmpty();
    }

    @Test
    public void isFirstDateAfterSecond() throws ParseException {
        boolean result = DateUtil.isFirstDateAfterSecond("09/11/2018", "09/10/2018");

        assertThat(result).isTrue();
    }

    @Test
    public void isFirstDateAfterSecond_FirstDateBeforeSecond() throws ParseException {
        boolean result = DateUtil.isFirstDateAfterSecond("09/09/2018", "09/10/2018");

        assertThat(result).isFalse();
    }

    @Test
    public void isFirstDateAfterSecond_NullInput() throws ParseException {
        boolean result = DateUtil.isFirstDateAfterSecond(null, null);

        assertThat(result).isFalse();
    }

    @Test
    public void isFirstDateAfterSecond_EmptyInput() throws ParseException {
        boolean result = DateUtil.isFirstDateAfterSecond(null, null);

        assertThat(result).isFalse();
    }

    @Test
    public void getCurrentDateAsString() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy");

        String currDateFromUtil = DateUtil.getCurrentDateAsString();
        String currDate = simpleDateFormat.format(new Date());

        assertThat(currDateFromUtil).isNotEmpty();
        assertThat(currDateFromUtil).isEqualToIgnoringCase(currDate);
    }

    @Test
    public void getNumberOfDaysFromTodayTest() {
        // set up String containing todaysDate plus 6
        String currentDate = DateUtil.getCurrentDateAsString();
        LocalDate today = LocalDate.now();
        LocalDate todayPlusSix = today.plus(6, ChronoUnit.DAYS);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        String stringTodayPlusSix = todayPlusSix.format(formatter);

        // call util method to determine how many (forecast) days to go
        Long diff = DateUtil.getNumberOfDaysFromToday(stringTodayPlusSix);
        assertEquals(diff, new Long(6));
    }
}
