package com.aa.amps.ampsui.yieldmanagement;

import com.aa.amps.ampsui.yieldmangement.YieldManagement;
import com.aa.amps.ampsui.yieldmangement.YieldManagementRequest;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for yield management api.
 *
 * @author Thanuja
 * @since 5/16/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class YieldManagementIT {

    private static final Logger LOGGER = LoggerFactory.getLogger(YieldManagementIT.class);

    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

    private MediaType contentTypeText = new MediaType(MediaType.TEXT_PLAIN.getType(),
            MediaType.TEXT_PLAIN.getSubtype(),
            Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

    @Test
    @Ignore
    public void getLAAYieldManagementList() throws Exception {

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");

        String yieldRequestJson = json(yieldRequest);

        MvcResult result = mockMvc
                .perform(post("/yield")
                        .contentType(contentType)
                        .content(yieldRequestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue())).andReturn();

        LOGGER.trace("getting LAA yield management data - result json - {}", result.getResponse().getContentAsString());
    }

    @Test
    @Ignore
    public void getLUSYieldManagementList() throws Exception {

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");

        String yieldRequestJson = json(yieldRequest);

        MvcResult result = mockMvc
                .perform(post("/yield")
                        .contentType(contentType)
                        .content(yieldRequestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue())).andReturn();

        LOGGER.trace("getting LUS yield management data - result json - {}", result.getResponse().getContentAsString());
    }

    @Test
    @Ignore
    public void saveLAAYieldManagementList() throws Exception {

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        List<YieldManagement> yieldList = new ArrayList<>();
        yieldRequest.setAirlineCode("AA");
        YieldManagement yield = new YieldManagement();
        yield.setBlueVal("405");
        yield.setRedVal("102");
        yield.setGreenVal("203");
        yield.setFleetCode("S80");
        yield.setSubFleetCode("S801");
        yield.setYieldFrom("23");
        yield.setYieldTo("45");
        yield.setUserId("259891");
        yieldList.add(yield);
        yieldRequest.setYieldManagementList(yieldList);
        String yieldRequestJson = json(yieldRequest);
        MvcResult result = mockMvc
                .perform(post("/yield/save")
                        .contentType(contentType)
                        .content(yieldRequestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentTypeText))
                .andExpect(content().string("Request Processed Successfully")).andReturn();

        LOGGER.trace("saving LAA yield management data - result text  {}", result.getResponse().getContentAsString());

    }

    @Test
    @Ignore
    public void saveLUSYieldManagementList() throws Exception {

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        List<YieldManagement> yieldLusList = new ArrayList<>();
        YieldManagement lusYield = new YieldManagement();
        lusYield.setBlueVal("44");
        lusYield.setRedVal("9");
        lusYield.setGreenVal("213");
        lusYield.setFleetCode("ZZ");
        lusYield.setSubFleetCode("ZZ_100");
        lusYield.setYieldFrom("80");
        lusYield.setYieldTo("90");
        lusYield.setUserId("259891");
        lusYield.setAircftTypeEqpCode("27");
        yieldRequest.setSmSession("1111");
        yieldLusList.add(lusYield);
        yieldRequest.setYieldManagementList(yieldLusList);
        String yieldRequestJson = json(yieldRequest);
        MvcResult result = mockMvc
                .perform(post("/yield/save")
                        .contentType(contentType)
                        .content(yieldRequestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentTypeText))
                .andExpect(content().string("Request Processed Successfully")).andReturn();

        LOGGER.trace("saving LUS yield management data - result text - {}", result.getResponse().getContentAsString());
    }
}
