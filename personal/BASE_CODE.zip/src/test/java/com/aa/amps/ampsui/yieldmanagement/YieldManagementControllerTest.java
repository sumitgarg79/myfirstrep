package com.aa.amps.ampsui.yieldmanagement;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.Constants;
import com.aa.amps.ampsui.yieldmangement.YieldManagement;
import com.aa.amps.ampsui.yieldmangement.YieldManagementController;
import com.aa.amps.ampsui.yieldmangement.YieldManagementRequest;
import com.aa.amps.ampsui.yieldmangement.YieldManagementService;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.BDDMockito.given;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for YieldManagementController.
 *
 * @author Thanuja
 * @since 5/15/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class YieldManagementControllerTest {

    @Autowired
    private YieldManagementController yieldManagementController;

    @MockBean
    private YieldManagementService yieldManagementService;

    private static List<YieldManagement> getLAAYieldData() {

        List<YieldManagement> yieldList = new ArrayList<>();
        YieldManagement yield = new YieldManagement();
        yield.setBlueVal("405");
        yield.setRedVal("102");
        yield.setGreenVal("203");
        yield.setFleetCode("S80");
        yield.setSubFleetCode("S801");
        yield.setYieldFrom("23");
        yield.setYieldTo("45");
        yield.setUserId("967618");
        yieldList.add(yield);

        return yieldList;
    }

    private static List<YieldManagement> getLUSYieldData() {
        List<YieldManagement> yieldLusList = new ArrayList<>();
        YieldManagement lusYield = new YieldManagement();
        lusYield.setBlueVal("44");
        lusYield.setRedVal("9");
        lusYield.setGreenVal("213");
        lusYield.setFleetCode("737");
        lusYield.setSubFleetCode("737k");
        lusYield.setYieldFrom("80");
        lusYield.setYieldTo("90");
        lusYield.setUserId("967618");
        lusYield.setAircftTypeEqpCode("27");
        yieldLusList.add(lusYield);
        return yieldLusList;
    }

    private Map<String, String> getResponseMap() {

        Map<String, String> responseMap = new HashMap<>();
        responseMap.put(Constants.STATUS, Constants.RES_SUCCESS);

        return responseMap;
    }

    @Test
    public void getLAAYieldList() {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");

        given(yieldManagementService.getYieldManagementList(yieldRequest)).willReturn(getLAAYieldData());

        List<YieldManagement> yieldList = yieldManagementController.getYieldManagementList(yieldRequest);

        assertThat(yieldList).isNotNull().isNotEmpty().hasSize(1);
        assertThat(yieldList.get(0).getYieldTo()).isNotBlank().isEqualToIgnoringCase("45");
    }

    @Test
    public void getLUSYieldList() {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        given(yieldManagementService.getYieldManagementList(yieldRequest)).willReturn(getLUSYieldData());
        List<YieldManagement> yieldList = yieldManagementController.getYieldManagementList(yieldRequest);
        assertThat(yieldList).isNotNull().isNotEmpty().hasSize(1);
        assertThat(yieldList.get(0).getYieldFrom()).isNotBlank().isEqualToIgnoringCase("80");
    }

    @Test
    public void saveLUSYieldData() throws AmpsuiServiceException {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        yieldRequest.setYieldManagementList(getLUSYieldData());

        given(yieldManagementService.saveYieldManagementData(yieldRequest)).willReturn(getResponseMap());
        Map<String, String> responseMap = yieldManagementController.saveYieldMngmtData(yieldRequest);

        Assert.assertEquals(Constants.RES_SUCCESS, responseMap.get(Constants.STATUS));
    }

    @Test
    public void saveLAAYieldData() throws AmpsuiServiceException {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");
        yieldRequest.setYieldManagementList(getLAAYieldData());

        given(yieldManagementService.saveYieldManagementData(yieldRequest)).willReturn(getResponseMap());
        Map<String, String> responseMap = yieldManagementController.saveYieldMngmtData(yieldRequest);

        Assert.assertEquals(Constants.RES_SUCCESS, responseMap.get(Constants.STATUS));
    }

    @Test
    public void deleteLUSYieldData() throws AmpsuiServiceException {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        yieldRequest.setYieldManagementList(getLUSYieldData());

        given(yieldManagementService.deleteYieldManagementData(yieldRequest)).willReturn(getResponseMap());
        Map<String, String> responseMap = yieldManagementController.deleteYieldMngmtData(yieldRequest);

        Assert.assertEquals(Constants.RES_SUCCESS, responseMap.get(Constants.STATUS));
    }

    @Test
    public void deleteLAAYieldData() throws AmpsuiServiceException {
        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");
        yieldRequest.setYieldManagementList(getLAAYieldData());

        given(yieldManagementService.deleteYieldManagementData(yieldRequest)).willReturn(getResponseMap());
        Map<String, String> responseMap = yieldManagementController.deleteYieldMngmtData(yieldRequest);

        Assert.assertEquals(Constants.RES_SUCCESS, responseMap.get(Constants.STATUS));
    }

}
