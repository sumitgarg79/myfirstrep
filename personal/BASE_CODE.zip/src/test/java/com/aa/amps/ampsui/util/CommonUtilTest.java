package com.aa.amps.ampsui.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit test class for {@link CommonUtil}.
 *
 * @author Ramesh Rudra
 * @since 08/16/2019
 */
public class CommonUtilTest {


    @Test
    public void shortenUserIdTo6Characters_Success() {
        String USER_ID = "00842020";
        String result = CommonUtil.shortenUserIdTo6Characters(USER_ID);
        assertThat(result).isNotEmpty().hasSize(6);
        assertThat(result).isEqualToIgnoringCase("842020");

    }

}