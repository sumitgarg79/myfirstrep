package com.aa.amps.cwlv.cwlgrid.lus;

import com.aa.amps.cwlv.exception.TaskRepositoryException;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.util.Constants;
import org.junit.After;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Test class for {@code LUSTaskRepository}. The @FixMethodOrder(MethodSorters.NAME_ASCENDING)
 * annotation on this class makes sure that the test cases are executed in lexicographic order of their name.
 *
 * @author Naseer Mohammed(842018)
 * @since 4/24/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class LUSTaskRepositoryTest {
    private static final String MNTNC_ID = "0058457";

    private static final String PLANNED_DATE = "04/24/2018";

    @Autowired
    @Qualifier("namedJdbcTemplate")
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    private LUSTaskRepository lusTaskRepository;
    private Map<String, Object> searchCriteria;

    @Before
    public void setUp() {
        lusTaskRepository = new LUSTaskRepository(namedJdbcTemplate);
        searchCriteria = new HashMap<>();
    }

    @Test(expected = TaskRepositoryException.class)
    public void nullSearchCriteria() {
        lusTaskRepository.getCombinedTasksDetails(null);
    }

    @Test(expected = TaskRepositoryException.class)
    public void emptySearchCriteria() {
        lusTaskRepository.getCombinedTasksDetails(new HashMap<>());
    }

    @Test
    public void srchCriteriaWithMissingFromDate() {
        try {
            searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
            lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        } catch (TaskRepositoryException ex) {
            assertEquals("Repository Exception for Planned Date missing ", TaskRepositoryException.PLANNED_DATE_MISSING, ex.getMessage());
        }
    }

    @Test
    public void srchCriteriaWithMissingToDate() {
        try {
            searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
            lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        } catch (TaskRepositoryException ex) {
            assertEquals("Repository Exception for Planned Date missing ", TaskRepositoryException.PLANNED_DATE_MISSING, ex.getMessage());
        }
    }

    @Test
    public void srchCriteriaWithToDateFromDate() {
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithAircraft() {
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithAllOptions() {
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, "");
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithRON() {
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, Constants.RON); //Testing with RON
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithROD() {
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, Constants.ROD); //Testing with ROD
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithRonRodALL() {
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, Constants.ALL); //Testing with ALL
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithMntncID() {
        String[] types = {"2"};
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, Constants.ALL); //Testing with ALL
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.MNTNC_TYPE, Arrays.asList(types));
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @Test
    public void srchCriteriaWithTaskDesc() {
        String[] types = {"3"};
        searchCriteria.put(Constants.STATION_PLANNED, "DFW");
        searchCriteria.put(Constants.MNTNC_ID, MNTNC_ID);
        searchCriteria.put(Constants.ROD_RON, Constants.ALL); //Testing with ALL
        searchCriteria.put(Constants.FLEET_CODE, "737");
        searchCriteria.put(Constants.STATUS_PLANNED, "true");
        searchCriteria.put(Constants.AIRCRAFT_NO, "062");
        searchCriteria.put(Constants.MNTNC_TYPE, Arrays.asList(types));
        searchCriteria.put(Constants.TASK_KEYWORD, "CKC");
        searchCriteria.put(Constants.PLANNED_DATE_TO, PLANNED_DATE);
        searchCriteria.put(Constants.PLANNED_DATE_FROM, PLANNED_DATE);
        List<CombinedTaskDetail> taskDetailList = lusTaskRepository.getCombinedTasksDetails(searchCriteria);
        assertNotNull(taskDetailList);
        assertThat(taskDetailList.size()).isZero();
    }

    @After
    public void tearDown() {
        namedJdbcTemplate = null;
    }
}
