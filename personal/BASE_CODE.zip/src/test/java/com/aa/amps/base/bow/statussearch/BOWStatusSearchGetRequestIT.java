package com.aa.amps.base.bow.statussearch;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for all the API endpoints defined in class {@link BOWStatusSearchController}.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class BOWStatusSearchGetRequestIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {
        this.mappingJackson2HttpMessageConverter = Arrays.stream(converters)
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

    @Before
    public void setUp() {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void testGetWorkPackage() throws Exception {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("DRAFT");
        searchCriteria.setFromDate("10/07/2018");
        searchCriteria.setToDate("10/07/2018");
        String requestJson = json(searchCriteria);
        mockMvc.perform(post("/base/bow/search" + "/getWorkPackages")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.[0].workPkgId", is(2424)));
    }

    /**
     * Test case for getting work package of given search inputs for visitor role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for visitor role.
     */
    @Test
    public void testGetWorkPackageForVisitor() throws Exception {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setKeyword("TEST");
        searchCriteria.setFromDate("10/05/2018");
        searchCriteria.setToDate("10/05/2018");
        searchCriteria.setUserRole("52");
        String requestJson = json(searchCriteria);
        mockMvc.perform(post("/base/bow/search" + "/getWorkPackages")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.[0].workPkgStatusCd", is("FINALIZED")));
    }

    /**
     * Test case for getting work package of given search inputs for planner role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for planner role.
     */
    @Test
    public void testGetWorkPackageForPlanner() throws Exception {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setKeyword("TEST");
        searchCriteria.setFromDate("10/05/2018");
        searchCriteria.setToDate("10/05/2018");
        searchCriteria.setUserRole("50");
        String requestJson = json(searchCriteria);
        mockMvc.perform(post("/base/bow/search" + "/getWorkPackages")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.[0].workPkgStatusCd", is("FINALIZED")));
    }

    /**
     * Test case for getting work package of given search inputs for checker role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for checker role.
     */
    @Test
    public void testGetWorkPackageForChecker() throws Exception {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setKeyword("TEST");
        searchCriteria.setFromDate("10/05/2018");
        searchCriteria.setToDate("10/05/2018");
        searchCriteria.setUserRole("59");
        String requestJson = json(searchCriteria);
        mockMvc.perform(post("/base/bow/search" + "/getWorkPackages")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.[0].workPkgStatusCd", is("FINALIZED")));
    }
}
