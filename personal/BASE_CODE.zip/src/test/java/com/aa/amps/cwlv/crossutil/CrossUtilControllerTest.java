package com.aa.amps.cwlv.crossutil;

import com.aa.amps.cwlv.util.ServiceResponseMessage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * This the test class for {@code CrossUtilController}.
 *
 * @author Neelabh Tripathi(847697)
 * create on 3/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CrossUtilControllerTest {

    @Autowired
    private CrossUtilController crossUtilController;

    private List<CrossUtilEntity> crossUtilEntitiesResult;

    @MockBean
    private CrossUtilService crossUtilService;

    @Before
    public void setUp() throws Exception {
        crossUtilEntitiesResult = new ArrayList<>();

        CrossUtilEntity ob1 = new CrossUtilEntity();
        CrossUtilEntity ob2 = new CrossUtilEntity();

        ob1.setMntncStnCode("DFW");
        ob2.setMntncStnCode("CLT");

        crossUtilEntitiesResult.add(ob1);
        crossUtilEntitiesResult.add(ob2);
    }

    /**
     * Test case for getCrossUtilDetails. Happy Path scenario.
     */
    @Test
    public void getCrossUtilDetails() {
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntitiesResult);

        List<CrossUtilEntity> result = crossUtilController.getCrossUtilDetails();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getMntncStnCode()).isEqualToIgnoringCase("DFW");
    }

    /**
     * Test case for update method. This tests the success scenario when record is updated.
     */
    @Test
    public void updateCrossUtilRecord_Success() {
        CrossUtilEntity updateRequest = null;
        ServiceResponseMessage mockResponse = ServiceResponseMessage.getUpdateSuccessStatus();

        given(this.crossUtilService.updateCrossUtilRecord(updateRequest)).willReturn(Optional.of(mockResponse));
        ResponseEntity result = crossUtilController.updateCrossUtilRecord(updateRequest);

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }


    /**
     * Test case for update method. This tests the scenario when no record is updated.
     */
    @Test
    public void updateCrossUtilRecord_NoRecordUpdated() {
        CrossUtilEntity updateRequest = null;

        ServiceResponseMessage mockResponse = ServiceResponseMessage.getRecordNotFoundStatusOnly();

        given(this.crossUtilService.updateCrossUtilRecord(updateRequest)).willReturn(Optional.of(mockResponse));
        ResponseEntity result = crossUtilController.updateCrossUtilRecord(updateRequest);

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }


    /**
     * Test case for createStation method. This tests the success scenario when record is updated.
     */
    @Test
    public void createStation_Success() {
        CrossUtilEntity addRequest = null;
        ServiceResponseMessage mockResponse = ServiceResponseMessage.getUpdateSuccessStatus();

        given(this.crossUtilService.addStation(addRequest)).willReturn(Optional.of(mockResponse));
        ResponseEntity result = crossUtilController.createStation(addRequest);

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.ACCEPTED);
    }


    /**
     * Test case for createStation method. This tests the scenario when no record is updated.
     */
    @Test
    public void createStation_NoRecordUpdated() {
        CrossUtilEntity addRequest = null;

        ServiceResponseMessage mockResponse = ServiceResponseMessage.getRecordNotFoundStatusOnly();

        given(this.crossUtilService.updateCrossUtilRecord(addRequest)).willReturn(Optional.of(mockResponse));
        ResponseEntity result = crossUtilController.createStation(addRequest);

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    /**
     * Test case for deleteStation method. This tests the scenario when no record is updated.
     */
    @Test
    public void deleteStation_stationNotFound() {

        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("DFW");
        crossUtilEntity.setCrossUtilFlag('Y');
        crossUtilEntity.setUserId("847697");

        ServiceResponseMessage mockResponse = ServiceResponseMessage.getRecordNotFoundStatusOnly();

        given(this.crossUtilService.deleteStation(crossUtilEntity.getMntncStnCode(), crossUtilEntity.getUserId())).willReturn
            (Optional.of
            (mockResponse));
        given(this.crossUtilService.getStation(crossUtilEntity.getMntncStnCode())).willReturn(crossUtilEntity);

        ResponseEntity result = crossUtilController.deleteStation(crossUtilEntity.getMntncStnCode(), crossUtilEntity
            .getUserId());

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.NO_CONTENT);
    }

    /**
     * Test case for createStation method. This tests the scenario when no record is updated.
     */
    @Test
    public void deleteStation_Success() {

        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("DFW");
        crossUtilEntity.setCrossUtilFlag('Y');
        crossUtilEntity.setUserId("847697");

        ServiceResponseMessage mockResponse = ServiceResponseMessage.getSuccessStatusOnly();

        given(this.crossUtilService.deleteStation(crossUtilEntity.getMntncStnCode(), crossUtilEntity.getUserId())).willReturn
            (Optional.of
            (mockResponse));
        given(this.crossUtilService.getStation(crossUtilEntity.getMntncStnCode())).willReturn(crossUtilEntity);

        ResponseEntity result = crossUtilController.deleteStation(crossUtilEntity.getMntncStnCode(), crossUtilEntity
            .getUserId());

        assertThat(result).isNotNull();
        assertThat(result.getStatusCode()).isEqualTo(HttpStatus.OK);
    }


    /**
     * Test Case for CrossUtilStation method Happy Path Scenario.
     */
    @Test
    public void getCrossUtilStation_Success(){

        List<String> station= Arrays.asList("AUS","BOS","BWI","CLT","DCA","DEN","DFW","DTW","EWR","FLL","IAD","IAH",
                "JFK","LAS","LAX","LGA","MCO","MIA","MSP","ORD","PHX","SEA","SLC","TUL");

        given(this.crossUtilService.getCrossUtilizationStation()).willReturn(station);

        List<String> utilStation = crossUtilController.getCrossUtilStation();

        assertThat(utilStation).isNotNull();
        assertThat(utilStation.size()).isEqualTo(24);

    }

    @Test
    public void getCrossUtilStationsForCwv() {
        List<String> stations = Arrays.asList("DFW", "CLT");

        given(this.crossUtilService.getCrossUtilizationStation()).willReturn(stations);

        List<StationResponse> response = crossUtilController.getCrossUtilStationsForCwv();

        assertThat(response).isNotNull().isNotEmpty();
        assertThat(response.get(0).getText()).isEqualTo("DFW");
        assertThat(response.get(0).isChecked()).isEqualTo(false);
    }

    @Test
    public void healthCheck() {
        List<String> stations = Arrays.asList("DFW", "CLT");

        given(this.crossUtilService.getCrossUtilizationStation()).willReturn(stations);

       String response = crossUtilController.healthCheck();

        assertThat(response).isNotNull().isNotEmpty();
        assertThat(response).isEqualTo("ALL UP");
    }

    @Test
    public void healthCheck_AllDownResponse() {
        List<String> stations = Arrays.asList("DFW", "CLT");

        given(this.crossUtilService.getCrossUtililzionDetails()).willThrow(RuntimeException.class);

        String response = crossUtilController.healthCheck();

        assertThat(response).isNotNull().isNotEmpty();
        assertThat(response).isEqualTo("ALL DOWN");
    }
}
