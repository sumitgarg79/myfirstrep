package com.aa.amps.base.util;

import com.aa.amps.base.util.sysparam.SysParamService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * This the test class for {@link UtilityController}
 *
 * @author HCL (922166)
 * @since 8/29/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class UtilityControllerTest {

    @Autowired
    private UtilityController utilityController;

    @MockBean
    private SysParamService sysParamService;

    private Map<String, String> paramMap;

    @Before
    public void setUp() {
        paramMap = new HashMap<>();
        paramMap.put("PRIORITY_0_REQ", "0");
        paramMap.put("MNTNC_TYPES", " ,RON,BASE");
    }

    @Test
    public void refreshSysParam() {
        given(this.sysParamService.refreshSysParamMap()).willReturn(paramMap);
        Map<String, String> result = utilityController.refreshSysParam();
        assertThat(result).isNotNull();
        assertThat(result.get("PRIORITY_0_REQ")).isEqualToIgnoringCase("0");
    }

    @Test
    public void getSysParam() {
        given(this.sysParamService.refreshSysParamMap()).willReturn(paramMap);
        Map<String, String> result = utilityController.getSysParam();
        assertThat(result).isNotNull();
        assertThat(result.get("PRIORITY_0_REQ")).isEqualToIgnoringCase("0");
    }
}