package com.aa.amps.base.station;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code StationController}.
 *
 * @author HCL(922166)
 * Created on 5/18/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StationControllerTest {

    @Autowired
    private StationController stationController;

    private List<StationEntity> stationEntities;

    private List<StationEntity> baseStationEntities;

    private List<StationEntity> lineStationEntities;

    @MockBean
    private StationService stationControlService;

    @Before
    public void setUp() throws Exception {
        stationEntities = new ArrayList<>();
        baseStationEntities = new ArrayList<>();
        lineStationEntities = new ArrayList<>();

        StationEntity ob1 = new StationEntity();

        ob1.setMntncStnCd("DFW");
        ob1.setMntncStnTypCd("H");
        ob1.setMntncStnAliasCd("DFW");

        stationEntities.add(ob1);
        baseStationEntities.add(ob1);

        StationEntity ob2 = new StationEntity();

        ob2.setMntncStnCd("CLT");
        ob2.setMntncStnTypCd("L");
        ob2.setMntncStnAliasCd("CLT");

        stationEntities.add(ob2);
        lineStationEntities.add(ob2);
    }

    /**
     * Test case for getAllActiveStations. Happy Path scenario.
     */
    @Test
    public void getAllStations() {
        given(this.stationControlService.getAllActiveStations()).willReturn(stationEntities);

        StationResponse result = stationController.getAllActiveStations();
        assertThat(result).isNotNull();
        assertThat(result.getAllStations()).isNotEmpty().hasSize(2);
        assertThat(result.getAllStations().get(0).getMntncStnCd()).isEqualToIgnoringCase("DFW");
    }

    /**
     * Test case to get all the base stations.
     */
    @Test
    public void getActiveStationsForBase() {
        String stationType = "base";
        given(this.stationControlService.getActiveStations(stationType)).willReturn(baseStationEntities);
        StationResponse result = stationController.getActiveStations(stationType);
        assertThat(result).isNotNull();
        assertThat(result.getStationEntityList()).hasSize(1);
        assertThat(result.getStationEntityList().get(0).getMntncStnCd()).isEqualToIgnoringCase("DFW");
    }

    /**
     * Test case to get all the line stations.
     */
    @Test
    public void getActiveStationsForLine() {
        String stationType = "line";
        given(this.stationControlService.getActiveStations(stationType)).willReturn(lineStationEntities);
        StationResponse result = stationController.getActiveStations(stationType);
        assertThat(result).isNotNull();
        assertThat(result.getStationEntityList()).hasSize(1);
        assertThat(result.getStationEntityList().get(0).getMntncStnCd()).isEqualToIgnoringCase("CLT");
    }

    /**
     * Test case to get active stations for input null.
     */
    @Test
    public void getActiveStations_NullInput() {
        StationResponse result = stationController.getActiveStations(null);
        assertThat(result.getStationEntityList()).isNotNull();
        assertThat(result.getStationEntityList()).hasSize(0);
    }

    /**
     * Test case to get active stations for input empty.
     */
    @Test
    public void getActiveStations_EmptyInput() {
        String stationType = "";
        StationResponse result = stationController.getActiveStations(stationType);
        assertThat(result.getStationEntityList()).isNotNull();
        assertThat(result.getStationEntityList()).hasSize(0);
    }

    /**
     * Test case for get All Active Stations with Order Station Type.
     */
    @Test
    public void getAllStations_OrderStnType() {
        given(this.stationControlService.getAllStnOrderStnType()).willReturn(stationEntities);
        StationResponse result = stationController.getAllStnOrderStnType();
        assertThat(result).isNotNull();
        assertThat(result.getAllStations()).isNotEmpty().hasSize(2);
        assertThat(result.getAllStations().get(0).getMntncStnCd()).isEqualToIgnoringCase("DFW");
        assertThat(result.getAllStations().get(1).getMntncStnCd()).isEqualToIgnoringCase("CLT");
    }

}
