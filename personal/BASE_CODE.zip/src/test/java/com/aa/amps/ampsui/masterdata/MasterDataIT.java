package com.aa.amps.ampsui.masterdata;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;


/**
 * Integration test class for Master Data API.
 *
 * @author Neelabh Tripathi
 * @since 04/24/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)//Brings up the tomcat server on 8080.
@ActiveProfiles("test")
public class MasterDataIT {
    private static final Logger LOG = LoggerFactory.getLogger(MasterDataIT.class);

    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                                                  MediaType.APPLICATION_JSON.getSubtype(),
                                                  Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                      this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }


    /**
     * Happy path scenario for ALL data - both LAA and LUS. NOTE: Please check the logs printing the JSON to verify the
     * data being returned from the H2 DB.
     *
     * @throws Exception
     */
    @Test
    public void getMasterData() throws Exception {
        MvcResult result = mockMvc.perform(get("/ampsui/masterdata"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.fleet[0].fleetCode", is("330")))
                .andExpect(jsonPath("$.fleet[0].subfleet[0].subfleetCode", is("29")))
                .andExpect(jsonPath("$.fleet[0].subfleet[0].aircraft[0].aircraftNumber", is("66"))).andReturn();

        LOG.info("getMasterData - result json : {}", result.getResponse().getContentAsString());
    }

    /**
     * Happy path scenario for LAA data. NOTE: Please check the logs printing the JSON to verify the data being returned
     * from the H2 DB.
     *
     * @throws Exception
     */
    @Test
    public void getMasterData_AirlineCodeLAA() throws Exception {
        MvcResult result = mockMvc
                .perform(get("/ampsui/masterdata?airlineCd=LAA"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.fleet[1].fleetCode", is("777")))
                .andExpect(jsonPath("$.fleet[1].subfleet[0].subfleetCode", is("B772")))
                .andExpect(jsonPath("$.fleet[1].subfleet[0].aircraft[0].aircraftNumber", is("7BB"))).andReturn();

        LOG.info("getMasterData_AirlineCodeLAA() - result json - {}", result.getResponse().getContentAsString());
    }

    /**
     * Happy path scenario for LUS data. NOTE: Please check the logs printing the JSON to verify the data being returned
     * from the H2 DB.
     *
     * @throws Exception
     */
    @Test
    public void getMasterData_AirlineCodeLUS() throws Exception {
        MvcResult result = mockMvc
                .perform(get("/ampsui/masterdata?airlineCd=LUS"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.fleet[0].fleetCode", is("330")))
                .andExpect(jsonPath("$.fleet[0].subfleet[0].subfleetCode", is("29")))
                .andExpect(jsonPath("$.fleet[0].subfleet[0].aircraft[0].aircraftNumber", is("66"))).andReturn();

        LOG.info("getMasterData_AirlineCodeLUS() - result json - {}", result.getResponse().getContentAsString());
    }


    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
                o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

}
