package com.aa.amps.ampsui.yieldmanagement;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.Constants;
import com.aa.amps.ampsui.yieldmangement.YieldManagement;
import com.aa.amps.ampsui.yieldmangement.YieldManagementRequest;
import com.aa.amps.ampsui.yieldmangement.YieldManagementService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Test class for YieldManagementService.
 *
 * @author Thanuja
 * @since 5/15/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class YieldManagementServiceTest {

    @Autowired
    private YieldManagementService yieldManagementService;

    @Value("${ampsui.yieldmanagement.api}")
    private String yieldManagementApi;

    @Value("${ampsui.yieldmanagement.api.save}")
    private String yieldManagementSaveAPI;

    @Value("${ampsui.yieldmanagement.api.delete}")
    private String yieldManagementDeleteAPI;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setUp() {
        mockServer = MockRestServiceServer.createServer(yieldManagementService.getRestTemplate());
    }

    private List<YieldManagement> getLAAYieldDataResponse() {

        List<YieldManagement> yieldLAAList = new ArrayList<>();
        YieldManagement yield = new YieldManagement();
        yield.setBlueVal("105");
        yield.setRedVal("102");
        yield.setGreenVal("203");
        yield.setFleetCode("S80");
        yield.setSubFleetCode("S801");
        yield.setYieldFrom("25");
        yield.setYieldTo("45");
        yield.setUserId("967618");
        yieldLAAList.add(yield);

        return yieldLAAList;
    }

    private List<YieldManagement> getLUSYieldDataResponse() {
        List<YieldManagement> yieldLusList = new ArrayList<>();
        YieldManagement lusYield = new YieldManagement();
        lusYield.setBlueVal("99");
        lusYield.setRedVal("9");
        lusYield.setGreenVal("213");
        lusYield.setFleetCode("737");
        lusYield.setSubFleetCode("737k");
        lusYield.setYieldFrom("80");
        lusYield.setYieldTo("90");
        lusYield.setUserId("967618");
        lusYield.setAircftTypeEqpCode("27");
        yieldLusList.add(lusYield);
        return yieldLusList;
    }

    private static List<YieldManagement> getLAAYieldMgmtData() {

        List<YieldManagement> yieldList = new ArrayList<>();
        YieldManagement yield = new YieldManagement();
        yield.setBlueVal("405");
        yield.setRedVal("102");
        yield.setGreenVal("203");
        yield.setFleetCode("S80");
        yield.setSubFleetCode("S801");
        yield.setYieldFrom("23");
        yield.setYieldTo("45");
        yield.setUserId("967618");
        yieldList.add(yield);

        return yieldList;
    }

    private static List<YieldManagement> getLUSYieldMgmtData() {
        List<YieldManagement> yieldLusList = new ArrayList<>();
        YieldManagement lusYield = new YieldManagement();
        lusYield.setBlueVal("44");
        lusYield.setRedVal("9");
        lusYield.setGreenVal("213");
        lusYield.setFleetCode("737");
        lusYield.setSubFleetCode("737k");
        lusYield.setYieldFrom("80");
        lusYield.setYieldTo("90");
        lusYield.setUserId("967618");
        lusYield.setAircftTypeEqpCode("27");
        yieldLusList.add(lusYield);

        return yieldLusList;
    }

    private Map<String, String> getResultMap() {

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put(Constants.STATUS, Constants.RES_SUCCESS);

        return resultMap;
    }

    @Test
    public void getLAAYieldData() throws JsonProcessingException, URISyntaxException {

        String yieldAPIURL = yieldManagementApi + "?airlineCode=AA";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldAPIURL)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getLAAYieldDataResponse())));


        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");

        List<YieldManagement> yieldLAAList = yieldManagementService.getYieldManagementList(yieldRequest);

        mockServer.verify();

        assertThat(yieldLAAList).isNotEmpty().hasSize(1);
        assertThat(yieldLAAList.get(0).getYieldFrom()).isNotBlank().isEqualToIgnoringCase("25");
        assertThat(yieldLAAList.get(0).getYieldTo()).isNotBlank().isEqualToIgnoringCase("45");
    }

    @Test
    public void getLUSYieldData() throws JsonProcessingException, URISyntaxException {
        String yieldAPIURL = yieldManagementApi + "?airlineCode=US";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldAPIURL)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getLUSYieldDataResponse())));

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");

        List<YieldManagement> yieldLUSList = yieldManagementService.getYieldManagementList(yieldRequest);

        mockServer.verify();
        assertThat(yieldLUSList).isNotEmpty().hasSize(1);
        assertThat(yieldLUSList.get(0).getYieldFrom()).isNotBlank().isEqualToIgnoringCase("80");
        assertThat(yieldLUSList.get(0).getYieldTo()).isNotBlank().isEqualToIgnoringCase("90");
    }

    @Test
    public void saveLUSYieldData() throws JsonProcessingException, URISyntaxException, AmpsuiServiceException {
        String yieldSaveAPIURL = yieldManagementSaveAPI + "?airlineCode=US";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldSaveAPIURL)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getResultMap())));

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        yieldRequest.setYieldManagementList(getLUSYieldMgmtData());
        Map<String, String> resultMap = yieldManagementService.saveYieldManagementData(yieldRequest);
        mockServer.verify();
        Assert.assertEquals(Constants.RES_SUCCESS, resultMap.get(Constants.STATUS));
    }

    @Test
    public void saveLAAYieldData() throws JsonProcessingException, URISyntaxException, AmpsuiServiceException {
        String yieldSaveAPIURL = yieldManagementSaveAPI + "?airlineCode=AA";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldSaveAPIURL)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getResultMap())));

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");
        yieldRequest.setYieldManagementList(getLAAYieldMgmtData());
        Map<String, String> resultMap = yieldManagementService.saveYieldManagementData(yieldRequest);
        mockServer.verify();
        Assert.assertEquals(Constants.RES_SUCCESS, resultMap.get(Constants.STATUS));
    }

    @Test
    public void deleteLUSYieldData() throws JsonProcessingException, URISyntaxException, AmpsuiServiceException {
        String yieldDeleteAPIURL = yieldManagementDeleteAPI + "?airlineCode=US";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldDeleteAPIURL)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getResultMap())));

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("US");
        yieldRequest.setYieldManagementList(getLUSYieldMgmtData());
        Map<String, String> resultMap = yieldManagementService.deleteYieldManagementData(yieldRequest);
        mockServer.verify();
        Assert.assertEquals(Constants.RES_SUCCESS, resultMap.get(Constants.STATUS));
    }

    @Test
    public void deleteLAAYieldData() throws JsonProcessingException, URISyntaxException, AmpsuiServiceException {
        String yieldDeleteAPIURL = yieldManagementDeleteAPI + "?airlineCode=AA";
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(yieldDeleteAPIURL)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getResultMap())));

        YieldManagementRequest yieldRequest = new YieldManagementRequest();
        yieldRequest.setAirlineCode("AA");
        yieldRequest.setYieldManagementList(getLAAYieldMgmtData());
        Map<String, String> resultMap = yieldManagementService.deleteYieldManagementData(yieldRequest);
        mockServer.verify();
        Assert.assertEquals(Constants.RES_SUCCESS, resultMap.get(Constants.STATUS));
    }
}
