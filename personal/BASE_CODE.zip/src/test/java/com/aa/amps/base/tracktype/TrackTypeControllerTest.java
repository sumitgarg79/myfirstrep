package com.aa.amps.base.tracktype;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code TrackTypeController}.
 *
 * @author HCL(292147)
 * Created on 5/29/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TrackTypeControllerTest {

    @Autowired
    private TrackTypeController trackTypeController;

    private List<TrackTypeEntity> trackTypeEntities;

    @MockBean
    private TrackTypeService trackTypeService;

    @Before
    public void setUp() {
        trackTypeEntities = new ArrayList<>();
        TrackTypeEntity ob1 = new TrackTypeEntity();

        ob1.setWorkPkgTrackTypCd("03");
        ob1.setWorkPkgTrackTypDesc("Base");
        ob1.setMenuDispInd("T");
        ob1.setBaseWPTrackTypDesc("03 - Base");

        trackTypeEntities.add(ob1);
    }

    /**
     * Test case for getBaseTrackTypes.
     */
    @Test
    public void getBaseTrackTypes() {
        given(this.trackTypeService.getBaseTrackTypes()).willReturn(trackTypeEntities);

        List<TrackTypeEntity> result = trackTypeController.getBaseTrackTypes();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getWorkPkgTrackTypCd()).isEqualToIgnoringCase("03");
    }
}