package com.aa.amps.cwlv.crossutil;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@code CrossUtilRepository}. The @FixMethodOrder(MethodSorters.NAME_ASCENDING)
 * annotation on this class makes sure that the test cases are executed in lexicographic order of their name.
 *
 * @author Neelabh Tripathi(847697)
 * created on 3/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CrossUtilRepositoryTest {
    @Autowired
    @Qualifier("jdbcTemplate")
    JdbcTemplate jdbcTemplate;
    @Autowired
    private CrossUtilRepository crossUtilRepository;

    /**
     * Get all active XUtil records.
     */
    @Test
    public void getAllActiveStations() {
        List<CrossUtilEntity> result = crossUtilRepository.getAllActiveStations();

        assertThat(result).isNotNull();
        assertThat(result.size()).isGreaterThan(1); // We expect more that 1 stations
        assertThat(result.get(0).getMntncStnCode()).isNotEmpty();
        assertThat(result.get(0).getMntncStnCode()).isNotBlank();
    }

    /**
     * This is the test case for covering scenario where no results are returned when we call getAllActiveStations.
     * <b>NOTE:</b> This method is intentionally named as zzz... as we want to execute this method as the last test
     * case.
     * Reason being we have to truncate the table so as to fulfill our scenario. The {@code @FixMethodOrder
     * (MethodSorters.NAME_ASCENDING)}
     * annotation on this class makes sure that the test cases are executed in lexicographic order of their name.
     */
    @Test
    public void zzzGetAllActiveStationsNullResult() {
        truncateXutilTable();

        List<CrossUtilEntity> result = crossUtilRepository.getAllActiveStations();

        assertThat(result).isNotNull();
        assertThat(result.size()).isZero();
    }

    /**
     * Test case for updating an existing station successfully.
     */
    @Test
    public void updateStation_Success() {
        CrossUtilEntity entityToUpdate = new CrossUtilEntity();

        entityToUpdate.setMntncStnCode("DFW");
        entityToUpdate.setCrossUtilFlag('Y');
        entityToUpdate.setRodCapacity(1999L);
        entityToUpdate.setRonCapacity(4999L);

        int updatedRowCount = crossUtilRepository.updateStation(entityToUpdate);

        Optional<CrossUtilEntity> updatedEntity = crossUtilRepository.getStationDetail("DFW");

        assertThat(updatedRowCount).isEqualTo(1); // Exactly 1 row should be updated
        assertThat(updatedEntity.isPresent()).isTrue(); // There should be a non-null response object
        assertThat(updatedEntity.get().getRonCapacity()).isEqualTo(4999L);
        assertThat(updatedEntity.get().getRodCapacity()).isEqualTo(1999L);
    }

    /**
     * Test scenario for update station when station provided is not present in DB.
     */
    @Test
    public void updateStation_StationNotFound() {
        CrossUtilEntity entityToUpdate = new CrossUtilEntity();

        entityToUpdate.setMntncStnCode("ZYX");
        entityToUpdate.setCrossUtilFlag('Y');
        entityToUpdate.setRodCapacity(9999L);
        entityToUpdate.setRonCapacity(8999L);

        int updatedRowCount = crossUtilRepository.updateStation(entityToUpdate);

        Optional<CrossUtilEntity> updatedEntity = crossUtilRepository.getStationDetail("ZYX");

        assertThat(updatedRowCount).isEqualTo(0); // No rows should be updated
        assertThat(updatedEntity.isPresent()).isFalse(); // No object should be present
    }

    /**
     * Test case for null argument passed to the update method.
     */
    @Test
    public void updateStation_NullInputEntity() {
        int updatedRowCount = crossUtilRepository.updateStation(null);

        assertThat(updatedRowCount).isEqualTo(0); // No rows should be updated
    }

    /**
     * Test case for non-null entity but null station.
     */
    @Test
    public void updateStation_NullInputStation() {
        CrossUtilEntity entityToUpdate = new CrossUtilEntity();

        int updatedRowCount = crossUtilRepository.updateStation(entityToUpdate);
        assertThat(updatedRowCount).isEqualTo(0); // No rows should be updated
    }

    /**
     * Test case for getting a station present in the DB.
     */
    @Test
    public void getStationDetail() {
        Optional<CrossUtilEntity> updatedEntity = crossUtilRepository.getStationDetail("DFW");

        assertThat(updatedEntity.isPresent()).isTrue();
    }

    /**
     * Test case for getting a station which is not in DB
     */
    @Test
    public void getStationDetail_StationNotFound() {
        Optional<CrossUtilEntity> updatedEntity = crossUtilRepository.getStationDetail("ZYX");

        assertThat(updatedEntity.isPresent()).isFalse();
    }

    /**
     * Method to TRUNCATE the XUtil table so that we can execute the test case in {@code
     * zzzGetAllActiveStationsNullResult}
     */
    public void truncateXutilTable() {
        boolean trancated = false;
        jdbcTemplate.execute("TRUNCATE TABLE CRSS_UTLZD_STN_CAP");
    }


    /**
     * Test case for adding a station which is not in DB
     */
    @Test
    public void addStation_Success() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("YYZ");
        crossUtilEntity.setRonCapacity(2L);
        crossUtilEntity.setRodCapacity(5L);
        crossUtilEntity.setCrossUtilFlag('Y');

        int count = crossUtilRepository.addStation(crossUtilEntity);

        assertThat(count).isEqualTo(1);
    }

    /**
     * Test case for adding a station Failure
     */
    @Test
    public void addStation_failure() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("");
        int count = crossUtilRepository.addStation(crossUtilEntity);

        assertThat(count).isEqualTo(0);
    }


    /**
     * Test case for adding a station(by making station active Flg True)which is in DB
     */
    @Test
    public void updateAddStation_Success() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("PHX");
        crossUtilEntity.setRonCapacity(2L);
        crossUtilEntity.setRodCapacity(5L);
        crossUtilEntity.setCrossUtilFlag('Y');

        int count = crossUtilRepository.updateStationToActive(crossUtilEntity);

        assertThat(count).isEqualTo(1);
    }

    /**
     * Test case for adding a station in LowerCase(by making station active Flg True)which is in DB
     */
    @Test
    public void updateAddStation_LowerCaseSuccess() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("ord");
        crossUtilEntity.setRonCapacity(2L);
        crossUtilEntity.setRodCapacity(5L);
        crossUtilEntity.setCrossUtilFlag('Y');

        int count = crossUtilRepository.updateStationToActive(crossUtilEntity);

        assertThat(count).isEqualTo(1);
    }

    /**
     * Test case for adding a station by Updating Flag.
     */
    @Test
    public void updateAddStation_failure() {
        CrossUtilEntity updateAddStation = new CrossUtilEntity();

        int count = crossUtilRepository.updateStationToActive(updateAddStation);

        assertThat(count).isEqualTo(0);
    }

    /**
     * Test case for getting single station data HappyPath.
     */
    @Test
    public void getStation_Success() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("DFW");

        CrossUtilEntity result = crossUtilRepository.getStation(crossUtilEntity.getMntncStnCode());

        assertThat(result).isNotEqualTo(null);
        assertThat(result.getMntncStnCode()).isNotNull();
    }

    /**
     * Test case for getting single station data failure scenario.
     */
    @Test
    public void getStation_RecordNotFound() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("123");

        CrossUtilEntity result = crossUtilRepository.getStation(crossUtilEntity.getMntncStnCode());

        assertThat(result).isNotNull();
    }

    /**
     * Test case for station data delete success scenario.
     */
    @Test
    public void deleteStation_Success() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();
        crossUtilEntity.setMntncStnCode("CLT");

        int count = crossUtilRepository.deleteStation(crossUtilEntity.getMntncStnCode());

        assertThat(count).isEqualTo(1);
    }

    /**
     * Test case for getting single station data failure scenario.
     */
    @Test
    public void deleteStation_NullInput() {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();

        int count = crossUtilRepository.deleteStation(crossUtilEntity.getMntncStnCode());

        assertThat(count).isEqualTo(0);
    }

    /**
     * Test Case for getAllStation Repository  HappyPath_Scenario
     */
    @Test
    public void getAllStations_Success(){
        List<String> stations = crossUtilRepository.getAllStations();
        assertThat(stations.size()).isGreaterThan(0);
    }
}
