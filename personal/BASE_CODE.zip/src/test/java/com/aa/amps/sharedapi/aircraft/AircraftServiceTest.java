package com.aa.amps.sharedapi.aircraft;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link AircraftService}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/3/2019.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AircraftServiceTest {

    @Autowired
    AircraftService aircraftService;

    @MockBean
    AircraftRepository aircraftRepository;

    private List<AircraftEntity> getAircraftData() {
        AircraftEntity aircraft1 = new AircraftEntity();
        aircraft1.setAircraftNumber("3AB");
        aircraft1.setAirlineCode("LAA");
        aircraft1.setFleet("737");
        aircraft1.setSubfleet("737-200");

        AircraftEntity aircraft2 = new AircraftEntity();
        aircraft2.setAircraftNumber("971");
        aircraft2.setAirlineCode("LUS");
        aircraft2.setFleet("321");
        aircraft2.setSubfleet("321-E21");

        AircraftEntity aircraft3 = new AircraftEntity();
        aircraft3.setAircraftNumber("3AH");
        aircraft3.setAirlineCode("LAA");
        aircraft3.setFleet("737");
        aircraft3.setSubfleet("737-300");

        List<AircraftEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);
        aircraftData.add(aircraft2);
        aircraftData.add(aircraft3);

        return aircraftData;
    }

    @Test
    public void getAllAircraft() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        List<AircraftEntity> aircraftDetails = aircraftService.getAllAircraft();

        assertThat(aircraftDetails).isNotNull().isNotEmpty().hasSize(3);
        assertThat(aircraftDetails.get(0).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("3AB");
        assertThat(aircraftDetails.get(1).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("971");
        assertThat(aircraftDetails.get(2).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("3AH");
    }

    @Test
    public void getAllAircraft_WithAirlineCode() {
        final String AIRLINE_CODE_LUS = "LUS";

        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        List<AircraftEntity> aircraftDetails = aircraftService.getAllAircraft(AIRLINE_CODE_LUS);

        assertThat(aircraftDetails).isNotNull().isNotEmpty().hasSize(1);
        assertThat(aircraftDetails.get(0).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("971");
        assertThat(aircraftDetails.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase(AIRLINE_CODE_LUS);
    }

    @Test
    public void getAllAircraft_WithAirlineCodeInLowerCase() {
        final String AIRLINE_CODE_LUS = "lus";

        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        List<AircraftEntity> aircraftDetails = aircraftService.getAllAircraft(AIRLINE_CODE_LUS);

        assertThat(aircraftDetails).isNotNull().isNotEmpty().hasSize(1);
        assertThat(aircraftDetails.get(0).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("971");
        assertThat(aircraftDetails.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase(AIRLINE_CODE_LUS);
    }

    @Test
    public void getAllAircraft_InvalidAirlineCode() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        List<AircraftEntity> aircraftDetails = aircraftService.getAllAircraft("XYZ");

        assertThat(aircraftDetails).isNotNull().hasSize(0);
    }

    @Test
    public void getAllAircraft_NullAirlineCode() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        List<AircraftEntity> aircraftDetails = aircraftService.getAllAircraft(null);

        assertThat(aircraftDetails).isNotNull().hasSize(0);
    }

    @Test
    public void getAircraft() {
        final String AIRCRAFT_NUMMER = "3AB";
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        AircraftEntity aircraft = aircraftService.getAircraft(AIRCRAFT_NUMMER);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase(AIRCRAFT_NUMMER);
    }

    @Test
    public void getAircraft_LowerCaseInput() {
        final String AIRCRAFT_NUMBER = "3ab";
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        AircraftEntity aircraft = aircraftService.getAircraft(AIRCRAFT_NUMBER);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase(AIRCRAFT_NUMBER);
    }

    @Test
    public void getAircraft_InvalidAircraft() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        AircraftEntity aircraft = aircraftService.getAircraft("678");

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNull();
        assertThat(aircraft.getAirlineCode()).isNull();
        assertThat(aircraft.getFleet()).isNull();
        assertThat(aircraft.getSubfleet()).isNull();
    }

    @Test
    public void getAircraft_NullInput() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        AircraftEntity aircraft = aircraftService.getAircraft(null);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNull();
        assertThat(aircraft.getAirlineCode()).isNull();
        assertThat(aircraft.getFleet()).isNull();
        assertThat(aircraft.getSubfleet()).isNull();
    }

    @Test
    public void getAircraft_EmptyInput() {
        given(aircraftRepository.getAllAircraftDetails()).willReturn(getAircraftData());

        AircraftEntity aircraft = aircraftService.getAircraft(" ");

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNull();
        assertThat(aircraft.getAirlineCode()).isNull();
        assertThat(aircraft.getFleet()).isNull();
        assertThat(aircraft.getSubfleet()).isNull();
    }
}
