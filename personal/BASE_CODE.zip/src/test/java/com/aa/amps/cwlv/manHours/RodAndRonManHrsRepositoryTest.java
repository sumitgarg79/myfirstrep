package com.aa.amps.cwlv.manHours;

import com.aa.amps.cwlv.util.DateUtil;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * Test class for {@code {@link RodAndRonManHrsRepository}}. The @FixMethodOrder(MethodSorters.NAME_ASCENDING)
 * annotation on this class makes sure that the test cases are executed in lexicographic order of their name.
 *
 * @author RAMESH RUDRA(842020)
 * created on 4/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RodAndRonManHrsRepositoryTest {

    @Autowired
    private RodAndRonManHrsRepository rodAndRonManHrsRepository;

    @Before
    public void setUp() throws Exception {

    }

    /**
     * Get all LusRonManHrs records.
     */
    @Test
    public void getLusRonManHrs_Success() {
        String date="2018-04-25";
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLusRonManHrs(date);
        assertNotNull(result);
        assertEquals(5,result.size());
    }

    /**
     Getting empty Array list if result doesn't exist for LAA RON ManHrs
     */
    @Test
    public void getLusRonManHrs_NullResult() {
        String date="2018-03-25";
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLusRonManHrs(date);
        assertNotNull(result);
        assertEquals(0,result.size());
    }

    /**
     * Get all LusRodManHrs records.
     */
    @Test
    public void getLusRodManHrs_Success() {
        String date="2018-04-25";
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLusRodManHrs(date);
        assertNotNull(result);

    }

    /**
     Getting empty Array list if result doesn't exist for LUS ROD ManHrs
     */
    @Test
    public void getLusRodManHrs_NullResult() {
        String date="2018-03-25";
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLusRodManHrs(date);
        assertNotNull(result);
        assertEquals(0,result.size());

    }

    /**
     * Get all LaaRonManHrs records.
     */
    @Test
    public void getLaaRonManHrs_Success() {

        String date = DateUtil.getTodaysDate();
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLaaRonManHrs(date);
        assertNotNull(result);
        assertEquals(4,result.size());

    }

    /**
     Getting empty Array list if result doesn't exist for LAA RON MANHRS
     */
    @Test
    public void getLaaRonManHrs_NullResult() {

        String date="2018-03-25";
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsRepository.getLaaRonManHrs(date);
        assertNotNull(result);
        assertEquals(0,result.size());

    }
}
