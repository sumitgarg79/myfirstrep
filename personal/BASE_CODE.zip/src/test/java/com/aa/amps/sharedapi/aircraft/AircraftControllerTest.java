package com.aa.amps.sharedapi.aircraft;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link AircraftController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/4/2019.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AircraftControllerTest {

    @Autowired
    AircraftController aircraftController;

    @MockBean
    AircraftService aircraftService;

    public List<AircraftEntity> getAllAircraftData() {
        AircraftEntity aircraft1 = new AircraftEntity();
        aircraft1.setAircraftNumber("3AB");
        aircraft1.setFleet("737");
        aircraft1.setSubfleet("737-200");
        aircraft1.setAirlineCode("LAA");

        AircraftEntity aircraft2 = new AircraftEntity();
        aircraft2.setAircraftNumber("3AH");
        aircraft2.setFleet("737");
        aircraft2.setSubfleet("737-800");
        aircraft2.setAirlineCode("LAA");

        AircraftEntity aircraft3 = new AircraftEntity();
        aircraft3.setAircraftNumber("971");
        aircraft3.setFleet("321");
        aircraft3.setSubfleet("321-E200");
        aircraft3.setAirlineCode("LUS");

        List<AircraftEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);
        aircraftData.add(aircraft2);
        aircraftData.add(aircraft3);

        return aircraftData;
    }

    public List<AircraftEntity> getLaaAircraftData() {
        AircraftEntity aircraft1 = new AircraftEntity();
        aircraft1.setAircraftNumber("3AB");
        aircraft1.setFleet("737");
        aircraft1.setSubfleet("737-200");
        aircraft1.setAirlineCode("LAA");

        AircraftEntity aircraft2 = new AircraftEntity();
        aircraft2.setAircraftNumber("3AH");
        aircraft2.setFleet("737");
        aircraft2.setSubfleet("737-800");
        aircraft2.setAirlineCode("LAA");

        List<AircraftEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);
        aircraftData.add(aircraft2);

        return aircraftData;
    }

    public List<AircraftEntity> getLusAircraftData() {
        AircraftEntity aircraft1 = new AircraftEntity();
        aircraft1.setAircraftNumber("971");
        aircraft1.setFleet("321");
        aircraft1.setSubfleet("321-E200");
        aircraft1.setAirlineCode("LUS");
        aircraft1.setSceptreFleetCode("29");

        List<AircraftEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);

        return aircraftData;
    }


    @Test
    public void getAllAircraft() {
        given(aircraftService.getAllAircraft()).willReturn(getAllAircraftData());

        List<AircraftEntity> testSetupData = getAllAircraftData();

        List<AircraftEntity> aircraftResponse = aircraftController.getAllAircraft(null);

        assertThat(aircraftResponse).isNotNull().isNotEmpty().hasSize(3);
        assertThat(aircraftResponse.get(0).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(0).getAircraftNumber());
        assertThat(aircraftResponse.get(0).getAirlineCode()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(0).getAirlineCode());
        assertThat(aircraftResponse.get(1).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(1).getAircraftNumber());
        assertThat(aircraftResponse.get(2).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(2).getAircraftNumber());
    }

    @Test
    public void getAllAircraft_WithAirlineCodeLaa() {
        final String AIRLINE_LAA = "LAA";
        given(aircraftService.getAllAircraft(AIRLINE_LAA)).willReturn(getLaaAircraftData());

        List<AircraftEntity> aircraftResponse = aircraftController.getAllAircraft(AIRLINE_LAA);

        assertThat(aircraftResponse).isNotNull().isNotEmpty().hasSize(2);
        assertThat(aircraftResponse.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AB");
        assertThat(aircraftResponse.get(0).getAirlineCode()).isNotBlank().isEqualToIgnoringCase(AIRLINE_LAA);
        assertThat(aircraftResponse.get(1).getAirlineCode()).isNotBlank().isEqualToIgnoringCase(AIRLINE_LAA);
    }

    @Test
    public void getAllAircraft_WithAirlineCodeLus() {
        final String AIRLINE_LUS = "LUS";
        given(aircraftService.getAllAircraft(AIRLINE_LUS)).willReturn(getLusAircraftData());

        List<AircraftEntity> aircraftResponse = aircraftController.getAllAircraft(AIRLINE_LUS);

        assertThat(aircraftResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(aircraftResponse.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("971");
        assertThat(aircraftResponse.get(0).getAirlineCode()).isNotBlank().isEqualToIgnoringCase(AIRLINE_LUS);
    }

    @Test
    public void getAllAircraft_WithAirlineCodeLowerCase() {
        final String AIRLINE_LAA = "laa";
        given(aircraftService.getAllAircraft(AIRLINE_LAA)).willReturn(getLaaAircraftData());

        List<AircraftEntity> aircraftResponse = aircraftController.getAllAircraft(AIRLINE_LAA);

        assertThat(aircraftResponse).isNotNull().isNotEmpty().hasSize(2);
        assertThat(aircraftResponse.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("3AB");
        assertThat(aircraftResponse.get(0).getAirlineCode()).isNotBlank().isEqualToIgnoringCase(AIRLINE_LAA);
        assertThat(aircraftResponse.get(1).getAirlineCode()).isNotBlank().isEqualToIgnoringCase(AIRLINE_LAA);
    }

    @Test
    public void getAircraft() {
        final String AIRCRAFT_971 = "971";
        given(aircraftService.getAircraft(AIRCRAFT_971)).willReturn(getLusAircraftData().get(0));

        AircraftEntity testSetupData = getLusAircraftData().get(0);

        AircraftEntity aircraft = aircraftController.getAircraft(AIRCRAFT_971);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotBlank().isEqualToIgnoringCase(AIRCRAFT_971);
        assertThat(aircraft.getAirlineCode()).isNotBlank().isEqualToIgnoringCase(testSetupData.getAirlineCode());
        assertThat(aircraft.getFleet()).isNotBlank().isEqualToIgnoringCase(testSetupData.getFleet());
        assertThat(aircraft.getSubfleet()).isNotBlank().isEqualToIgnoringCase(testSetupData.getSubfleet());
        assertThat(aircraft.getSceptreFleetCode()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.getSceptreFleetCode());
    }

    @Test
    public void getAircraft_LowerCase() {
        final String AIRCRAFT_3AB = "3ab";
        given(aircraftService.getAircraft(AIRCRAFT_3AB)).willReturn(getLaaAircraftData().get(0));

        AircraftEntity testSetupData = getLaaAircraftData().get(0);

        AircraftEntity aircraft = aircraftController.getAircraft(AIRCRAFT_3AB);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotBlank().isEqualToIgnoringCase(AIRCRAFT_3AB);
        assertThat(aircraft.getAirlineCode()).isNotBlank().isEqualToIgnoringCase(testSetupData.getAirlineCode());
        assertThat(aircraft.getFleet()).isNotBlank().isEqualToIgnoringCase(testSetupData.getFleet());
        assertThat(aircraft.getSubfleet()).isNotBlank().isEqualToIgnoringCase(testSetupData.getSubfleet());
    }

    @Test
    public void clearAircraftCache() {
        given(aircraftService.getAllAircraft()).willReturn(getAllAircraftData());

        List<AircraftEntity> testSetupData = getAllAircraftData();

        List<AircraftEntity> aircraftResponse = aircraftController.refreshAircraftCache();

        assertThat(aircraftResponse).isNotNull().isNotEmpty().hasSize(3);
        assertThat(aircraftResponse.get(0).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(0).getAircraftNumber());
        assertThat(aircraftResponse.get(0).getAirlineCode()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(0).getAirlineCode());
        assertThat(aircraftResponse.get(1).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(1).getAircraftNumber());
        assertThat(aircraftResponse.get(2).getAircraftNumber()).isNotBlank()
            .isEqualToIgnoringCase(testSetupData.get(2).getAircraftNumber());
    }
}
