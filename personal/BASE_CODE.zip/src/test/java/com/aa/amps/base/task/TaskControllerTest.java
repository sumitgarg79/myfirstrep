package com.aa.amps.base.task;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.exception.TaskFilterRequestException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

/**
 * This the test class for {@code TaskController}.
 *
 * @author Paul Verner
 * @since 6/12/2018.
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TaskControllerTest {

    @Autowired
    private TaskController taskController;

    private List<TaskEntity> taskEntityList;
    private TaskContainerResponse taskContainer;

    @MockBean
    private TaskService taskService;

    @Before
    public void setUp() {
        taskContainer = new TaskContainerResponse();
        taskEntityList = new ArrayList<>();

        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setAircraftNbr("723");
        taskEntity.setAtaCode("05-38");
        taskEntity.setDeferralLockInd(false);
        taskEntity.setDescription("REP, 26L00038001, POTABLE WATER");
        taskEntity.setDni(false);
        taskEntity.setFleetCode("319");
        taskEntity.setForecastDateAsString("6/19/2018");
        taskEntity.setManHours(6);
        taskEntity.setPriority("3");
        taskEntity.setRouteControlCode("U");
        taskEntity.setStatus("Open");
        taskEntity.setTaskId("26-0538-8-0004 0723");
        taskEntity.setTaskTypeCode("ME8");
        taskEntity.setTtgCycles(8);
        taskEntity.setTtgDays(5);
        taskEntity.setTtgHours(89);
        taskEntity.setWorkControl(3456);
        taskEntity.setPlannedStation("BOS");

        taskEntityList.add(taskEntity);
        taskContainer.setTaskList(taskEntityList);
        taskContainer.setWorkCodeJobOrder("2210323");
    }

    /**
     * Test case for TaskController.getTasks()
     */
    @Test
    public void getTasksTest() throws ParseException, TaskFilterRequestException {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        given(this.taskService.getTasksBySearchCriteria(searchCriteria.getSearchCriteriaAsMap())).willReturn
                (taskEntityList);
        List<TaskEntity> taskEntityLists = taskController.getTasks(searchCriteria);
        assertTrue(!taskEntityLists.isEmpty());
    }

    /**
     * Test case for TaskController.getTasks()
     */
    @Test
    public void getTaskContainerTest() throws ParseException, TaskFilterRequestException {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        given(this.taskService.getTaskContainerBySearchCriteria(searchCriteria.getSearchCriteriaAsMap())).willReturn
                (taskContainer);
        TaskContainerResponse tasks = taskController.getTaskContainer(searchCriteria);
        assertTrue(tasks.getTaskList() != null);
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void saveBaseDraftTest() throws BaseServiceException {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("2018-07-18");
        wrkPkgEntity.setPlanStationCd("CLT");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421656");
        taskEntity.setAircraftNbr("824");
        taskEntity.setRouteControlCode("M");
        taskEntity.setDni(true);
        taskEntity.setDeferralLockInd(true);
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);

        given(this.taskService.saveBaseDraft(wrkPkgEntity)).willReturn(true);

        boolean result = taskController.saveBaseDraft(wrkPkgEntity);
        assertTrue("Draft Saved successfully", result);
    }

    /**
     * Test case for saving Base Draft exception in case of duplicate draft.
     */
    @Test(expected = BaseServiceException.class)
    public void saveBaseDraftTestException() throws BaseServiceException {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        BaseServiceException baseServiceException = new BaseServiceException("This is test", null);
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("825");
        wrkPkgEntity.setPkgSchdDt("2018-07-18");
        wrkPkgEntity.setPlanStationCd("CLT");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        given(this.taskService.saveBaseDraft(wrkPkgEntity)).willThrow(baseServiceException);
        taskController.saveBaseDraft(wrkPkgEntity);
    }

    /**
     * Test case for TaskController.getTaskDetails()
     */
    @Test
    public void getTaskDetailsTest() throws TaskDetailException {
        String[] taskIds = {"25-0525-8-0088 0723"};
        String[] aircraftNbrs = {"723"};

        TaskDetailRequest taskDetailRequest = new TaskDetailRequest();
        taskDetailRequest.setAircraftNbrs(aircraftNbrs);
        taskDetailRequest.setTaskIds(taskIds);

        given(this.taskService.getTaskDetails(BDDMockito.anyMap())).willReturn(taskEntityList);
        List<TaskEntity> taskDetails = taskController.getTaskDetails(taskDetailRequest);
        assertThat(taskDetails).isNotNull();
    }

}
