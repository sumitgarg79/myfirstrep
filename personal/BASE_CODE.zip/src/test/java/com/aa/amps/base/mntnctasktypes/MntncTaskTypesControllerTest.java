package com.aa.amps.base.mntnctasktypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * This is test class for {@link MntncTaskTypesController}
 *
 * @author Sudeep(842019)
 * @since 5/22/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MntncTaskTypesControllerTest {

    @Autowired
    private MntncTaskTypesController mntncTaskTypesController;

    private List<MntncTaskTypeEntity> mntncTaskTypeEntityList;

    @MockBean
    private MntncTaskTypesService mntncTaskTypesService;

    @Before
    public void setUp() throws Exception {
        mntncTaskTypeEntityList = new ArrayList<>();
        MntncTaskTypeEntity lineBase = new MntncTaskTypeEntity();
        lineBase.setAcftMntncTaskType("CDL");
        lineBase.setAcftMntncTaskType("ESI");
        lineBase.setAcftMntncTaskType("ME8-MON");
        lineBase.setAcftMntncTaskType("ME8-TC");
        lineBase.setAcftMntncTaskType("ME8-EO");
        lineBase.setAcftMntncTaskType("ME8-CKC");

        MntncTaskTypeEntity line = new MntncTaskTypeEntity();
        line.setAcftMntncTaskType("CDL");
        line.setAcftMntncTaskType("ESI");

        mntncTaskTypeEntityList.add(lineBase);
    }

    @Test
    public void getAllMntncTaskTypes() {
        getMaintenanceTaskTypes("");

    }

    @Test
    public void getBaseMaintenanceTaskTypes() {
        getMaintenanceTaskTypes("B");
    }

    private void getMaintenanceTaskTypes(String b) {
        String appType = b;
        given(this.mntncTaskTypesService.getMaintenanceTaskTypes(appType)).willReturn(mntncTaskTypeEntityList);
        List<MntncTaskTypeEntity> result = mntncTaskTypesController.getAircraftMaintenanceTaskTypes(appType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getAcftMntncTaskType()).isEqualToIgnoringCase("ME8-CKC");
    }

    @Test
    public void getLineBaseMaintenanceTaskTypes() {
        getMaintenanceTaskTypes("LB");
    }

}