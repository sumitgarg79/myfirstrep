package com.aa.amps.base.task;

import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.util.DateUtil;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.aa.amps.base.task.TaskConstants.AIRCFT_MNTNC_TASK_ID_DB;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Test class for {@code TaskRepository}.
 *
 * @author Paul Verner (650196)
 * @since 6/11/2018.
 * <p>
 * 292147 03-07-2018 : US748803  : [Base  BOW] [Filter] Search by - Task Types
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TaskRepositoryTest {
    private static final String AD_DNI = "ad_dni";
    @Autowired
    private TaskRepository taskRepository;

    private TaskFilterRequest searchCriteria;

    @Before
    public void setUp() {
        searchCriteria = new TaskFilterRequest();
    }

    @Test
    public void getTasksTest() throws Exception {
        searchCriteria.setAircraftNumber("723");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    @Test
    public void getAircraftEquipType() {
        String typeEquipment = taskRepository.getAircraftEquipmentType("062");
        assertThat(typeEquipment).isNotNull();
        String typeEquipmentNull = taskRepository.getAircraftEquipmentType("777");
        assertThat(typeEquipmentNull).isNull();
    }

    /**
     * Test case for getting task types in the DB.
     */
    @Test
    public void getTasksTypeBySearchCriteriaTest() throws Exception {
        searchCriteria.setAircraftNumber("723");
        String[] taskTypeCd = {"ME9", "ME8-CKC", "ME8-TC", "ME8-EO"};
        searchCriteria.setTaskTypes(taskTypeCd);
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * Test case for getting task types in the DB.  ME8 subtypes only.
     */
    @Test
    public void getTasksTypeBySearchCriteriaTest_ME8SubtypesOnly() throws Exception {
        searchCriteria.setAircraftNumber("723");
        String[] taskTypeCd = {"ME8-CKC", "ME8-TC", "ME8-EO", "ME8-DNS", "ME8-MON"};
        searchCriteria.setTaskTypes(taskTypeCd);
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * Test case for getting task types in the DB. ME8 plus ME8 subtypes.
     */
    @Test
    public void getTasksTypeBySearchCriteriaTest_ME8PlusSubtypes() throws Exception {
        searchCriteria.setAircraftNumber("723");
        String[] taskTypeCd = {"ME8", "ME8-CKC", "ME8-TC", "ME8-EO", "ME8-DNS", "ME8-MON"};
        searchCriteria.setTaskTypes(taskTypeCd);
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748801 : [Base  BOW] [Filter] Search by - Keyword
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByKeywordTest() throws Exception {
        searchCriteria.setAircraftNumber("723");
        //DE70713- Input parameter from UI not matching with BE TaskFilterRequest.
        searchCriteria.setSearchKeyWord("GRAPHICS");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith - AD
     * Test case for TaskController.getTasks() with ItemsWith AD
     */
    @Test
    public void getTasksItemWithAD() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{"ad"});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith - DNI
     * Test case for TaskController.getTasks() with ItemsWith DNI
     */
    @Test
    public void getTasksItemWithDNI() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{"dni"});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith
     * Test case for TaskController.getTasks() with ItemsWith AD_DNI
     */
    @Test
    public void getTasksItemWithADandDNI() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{AD_DNI});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith
     * Test case for TaskController.getTasks() with ItemsWith AD, DNI
     */
    @Test
    public void getTasksItemWithAD_DNI() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{"ad", "dni"});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith
     * Test case for TaskController.getTasks() with ItemsWith AD, AD_DNI
     */
    @Test
    public void getTasksItemWithAD_ADandDNI() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{"ad", AD_DNI});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US748805 : [Base  BOW] [Filter] Search by - ItemsWith
     * Test case for TaskController.getTasks() with ItemsWith DNI, AD_DNI
     */
    @Test
    public void getTasksItemWithDNI_ADandDNI() throws Exception {
        searchCriteria.setAircraftNumber("113");
        searchCriteria.setItemsWith(new String[]{"dni", AD_DNI});
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksBySoftTimes() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setSoftTime("T");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByForecastDate() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setForecast("true");
        searchCriteria.setForecastFromDate(DateUtil.getCurrentDateAsString());
        searchCriteria.setForecastToDate(DateUtil.getCurrentDateAsString());
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    @Test
    public void getTasksByForecastDateToday() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setForecast("true");
        searchCriteria.setForecastFromDate("06/06/2018");
        searchCriteria.setForecastToDate("07/06/2018");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByNoForecastDate() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setNoForecast("true");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByForecastDateandSoftTimes() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setSoftTime("T");

        searchCriteria.setForecastFromDate("06/06/2018");
        searchCriteria.setForecastToDate("07/06/2018");
        searchCriteria.setNoForecast("true");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByForecastDateandSoftTimesExtended() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setSoftTime("T");

        searchCriteria.setForecastFromDate("07/14/2018");
        searchCriteria.setForecastToDate("07/15/2018");
        searchCriteria.setNoForecast("true");
        //Logic to keep the date with latest
        Date fromDate = new Date();
        Date toDate;
        Calendar c = Calendar.getInstance();
        c.setTime(fromDate);
        c.add(Calendar.DATE, 1);
        fromDate = c.getTime();
        c.add(Calendar.DATE, 5);
        toDate = c.getTime();
        DateFormat dateFormat = new SimpleDateFormat("MM/DD/YYYY");

        searchCriteria.setForecastFromDate(dateFormat.format(fromDate));
        searchCriteria.setForecastToDate(dateFormat.format(toDate));
        searchCriteria.setNoForecast("true");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search
     */
    @Test
    public void getTasksByEmptyForecastTodate() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setSoftTime("T");

        searchCriteria.setForecastFromDate("07/14/2018");
        searchCriteria.setForecastToDate("");
        searchCriteria.setNoForecast("true");
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
    }

    /**
     * US845027: [Base BOW] [Filter] Search by - Station
     * Test case for TaskController.getTasks() search tasks based on station search
     */
    @Test
    public void getTasksByStationCriteriaTest() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("161");
        String[] stations = {"CLT"};
        searchCriteria.setStations(stations);
        List<TaskEntity> taskList = taskRepository.getTasks(searchCriteria.getSearchCriteriaAsMap());
        assertThat(taskList).isNotNull();
        assertThat(taskList.get(0).getPlannedStation()).isEqualToIgnoringCase("CLT");
    }

    /**
     * Test case for TaskController.getTaskDetails()
     */
    @Test
    public void getTaskDetailsTest() throws TaskDetailException {
        String[] taskIds = {"25-0525-8-0088 0723"};
        String[] aircraftNbrs = {"723"};

        TaskDetailRequest taskDetailRequest = new TaskDetailRequest();
        taskDetailRequest.setAircraftNbrs(aircraftNbrs);
        taskDetailRequest.setTaskIds(taskIds);

        List<TaskEntity> taskDetails = taskRepository.getTaskDetails(taskDetailRequest.getTaskDetailRequestAsMap());
        assertThat(taskDetails).isNotNull();
        assertThat(taskDetails.get(0).getTaskId()).isEqualToIgnoringCase("25-0525-8-0088 0723");
    }

    /**
     * Test case for TaskController.getTaskDetails() order date Forecast Date
     */
    @Test
    public void getTaskDetailsOrderByForecastDateTest() throws TaskDetailException, ParseException {
        String[] taskIds = {"25-0525-8-0088 0723", "26-0525-8-2564 0723", "30-4527-8-3322 0723"};
        String[] aircraftNbrs = {"723"};

        TaskDetailRequest taskDetailRequest = new TaskDetailRequest();
        taskDetailRequest.setAircraftNbrs(aircraftNbrs);
        taskDetailRequest.setTaskIds(taskIds);

        List<TaskEntity> taskDetails = taskRepository.getTaskDetails(taskDetailRequest.getTaskDetailRequestAsMap());
        assertThat(taskDetails).isNotNull();
        assertThat(taskDetails.get(0).getTaskId()).isEqualToIgnoringCase("25-0525-8-0088 0723");
        assertThat(taskDetails.get(1).getTaskId()).isEqualToIgnoringCase("26-0525-8-2564 0723");
        assertThat(taskDetails.get(2).getTaskId()).isEqualToIgnoringCase("30-4527-8-3322 0723");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = sdf.parse(taskDetails.get(0).getDueDate().toString());
        Date date2 = sdf.parse(taskDetails.get(1).getDueDate().toString());
        Date date3 = sdf.parse(taskDetails.get(2).getDueDate().toString());

        assertThat(date1.compareTo(date2) < 0).isTrue();
        assertThat(date2.compareTo(date3) < 0).isTrue();
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void saveBaseDraftTest() {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("07/21/2018");
        wrkPkgEntity.setPlanStationCd("MIA");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setComments("Test Draft Pkg");

        boolean result = taskRepository.saveBaseDraft(wrkPkgEntity, 101L);
        assertTrue("Expected true as a response", result);
    }

    /**
     * Test case for saving Base Draft Tasks
     */
    @Test
    public void saveWorkPkgDraftTasksTest() {

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421656");
        taskEntity.setAircraftNbr("824");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        TaskEntity taskEntityOne = new TaskEntity();
        taskEntityOne.setTaskId("8421658");
        taskEntityOne.setAircraftNbr("824");
        taskEntityOne.setWrkPkgTaskStatus("U");
        taskEntityOne.setUserId("292147");
        taskEntityOne.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        taskEntities.add(taskEntityOne);

        boolean result = taskRepository.saveWorkPkgDraftTasks(taskEntities, 101L);
        assertTrue("Expected true as a response", result);
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void updateWorkPackageEntityTest() {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("07/21/2018");
        wrkPkgEntity.setPlanStationCd("MIA");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setComments("Test Draft Pkg Update");

        boolean result = taskRepository.updateWorkPackageEntity(wrkPkgEntity);
        assertTrue("Expected true as a response", result);
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void checkWorkPackageExistsTest() {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("10-07-2018");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("03");

        Map<String, Object> dbWorkPkgEntity = taskRepository.checkWorkPackageExists(wrkPkgEntity);
        assertThat(dbWorkPkgEntity).isNotNull();
        assertThat(dbWorkPkgEntity.get("DRAFT_PLAN_STN_CD").toString()).isEqualToIgnoringCase("DFW");
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void checkWorkPackageExistsTestEmpty() {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("800");
        wrkPkgEntity.setPkgSchdDt("10-07-2018");
        wrkPkgEntity.setPlanStationCd("DFW");

        Map<String, Object> dbWorkPkgEntity = taskRepository.checkWorkPackageExists(wrkPkgEntity);
        assertThat(dbWorkPkgEntity).isNull();
    }

    /**
     * Test case for saving Base Draft
     */
    @Test
    public void zzupdateBaseDraftTest() {
        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421656");
        taskEntity.setAircraftNbr("824");
        taskEntity.setRouteControlCode("M");
        taskEntity.setDni(true);
        taskEntity.setDeferralLockInd(true);
        taskEntity.setWrkPkgTaskStatus("U");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        TaskEntity taskEntityOne = new TaskEntity();
        taskEntityOne.setTaskId("8421660");
        taskEntityOne.setAircraftNbr("824");
        taskEntityOne.setRouteControlCode("M");
        taskEntityOne.setDni(true);
        taskEntityOne.setDeferralLockInd(true);
        taskEntityOne.setWrkPkgTaskStatus("U");
        taskEntityOne.setUserId("292147");
        taskEntityOne.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        taskEntities.add(taskEntityOne);

        boolean result = taskRepository.updateWorkPkgDraftTasks(taskEntities, 101L);
        assertTrue("Expected true as a response", result);
    }


    /**
     * Test case for get task for draft work package id
     */
    @Test
    public void getTaskEntitiesTest() {
        List<Map<String, Object>> taskList = taskRepository.getTaskEntitiesForDraft((long) 2424);
        assertThat(taskList).isNotNull();
        assertThat(taskList.get(0).get("DRAFT_WORK_PKG_ID").toString()).isEqualToIgnoringCase("2424");
    }

    /**
     * Test case for getting the work package Id sequence
     */
    @Test
    public void getWorkPackageSeqIdTest() {
        Long workPackageSeqId = taskRepository.getWorkPackageSeqId();
        assertThat(workPackageSeqId).isNotNull();
    }

    /**
     * Test case for getting the work package tasks.
     */
    @Test
    public void getWorkPackageTasksTest() {
        List<TaskEntity> taskEntityList = taskRepository.getWorkPackageTasks((long) 2424);
        assertThat(taskEntityList).isNotNull();
        assertThat(taskEntityList.get(0).getWorkPkgId().toString()).isEqualToIgnoringCase("2424");
    }

    /**
     * Z is added so that this test case will run at last
     * Test case for delete task from work package
     */
    @Test
    public void zzzdeleteTaskFromWorkPkgTest() {
        Map<String, Object> dbTaskEntityMap = new HashMap<>();
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setUserId("292147");

        List<Map<String, Object>> dbTaskEntityList = taskRepository.getTaskEntitiesForDraft(wrkPkgEntity.getWorkPkgId());
        dbTaskEntityList.forEach(taskEntity -> dbTaskEntityMap.put((String) taskEntity.get(AIRCFT_MNTNC_TASK_ID_DB),
                taskEntity));

        boolean isDataDeleted = taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap, wrkPkgEntity.getWorkPkgId(), "292147");

        List<TaskEntity> taskList = taskRepository.getWorkPackageTasks((long) 101);
        assertThat(taskList).isNotNull();
        assertThat(taskList.size()).isEqualTo(0);
        assertTrue("Expected true as a response", isDataDeleted);
    }

    /**
     * z is added sothat this test case will run after zzzdeleteTaskFromWorkPkgTest
     * Test case for delete work package
     */
    @Test
    public void zzzzdeleteWorkPackageEntity() {
        Long workPkgId = 101L;
        String userId = "292147";

        boolean isDataDeleted = taskRepository.deleteWorkPackageEntity(workPkgId, userId);

        assertTrue("Expected true as a response", isDataDeleted);
    }

    /**
     * Z is added sothat this test case will run after zzzdeleteTaskFromWorkPkgTest
     * Test case for delete all task from work package
     */
    @Test
    public void zzzzdeleteAllTasksForWorkPkg() {
        Long workPkgId = 101L;
        String userId = "292147";

        boolean isDataDeleted = taskRepository.deleteAllTasksForWorkPkg(workPkgId, userId);

        List<TaskEntity> taskList = taskRepository.getWorkPackageTasks((long) 101);
        assertThat(taskList).isNotNull();
        assertThat(taskList.size()).isEqualTo(0);
        assertTrue("Expected true as a response", isDataDeleted);
    }
}