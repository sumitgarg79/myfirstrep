package com.aa.amps.base.bow.actions;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@Link BOWStatusActionController}.
 *
 * @author HCL(296319)
 * @since on 8/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BOWStatusActionControllerTest {

    @Autowired
    private BOWStatusActionController bowStatusActionController;

    @MockBean
    private BOWStatusActionService bowStatusActionService;

    /**
     * Test case for getAllActiveStations.
     */
    @Test
    public void getAllActions() {
        List<String> strActions = Arrays.asList("Edit", "Copy", "Delete", "Export To Excel", "PDF");

        given(this.bowStatusActionService.getAllActions()).willReturn(strActions);
        List<String> result = bowStatusActionController.getAllActions();

        assertThat(result).isNotNull();
        assertEquals(strActions.size(), result.size());
    }
}
