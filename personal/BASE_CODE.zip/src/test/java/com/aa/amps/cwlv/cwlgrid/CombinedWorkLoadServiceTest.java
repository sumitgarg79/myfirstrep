package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.crossutil.CrossUtilService;
import com.aa.amps.cwlv.cwlgrid.laa.LAATaskService;
import com.aa.amps.cwlv.cwlgrid.lus.LUSTaskService;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CombinedWorkLoadServiceTest {

    List<CombinedTaskDetail> resposeLUS;
    List<CombinedTaskDetail> resposeLAA;
    List<String> stationList;

    @MockBean
    private LUSTaskService lusTaskService;
    @MockBean
    private LAATaskService laaTaskService;
    @MockBean
    private CrossUtilService crossUtilService;

    @Autowired
    private CombinedWorkLoadService combinedWorkLoadService;

    private FilterRequest filterRequest;

    @Before
    public void setUp() throws Throwable {
        filterRequest = new FilterRequest();

        resposeLUS = getLUSResponse();
        resposeLAA = getLAAResponse();
        stationList = getStations();
    }

    @Test
    public void getCombinedWorkLoadTasksDetails() {
        given(lusTaskService.getCombinedTasksDetails(Mockito.anyMap())).willReturn(resposeLUS);
        given(laaTaskService.getCombinedTasksDetails(Mockito.anyMap())).willReturn(resposeLAA);
        given(crossUtilService.getCrossUtilizationStation()).willReturn(stationList);

        List<CombinedTaskDetail> response = combinedWorkLoadService.getCombinedWorkLoadTasksDetails(filterRequest.getSearchCriteriaAsMap());

        assertThat(response.size() == 5);
    }

    @Test
    public void getCombinedWorkLoadTasksDetails_Failed() {
        given(lusTaskService.getCombinedTasksDetails(Mockito.anyMap())).willReturn(null);
        given(laaTaskService.getCombinedTasksDetails(Mockito.anyMap())).willReturn(null);
        given(crossUtilService.getCrossUtilizationStation()).willReturn(stationList);

        List<CombinedTaskDetail> response = combinedWorkLoadService.getCombinedWorkLoadTasksDetails(filterRequest.getSearchCriteriaAsMap());

        assertThat(CollectionUtils.isEmpty(response));
    }

    private List<CombinedTaskDetail> getLAAResponse() {
        CombinedTaskDetail c = new CombinedTaskDetail();
        c.setAircftNbr("342");
        c.setLogo("DECS");
        c.setFleetCd("737");
        c.setStnCd("SFO");
        c.setTaskId("3PT25000C-NONE");
        c.setTaskDesc("AIRCRAFT REGISTRATION HAS PENDING GOVERNMENT APPROVAL FROM ECUADOR. *TAC* A/C PENDING ECUADOR APPROV");
        c.setTaskTypeCd("PML");
        c.setSchdDt("2018-05-31");
        c.setForecastDt("2018-12-11");
        c.setRodRon("RON");
        c.setTimeCycle("194 D");
        c.setMechHour("1");
        c.setFlightNbr("2639");
        c.setInvalidRecord(false);

        CombinedTaskDetail c1 = new CombinedTaskDetail();
        c1.setAircftNbr("3AA");
        c1.setLogo("DECS");
        c1.setFleetCd("737");
        c1.setStnCd("SFO");
        c1.setTaskId("3PT25000C-NONE");
        c1.setTaskDesc("AIRCRAFT REGISTRATION HAS PENDING APPROV");
        c1.setTaskTypeCd("PML");
        c1.setSchdDt("2018-05-31");
        c1.setForecastDt("2018-12-11");
        c1.setRodRon("RON");
        c1.setTimeCycle("194 D");
        c1.setMechHour("1");
        c1.setFlightNbr(null);
        c1.setInvalidRecord(true);

        CombinedTaskDetail c2 = new CombinedTaskDetail();
        c2.setAircftNbr("3AA");
        c2.setLogo("DECS");
        c2.setFleetCd("737");
        c2.setStnCd("SFO");
        c2.setTaskId("3PT25000C-NONE");
        c2.setTaskDesc("AIRCRAFT REGISTRATION HAS PENDING APPROV");
        c2.setTaskTypeCd("PML");
        c2.setSchdDt("2018-05-31");
        c2.setForecastDt("2018-12-11");
        c2.setRodRon("ROD");
        c2.setTimeCycle("194 D");
        c2.setMechHour("1");
        c2.setFlightNbr(null);
        c2.setInvalidRecord(true);

        List<CombinedTaskDetail> response = new ArrayList<>();
        response.add(c);
        response.add(c1);
        response.add(c2);

        return response;

    }

    private List<CombinedTaskDetail> getLUSResponse() {
        CombinedTaskDetail c = new CombinedTaskDetail();
        c.setAircftNbr("342");
        c.setLogo("SCPT");
        c.setFleetCd("737");
        c.setStnCd("SFO");
        c.setTaskId("3PT25000D");
        c.setTaskDesc("AIRCRAFT A/C PENDING ECUADOR APPROV");
        c.setTaskTypeCd("PML");
        c.setSchdDt("2018-05-31");
        c.setForecastDt("2018-12-11");
        c.setRodRon("RON");
        c.setTimeCycle("194 D");
        c.setMechHour("1");
        c.setFlightNbr("2639");
        c.setInvalidRecord(false);

        CombinedTaskDetail c1 = new CombinedTaskDetail();
        c1.setAircftNbr("3AA");
        c1.setLogo("SCPT");
        c1.setFleetCd("737");
        c1.setStnCd("SFO");
        c1.setTaskId("3PT25000C-NONE");
        c1.setTaskDesc("AIRCRAFT REGISTRATION HAS PENDING APPROV");
        c1.setTaskTypeCd("PML");
        c1.setSchdDt("2018-05-31");
        c1.setForecastDt("2018-12-11");
        c1.setRodRon("RON");
        c1.setTimeCycle("194 D");
        c1.setMechHour("1");
        c1.setFlightNbr(null);
        c1.setInvalidRecord(true);

        CombinedTaskDetail c2 = new CombinedTaskDetail();
        c2.setAircftNbr("3AA");
        c2.setLogo("SCPT");
        c2.setFleetCd("737");
        c2.setStnCd("SFO");
        c2.setTaskId("3PT25000C-NONE");
        c2.setTaskDesc("AIRCRAFT REGISTRATION");
        c2.setTaskTypeCd("PML");
        c2.setSchdDt("2018-05-31");
        c2.setForecastDt("2018-12-11");
        c2.setRodRon("ROD");
        c2.setTimeCycle("194 D");
        c2.setMechHour("1");
        c2.setFlightNbr(null);
        c2.setInvalidRecord(true);

        List<CombinedTaskDetail> response = new ArrayList<>();
        response.add(c);
        response.add(c1);
        response.add(c2);

        return response;

    }

    private List<String> getStations() {
        String[] stations = {"DFW","ATL"};
        return Arrays.asList(stations);
    }

}