package com.aa.amps.base.validation;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for all the API endpoints defined in class
 * {@link com.aa.amps.base.validation.ValidationController}.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class ValidationIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {
        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setUp() {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

    /**
     * GET /base/validation/aircraft
     * Scenario for passing aircraft number only.
     */
    @Test
    public void isValidAircraft_AircraftNumberOnly() throws Exception {
        mockMvc.perform(get("/base/validation/aircraft")
                .param("acNum", "3AB")
                .param("airlineCd", "")
                .param("fleet", ""))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.valid", is("true")))
                .andExpect(jsonPath("$.aircraftNum", is("3AB")))
                .andExpect(jsonPath("$.airlineCode", is("LAA")))
                .andExpect(jsonPath("$.fleet", is("737")));
    }

    /**
     * GET /base/validation/aircraft
     * Scenario for passing aircraft number and airline code only.
     */
    @Test
    public void isValidAircraft_AircraftAndAirlineCode() throws Exception {
        mockMvc.perform(get("/base/validation/aircraft")
                .param("acNum", "3AB")
                .param("airlineCd", "LAA")
                .param("fleet", ""))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.valid", is("true")))
                .andExpect(jsonPath("$.aircraftNum", is("3AB")))
                .andExpect(jsonPath("$.airlineCode", is("LAA")))
                .andExpect(jsonPath("$.fleet", is("737")));
    }

    /**
     * GET /base/validation/aircraft
     * Scenario for passing aircraft number, airline code and Fleet.
     */
    @Test
    public void isValidAircraft_AircraftNbrAndAirlineCodeAndFleet() throws Exception {
        mockMvc.perform(get("/base/validation/aircraft")
                .param("acNum", "3AB")
                .param("airlineCd", "LAA")
                .param("fleet", "737"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.valid", is("true")))
                .andExpect(jsonPath("$.aircraftNum", is("3AB")))
                .andExpect(jsonPath("$.airlineCode", is("LAA")))
                .andExpect(jsonPath("$.fleet", is("737")));
    }

    /**
     * GET /validation/aircraft
     * Scenario for passing a valid aircraft number and invalid airline code.
     */
    @Test
    public void isValidAircraft_InvalidAirlineCode() throws Exception {
        mockMvc.perform(get("/base/validation/aircraft")
                .param("acNum", "3AB")
                .param("airlineCd", "LUS")
                .param("fleet", ""))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.valid", is("false")))
                .andExpect(jsonPath("$.aircraftNum", is("3AB")));
    }

    /**
     * GET /base/validation/aircraft
     * Scenario for passing a invalid aircraft number.
     */
    @Test
    public void isValidAircraft_InvalidAircraftNum() throws Exception {
        mockMvc.perform(get("/base/validation/aircraft")
                .param("acNum", "YYY")
                .param("airlineCd", "")
                .param("fleet", ""))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$.valid", is("false")))
                .andExpect(jsonPath("$.aircraftNum", is("YYY")));
    }
}