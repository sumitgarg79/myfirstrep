package com.aa.amps.base.user;

import com.aa.amps.base.exception.BaseServiceException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code UserService}.
 *
 * @author Paul Verner (650196)
 * @since 9/13/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class UserServiceTest {
    @Autowired
    UserService userService;
    UserRequest userRequest;
    UserRequest userReq;

    @MockBean
    UserRepository userRepository;

    @Before
    public void setUp() {

    }

    /**
     * Test UserService.loginUser() method for userId that already is in AMPS_USER and AMPS_USER_LOGIN tables
     *
     * @throws Exception
     */
    @Test
    public void loginUserExistingUserTest() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00998765");
        userRequest.setFirstName("NINETY");
        userRequest.setLastName("NINE");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateAmpsUser(userRequest)).willReturn(1);
        given(this.userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateUserLogin(userRequest.getUserId())).willReturn(1);

        boolean success = userService.loginUser(userRequest);
        assertTrue(success);
    }

    /**
     * Test UserService.loginUser() method for userId that does NOT exist in AMPS_USER and AMPS_USER_LOGIN tables
     *
     * @throws Exception
     */
    @Test
    public void loginUserForNewUserTest() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00998000");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(false);
        given(this.userRepository.insertAmpsUser(userRequest)).willReturn(1);
        given(this.userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId())).willReturn(false);
        given(this.userRepository.insertAmpsUserLogin(userRequest.getUserId())).willReturn(1);
        // test loginUser() method for new userId
        boolean success = userService.loginUser(userRequest);
        assertTrue(success);
    }

    @Test(expected = BaseServiceException.class)
    public void loginUser_UpdateAmpsUserException() throws BaseServiceException {

        userRequest = new UserRequest();
        userRequest.setUserId("00998765");
        userRequest.setFirstName("NINETY");
        userRequest.setLastName("NINE");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateAmpsUser(userRequest)).willReturn(2);

        boolean success = userService.loginUser(userRequest);
    }

    @Test(expected = BaseServiceException.class)
    public void loginUser_InsertAmpsUserException() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00998000");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(false);
        given(this.userRepository.insertAmpsUser(userRequest)).willReturn(2);
        boolean success = userService.loginUser(userRequest);
    }

    @Test(expected = BaseServiceException.class)
    public void loginUser_UpdateAmpsUserLoginException() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00998000");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateAmpsUser(userRequest)).willReturn(1);
        given(this.userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateUserLogin(userRequest.getUserId())).willReturn(2);

        boolean success = userService.loginUser(userRequest);
    }

    @Test(expected = BaseServiceException.class)
    public void loginUser_InsertAmpsUserLoginException() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00998000");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");

        given(this.userRepository.userIdExistsInAmpsUser(userRequest.getUserId())).willReturn(true);
        given(this.userRepository.updateAmpsUser(userRequest)).willReturn(1);
        given(this.userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId())).willReturn(false);
        given(this.userRepository.insertAmpsUserLogin(userRequest.getUserId())).willReturn(2);

        boolean success = userService.loginUser(userRequest);
    }
}
