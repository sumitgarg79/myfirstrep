package com.aa.amps.ampsui.restclients;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Unit test class for {@link FleetClientService}.
 *
 * @author Neelabh Tripathi
 * @since 04/23/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class FleetClientServiceTest {

    @Value("${ampsui.fleet.api.url}")
    private String fleetApiUrl;

    @Autowired
    private FleetClientService fleetClientService;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void init() {
        mockServer = MockRestServiceServer.createServer(fleetClientService.getRestTemplate());
    }

    public List<FleetResponseEntity> getFleetSubfleetData() {
        FleetResponseEntity fleet1 = new FleetResponseEntity();

        fleet1.setFleet("737");
        List<String> subfleets2 = new ArrayList<>();
        subfleets2.add("737-300");
        subfleets2.add("737-200");
        fleet1.setSubfleet(subfleets2);
        fleet1.setAirlineCode("LAA");
        fleet1.setValidFleetCode(true);

        List<FleetResponseEntity> response = new ArrayList<>();
        response.add(fleet1);

        return response;
    }

    @Test
    public void getAllFleets() throws URISyntaxException, JsonProcessingException {

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(fleetApiUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(getFleetSubfleetData()))
                );

        List<FleetResponseEntity> fleetClientResponse = fleetClientService.getAllFleets();

        mockServer.verify();
        assertThat(fleetClientResponse).isNotEmpty().hasSize(1);
        assertThat(fleetClientResponse.get(0).getFleet()).isNotBlank().isEqualToIgnoringCase("737");
    }


    @Test
    public void getAllFleets_NullResponseBody() throws URISyntaxException, JsonProcessingException {

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(fleetApiUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(null))
                );

        List<FleetResponseEntity> fleetClientResponse = fleetClientService.getAllFleets();

        mockServer.verify();
        assertThat(fleetClientResponse).isEmpty();
    }


    @Test
    public void getFleets_LAA() throws URISyntaxException, JsonProcessingException {
        final String AIRLINE_LAA = "LAA";
        String aircraftUrlWithAirline = fleetApiUrl + "?airlineCd=" + AIRLINE_LAA;

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftUrlWithAirline)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(getFleetSubfleetData()))
                );

        List<FleetResponseEntity> fleetClientResponse = fleetClientService.getFleets(AIRLINE_LAA);

        mockServer.verify();
        assertThat(fleetClientResponse).isNotEmpty().hasSize(1);
        assertThat(fleetClientResponse.get(0).getFleet()).isNotBlank().isEqualToIgnoringCase("737");
    }


    @Test
    public void getFleets_NullResponseBody() throws URISyntaxException, JsonProcessingException {
        final String AIRLINE_LAA = "LAA";
        String aircraftUrlWithAirline = fleetApiUrl + "?airlineCd=" + AIRLINE_LAA;

        mockServer.expect(ExpectedCount.once(),
                          requestTo(new URI(aircraftUrlWithAirline)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(null))
                );

        List<FleetResponseEntity> fleetClientResponse = fleetClientService.getFleets(AIRLINE_LAA);

        mockServer.verify();
        assertThat(fleetClientResponse).isEmpty();
    }
}