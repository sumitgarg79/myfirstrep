package com.aa.amps.cwlv.accessControl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.FileNotFoundException;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for AccessControlRepository
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AccessControlRepositoryTest {

    @Autowired
    private AccessControlRepository accessControlRepository;

    @Before
    public void setUp() {
    }

    @Test
    public void getAppList() throws Exception {
        int roleId = 54;
        String result = accessControlRepository.getAppList(roleId);
        assertThat(result).isNotNull();
        assertThat(result.contains("AMPS CWV")).isTrue();
    }

    @Test(expected = FileNotFoundException.class)
    public void getAppListException() throws Exception {
        accessControlRepository.getAppList(1);
    }

    @Test
    public void getRoleAppAccess() throws Exception {
        int roleId = 54;
        String appName = "CWLV";
        String result = accessControlRepository.getRoleAccess(roleId, appName);
        assertThat(result).isNotNull();
        assertThat(result.contains("BASE_PLANNER")).isTrue();
    }

    @Test(expected = FileNotFoundException.class)
    public void getRoleAppAccessException() throws Exception {
        String appName = "CWLV";
        accessControlRepository.getRoleAccess(1, appName);
    }
}