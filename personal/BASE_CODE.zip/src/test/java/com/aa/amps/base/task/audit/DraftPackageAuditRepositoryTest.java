package com.aa.amps.base.task.audit;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.task.TaskConstants.*;
import static com.aa.amps.base.util.BaseRepositoryConstants.*;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class DraftPackageAuditRepositoryTest {
    @Autowired
    private DraftPackageAuditRepository draftPackageAuditRepository;

    private Map<String, Object> parameterMap;
    private List<Map<String, Object>> insertParameterMapList;

    @Before
    public void setUp() {
        //Draft Work Package
        parameterMap = new HashMap<>();
        parameterMap.put(WORK_PACKAGE_ID, "2424");
        parameterMap.put(AIRCRAFT_NUMBER, "952");
        parameterMap.put(PKG_SCHD_DATE, "09-06-2018");
        parameterMap.put(STATION_CODE, "DFW");
        parameterMap.put(TRACK_TYPE_CODE, "1");
        parameterMap.put(SPAN, "2");
        parameterMap.put(WORK_ORDER_JOB_CODE, "4004");
        parameterMap.put(SCEPTRE_MNTNC_WORK_PKG_ID, "44");
        parameterMap.put(DOCK_CODE, "DC");
        parameterMap.put(WORK_PKG_TXT, "Test");
        parameterMap.put(WORK_PKG_STATUS_CODE, "C");
        parameterMap.put(WORK_PACKAGE_TASK_STATUS, "D");
        parameterMap.put(COMMENTS, "TEST");
        parameterMap.put(USER_ID, "292147");

        //Tasks
        insertParameterMapList = new ArrayList<>();
        Map<String, Object> taskParameterMap;
        taskParameterMap = new HashMap<>();
        taskParameterMap.put(WORK_PACKAGE_ID, "2424");
        taskParameterMap.put(AIRCRAFT_NUMBER, "952");
        taskParameterMap.put(TASK_ID, "2424");
        taskParameterMap.put(ROUTE_CONTROL_CODE, "A");
        taskParameterMap.put(DNI, TRUE);
        taskParameterMap.put(DEFERRAL_LOCK_INDICATOR, FALSE);
        taskParameterMap.put(WORK_PACKAGE_TASK_STATUS, CREATE);
        taskParameterMap.put(WORK_PACKAGE_TASK_STATUS, "D");
        taskParameterMap.put(USER_ID, "1234");
        insertParameterMapList.add(taskParameterMap);
    }

    /**
     * Test case for audit of draft work package.
     */
    @Test
    public void createDraftPackageAuditTest() {
        int rowCount = draftPackageAuditRepository.createDraftPackageAudit(parameterMap);
        assertEquals(1, rowCount);
    }

    /**
     * Test case for audit of draft work package tasks.
     */
    @Test
    public void createDraftPackageTaskAuditTest() {
        int[] rowCount = draftPackageAuditRepository.createDraftPackageTaskAudit(insertParameterMapList.toArray(new HashMap[insertParameterMapList.size()]));
        assertEquals(1, rowCount[0]);
    }

    /**
     * Test case for audit of deleted work package.
     */
    @Test
    public void createDraftPackageAuditForDeleteTest() {
        int rowCount = draftPackageAuditRepository.createDraftPackageAuditForDelete(parameterMap);
        assertEquals(1, rowCount);
    }

    /**
     * Test case for audit of deleted work package tasks.
     */
    @Test
    public void createDraftPackageTaskAuditForDeleteTest() {
        int rowCount = draftPackageAuditRepository.createDraftPackageTaskAuditForDelete(parameterMap);
        assertEquals(1, rowCount);
    }

}
