package com.aa.amps.base.preset;

import com.aa.amps.base.exception.BaseRepositoryException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.aa.amps.base.exception.BaseRepositoryException.*;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.*;


/**
 * Test class for {@Link PresetService}.
 *
 * @author Ramesh Rudra(842020)
 * @since on 8/20/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class PresetServiceTest {

    private static final String SEARCH_TXT = "\"{\\\"pageCount\\\":0,\\\"searchCriteria\\\"" +
            ":{\\\"statusPlanned\\\":true,\\\"sortedItems\\\":[\\\"FleetCode\\\"" +
            ",\\\"AircraftNum\\\",\\\"Criticality\\\"],\\\"allowOTRTypes\\\":false" +
            ",\\\"fleetCode\\\":[787],\\\"airlineCode\\\":\\\"US\\\",\\\"statusOpen\\\"" +
            ":true,\\\"recordCount\\\":false}}\"";

    public static final String USER_ID = "842020";
    public static final String SEARCH_CRITER_TXT = "myTest1";
    List<PresetResponse> presetResponses;
    List<PresetEntity> presetEntities;

    @Autowired
    private PresetService presetService;
    @MockBean
    private PresetRepository presetRepository;

    @Before
    public void setUp() {
        presetResponses = new ArrayList<>();
        PresetResponse response = new PresetResponse();
        response.setSno("345");
        response.setPresetCreatedDt("10-07-18");
        response.setPresetData("abc");
        response.setPresetDesc("description");
        response.setPresetTypeCd("F");
        response.setPresetUpdatedDt("10-07-18");
        presetResponses.add(response);

        presetEntities = new ArrayList<>();
        PresetEntity entity = new PresetEntity();
        entity.setUserId("84200");
        entity.setActlSelectTxt("abc");
        entity.setSearchCriterId(2);
        entity.setSearchCriterTypeCd("F");
        presetEntities.add(entity);
    }

    @Test
    public void findByUserIdAndSearchCriterTypeCd() {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                presetRequest
                        .getSearchCriterCd())).willReturn(presetEntities);

        final List<PresetResponse> response = presetService.findByUserIdAndSearchCriterTypeCd(presetRequest);

        assertThat(response.size()).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get(0).getPresetTypeCd()).isEqualTo("F");

    }

    @Test
    public void addPreset() throws BaseRepositoryException {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);


        PresetEntity entity = new PresetEntity(presetRequest);

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                presetRequest
                        .getSearchCriterCd())).willReturn(presetEntities);
        given(this.presetRepository.getMaxOfSearchCriterId(presetRequest.getUserId(), presetRequest
                .getSearchCriterCd())).willReturn((long) 1);
        given(this.presetRepository.save(entity)).willReturn(entity);

        final List<PresetResponse> response = presetService.addPreset(presetRequest);

        assertThat(response.size()).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get(0).getPresetTypeCd()).isEqualTo("F");

    }


    @Test
    public void updatePreset() throws BaseRepositoryException {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        PresetEntity entity = new PresetEntity(presetRequest);

        given(this.presetRepository.findByUserIdAndSearchCriterIdAndSearchCriterTypeCd(presetRequest.getUserId(), presetRequest
                .getSearchCriterId(), presetRequest.getSearchCriterCd())).willReturn(entity);
        given(this.presetRepository.save(entity)).willReturn(entity);

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                presetRequest
                        .getSearchCriterCd())).willReturn(presetEntities);

        final List<PresetResponse> response = presetService.updatePreset(presetRequest);

        assertThat(response.size()).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get(0).getPresetTypeCd()).isEqualTo("F");

    }

    @Test
    public void updatePresetRecordNotExsist() {

        boolean result = false;

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        PresetEntity entity = new PresetEntity(presetRequest);

        given(this.presetRepository.findByUserIdAndSearchCriterIdAndSearchCriterTypeCd(presetRequest.getUserId(), presetRequest
                .getSearchCriterId(), presetRequest.getSearchCriterCd())).willReturn(null);
        given(this.presetRepository.save(entity)).willReturn(entity);

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                presetRequest
                        .getSearchCriterCd())).willReturn(presetEntities);

        try {
            presetService.updatePreset(presetRequest);
        } catch (Exception e) {
            result = true;
        }

        assertThat(result).isEqualTo(true);
    }

    @Test
    public void deletePreset() throws BaseRepositoryException {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);


        given(this.presetRepository.deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd(presetRequest.getUserId(), presetRequest
                .getSearchCriterId(), presetRequest.getSearchCriterCd())).willReturn(1);

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                presetRequest
                        .getSearchCriterCd())).willReturn(presetEntities);

        final List<PresetResponse> response = presetService.deletePreset(presetRequest);

        assertThat(response.size()).isNotNull();
        assertThat(response.size()).isEqualTo(1);
        assertThat(response.get(0).getPresetTypeCd()).isEqualTo("F");

    }

    @Test
    public void getNextId() throws BaseRepositoryException {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        given(this.presetRepository.getMaxOfSearchCriterId(presetRequest.getUserId(), presetRequest.getSearchCriterCd())).willReturn((long) 1);

        final int nextId = presetService.getNextId(presetRequest);
        assertThat(nextId).isNotNull();
        assertThat(nextId).isEqualTo(2);
    }

    @Test
    public void getNextIdThrowsException() throws BaseRepositoryException {

        PresetRequest presetRequest = null;

        try {
            presetService.getNextId(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from getNextId() method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_ADD_FAILED);
        }
    }

    @Test
    public void addPresetExceptionWhenRecordAddFailed() {
        willReturn(null).given(presetRepository).findByUserIdAndSearchCriterTypeCd(BDDMockito
                .anyString(), BDDMockito.anyString());
        willAnswer(invocation -> {
            throw new BaseRepositoryException(RECORD_ADD_FAILED, null);
        }).given(presetRepository)
                .save(BDDMockito.any());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("B");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_CRITER_TXT);
        presetRequest.setActlSelectTxt(SEARCH_TXT);

        try {
            presetService.addPreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from addPreset Failed..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_ADD_FAILED);
        }
    }

    @Test
    public void addPresetAlreadyExistException() {
        PresetEntity presetEntity = new PresetEntity();
        presetEntity.setSearchCriterTxt(SEARCH_CRITER_TXT);
        willReturn(Arrays.asList(presetEntity)).given(presetRepository).findByUserIdAndSearchCriterTypeCd
                (BDDMockito.anyString(), BDDMockito.anyString());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setUserId("842018");
        presetRequest.setSearchCriterCd("B");
        presetRequest.setSearchCriterTxt(SEARCH_CRITER_TXT);

        try {
            presetService.addPreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from addPreset method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_EXIST);
        }
    }

    @Test
    public void updatePresetExceptionWhenRecordUpdateFailed() {
        PresetEntity presetEntity = new PresetEntity();
        presetEntity.setSearchCriterTxt(SEARCH_CRITER_TXT);
        willReturn(presetEntity).given(presetRepository).findByUserIdAndSearchCriterIdAndSearchCriterTypeCd
                (BDDMockito.anyString(), BDDMockito.anyInt(), BDDMockito.anyString());

        willAnswer(invocation -> {
            throw new BaseRepositoryException(RECORD_UPDATE_FAILED, null);
        }).given(presetRepository)
                .save(BDDMockito.any());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("B");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_CRITER_TXT);
        presetRequest.setActlSelectTxt(SEARCH_TXT);

        try {
            presetService.updatePreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from updatePreset method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_UPDATE_FAILED);
        }
    }

    @Test
    public void updatePresetRecordNotFound() {
        willReturn(null).given(presetRepository).findByUserIdAndSearchCriterIdAndSearchCriterTypeCd
                (BDDMockito.anyString(), BDDMockito.anyInt(), BDDMockito.anyString());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("B");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_CRITER_TXT);

        try {
            presetService.updatePreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from updatePreset method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_NOT_FOUND_DESC);
        }
    }

    @Test
    public void deletePresetExceptionWhenRecordDeleteFailed() {

        willReturn(0).given(presetRepository).deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd
                (BDDMockito.anyString(), BDDMockito.anyInt(), BDDMockito.anyString());

        willAnswer(invocation -> {
            throw new BaseRepositoryException(RECORD_DELETE_FAILED, null);
        }).given(presetRepository).deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd(BDDMockito.anyString(),
                BDDMockito.anyInt(), BDDMockito.anyString());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("B");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_CRITER_TXT);
        presetRequest.setActlSelectTxt(SEARCH_TXT);

        try {
            presetService.deletePreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from deletePreset method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), RECORD_DELETE_FAILED);
        }
    }

    @Test
    public void addPresetMaxPresetExceed() {
        willReturn(Long.valueOf("16")).given(presetRepository).countByUserIdAndSearchCriterTypeCd(BDDMockito.anyString(), BDDMockito.anyString());

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setUserId("842018");
        presetRequest.setSearchCriterTxt("myTest112");
        presetRequest.setSearchCriterCd("B");

        try {
            presetService.addPreset(presetRequest);
            fail("Expected BaseRepositoryException to be throwm from addPreset method..");
        } catch (BaseRepositoryException e) {
            assertEquals(e.getMessage(), MAX_PRESET_EXCEED);
        }
    }

    @Test
    public void verifyPresetWithDescExist() {
        PresetRequest presetRequest = null;
        Assert.assertFalse(this.presetService.verifyPresetWithDescExist(presetRequest));

        presetRequest = new PresetRequest();
        presetRequest.setUserId("842019");
        presetRequest.setSearchCriterTxt("myTest");
        presetRequest.setSearchCriterCd("B");
        presetRequest.setSearchCriterId(1);

        PresetEntity presetEntity = new PresetEntity();
        presetEntity.setSearchCriterTxt("myTest");

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCd(BDDMockito.anyString(),
                BDDMockito.anyString())).willReturn(Arrays.asList(presetEntity));

        assertTrue(this.presetService.verifyPresetWithDescExist(presetRequest));

        given(this.presetRepository.findByUserIdAndSearchCriterTypeCd(BDDMockito.anyString(),
                BDDMockito.anyString())).willReturn(null);

        Assert.assertFalse(this.presetService.verifyPresetWithDescExist(presetRequest));
    }
}