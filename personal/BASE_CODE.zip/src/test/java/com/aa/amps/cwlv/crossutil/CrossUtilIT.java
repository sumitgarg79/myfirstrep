package com.aa.amps.cwlv.crossutil;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static com.aa.amps.cwlv.crossutil.CrossUtilService.CROSS_UTIL_STATION_DEL;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseDescription.*;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatus.EXCEPTION;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatus.SUCCESS;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for all the API endpoints defined in class {@link CrossUtilController}.
 *
 * @author Neelabh Tripathi(847697)
 * created on 3/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class CrossUtilIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                                                  MediaType.APPLICATION_JSON.getSubtype(),
                                                  Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
            .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
            .findAny()
            .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                      this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void getCrossUtilDetails() throws Exception {
        mockMvc.perform(get("/xutil" + "/getAll"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", not(0)))
            .andExpect(jsonPath("$[0].activeFlag", is("Y")));
    }


    @Test
    public void getCrossUtilStation() throws Exception {
        mockMvc.perform(get("/xutil" + "/getAllStations"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", not(0)))
            .andExpect(jsonPath("$[0]", is("CLT")));
    }

    @Test
    public void getCrossUtilStationsForCwv() throws Exception {
        mockMvc.perform(get("/xutil/getAllStationsCwv"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", not(0)))
            .andExpect(jsonPath("$[0].text", is("CLT")))
            .andExpect(jsonPath("$[0].checked", is(false)));
    }

    /**
     * Integration test for update endpoint. This is the <i>Happy Path</i> scenario. The response expected is HTTP
     * response status 200(OK).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_Success() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("DFW");
        request.setRonCapacity(2999L);
        request.setRodCapacity(999L);
        request.setCrossUtilFlag('Y');
        request.setUserId("847697");

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status", is(SUCCESS.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(RECORD_UPDATED_SUCCESSSFULLY.toString())));
    }

    /**
     * Integration test for update endpoint. This is the <b>Record Not Found</b> scenario. The response expected is
     * HTTP Status 404(NOT FOUND).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_RecordNotFound() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("ZXY");
        request.setRonCapacity(7989L);
        request.setRodCapacity(7999L);
        request.setCrossUtilFlag('Y');
        request.setUserId("847697");

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status", is(EXCEPTION.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(RECORD_NOT_FOUND_DESC.toString())));
    }

    /**
     * Integration test for update endpoint. This is the <b>RON Capacity is set to 0</b> scenario. The response
     * expected is HTTP Status 404(NOT FOUND).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_RonSetToZero() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("DFW");
        request.setRonCapacity(0L);
        request.setRodCapacity(7999L);
        request.setCrossUtilFlag('Y');
        request.setUserId("847697");

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status", is(SUCCESS.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(RECORD_UPDATED_SUCCESSSFULLY.toString())));
    }

    /**
     * Integration test for update endpoint. This is the <b>RON Capacity is set to negative</b> scenario. The response
     * expected is HTTP Status 404(NOT FOUND) along with JSON response with "status" as "EXCEPTION".
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_RonSetToNegative() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("ZXY");
        request.setRonCapacity(-10L);
        request.setRodCapacity(7999L);
        request.setCrossUtilFlag('Y');

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isNotFound())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$.status", is(EXCEPTION.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(CrossUtilService.RON_CAPACITY_INVALID)));
    }

    /**
     * Integration test for update endpoint. This is the <b>ROD Capacity is set to negative</b> scenario. The response
     * expected is HTTP Status 404(NOT FOUND) along with JSON response with "status" as "EXCEPTION".
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_RodSetToNegative() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("DFW");
        request.setRonCapacity(100L);
        request.setRodCapacity(-7999L);
        request.setCrossUtilFlag('Y');

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isNotFound())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$.status", is(EXCEPTION.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(CrossUtilService.ROD_CAPACITY_INVALID)));
    }

    /**
     * Integration test for update endpoint. This is the <b>ROD Capacity is set to negative</b> scenario. The response
     * expected is HTTP Status 404(NOT FOUND) along with JSON response with "status" as "EXCEPTION".
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_CrossUtilFlagInvalid() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("DFW");
        request.setRonCapacity(100L);
        request.setRodCapacity(7999L);
        request.setCrossUtilFlag('Z');

        String updateRequestJson = json(request);
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(updateRequestJson))
            .andExpect(status().isNotFound())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$.status", is(EXCEPTION.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(CrossUtilService.CROSS_UTIL_FLAG_INVALID)));
    }

    /**
     * Integration test for update endpoint. This is the <b>Malformed Request JSON</b> scenario. The response
     * expected is HTTP Status 404(NOT FOUND).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_MalformedJsonRequestBody() throws Exception {
        String malformedUpdateRequestJson = "{\n" +
            "    \"mntncStn\": \"CLL\",\n" +
            "    \"crossUtil\": \"Y\",\n" +
            "    \"rodCapay\": 1999,\n" +
            "    \"ronCapacy\": 6777,\n" +
            "    \"actiag\": \"Y\"\n" +
            "}";
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType)
                            .content(malformedUpdateRequestJson))
            .andExpect(status().isNotFound());
    }

    /**
     * Integration test for update endpoint. This is the <b>Empty Request Body(JSON)</b> scenario. The response
     * expected is HTTP Status 400(BAD REQUEST).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void updateCrossUtilRecord_EmptyRequestBody() throws Exception {
        mockMvc.perform(put("/xutil" + "/update")
                            .contentType(contentType))
            .andExpect(status().isBadRequest());
    }


    /**
     * Integration test for SAVE STATION endpoint. This is the <i>Happy Path</i> scenario. The response expected is HTTP
     * response status 202(ACCEPTED).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void createStation_Success() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("XYZ");
        request.setRonCapacity(2999L);
        request.setRodCapacity(999L);
        request.setCrossUtilFlag('Y');
        request.setUserId("847697");

        String addRequestJson = json(request);
        mockMvc.perform(post("/xutil" + "/add")
                            .contentType(contentType)
                            .content(addRequestJson))
            .andExpect(status().isAccepted())
            .andExpect(jsonPath("$.status", is(SUCCESS.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(RECORD_ADDED_SUCCESSSFULLY.toString())));
    }

    /**
     * Integration test for UPDATING EXISTING STATION TO BE CROSS UTIL endpoint. This is the <i>Happy Path</i>
     * scenario. The response expected is HTTP response status 202(ACCEPTED).
     *
     * @throws Exception if there is exception while inserting the record
     */
    @Test
    public void createStation_LowerCaseAndInactiveStation() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("ord");
        request.setRonCapacity(2999L);
        request.setRodCapacity(999L);
        request.setCrossUtilFlag('Y');
        request.setUserId("847697");

        String addRequestJson = json(request);
        mockMvc.perform(post("/xutil" + "/add")
                            .contentType(contentType)
                            .content(addRequestJson))
            .andExpect(status().isAccepted())
            .andExpect(jsonPath("$.status", is(SUCCESS.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(RECORD_ADDED_SUCCESSSFULLY.toString())));
    }

    /**
     * Integration test for SAVING STATION  WHICH IS DUPLICATE RECORD. The response expected is HTTP
     * response status 204(NOT_FOUND).
     *
     * @throws Exception if there is exception while inserting the record
     */
    @Test
    public void createStation_DuplicateRecord() throws Exception {
        CrossUtilEntity request = new CrossUtilEntity();

        request.setMntncStnCode("DFW");
        request.setRonCapacity(2999L);
        request.setRodCapacity(999L);
        request.setCrossUtilFlag('Y');

        String addRequestJson = json(request);
        mockMvc.perform(post("/xutil" + "/add")
                            .contentType(contentType)
                            .content(addRequestJson))
            .andExpect(status().isNotFound())
            .andExpect(jsonPath("$.status", is(EXCEPTION.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(STATION_ALREADY_EXSIST.toString())));
    }

    /**
     * Integration test for DELETING STATION .
     * The response expected is HTTP response status 200(OK).
     */
    @Test
    public void deleteStation_Success() throws Exception {

        mockMvc.perform(delete("/xutil" + "/delete/LAX/847697"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status", is(SUCCESS.toString().toUpperCase())))
            .andExpect(jsonPath("$.message", is(CROSS_UTIL_STATION_DEL)));
        ;
    }

    /**
     * Integration test for DELETING STATION .
     * The response expected is HTTP response status 404(NOTFOUND).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void deleteStation_Failure() throws Exception {

        mockMvc.perform(delete("/xutil" + "/delete/AAA"))
            .andExpect(status().isNotFound());

    }

    /**
     * Integration test for DELETING STATION .
     * The response expected is HTTP response status 404(NOTFOUND).
     *
     * @throws Exception if there is exception while updating the record
     */
    @Test
    public void deleteStation_LowerCase() throws Exception {

        mockMvc.perform(delete("/xutil" + "/delete/dfw"))
            .andExpect(status().isNotFound());
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
            o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }
}
