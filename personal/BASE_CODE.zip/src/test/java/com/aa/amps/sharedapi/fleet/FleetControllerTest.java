package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiServiceException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link FleetController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/19/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class FleetControllerTest {

    @Autowired
    FleetController fleetController;

    @MockBean
    FleetService fleetService;

    List<String> fleetsSetup;

    @Before
    public void setup() {
        fleetsSetup = new ArrayList<>();
        fleetsSetup.add("737");
        fleetsSetup.add("A321");
    }

    public List<FleetSubfleetEntity> fleetSubfleetData() {
        FleetSubfleetEntity fleet1 = new FleetSubfleetEntity();
        fleet1.setFleet("321");
        List<String> subfleets1 = new ArrayList<>();
        subfleets1.add("321-200");
        subfleets1.add("321-E300");
        fleet1.setSubfleet(subfleets1);
        fleet1.setAirlineCode("LUS");
        fleet1.setValidFleetCode(true);

        FleetSubfleetEntity fleet2 = new FleetSubfleetEntity();
        fleet2.setFleet("737");
        List<String> subfleets2 = new ArrayList<>();
        subfleets2.add("737-400");
        subfleets2.add("737-550");
        fleet2.setSubfleet(subfleets2);
        fleet2.setAirlineCode("LAA");
        fleet2.setValidFleetCode(true);

        List<FleetSubfleetEntity> response = new ArrayList<>();
        response.add(fleet1);
        response.add(fleet2);

        return response;
    }

    @Test
    public void getFleets() {
        given(fleetService.getFleets()).willReturn(fleetsSetup);
        List<String> fleets = fleetController.getFleets();

        assertThat(fleets).isNotNull().isNotEmpty();
        assertThat(fleets).hasSize(2);
        assertThat(fleets.get(0)).isEqualToIgnoringCase("737");
    }

    /**
     * Test scenario where no parameter is passed. This will return all the fleets and subfleets.
     */
    @Test
    public void getFleetAndSubfleetWithParams() throws SharedApiServiceException {
        given(fleetService.getFleetSubfleets()).willReturn(fleetSubfleetData());

        List<FleetSubfleetEntity> fleetResponse = fleetController.getFleetAndSubfleetWithParams(null, null);
        assertThat(fleetResponse).isNotNull().isNotEmpty();
        assertThat(fleetResponse).hasSize(2);

        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isEqualToIgnoringCase("321");
        assertThat(fleetResponse.get(0).getSubfleet()).isNotNull().hasSize(2);

        assertThat(fleetResponse.get(1)).isNotNull();
        assertThat(fleetResponse.get(1).getFleet()).isNotNull().isEqualToIgnoringCase("737");
        assertThat(fleetResponse.get(1).getSubfleet()).isNotNull().hasSize(2);
    }

    /**
     * Test scenario where both parameters are passed.
     */
    @Test
    public void getFleetAndSubfleetWithParams_FleetAndAirlineCdProvided() throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetServiceResponse = fleetSubfleetData();
        fleetServiceResponse.remove(1);

        Set<String> fleetInput = new HashSet<>();
        fleetInput.add("321");

        given(fleetService.getFleetSubfleets("LUS", new ArrayList<>(fleetInput))).willReturn(fleetServiceResponse);

        List<FleetSubfleetEntity> fleetResponse = fleetController.getFleetAndSubfleetWithParams("LUS", fleetInput);

        assertThat(fleetResponse).isNotNull().isNotEmpty();
        assertThat(fleetResponse).hasSize(1);

        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isEqualToIgnoringCase("321");
        assertThat(fleetResponse.get(0).getSubfleet()).isNotNull().hasSize(2);
        assertThat(fleetResponse.get(0).getAirlineCode()).isNotNull().isEqualToIgnoringCase("LUS");
    }

    /**
     * Test scenario where only fleet parameters is passed.
     */
    @Test
    public void getFleetAndSubfleetWithParams_FleetOnlyProvided() throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetServiceResponse = fleetSubfleetData();

        Set<String> fleetInput = new HashSet<>();
        fleetInput.add("321");
        fleetInput.add("737");

        given(fleetService.getFleetSubfleets(new ArrayList<>(fleetInput))).willReturn(fleetServiceResponse);

        List<FleetSubfleetEntity> fleetResponse = fleetController.getFleetAndSubfleetWithParams(null, fleetInput);

        assertThat(fleetResponse).isNotNull().isNotEmpty();
        assertThat(fleetResponse).hasSize(2);

        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isEqualToIgnoringCase("321");
        assertThat(fleetResponse.get(0).getSubfleet()).isNotNull().hasSize(2);

        assertThat(fleetResponse.get(1)).isNotNull();
        assertThat(fleetResponse.get(1).getFleet()).isNotNull().isEqualToIgnoringCase("737");
        assertThat(fleetResponse.get(1).getSubfleet()).isNotNull().hasSize(2);
    }

    /**
     * Test scenario where only airline code parameters is passed.
     */
    @Test
    public void getFleetAndSubfleetWithParams_AirlineCdOnlyProvided() throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetServiceResponse = fleetSubfleetData();
        fleetServiceResponse.remove(0);

        given(fleetService.getFleetSubfleets("LAA")).willReturn(fleetServiceResponse);

        List<FleetSubfleetEntity> fleetResponse = fleetController.getFleetAndSubfleetWithParams("LAA", null);

        assertThat(fleetResponse).isNotNull().isNotEmpty();
        assertThat(fleetResponse).hasSize(1);

        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isEqualToIgnoringCase("737");
        assertThat(fleetResponse.get(0).getSubfleet()).isNotNull().hasSize(2);
    }

    @Test
    public void refreshFleets() throws SharedApiServiceException {
        Map<String, String> response = fleetController.refreshFleets();

        assertThat(response).isNotNull().isNotEmpty().hasSize(2);
        assertThat(response.get(FleetController.STATUS))
                .isEqualToIgnoringCase(FleetController.CACHE_REFRESH_STATUS_SUCCESS);
        assertThat(response.get(FleetController.MESSAGE)).isEqualToIgnoringCase(FleetController.CACHE_REFRESH_MESSAGE);
    }
}
