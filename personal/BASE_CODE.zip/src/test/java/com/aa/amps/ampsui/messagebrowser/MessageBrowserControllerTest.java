package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link MessageBrowser}.
 *
 * @author Ramesh Rudra(842020)
 * @since 1/10/2019.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MessageBrowserControllerTest {

    @Autowired
    MessageBrowserController messageBrowserController;

    @MockBean
    MessageBrowserService messageBrowserService;

    public List<MessageBrowser> getMsgListData() {

        List<MessageBrowser> msgList = new ArrayList<>();
        MessageBrowser browser = new MessageBrowser();
        browser.setStationCode("CLT");
        browser.setAircraftNumber("190");
        browser.setAmpsMsgId("21");
        browser.setFleetCode("NULL");

        MessageBrowser browser1 = new MessageBrowser();
        browser1.setAircraftNumber("190");
        browser1.setAmpsMsgId("24");
        browser1.setFleetCode("NULL");

        MessageBrowser browser2 = new MessageBrowser();
        browser2.setAircraftNumber("190");
        browser2.setAmpsMsgId("24");
        browser2.setFleetCode("NULL");

        msgList.add(browser);
        msgList.add(browser1);
        msgList.add(browser2);

        return msgList;
    }

    @Test
    public void getMessageBrowserList() throws AmpsuiServiceException {

        MessageBrowserRequest messageBrowserRequest = new MessageBrowserRequest();
        messageBrowserRequest.setAircraftNumber("3AB");
        Map<String, Object> requestMap = messageBrowserRequest.getSearchCriteriaAsMap();

        given(messageBrowserService.getMessageBrowserList(requestMap)).willReturn(getMsgListData());

        List<MessageBrowser> msgList = messageBrowserService.getMessageBrowserList(requestMap);

        assertThat(msgList).isNotNull().isNotEmpty().hasSize(3);
        assertThat(msgList.get(0).getAircraftNumber()).isNotBlank().isEqualToIgnoringCase("190");

    }

    @Test
    public void deleteMessageBrowser_Success() throws AmpsuiServiceException {
        given(messageBrowserService.deleteMessageBrowser(getMsgListData())).willReturn(true);

        boolean response = messageBrowserController.deleteMessageBrowser(getMsgListData());

        assertThat(response).isNotNull();
        assertThat(response).isEqualTo(Boolean.TRUE);
    }

    @Test
    public void deleteMessageBrowser_Failed() throws AmpsuiServiceException {
        given(messageBrowserService.deleteMessageBrowser(getMsgListData())).willReturn(false);

        boolean response = messageBrowserController.deleteMessageBrowser(getMsgListData());

        assertThat(response).isNotNull();
        assertThat(response).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void updateMessageBrowser_Success() throws AmpsuiServiceException {
        given(messageBrowserService.updateMessageBrowser(getMsgListData())).willReturn(true);

        boolean response = messageBrowserController.updateMessageBrowser(getMsgListData());

        assertThat(response).isNotNull();
        assertThat(response).isEqualTo(Boolean.TRUE);
    }


    @Test
    public void updateMessageBrowser_Failure() throws AmpsuiServiceException {

        given(messageBrowserService.updateMessageBrowser(getMsgListData())).willReturn(false);

        boolean response = messageBrowserController.updateMessageBrowser(getMsgListData());

        assertThat(response).isNotNull();
        assertThat(response).isEqualTo(Boolean.FALSE);
    }
}