package com.aa.amps.cwlv.accessControl;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test Class for AccessControlService
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AccessControlServiceTest {

    @Autowired
    private AccessControlService accessControlService;

    @MockBean
    private AccessControlRepository accessControlRepository;

    private String appList;
    private String roleAppAccess;

    @Before
    public void setUp() {
        appList = "[{\"text\":\"AMPS CWLV\",\"url\":\"cwlv\"}]";
        roleAppAccess = "[{\"text\":\"BASE_PLANNER\",\"items\":[{\"text\":\"CLWV\",\"state\":\"enabled\",\"items\":[{\"text\":\"clwv-tab\",\"state\":\"enabled\",\"items\":[{\"text\":\"filter-panel\",\"state\":\"enabled\",\"items\":[{\"text\":\"cwvFilterAircraftCtrl\",\"state\":\"disabled\"}]}]}]}]}]";
    }

    @Test
    public void getAppList_Success() throws Exception {
        int roleId = 1;
        given(this.accessControlRepository.getAppList(roleId)).willReturn(appList);
        String result = accessControlService.getAppList(roleId);
        assertThat(result).isNotNull();
        assertThat(result.contains("AMPS CWLV")).isTrue();
    }

    @Test
    public void getRoleApp_Success() throws Exception {
        int roleId = 1;
        String appName = "CWLV";
        given(this.accessControlRepository.getRoleAccess(roleId, appName)).willReturn(roleAppAccess);
        String result = accessControlService.getRoleAccess(roleId, appName);
        assertThat(result).isNotNull();
        assertThat(result.contains("BASE_PLANNER")).isTrue();
    }
}