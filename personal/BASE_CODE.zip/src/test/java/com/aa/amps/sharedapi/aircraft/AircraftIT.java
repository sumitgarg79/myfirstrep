package com.aa.amps.sharedapi.aircraft;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration Test class for the Aircraft API. Controller of this API is {@link AircraftController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/4/2019.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class AircraftIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                                                  MediaType.APPLICATION_JSON.getSubtype(),
                                                  Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
            .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
            .findAny()
            .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                      this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * /GET endpoint for URI /sharedapi/aircraft.
     * <p>
     * This test case covers the get all aircraft scenario. Expected response in the format -
     * <br>
     * <code>
     * [
     * {
     * "aircraftNumber": "190",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * },
     * {
     * "aircraftNumber": "191",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * }
     * ]
     * </code>
     *
     * @throws Exception if there is any error while retrieving aircraft details
     */
    @Test
    public void getAllAircraft() throws Exception {
        mockMvc.perform(get("/sharedapi/aircraft"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", hasSize(6)))
            .andExpect(jsonPath("$[0].aircraftNumber", is("161")));
    }

    /**
     * /GET endpoint for /sharedapi/aircraft.
     * <p>
     * Passing the query parameter airlineCd as LAA along with the GET request. The URI will look like the following -
     * /sharedapi/aircraft?airlineCd=LAA. Expected response format is -
     *
     * <br>
     * <code>
     * [
     * {
     * "aircraftNumber": "190",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * },
     * {
     * "aircraftNumber": "191",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * }
     * ]
     * </code>
     *
     * @throws Exception if there is any error while retrieving aircraft details
     */
    @Test
    public void getAllAircraft_Laa() throws Exception {
        mockMvc.perform(get("/sharedapi/aircraft?airlineCd=LAA"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", hasSize(3)))
            .andExpect(jsonPath("$[0].aircraftNumber", is("3AB")))
            .andExpect(jsonPath("$[0].airlineCode", is("LAA")))
            .andExpect(jsonPath("$[0].fleet", is("737")))
            .andExpect(jsonPath("$[0].subfleet", is("738D")))
            .andExpect(jsonPath("$[0].sceptreFleetCode", is("")))
            .andExpect(jsonPath("$[1].airlineCode", is("LAA"))) //checking airline code for rest of the entries
            .andExpect(jsonPath("$[2].airlineCode", is("LAA")));
    }

    /**
     * /GET endpoint for URI /sharedapi/aircraft/{aircraftNumber}.
     * <p>
     * A sample request URI will look like - /sharedapi/aircraft/190. The response will be in following format -
     * <br>
     * <code>
     * {
     * "aircraftNumber": "190",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * }
     * </code>
     *
     * @throws Exception if there is any error while retrieving aircraft details
     */
    @Test
    public void getAircraft() throws Exception {
        mockMvc.perform(get("/sharedapi/aircraft/161"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$.aircraftNumber", is("161")))
            .andExpect(jsonPath("$.airlineCode", is("LUS")))
            .andExpect(jsonPath("$.fleet", is("321")))
            .andExpect(jsonPath("$.subfleet", is("321")))
            .andExpect(jsonPath("$.sceptreFleetCode", is("29")));
    }

    /**
     * /POST endpoint for URI /sharedapi/aircraft/refreshCache.
     * <p>
     * This test case covers the refreshing of aircraft cache scenario. After clearing up the cache this endpoint
     * loads the fresh aircraft details from DB. Expected response in the format -
     * <br>
     * <code>
     * [
     * {
     * "aircraftNumber": "190",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * },
     * {
     * "aircraftNumber": "191",
     * "fleet": "321",
     * "subfleet": "321",
     * "airlineCode": "LUS",
     * "sceptreFleetCode": "29"
     * }
     * ]
     * </code>
     *
     * @throws Exception if there is any error while retrieving aircraft details
     */
    @Test
    public void refreshAircraftCache() throws Exception {
        mockMvc.perform(post("/sharedapi/aircraft/refreshCache"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(contentType))
            .andExpect(jsonPath("$", notNullValue()))
            .andExpect(jsonPath("$", hasSize(6)))
            .andExpect(jsonPath("$[0].aircraftNumber", is("161")));
    }


    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
            o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }
}
