package com.aa.amps.base.util.sysparam;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

/**
 * This the test class for {@link SysParamService}.
 *
 * @author HCL (922166)
 * @since 8/28/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class SysParamServiceTest {

    private Map<String, String> sysParamMap;
    private String taskTypeOrderOne;
    private String taskTypeOrderTwo;
    @Autowired
    private SysParamService sysParamService;

    @MockBean
    private SysParamRepository sysParamRepo;

    @Before
    public void setUp() {
        sysParamMap = new HashMap<>();
        taskTypeOrderOne = "ME8,EO,MON,SAD,SIL,ME9,ESI,PSI,TSI,MEL,CDL,NEF,TAC";
        taskTypeOrderTwo = "TI,RSI,ROB,BOR,REM,OPS";
        sysParamMap.put("BASE_TASK_TYPE_ORDER_P1", taskTypeOrderOne);
        sysParamMap.put("BASE_TASK_TYPE_ORDER_P2", taskTypeOrderTwo);
    }

    @Test
    public void getParamValue() {
        given(this.sysParamRepo.refreshMap()).willReturn(sysParamMap);
        String paramValue = sysParamService.getParamValue("BASE_TASK_TYPE_ORDER_P1");
        assertTrue(StringUtils.isNotEmpty(paramValue));
        assertTrue(paramValue.contains("ME8"));
    }

    @Test
    public void getTaskTypeOrder() {
        given(this.sysParamRepo.refreshMap()).willReturn(sysParamMap);
        Map<String, Integer> taskTypesOrder = sysParamService.getTaskTypeOrder();
        assertTrue(!CollectionUtils.isEmpty(taskTypesOrder));
        assertEquals(taskTypesOrder.get("ME8"), new Integer(1));
    }

    @Test
    public void refreshMap() {
        given(this.sysParamRepo.refreshMap()).willReturn(sysParamMap);
        Map<String, String> sysParamMap = sysParamService.refreshSysParamMap();
        assertTrue(!CollectionUtils.isEmpty(sysParamMap));
        assertTrue(StringUtils.isNotEmpty(sysParamMap.get("BASE_TASK_TYPE_ORDER_P1")));
    }

}
