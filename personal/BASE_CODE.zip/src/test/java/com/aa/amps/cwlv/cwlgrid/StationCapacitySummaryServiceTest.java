package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import com.aa.amps.cwlv.crossutil.CrossUtilService;
import com.aa.amps.cwlv.manHours.RodAndRonManHours;
import com.aa.amps.cwlv.manHours.RodAndRonManHrsService;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.FeatureSwitchUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link StationCapacitySummary}.
 *
 * @author  Neelabh Tripathi(847697)
 * @since 5/17/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StationCapacitySummaryServiceTest {
    @Autowired
    private StationCapacitySummaryService stnCapSummService;

    @MockBean
    private RodAndRonManHrsService manHrsService;

    @MockBean
    private CrossUtilService crossUtilService;

    @Autowired
    private FeatureSwitchUtil featureSwitchUtil;

    List<RodAndRonManHours> manHours = new ArrayList<>();
    List<CrossUtilEntity> crossUtilEntities = new ArrayList<>();

    @Before
    public void setUp() throws Exception {
        RodAndRonManHours o1 = new RodAndRonManHours();
        o1.setStation("DFW");
        o1.setRodPriority0(50f);
        o1.setRodPriority1And2(50f);
        o1.setRodPriority3(100f);
        o1.setRodTotalManHours(200f);
        o1.setRonPriority0(50f);
        o1.setRonPriority1And2(50f);
        o1.setRonPriority3(200f);
        o1.setRonTotalManHours(300f);

        RodAndRonManHours o2 = new RodAndRonManHours();
        o2.setStation("CLT");
        o2.setRodPriority0(25f);
        o2.setRodPriority1And2(25f);
        o2.setRodPriority3(50f);
        o2.setRodTotalManHours(100f);
        o2.setRonPriority0(50f);
        o2.setRonPriority1And2(50f);
        o2.setRonPriority3(100f);
        o2.setRonTotalManHours(200f);

        manHours.add(o1);
        manHours.add(o2);

        CrossUtilEntity c1 = new CrossUtilEntity();
        c1.setMntncStnCode("DFW");
        c1.setRonCapacity(500L);
        c1.setRodCapacity(300L);

        CrossUtilEntity c2 = new CrossUtilEntity();
        c2.setMntncStnCode("CLT");
        c2.setRonCapacity(700L);
        c2.setRodCapacity(600L);

        crossUtilEntities.add(c1);
        crossUtilEntities.add(c2);
    }

    @Test
    public void getStationCapacitySumm_Success() {
        List<String> stations = new ArrayList<>();
        stations.add("DFW");
        stations.add("CLT");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        given(this.manHrsService.getTotalManHrs(searchCriteria)).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("500");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("300");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N")){
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("50.0");
        }else{
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("100.0");
        }

        assertThat(result.get(1).getStation()).isEqualToIgnoringCase("CLT");
        assertThat(result.get(1).getRonCapacity()).isEqualTo("700");
        assertThat(result.get(1).getRodCapacity()).isEqualTo("600");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N")) {
            assertThat(result.get(1).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(1).getTotalSchdROD()).isEqualTo("25.0");
        }else{
            assertThat(result.get(1).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(1).getTotalSchdROD()).isEqualTo("50.0");
        }
    }

    @Test
    public void getStationCapacitySumm_StnCodeInLowerCase() {
        List<String> stations = new ArrayList<>();
        stations.add("DFW");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        given(this.manHrsService.getTotalManHrs(Mockito.anyMap())).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("500");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("300");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N"))  {
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("50.0");
        }
        else{
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("100.0");
        }
    }

    @Test
    public void getStationCapacitySumm_StnsWithAndWithoutDataInManHrsAndCrossUtilCap() {
        List<String> stations = new ArrayList<>();
        stations.add("DFW");
        stations.add("MIA");//No man hours or capacity data
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        given(this.manHrsService.getTotalManHrs(searchCriteria)).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);


        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("500");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("300");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N"))  {
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("50.0");
        }else{
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("100.0");
        }

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(1).getStation()).isEqualToIgnoringCase("MIA");
        assertThat(result.get(1).getRonCapacity()).isEqualTo("0");
        assertThat(result.get(1).getRodCapacity()).isEqualTo("0");
        assertThat(result.get(1).getTotalSchdRON()).isEqualTo("0");
        assertThat(result.get(1).getTotalSchdROD()).isEqualTo("0");
    }

    @Test
    public void getStationCapacitySumm_StnWithNoManHrsAndCrossUtilCap() {
        List<String> stations = new ArrayList<>();
        stations.add("MIA");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        given(this.manHrsService.getTotalManHrs(searchCriteria)).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("MIA");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("0");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("0");
        assertThat(result.get(0).getTotalSchdRON()).isEqualTo("0");
        assertThat(result.get(0).getTotalSchdROD()).isEqualTo("0");
    }

    @Test
    public void getStationCapacitySumm_StnWithManHrsButNoCrossUtilCap() {
        List<String> stations = new ArrayList<>();
        stations.add("MIA");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        RodAndRonManHours o1 = new RodAndRonManHours();
        o1.setStation("MIA");
        o1.setRonPriority0(50f);
        o1.setRonPriority1And2(50f);
        o1.setRonPriority3(200f);
        o1.setRonTotalManHours(300f);
        o1.setRodPriority0(50f);
        o1.setRodPriority1And2(50f);
        o1.setRodPriority3(100f);
        o1.setRodTotalManHours(200f);

        manHours.add(o1);

        given(this.manHrsService.getTotalManHrs(searchCriteria)).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("MIA");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("0");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("0");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N")) {
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("50.0");
        }
        else{
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("100.0");
        }

        manHours.remove(2); //clean-up
    }

    @Test
    public void getStationCapacitySumm_StnWithCrossUtilCapButNoManHrs() {
        List<String> stations = new ArrayList<>();
        stations.add("MIA");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        CrossUtilEntity o1 = new CrossUtilEntity();
        o1.setMntncStnCode("MIA");
        o1.setRonCapacity(500L);
        o1.setRodCapacity(300L);

        crossUtilEntities.add(o1);

        given(this.manHrsService.getTotalManHrs(searchCriteria)).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(1);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("MIA");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("500");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("300");
        assertThat(result.get(0).getTotalSchdRON()).isEqualTo("0");
        assertThat(result.get(0).getTotalSchdROD()).isEqualTo("0");

        crossUtilEntities.remove(2); //clean-up
    }

    @Test
    public void getStationCapacitySumm_EmptyStnList() {
        List<String> stations = new ArrayList<>();
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(0);
    }

    @Test
    public void getStationCapacitySumm_NullStnList() {
        List<String> stations = null;
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(0);
    }

    @Test
    public void getStationCapacitySumm_EmptyDate() {
        List<String> stations = new ArrayList<>();
        String date = "";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        List<StationCapacitySummary> result = stnCapSummService.getStationCapacitySumm(searchCriteria);

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(0);
    }

    @Test
    public void getStationCapacitySummAsync() throws ExecutionException, InterruptedException {
        List<String> stations = new ArrayList<>();
        stations.add("DFW");
        stations.add("CLT");
        String date = "2018-05-17";

        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);
        searchCriteria.put(Constants.STATION_PLANNED, stations);

        given(this.manHrsService.getTotalManHrs(Mockito.anyMap())).willReturn(manHours);
        given(this.crossUtilService.getCrossUtililzionDetails()).willReturn(crossUtilEntities);

        CompletableFuture<List<StationCapacitySummary>> futuresResult = stnCapSummService.getStationCapacitySummAsync
            (searchCriteria);

        List<StationCapacitySummary> result = futuresResult.get();

        assertThat(result).isNotNull();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
        assertThat(result.get(0).getRonCapacity()).isEqualTo("500");
        assertThat(result.get(0).getRodCapacity()).isEqualTo("300");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N"))  {
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("50.0");
        }
        else{
            assertThat(result.get(0).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(0).getTotalSchdROD()).isEqualTo("100.0");
        }
        assertThat(result.get(1).getStation()).isEqualToIgnoringCase("CLT");
        assertThat(result.get(1).getRonCapacity()).isEqualTo("700");
        assertThat(result.get(1).getRodCapacity()).isEqualTo("600");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N"))  {
            assertThat(result.get(1).getTotalSchdRON()).isEqualTo("50.0");
            assertThat(result.get(1).getTotalSchdROD()).isEqualTo("25.0");
        }else{
            assertThat(result.get(1).getTotalSchdRON()).isEqualTo("100.0");
            assertThat(result.get(1).getTotalSchdROD()).isEqualTo("50.0");
        }
    }
}
