package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiRepositoryException;
import com.aa.amps.sharedapi.exception.SharedApiServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link FleetService}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/19/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class FleetServiceTest {
    @Autowired
    FleetService fleetService;

    @MockBean
    FleetRepository fleetRepository;

    @Test
    public void getFleets() {
        List<java.lang.String> fleetsSetup = new ArrayList<>();
        fleetsSetup.add("737");
        fleetsSetup.add("767");
        fleetsSetup.add("A321");

        given(fleetRepository.getFleets()).willReturn(fleetsSetup);

        List<java.lang.String> fleets = fleetService.getFleets();
        assertThat(fleets).isNotNull().isNotEmpty();
        assertThat(fleets).hasSize(3);
        assertThat(fleets.get(0)).isEqualToIgnoringCase("737");
    }

    public List<FleetSubfleetEntity> fleetSubfleetData() {
        FleetSubfleetEntity fleet1 = new FleetSubfleetEntity();
        fleet1.setFleet("321");
        List<String> subfleets1 = new ArrayList<>();
        subfleets1.add("321-200");
        subfleets1.add("321-E300");
        fleet1.setSubfleet(subfleets1);
        fleet1.setAirlineCode("LUS");
        fleet1.setValidFleetCode(true);

        FleetSubfleetEntity fleet2 = new FleetSubfleetEntity();
        fleet2.setFleet("737");
        List<String> subfleets2 = new ArrayList<>();
        subfleets2.add("737-400");
        subfleets2.add("737-550");
        fleet2.setSubfleet(subfleets2);
        fleet2.setAirlineCode("LAA");
        fleet2.setValidFleetCode(true);

        List<FleetSubfleetEntity> response = new ArrayList<>();
        response.add(fleet1);
        response.add(fleet2);

        return response;
    }


    /**
     * Test case for getFleetSubfleets()
     */
    @Test
    public void getFleetSubfleets() throws SharedApiRepositoryException, SharedApiServiceException {
        given(fleetRepository.getFleetsAndSubfleets()).willReturn(fleetSubfleetData());

        List<FleetSubfleetEntity> fleetDetails = fleetService.getFleetSubfleets();
        assertThat(fleetDetails).isNotNull().isNotEmpty().hasSize(2);
        assertThat(fleetDetails.get(0).getFleet()).isEqualToIgnoringCase("321");

        assertThat(fleetDetails.get(0).getSubfleet()).isNotNull().isNotEmpty().hasSize(2);
        assertThat(fleetDetails.get(0).getSubfleet().get(0)).isEqualToIgnoringCase("321-200");

        assertThat(fleetDetails.get(0).getAirlineCode()).isNotNull().isNotEmpty().isEqualToIgnoringCase("LUS");
    }

    /**
     * Scenario where repository method calls throws SharedApiRepositoryException. SharedApiServiceException is expected
     * from the service class.
     */
    @Test(expected = SharedApiServiceException.class)
    public void getFleetSubfleets_Exception() throws SharedApiRepositoryException, SharedApiServiceException {
        given(fleetRepository.getFleetsAndSubfleets()).willThrow(SharedApiRepositoryException.class);

        fleetService.getFleetSubfleets();
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode). Happy Path scenario.
     */
    @Test
    public void getFleetSubfleets_AirlineCodeAsInput() throws SharedApiRepositoryException, SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("LUS");

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isEqualToIgnoringCase("321");
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode). Input is null.
     */
    @Test
    public void getFleetSubfleets_AirlineCodeInputAsNullString() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("");

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0).getAirlineCode()).isEmpty();
        assertThat(fleetResponse.get(0).getFleet()).isNull();
        assertThat(fleetResponse.get(0).getSubfleet()).isNull();
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode) where input is not either LAA or LUS.
     */
    @Test
    public void getFleetSubfleets_AirlineCodeInputInvalid() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("XYZ");

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase("XYZ");
        assertThat(fleetResponse.get(0).getFleet()).isNull();
        assertThat(fleetResponse.get(0).getSubfleet()).isNull();
    }

    /**
     * Test case for getFleetSubfleets(List<String> fleetToSearch). Happy Path scenario.
     */
    @Test
    public void getFleetSubfleets_FleetCodesAsInput() throws SharedApiRepositoryException, SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetsToSearch = new ArrayList<>();
        fleetsToSearch.add("737");

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets(fleetsToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isEqualToIgnoringCase("737");
    }

    /**
     * Test case for getFleetSubfleets(List<String> fleetToSearch). Passing list as input invalid fleet code e.g., 999.
     */
    @Test
    public void getFleetSubfleets_FleetCodesInputInvalidFleetCode() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetsToSearch = new ArrayList<>();
        fleetsToSearch.add("999");

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets(fleetsToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isNotEmpty().isEqualToIgnoringCase("999");
        assertThat(fleetResponse.get(0).isValidFleetCode()).isFalse();
    }

    /**
     * Test case for getFleetSubfleets(List<String> fleetToSearch). Passing list as input invalid fleet code e.g., 999.
     */
    @Test
    public void getFleetSubfleets_FleetCodesInputValidAndInvalidFleetCode() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetsToSearch = new ArrayList<>();
        fleetsToSearch.add("737");
        fleetsToSearch.add("999");

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets(fleetsToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(2);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNotNull().isNotEmpty().isEqualToIgnoringCase("737");
        assertThat(fleetResponse.get(0).isValidFleetCode()).isTrue();

        assertThat(fleetResponse.get(1)).isNotNull();
        assertThat(fleetResponse.get(1).getFleet()).isNotNull().isNotEmpty().isEqualToIgnoringCase("999");
        assertThat(fleetResponse.get(1).getSubfleet()).isNull();
        assertThat(fleetResponse.get(1).getAirlineCode()).isNull();
        assertThat(fleetResponse.get(1).isValidFleetCode()).isFalse();
    }

    /**
     * Test case for getFleetSubfleets(List<String> fleetToSearch). Passing Empty list as input.
     */
    @Test
    public void getFleetSubfleets_FleetCodesInputAsEmptyList() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetsToSearch = new ArrayList<>();

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets(fleetsToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNull();
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode, List<String> fleetsToSearch). Happy Path scenario.
     */
    @Test
    public void getFleetSubfleets_AirlineCdAndFleetsAsInput() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetCodesToSearch = new ArrayList<>();
        fleetCodesToSearch.add("737");

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("LAA", fleetCodesToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isEqualToIgnoringCase("737");
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode, List<String> fleetsToSearch). Scenario is - airlineCode -
     * LAA and fleets=737,321. The result should contain just 1 entry for 737.
     */
    @Test
    public void getFleetSubfleets_AirlineCdAndFleetsWithAMismatchedAirlineCode() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetCodesToSearch = new ArrayList<>();
        fleetCodesToSearch.add("737");
        fleetCodesToSearch.add("321");

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("LAA", fleetCodesToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isEqualToIgnoringCase("737");
    }

    /**
     * Test case for getFleetSubfleets(String airlineCode, List<String> fleetsToSearch). Passing empty fleet codes.
     */
    @Test
    public void getFleetSubfleets_AirlineCdAndFleetsWithEmptyFleets() throws SharedApiRepositoryException,
        SharedApiServiceException {
        List<FleetSubfleetEntity> repoResponse = fleetSubfleetData();

        List<String> fleetCodesToSearch = new ArrayList<>();

        given(fleetRepository.getFleetsAndSubfleets()).willReturn(repoResponse);
        List<FleetSubfleetEntity> fleetResponse = fleetService.getFleetSubfleets("LAA", fleetCodesToSearch);

        assertThat(fleetResponse).isNotNull().isNotEmpty().hasSize(1);
        assertThat(fleetResponse.get(0)).isNotNull();
        assertThat(fleetResponse.get(0).getFleet()).isNull();
    }

    @Test
    public void refreshFleets() {
    }
}
