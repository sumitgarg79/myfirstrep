package com.aa.amps.cwlv.manHours.LaaRodManHrs;

import com.aa.amps.cwlv.util.DateUtil;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


/**
 * Test class for {@code {@link LaaRodManHrsRepositoryTest }}. The @FixMethodOrder(MethodSorters.NAME_ASCENDING)
 * annotation on this class makes sure that the test cases are executed in lexicographic order of their name.
 *
 * @author RAMESH RUDRA(842020)
 * created on 5/9/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LaaRodManHrsRepositoryTest {

    @Autowired
    @Qualifier("jdbcTemplate")
    JdbcTemplate jdbcTemplate;

    @Autowired
    private LaaRodManHrsRepository laaRodManHrsRepository;

    @Before
    public void setUp() throws Exception {

    }

    /**
     * Get all LAATermination Entity  records.
     */
    @Test
    public void getLaaRodManHrs_Success() {
        String date = DateUtil.getTodaysDate();
        List<LaaTerminationEntity> result = laaRodManHrsRepository.getLaaRodManHrs(date);

        assertNotNull(result);
        assertEquals(1, result.size());
    }

    /**
     * Getting empty Array list if result doesn't exist for LAATermination Entity
     */
    @Test
    public void getLusRonManHrs_NullResult() {
        String date = "2018-02-30";
        List<LaaTerminationEntity> result = laaRodManHrsRepository.getLaaRodManHrs(date);
        assertNotNull(result);
        assertEquals(0, result.size());
    }
}
