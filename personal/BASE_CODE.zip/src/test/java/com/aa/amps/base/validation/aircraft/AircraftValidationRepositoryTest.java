package com.aa.amps.base.validation.aircraft;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link AircraftValidationRepository}.
 *
 * @author HCL(296319)
 * @since on 7/27/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AircraftValidationRepositoryTest {
    @Autowired
    private AircraftValidationRepository aircraftValidationRepository;

    /**
     * Test case for isValidAircraft.
     */
    @Test
    public void getAircraftList_LaaHappyPath() {
        List<AircraftValidationEntity> aircraftEntities = aircraftValidationRepository.getAircraftList();
        assertThat(aircraftEntities).isNotNull().isNotEmpty();
        assertThat(aircraftEntities).hasSize(6);
        assertThat(aircraftEntities.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase("LAA");
        assertThat(aircraftEntities.get(0).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("3AB");
        assertThat(aircraftEntities.get(0).getFleet()).isNotEmpty().isEqualToIgnoringCase("737");
    }

    @Test
    public void getAircraftList_LusHappyPath() {
        List<AircraftValidationEntity> aircraftEntities = aircraftValidationRepository.getAircraftList();
        assertThat(aircraftEntities).isNotNull().isNotEmpty();
        assertThat(aircraftEntities).hasSize(6);
        assertThat(aircraftEntities.get(3).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase("LUS");
        assertThat(aircraftEntities.get(3).getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase("161");
        assertThat(aircraftEntities.get(3).getFleet()).isNotEmpty().isEqualToIgnoringCase("321");
    }
}
