package com.aa.amps.base.task;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;

/**
 * This the test class for {@code TaskConstantsTest}.
 *
 * @author Naseer Mohammed (842018)
 * @since 6/12/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TaskConstantsTest {

    @Test
    public void getSoftTimeIndicator() {
        String softtime = "true";
        assertEquals("T", TaskConstants.getSoftTimeIndicator(softtime));
        softtime = "false";
        assertEquals("F", TaskConstants.getSoftTimeIndicator(softtime));
        softtime = "abc";
        assertEquals("F", TaskConstants.getSoftTimeIndicator(softtime));
    }
}