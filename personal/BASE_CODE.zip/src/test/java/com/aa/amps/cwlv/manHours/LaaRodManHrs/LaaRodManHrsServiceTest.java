package com.aa.amps.cwlv.manHours.LaaRodManHrs;


import com.aa.amps.cwlv.util.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.BDDMockito.given;


/**
 * Test class for {@code {@link LaaRodManHrsService }}.
 *
 * @author RAMESH RUDRA(842020)
 * Created on 5/08/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class LaaRodManHrsServiceTest {


    String json = "{\n" +
            " \"DFWR\": {\n" +
            "        \"09May2018\": {\n" +
            "            \"874_0425\": 433,\n" +
            "            \"7AF_0940\": 461,\n" +
            "            \"3PD_1111\": 591\n" +
            "        },\n" +
            "        \"08May2018\": {\n" +
            "            \"7AX_0940\": 518,\n" +
            "            \"7BC_0176\": 472,\n" +
            "            \"7AL_0221\": 386\n" +
            "        },\n" +
            "        \"15May2018\": {\n" +
            "            \"7AL_0006\": 576,\n" +
            "            \"3MV_1111\": 536,\n" +
            "            \"7AB_0996\": 663\n" +
            "        },\n" +
            "        \"14May2018\": {\n" +
            "            \"7BP_0996\": 478,\n" +
            "            \"7BM_0008\": 586\n" +
            "        },\n" +
            "        \"13May2018\": {\n" +
            "            \"7BT_0996\": 618\n" +
            "        },\n" +
            "        \"12May2018\": {\n" +
            "            \"7AU_0940\": 601\n" +
            "        },\n" +
            "        \"11May2018\": {\n" +
            "            \"7BL_0996\": 618\n" +
            "        },\n" +
            "        \"10May2018\": {\n" +
            "            \"7BB_0996\": 618\n" +
            "        }\n" +
            "    }\n" +
            "}";
    @Autowired
    private LaaRodManHrsService laaRodManHrsService;
    private List<LaaTerminationEntity> laaTerminationEntities;
    @MockBean
    private LaaRodManHrsRepository laaRodManHrsRepository;
    @MockBean
    private RestTemplate restTemplate;
    private LaaRodManHrsService laaRodManHrsService1;
    private Map<String, Map<String, Map<String, Long>>> stationTerminations;

    @Before
    public void setUp() throws Exception {

        laaTerminationEntities = new ArrayList<>();

        LaaTerminationEntity ob1 = new LaaTerminationEntity();
        LaaTerminationEntity ob2 = new LaaTerminationEntity();

        ob1.setStation("DFW");
        ob1.setSchdFlightNbr("");
        ob1.setPriorityCode(2L);
        ob1.setManHrsOfpriorityCode(10F);
        ob1.setAircraftNbr("");

        ob2.setStation("DFW");
        ob2.setSchdFlightNbr("");
        ob2.setPriorityCode(2L);
        ob2.setManHrsOfpriorityCode(10F);
        ob2.setAircraftNbr("");

        laaTerminationEntities.add(ob1);
        laaTerminationEntities.add(ob2);

        ObjectMapper mapper = new ObjectMapper();
        stationTerminations = new HashMap<String, Map<String, Map<String, Long>>>();
        stationTerminations = mapper.readValue(json, new TypeReference<Map<String, Map<String, Map<String, Long>>>>() {
        });

        System.out.println(stationTerminations);
    }

    @Test
    @Ignore
    public void getLaaRodManHrs() throws Exception {

        String date = "2018-04-23";
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

//        LaaRodManHrsService mock = new LaaRodManHrsService();
//        LaaRodManHrsService mockSpy = PowerMockito.spy(mock);
//        PowerMockito.doReturn(null).when(mockSpy,"getTerminationRoutingFromCache");
        // LaaRodManHrsService mock =spy(new LaaRodManHrsService());
        //when(mock,"getTerminationRoutingFromCache").


        given(this.laaRodManHrsRepository.getLaaRodManHrs(date)).willReturn(laaTerminationEntities);


        laaRodManHrsService.getLaaRodManHrs(searchCriteria);

    }

    @Test
    @Ignore
    public void getTerminationRoutingFromCache_Success() {

        Map<String, Long> map1 = new HashMap<>();
        Map<String, Map<String, Long>> map2 = new HashMap<>();
        map2.put("Test", map1);
        Map<String, Map<String, Map<String, Long>>> map3 = new HashMap<>();
        map3.put("test", map2);


//        when(this.restTemplate.exchange(restTemplate.exchange(
//                Matchers.anyString(),
//                Matchers.any(HttpMethod.class),
//                Matchers.<HttpEntity<?>> any(),
//                Matchers.<Class<String>> any(),
//                Matchers.<ParameterizedTypeReference<List<String>>>any()))).thenReturn(
//                        (ResponseEntity<Map<String, Map<String, Map<String, Long>>>>) stationTerminations);
//
//        Map<String, Map<String, Map<String, Long>>> routingFromCache = laaRodManHrsService
//                .getTerminationRoutingFromCache();

    }
}