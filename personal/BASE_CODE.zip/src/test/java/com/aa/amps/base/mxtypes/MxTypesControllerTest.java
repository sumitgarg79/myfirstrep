package com.aa.amps.base.mxtypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code MxTypesController}.
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since on 06/04/2018.
 */


@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MxTypesControllerTest {

    @Autowired
    private MxTypesController mxtypesController;

    private List<String> mxtypesEntities;

    @MockBean
    private MxTypesService mxtypesService;

    @Before
    public void setUp() throws Exception {
        mxtypesEntities = new ArrayList<>();
        String mxtype = "RON";
        mxtypesEntities.add(mxtype);
    }

    /**
     * Test case for getMxTypes. Happy Path scenario.
     */
    @Test
    public void getMxTypes() {
        given(this.mxtypesService.getMxTypes()).willReturn(mxtypesEntities);
        List<String> result = mxtypesController.getMxTypes();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0)).isEqualToIgnoringCase("RON");
    }
}