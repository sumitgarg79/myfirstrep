package com.aa.amps.cwlv.util;

import org.junit.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

/**
 * Test class for {@link DateUtil}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/30/2018.
 */
public class DateUtilTest {

    @Test
    public void getDateInManHrFormat() {
        String result = DateUtil.getDateInManHrFormat("05/25/2018");

        assertThat(result).isNotEmpty();
        assertThat(result).isEqualTo("2018-05-25");
    }
}
