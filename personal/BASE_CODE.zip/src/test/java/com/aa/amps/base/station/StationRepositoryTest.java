package com.aa.amps.base.station;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StationRepositoryTest {

    @Autowired
    private StationRepository stationRepository;

    @Before
    public void setUp() {
    }

    @Test
    public void getAllActiveStations() {
        List<StationEntity> stationEntities = stationRepository.getAllActiveStations();
        assertThat(stationEntities).isNotNull();
        assertThat(stationEntities.size()).isGreaterThan(1); // We expect more that 1 stations
        assertThat(stationEntities.get(0).getMntncStnCd().equals("AAA")).isTrue();
    }
}