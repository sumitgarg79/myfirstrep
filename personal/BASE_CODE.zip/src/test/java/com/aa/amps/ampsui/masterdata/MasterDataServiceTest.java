package com.aa.amps.ampsui.masterdata;

import com.aa.amps.ampsui.restclients.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;


/**
 * Unit test class for {@link MasterDataService}.
 *
 * @author Neelabh Tripathi
 * @since 04/19/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MasterDataServiceTest {

    @Autowired
    MasterDataService masterDataService;

    @MockBean
    private FleetClientService fleetClientService;

    @MockBean
    private AircraftClientService aircraftClientService;

    @MockBean
    private StationClientService stationClientService;


    public List<FleetResponseEntity> getFleetSubfleetData() {
        FleetResponseEntity fleet1 = new FleetResponseEntity();

        fleet1.setFleet("737");
        List<String> subfleets2 = new ArrayList<>();
        subfleets2.add("737-300");
        subfleets2.add("737-200");
        fleet1.setSubfleet(subfleets2);
        fleet1.setAirlineCode("LAA");
        fleet1.setValidFleetCode(true);

        List<FleetResponseEntity> response = new ArrayList<>();
        response.add(fleet1);

        return response;
    }

    private List<AircraftResponseEntity> getAircraftData() {
        AircraftResponseEntity aircraft1 = new AircraftResponseEntity();
        aircraft1.setAircraftNumber("3AB");
        aircraft1.setAirlineCode("LAA");
        aircraft1.setFleet("737");
        aircraft1.setSubfleet("737-200");

        AircraftResponseEntity aircraft2 = new AircraftResponseEntity();
        aircraft2.setAircraftNumber("3AH");
        aircraft2.setAirlineCode("LAA");
        aircraft2.setFleet("737");
        aircraft2.setSubfleet("737-300");

        List<AircraftResponseEntity> aircraftData = new ArrayList<>();
        aircraftData.add(aircraft1);
        aircraftData.add(aircraft2);

        return aircraftData;
    }

    public StationResponseEntity getStationsData() {
        List<StationEntity> stationEntities = new ArrayList<>();
        StationEntity ob1 = new StationEntity();

        ob1.setMntncStnCd("JFK");
        ob1.setMntncStnTypCd("L");

        stationEntities.add(ob1);

        StationEntity ob2 = new StationEntity();

        ob2.setMntncStnCd("DWH");
        ob2.setMntncStnTypCd("H");

        stationEntities.add(ob2);

        StationResponseEntity responseEntity = new StationResponseEntity();
        responseEntity.setStationEntityList(stationEntities);

        return responseEntity;
    }

    @Test
    public void getMasterData() {
        final String AIRLINE_LAA = "LAA";

        given(fleetClientService.getFleets(AIRLINE_LAA)).willReturn(getFleetSubfleetData());
        given(aircraftClientService.getAircraft(AIRLINE_LAA)).willReturn(getAircraftData());
        given(stationClientService.getLineMaintenanceStations()).willReturn(getStationsData());

        MasterDataResponse response = masterDataService.getMasterData(AIRLINE_LAA);

        assertThat(response).isNotNull();
        assertThat(response.getFleet()).isNotNull().isNotEmpty().hasSize(1);
        assertThat(response.getFleet().get(0).getFleetCode()).isNotNull().isEqualToIgnoringCase("737");
        assertThat(response.getFleet().get(0).getSubfleet()).isNotNull().isNotEmpty().hasSize(2);

        assertThat(response.getStation()).isNotNull().isNotEmpty().hasSize(1);
        assertThat(response.getStation().get(0).getStationCode()).isNotEmpty().isEqualToIgnoringCase("JFK");
    }
}