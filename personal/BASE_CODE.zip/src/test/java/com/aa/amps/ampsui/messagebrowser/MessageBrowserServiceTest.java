package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.cwlv.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Unit test class for {@link MessageBrowserService}.
 *
 * @author Ramesh Rudra
 * @since 06/27/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class MessageBrowserServiceTest {

    @Value("${ampsui.messagebrowser.api}")
    private String ampsuiMessageBrowserApi;


    @Value("${ampsui.messagebrowserdelete.api}")
    private String messagebrowserDeleteApi;

    @Value("${ampsui.messagebrowserUpdate.api}")
    private String messagebrowserUpdateApi;

    @Autowired
    private MessageBrowserService messageBrowserService;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void init() {
        mockServer = MockRestServiceServer.createServer(messageBrowserService.getRestTemplate());
    }

    public List<MessageBrowser> getMsgListData() {

        List<MessageBrowser> msgList = new ArrayList<>();
        MessageBrowser browser = new MessageBrowser();
        browser.setStationCode("CLT");
        browser.setAircraftNumber("190");
        browser.setAmpsMsgId("21");
        browser.setFleetCode("NULL");

        MessageBrowser browser1 = new MessageBrowser();
        browser1.setAircraftNumber("190");
        browser1.setAmpsMsgId("24");
        browser1.setFleetCode("NULL");

        MessageBrowser browser2 = new MessageBrowser();
        browser2.setAircraftNumber("190");
        browser2.setAmpsMsgId("24");
        browser2.setFleetCode("NULL");

        msgList.add(browser);
        msgList.add(browser1);
        msgList.add(browser2);

        return msgList;
    }


    @Test
    public void getMessageBrowserList() throws URISyntaxException, JsonProcessingException, AmpsuiServiceException {

        mockServer.expect(ExpectedCount.once(),
                requestTo(new URI(ampsuiMessageBrowserApi)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getMsgListData()))
                );

        List<MessageBrowser> messageBrowsers = messageBrowserService.getMessageBrowserList((Map<String, Object>)
                getSearchCriteria());

        mockServer.verify();
        assertThat(messageBrowsers).isNotEmpty().hasSize(3);

    }

    private Map<String, Object> getSearchCriteria() {
        Map<String, Object> map = new HashMap<>();
        map.put(Constants.STATION_CODE, "CLT");
        return map;
    }

    @Test
    public void deleteMessageBrowser_Success() throws URISyntaxException, JsonProcessingException, AmpsuiServiceException {

        mockServer.expect(ExpectedCount.once(),
                requestTo(new URI(messagebrowserDeleteApi)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(Boolean.TRUE))
                );

        Boolean valid = messageBrowserService.deleteMessageBrowser(getMsgListData());

        mockServer.verify();
        assertThat(valid).isNotNull().isEqualTo(Boolean.TRUE);


    }

    @Test
    public void deleteMessageBrowser_Failed() throws URISyntaxException, JsonProcessingException, AmpsuiServiceException {

        mockServer.expect(ExpectedCount.once(),
                requestTo(new URI(messagebrowserDeleteApi)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(Boolean.FALSE))
                );

        Boolean valid = messageBrowserService.deleteMessageBrowser(getMsgListData());

        mockServer.verify();
        assertThat(valid).isNotNull().isEqualTo(Boolean.FALSE);
    }

    @Test
    public void updateMessageBrowser_Success() throws URISyntaxException, JsonProcessingException,
            AmpsuiServiceException {

        mockServer.expect(ExpectedCount.once(),
                requestTo(new URI(messagebrowserUpdateApi)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(Boolean.TRUE))
                );

        Boolean valid = messageBrowserService.updateMessageBrowser(getMsgListData());
        mockServer.verify();
        assertThat(valid).isNotNull().isEqualTo(Boolean.TRUE);
    }

    @Test
    public void updateMessageBrowser_Failed() throws URISyntaxException, JsonProcessingException,
            AmpsuiServiceException {

        mockServer.expect(ExpectedCount.once(),
                requestTo(new URI(messagebrowserUpdateApi)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(Boolean.FALSE))
                );

        Boolean valid = messageBrowserService.updateMessageBrowser(getMsgListData());
        mockServer.verify();
        assertThat(valid).isNotNull().isEqualTo(Boolean.FALSE);
    }
}