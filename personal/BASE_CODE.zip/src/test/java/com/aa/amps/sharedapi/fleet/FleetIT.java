package com.aa.amps.sharedapi.fleet;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for Fleet API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/19/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class FleetIT {
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
                                                  MediaType.APPLICATION_JSON.getSubtype(),
                                                  Charset.forName("utf8"));

    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                      this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Integration test for GET /fleet endpoint. It should fetch all the fleet codes. E.g., <br>
     * <code>
     * [ "737", "757", "767", "A321" ]
     * </code>
     *
     * @throws Exception if there is any error in making GET REST call to the endpoint
     */
    @Test
    public void getFleets() throws Exception {
        mockMvc.perform(get("/sharedapi/fleet"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", hasSize(5)))
                .andExpect(jsonPath("$[0]", is("330")));
    }

    /**
     * Integration test for GET /fleet/v2 endpoint. None of the query param is passed and therefore all the fleet data
     * is received. JSON reponse format <br>
     * <code>
     * [ { "fleet": "330", "subfleet": [ "330-200", "330-201", "330-300" ], "airlineCode": "LUS", "validFleetCode": true
     * }, { "fleet": "320", "subfleet": [ "320-E", "320-W" ], "airlineCode": "LUS", "validFleetCode": true } ]
     * </code>
     */
    @Test
    public void getFleetAndSubfleetWithParams() throws Exception {
        mockMvc.perform(get("/sharedapi/fleet/v2"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$[0].fleet", is("330")))
                .andExpect(jsonPath("$[0].subfleet[0]", is("29")))
                .andExpect(jsonPath("$[0].airlineCode", is("LUS")))
                .andExpect(jsonPath("$[0].validFleetCode", is(true)));
    }

    /**
     * Integration test for GET /fleet/v2 endpoint. Both the query params are passed.
     */
    @Test
    public void getFleetAndSubfleetWithParams_FleetAndAirlineCdProvided() throws Exception {
        mockMvc.perform(get("/sharedapi/fleet/v2")
                                .param("airlineCd", "LAA")
                                .param("fleet", "777,737"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$[0].fleet", is("777")))
                .andExpect(jsonPath("$[0].subfleet[0]", notNullValue()))
                .andExpect(jsonPath("$[0].airlineCode", is("LAA")))
                .andExpect(jsonPath("$[0].validFleetCode", is(true)))

                .andExpect(jsonPath("$[1].fleet", is("737")))
                .andExpect(jsonPath("$[1].subfleet[0]", notNullValue()))
                .andExpect(jsonPath("$[1].airlineCode", is("LAA")))
                .andExpect(jsonPath("$[1].validFleetCode", is(true)));
    }

    /**
     * Integration test for the POST /fleet endpoint that clears up the cache for fleet data.
     */
    @Test
    public void refreshFleets() throws Exception {
        mockMvc.perform(post("/sharedapi/fleet"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$.status", is(FleetController.CACHE_REFRESH_STATUS_SUCCESS)))
                .andExpect(jsonPath("$.message", is(FleetController.CACHE_REFRESH_MESSAGE)));
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
                o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }
}
