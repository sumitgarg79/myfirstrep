package com.aa.amps.cwlv.cwlgrid.lus;

import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LUSTaskServiceTest {

    public static final String SCHD_DT = "2018-05-21";
    public static final String DT_20180204 = "2018-02-04";

    List<CombinedTaskDetail> mockedCombinedTaskDetails = Collections.emptyList();

    @MockBean
    private LUSTaskRepository lusTaskRepo;

    private LUSTaskService lusTaskService;

    @Before
    public void setUp() throws Throwable {
        mockedCombinedTaskDetails = getMockCombinedTaskDetails();

        lusTaskService = new LUSTaskService(lusTaskRepo);
    }

    @Test
    public void getCombinedTasksDetails() {

        given(lusTaskRepo.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedCombinedTaskDetails);

        List<CombinedTaskDetail> responseLUS = lusTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLUS).isNotNull();
        assertThat(responseLUS.size()).isEqualTo(2);
        assertThat(responseLUS.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLUS.get(0).getStnCd()).isEqualToIgnoringCase("CVG");

        assertThat(responseLUS.get(1).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLUS.get(1).getStnCd()).isEqualToIgnoringCase("DFW");
    }

    private List<CombinedTaskDetail> getMockCombinedTaskDetails() {

        List<CombinedTaskDetail> cmTaskList = new ArrayList<>();

        CombinedTaskDetail combinedTaskDetail1 = new CombinedTaskDetail();
        combinedTaskDetail1.setAircftNbr("425");
        combinedTaskDetail1.setLogo("SCPT");
        combinedTaskDetail1.setFleetCd("S80");
        combinedTaskDetail1.setStnCd("CVG");
        combinedTaskDetail1.setTaskId("7924");
        combinedTaskDetail1.setTaskDesc("ENGINE 4TH STAGE TURBINE BLADES-ISOTOPE");
        combinedTaskDetail1.setSchdDt(SCHD_DT);
        combinedTaskDetail1.setForecastDt("2018-04-15");
        combinedTaskDetail1.setTaskTypeCd("SIC");
        combinedTaskDetail1.setRodRon("RON");
        combinedTaskDetail1.setMechHour("13");
        combinedTaskDetail1.setPriority("3");

        CombinedTaskDetail combinedTaskDetail2 = new CombinedTaskDetail();
        combinedTaskDetail2.setAircftNbr("4XB");
        combinedTaskDetail2.setLogo("SCPT");
        combinedTaskDetail2.setFleetCd("S80");
        combinedTaskDetail2.setStnCd("DFW");
        combinedTaskDetail2.setTaskId("5916");
        combinedTaskDetail2.setTaskDesc("DFGS RETURN-TO-SERVICE (RTS) TEST");
        combinedTaskDetail2.setSchdDt(SCHD_DT);
        combinedTaskDetail2.setForecastDt(DT_20180204);
        combinedTaskDetail2.setTaskTypeCd("SIC");
        combinedTaskDetail2.setRodRon("RON");
        combinedTaskDetail2.setMechHour("1");
        combinedTaskDetail2.setPriority("1");

        cmTaskList.add(combinedTaskDetail1);
        cmTaskList.add(combinedTaskDetail2);

        return cmTaskList;
    }
}