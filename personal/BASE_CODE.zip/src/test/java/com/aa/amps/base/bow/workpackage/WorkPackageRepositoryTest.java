package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.task.WorkPackageEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

/**
 * Test class for {@link WorkPackageRepository}.
 *
 * @author Shyam Sundar Ashok(202571)
 * @since on 10/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class WorkPackageRepositoryTest {

    @Autowired
    private WorkPackageRepository workPackageRepository;

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void testGetBOWDetail() {
        Long workPkgId = 2424L;
        WorkPackageEntity result = workPackageRepository.getBowDetail(workPkgId);
        assertThat(result).isNotNull();
        assertEquals(2424, result.getWorkPkgId().longValue());
    }
}
