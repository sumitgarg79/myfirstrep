package com.aa.amps.base.user;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code UserController}.
 *
 * @author Paul Verner (650196)
 * @since 9/13/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class UserControllerTest {

    @Autowired
    UserController userController;
    @MockBean
    UserService userService;

    UserRequest userRequest;

    @Before
    public void setUp() {

    }

    /**
     * Test case for User Logging into AMPS Base
     *
     * @throws Exception
     */
    @Test
    public void userLoginTest() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("999999");
        userRequest.setFirstName("NINETY");
        userRequest.setLastName("NINE");
        given(this.userService.loginUser(userRequest)).willReturn(true);

        Map<String, String> map = userController.loginUser(userRequest);
        assertEquals("success", map.get("result"));
    }
}
