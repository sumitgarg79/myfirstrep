package com.aa.amps.base.preset;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Arrays;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for all the API endpoints defined in class {@link PresetController}.
 *
 * @author RAMESH RUDRA(842020)
 * created on 8/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class PresetGetRequestIT {
    private static final String SEARCH_TXT = "\"{\\\"pageCount\\\":0,\\\"searchCriteria\\\"" +
            ":{\\\"statusPlanned\\\":true,\\\"sortedItems\\\":[\\\"FleetCode\\\"" +
            ",\\\"AircraftNum\\\",\\\"Criticality\\\"],\\\"allowOTRTypes\\\":false" +
            ",\\\"fleetCode\\\":[787],\\\"airlineCode\\\":\\\"US\\\",\\\"statusOpen\\\"" +
            ":true,\\\"recordCount\\\":false}}\"";
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));
    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;
    @Autowired
    private WebApplicationContext webApplicationContext;
    @Autowired
    private PresetRepository presetRepository;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {
        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setUp() throws Exception {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();

        PresetEntity entity = new PresetEntity();
        entity.setUserId("234567");
        entity.setSearchCriterTxt("Testinggg");
        entity.setSearchCriterId(3);
        entity.setSearchCriterTypeCd("T");

        presetRepository.save(entity);
    }

    @Test
    public void getPresets() throws Exception {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("234567");
        presetRequest.setSearchCriterId(2);
        presetRequest.setActlSelectTxt(SEARCH_TXT);
        String addRequestJson = json(presetRequest);

        mockMvc.perform(post("/base/preset" + "/getPresets")
                .contentType(contentType)
                .content(addRequestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].presetTypeCd", is("T")));
    }

    @Test
    public void addPreset() throws Exception {
        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("842020");
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);
        String addRequestJson = json(presetRequest);

        mockMvc.perform(post("/base/preset" + "/add")
                .contentType(contentType)
                .content(addRequestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].presetTypeCd", is("T")));
    }

    @Test
    public void updatePreset() throws Exception {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("234567");
        presetRequest.setSearchCriterId(3);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);
        String addRequestJson = json(presetRequest);

        mockMvc.perform(put("/base/preset" + "/update")
                .contentType(contentType)
                .content(addRequestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].presetTypeCd", is("T")));
    }

    @Test
    public void deletePreset() throws Exception {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("234567");
        presetRequest.setSearchCriterId(3);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);
        String addRequestJson = json(presetRequest);

        mockMvc.perform(delete("/base/preset" + "/delete" + "/234567" + "/3" + "/T")
                .contentType(contentType)
                .content(addRequestJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", notNullValue()));
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(
                o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }
}
