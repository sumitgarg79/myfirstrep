package com.aa.amps.base.task;


import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class to test API end points defined in {{@link TaskController}}
 *
 * @author Paul Verner(650196):American Airlines
 * @since 06/10/2018
 * <p>
 * 292147 03-07-2018 : US748803  : [Base  BOW] [Filter] Search by - Task Types
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TaskGetTaskRequestIT {
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskGetTaskRequestIT.class);
    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));
    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {
        this.mappingJackson2HttpMessageConverter = Arrays.stream(converters)
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setUp() {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    @Test
    public void getTasks() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTasks")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.[0].aircraftNbr", is("723")));
    }

    @Test
    public void getTasksContainer() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].aircraftNbr", is("723")));
    }

    @Test
    public void getTasksType() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        String[] types = {"ME8"};
        searchCriteria.setAircraftNumber("723");
        searchCriteria.setTaskTypes(types);
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].taskTypeCode", is("ME8-CKC")));
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

    /**
     * US748801 : [Base  BOW] [Filter] Search by - Keyword
     * Test case for TaskController.getTasks() with keyword search.
     */
    @Test
    public void getTasksByKeyword() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        //DE70713- Input parameter from UI not matching with BE TaskFilterRequest.
        searchCriteria.setSearchKeyWord("99-D270    / 270 Day - ESI");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].description", is("99-D270    / 270 Day - ESI")));
    }

    @Test
    public void getTasksTypeWithDesc() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        String[] types = {"ME8-DNS"};
        searchCriteria.setAircraftNumber("723");
        searchCriteria.setTaskTypes(types);
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].taskTypeCode", is("ME8-DNS")))
                .andExpect(jsonPath("$.taskList[0].description", is("DNS, 26C00025033, CLASS DIVIDER REFURBISMENT")));
    }

    @Test
    public void getTasksTypeWithItem() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        String[] itemsWithList = new String[2];
        itemsWithList[0] = "ad";
        itemsWithList[1] = "dni";
        searchCriteria.setAircraftNumber("723");
        searchCriteria.setItemsWith(itemsWithList);
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].dni", is(true)));
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search.
     */
    @Test
    public void getTasksBySoftTimes() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("723");
        searchCriteria.setSoftTime("True");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)))
                .andExpect(jsonPath("$.taskList[0].softTimes", is("T")));
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search.
     */
    @Test
    public void getTasksByForecastDate() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setForecast("true");
        searchCriteria.setForecastFromDate("06/06/2018");
        searchCriteria.setForecastToDate("07/06/2018");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search.
     */
    @Test
    public void getTasksByNoForecastDate() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setNoForecast("true");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * Test case for TaskController.getTasks() with keyword search.
     */
    @Test
    public void getTasksByForecastDateandSoftTimes() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        searchCriteria.setAircraftNumber("183");
        searchCriteria.setSoftTime("T");
        searchCriteria.setForecastFromDate("06/06/2018");
        searchCriteria.setForecastToDate("07/06/2018");
        searchCriteria.setNoForecast("true");
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Test case for saving Base Draft.
     * It will create the new draft which we will use in the follow up test cases.
     */
    @Test
    public void saveBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421656");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Test case for saving Second Base Draft to Test the delete with merge and override.
     * It will create the new draft which we will use in the follow up test cases.
     */
    @Test
    public void saveBaseDraftSecond() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added T so that it will run after saveBaseDraft test to throw the Exception.
     * Test case for saving Base Draft will throw Exception as it's duplicate record so we are checking the message.
     */
    @Test
    public void tttSaveBaseDraftException() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$.message", is("Draft already exist for aircraft : 723, schedule date : " +
                        "07-18-2018, schedule station : BOS and track type : 03")));
    }

    /**
     * Test case for updating Override Base Draft.
     * This will run after tttSaveBaseDraftException with override as user action.
     */
    @Test
    public void updateBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(1L);
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("OVERRIDE");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added V so that it will run after updateBaseDraft for Merge user action.
     * Test case for updating merge Base Draft.
     */
    @Test
    public void vvvMergeBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("MERGE");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421658");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added W so that it will run after vvvMergeBaseDraft for Edit user action.
     * Test case for editing same Base Draft.
     * It should not give Exception in case user editing same draft.
     */
    @Test
    public void wwwEditBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(1L);
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added W so that it will run after wwwEditBaseDraft for Edit user action.
     * Test case for updating merge Base Draft with deleting the old one.
     */
    @Test
    public void wwwMergeBaseDraftWithDelete() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(1L);
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("MERGE");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421658");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added W so that it will run after wwwMergeBaseDraftWithDelete for Create user action.
     * Test case if user want to create the draft which already exist in DB with deleted status.
     */
    @Test
    public void wwwsaveBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("BOS");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1112");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421656");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added W so that it will run after wwwsaveBaseDraft for Edit user action.
     * Test case for editing Base Draft and creating new from it.
     */
    @Test
    public void wwwwEditBaseDraft() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(1L);
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("CLT");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Added WWWW so that it will run after wwwwEditBaseDraft test to throw the Exception.
     * Test case for editing Base Draft will throw Exception as it's duplicate record so we are checking the message.
     */
    @Test
    public void wwwwEditBaseDraftException() throws Exception {
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(5L);
        wrkPkgEntity.setAircraftNbr("723");
        wrkPkgEntity.setPkgSchdDt("07-18-2018");
        wrkPkgEntity.setPlanStationCd("CLT");
        wrkPkgEntity.setTrackTypeCd("03");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND PERSONNEL REPORT A 3 INCH DENT IN THE LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        wrkPkgEntity.setUserAction("EDIT");

        List<TaskEntity> taskEntities = new ArrayList<>();
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("8421657");
        taskEntity.setAircraftNbr("723");
        taskEntity.setWrkPkgTaskStatus("C");
        taskEntity.setUserId("292147");
        taskEntity.setUpdatedTime(Timestamp.valueOf("2018-07-10 00:00:00"));

        taskEntities.add(taskEntity);
        wrkPkgEntity.setTaskEntityList(taskEntities);
        String requestJson = json(wrkPkgEntity);
        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/baseDraft")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isBadRequest())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$.message", is("Draft already exist for aircraft : 723, schedule date : " +
                        "07-18-2018, schedule station : CLT and track type : 03")));
    }

    /**
     * US845027: [Base BOW] [Filter] Search by - Station
     * Test case for TaskController.getTasks() searching tasks based on stations.
     */
    @Test
    public void getTasksByStation() throws Exception {
        TaskFilterRequest searchCriteria = new TaskFilterRequest();
        String[] stations = {"BOS"};

        searchCriteria.setAircraftNumber("183");
        searchCriteria.setStations(stations);
        String requestJson = json(searchCriteria);
        LOGGER.info("requestJson = " + requestJson);

        mockMvc.perform(post("/base/task" + "/getTaskContainer")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }

    /**
     * Test case for TaskController.getTaskDetails().
     */
    @Test
    public void getTaskDetails() throws Exception {
        String[] taskIds = new String[]{"25-0525-8-0088 0723"};
        String[] acftNbrs = new String[]{"723"};

        TaskDetailRequest taskDetailRequest = new TaskDetailRequest();
        taskDetailRequest.setTaskIds(taskIds);
        taskDetailRequest.setAircraftNbrs(acftNbrs);
        String requestJson = json(taskDetailRequest);

        LOGGER.info("requestJson = " + requestJson);
        mockMvc.perform(post("/base/task" + "/getTaskDetails")
                .contentType(contentType)
                .content(requestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$", not(0)));
    }
}