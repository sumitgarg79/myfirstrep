package com.aa.amps.ampsui.taskassociation;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mock.http.MockHttpOutputMessage;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

/**
 * Integration test class for Task Association api.
 *
 * @author HCL
 * @since 09/04/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class TaskAssociationIT {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskAssociationIT.class);

    private MediaType contentType = new MediaType(MediaType.APPLICATION_JSON.getType(),
            MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

    @Mock
    private RestTemplate restTemplate;


    private MockMvc mockMvc;
    private HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    void setConverters(HttpMessageConverter<?>[] converters) {

        this.mappingJackson2HttpMessageConverter = Arrays.asList(converters).stream()
                .filter(hmc -> hmc instanceof MappingJackson2HttpMessageConverter)
                .findAny()
                .orElse(null);

        assertNotNull("the JSON message converter must not be null",
                this.mappingJackson2HttpMessageConverter);
    }

    @Before
    public void setup()  {
        this.mockMvc = webAppContextSetup(webApplicationContext).build();
    }

    /**
     * Utility Method to convert an object to JSON.
     *
     * @param o object to be converted to JSON
     * @return the JSON representation of the supplied object
     * @throws IOException if there is exception while converting object to JSON
     */
    protected String json(Object o) throws IOException {
        MockHttpOutputMessage mockHttpOutputMessage = new MockHttpOutputMessage();
        this.mappingJackson2HttpMessageConverter.
                write(o, MediaType.APPLICATION_JSON, mockHttpOutputMessage);

        return mockHttpOutputMessage.getBodyAsString();
    }

    @Test
    public void saveTaskAssociationsData() throws Exception {

        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("26-3210-9-0067 2796");
        taskAssociationRequest.setSmSession("dsIKknvsd8jYOoiuj89uiy8789hhshfkjsdUDASJfhsHAuuMNVvhjhsdjkf");
        taskAssociationRequest.setIncExcBlockedJobsWrapperList(getLUSTaskAssociationsData());
        String taskAssociationJson =json(taskAssociationRequest);
        MvcResult result = mockMvc
                .perform(post("/mntncAssociation/save")
                .contentType(contentType)
                .content(taskAssociationJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$.status", is("SUCCESS"))).andReturn();

        LOGGER.info("saveTaskAssociationsData - result json - {}",
                result.getResponse().getContentAsString());

    }


    @Test
    public void saveTaskAssociationsData1() throws Exception {

        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("26-3210-9-0067 2796");
        taskAssociationRequest.setSmSession("dsIKknvsd8jYOoiuj89uiy8789hhshfkjsdUDASJfhsHAuuMNVvhjhsdjkf");
        taskAssociationRequest.setIncExcBlockedJobsWrapperList(getLUSTaskAssociationsData());
        String taskAssociationJson =json(taskAssociationRequest);

        Mockito.when(restTemplate.getForEntity("https://amps.dev.techops.qcorpaa.aa.com/AMPSUI/amps-api/mntncAssoc/save", String.class, taskAssociationJson)).
                thenReturn(new ResponseEntity<>("SUCCESS", HttpStatus.OK));
        ResponseEntity resp =
                restTemplate.getForEntity("https://amps.dev.techops.qcorpaa.aa.com/AMPSUI/amps-api/mntncAssoc/save", String.class, taskAssociationJson);
        assertEquals("SUCCESS", resp.getBody());
    }

    @Test
    public void fetchTaskAssociations() throws Exception {
        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("209-209");
        taskAssociationRequest.setSmSession("dsIKknvsd8jYOoiuj89uiy8789hhshfkjsdUDASJfhsHAuuMNVvhjhsdjkf");
        String taskAssociationRequestJson = json(taskAssociationRequest);

        MvcResult result = mockMvc
                .perform(post("/mntncAssociation")
                        .contentType(contentType)
                        .content(taskAssociationRequestJson))
                .andExpect(status().isOk())
                .andExpect(content().contentType(contentType))
                .andExpect(jsonPath("$", notNullValue()))
                .andExpect(jsonPath("$[0].lusAsoMntncId", is("205-205")))
                .andExpect(jsonPath("$[0].asoMntncCode", is("BLK"))).andReturn();

        LOGGER.info("fetchTaskAssociations - result json - {}",
                result.getResponse().getContentAsString());
    }

    private static List<TaskAssociations> getLUSTaskAssociationsData() {

        List<TaskAssociations> taskAssociationsList = new ArrayList<>();
        TaskAssociations taskAssociations = new TaskAssociations();
        taskAssociations.setAssocTaskId("26-3211-9-0004 3094");
        taskAssociations.setExclusionsInd("true");
        taskAssociationsList.add(taskAssociations);
        return taskAssociationsList;
    }
}
