package com.aa.amps.base.tracktype;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@code TrackTypeRepository}.
 *
 * @author HCL(292147)
 * Created on 5/29/2018.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TrackTypeRepositoryTest {

    @Autowired
    private TrackTypeRepository trackTypeRepository;

    /**
     * Test case for getBaseTrackTypes.
     */
    @Test
    public void getBaseTrackTypes() {
        List<TrackTypeEntity> trackTypeEntities = trackTypeRepository.getBaseTrackTypes();
        assertThat(trackTypeEntities).isNotNull();
        assertThat(trackTypeEntities.size()).isGreaterThan(0);
        assertThat(trackTypeEntities.get(0).getWorkPkgTrackTypCd().equals("03")).isTrue();
    }
}