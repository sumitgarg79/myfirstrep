package com.aa.amps.base.util.sysparam;

import org.apache.commons.lang.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.CollectionUtils;

import java.util.Map;

import static org.junit.Assert.assertTrue;

/**
 * Test Class for {@link SysParamRepository}
 *
 * @author HCL (922166)
 * @since 8/29/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class SysParamRepositoryTest {

    @Autowired
    private SysParamRepository sysParamRepository;

    @Before
    public void setUp() {
    }

    @Test
    public void refreshMap() {
        Map<String, String> sysParamMap = sysParamRepository.refreshMap();
        assertTrue(!CollectionUtils.isEmpty(sysParamMap));
        assertTrue(StringUtils.isNotEmpty(sysParamMap.get("BASE_TASK_TYPE_ORDER_P1")));
        assertTrue(sysParamMap.get("BASE_TASK_TYPE_ORDER_P1").contains("ME8"));
    }
}