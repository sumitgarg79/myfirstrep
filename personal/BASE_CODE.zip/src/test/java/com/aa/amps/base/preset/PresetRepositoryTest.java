package com.aa.amps.base.preset;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


/**
 * This is test class for {{@link PresetRepository}}
 *
 * @author RAMESH RUDRA(842020)
 * @since 08/26/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class PresetRepositoryTest {

    public static final String USER_ID = "234567";

    @PersistenceContext
    EntityManager entityManager;
    @Autowired
    private PresetRepository presetRepository;
    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    public void setPresetRepository(PresetRepository presetRepository) {
        this.presetRepository = presetRepository;
    }

    @Before
    public void setUp() {
        PresetEntity entity = new PresetEntity();
        entity.setUserId(USER_ID);
        entity.setActlSelectTxt("Testing");
        entity.setSearchCriterId(3);
        entity.setSearchCriterTypeCd("T");

        presetRepository.save(entity);
    }

    // Ignoring  out test-cases its failing in PR..
    @Test
    @Ignore
    public void findByUserIdAndSearchCriterIdAndSearchCriterTypeCd() {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(3);

        PresetEntity existingPreset = this.presetRepository.findByUserIdAndSearchCriterIdAndSearchCriterTypeCd(
                presetRequest.getUserId(), presetRequest.getSearchCriterId(), presetRequest.getSearchCriterCd());
        assertThat(existingPreset).isNotNull();
        assertThat(existingPreset.getUserId()).isEqualTo(USER_ID);
        assertThat(existingPreset.getSearchCriterId()).isEqualTo(3);
        assertThat(existingPreset.getSearchCriterTypeCd()).isEqualTo("T");


    }

    @Test
    @Ignore
    public void findByUserIdAndSearchCriterTypeCd() {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(3);

        List<PresetEntity> entityList = this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(
                presetRequest.getUserId(), presetRequest.getSearchCriterCd());

        assertThat(entityList).isNotNull();
        assertThat(entityList.size()).isEqualTo(1);
        assertThat(entityList.get(0).getUserId()).isEqualTo(USER_ID);
        assertThat(entityList.get(0).getSearchCriterTypeCd()).isEqualTo("T");
    }

    @Test
    @Ignore
    public void getMaxOfSearchCriterId() {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(3);

        Long id = this.presetRepository.getMaxOfSearchCriterId(
                presetRequest.getUserId(), presetRequest.getSearchCriterCd());

        assertThat(id).isNotNull();
        assertThat(id).isEqualTo(3);

    }

    @Test
    @Ignore
    public void deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd() {
        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId(USER_ID);
        presetRequest.setSearchCriterId(3);
        int result = this.presetRepository.deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd(
                presetRequest.getUserId(), presetRequest.getSearchCriterId(), presetRequest.getSearchCriterCd());
        assertThat(result).isNotNull();
        assertThat(result).isEqualTo(1);

    }
}