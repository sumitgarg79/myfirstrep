package com.aa.amps.base.validation;

import com.aa.amps.base.validation.aircraft.AircraftValidationEntity;
import com.aa.amps.base.validation.aircraft.AircraftValidationService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link ValidationController}.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class ValidationControllerTest {
    private final String AIRCRAFT_NUMBER = "aircraftNum";
    private final String VALID = "valid";
    private final String AIRLINE_CODE = "airlineCode";
    private final String FLEET = "fleet";

    @Autowired
    private ValidationController validationController;

    @MockBean
    private AircraftValidationService aircraftValidationService;

    @Test
    public void refreshAircraftList() {
        //Only 1 statement in this test since function returns void. We just
        //want to make sure that no exceptions are thrown. If one is thrown then
        //this test will failed.
        validationController.refreshAircfraftList();
    }

    /**
     * Test case for isValidAircraft.
     */
    @Test
    public void isValidAircraft() {
        String aircraftNumber = "908";

        AircraftValidationEntity aircraft = new AircraftValidationEntity();
        aircraft.setAircraftNumber(aircraftNumber);
        aircraft.setAirlineCode("LUS");
        aircraft.setFleet("A321");

        given(this.aircraftValidationService.isActiveAircraft(aircraftNumber, null, null)).willReturn(true);
        given(this.aircraftValidationService.getAircraftDetails(aircraftNumber)).willReturn(aircraft);

        Map<String, String> messageMap = validationController.isValidAircraft(aircraftNumber, null, null);

        assertThat(messageMap).isNotNull();
        assertThat(messageMap.get(VALID)).isEqualToIgnoringCase("true");
        assertThat(messageMap.get(AIRLINE_CODE)).isEqualToIgnoringCase("LUS");
        assertThat(messageMap.get(AIRCRAFT_NUMBER)).isEqualToIgnoringCase(aircraftNumber);
    }

    @Test
    public void isValidAircraft_WithAllInputParameter() {
        String aircraftNumber = "3AB";
        String airlineCode = "LAA";
        String fleet = "737";

        AircraftValidationEntity aircraft = new AircraftValidationEntity();
        aircraft.setAircraftNumber(aircraftNumber);
        aircraft.setAirlineCode("LAA");
        aircraft.setFleet("737");

        given(this.aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet)).willReturn(true);
        given(this.aircraftValidationService.getAircraftDetails(aircraftNumber)).willReturn(aircraft);

        Map<String, String> messageMap = validationController.isValidAircraft(aircraftNumber, airlineCode, fleet);

        assertThat(messageMap).isNotNull();
        assertThat(messageMap.get(VALID)).isEqualToIgnoringCase("true");
        assertThat(messageMap.get(AIRLINE_CODE)).isEqualToIgnoringCase("LAA");
        assertThat(messageMap.get(AIRCRAFT_NUMBER)).isEqualToIgnoringCase(aircraftNumber);
    }

    @Test
    public void testInvalidAircraft() {
        String aircraftNumber = "08";
        AircraftValidationEntity aircraft = new AircraftValidationEntity();

        given(this.aircraftValidationService.isActiveAircraft(aircraftNumber, null, null)).willReturn(false);
        given(this.aircraftValidationService.getAircraftDetails(aircraftNumber)).willReturn(aircraft);

        Map<String, String> messageMap = validationController.isValidAircraft(aircraftNumber, null, null);
        assertThat(messageMap).isNotNull();
        assertThat(messageMap.get(VALID)).isEqualToIgnoringCase("false");
    }
}
