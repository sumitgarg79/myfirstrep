package com.aa.amps.ampsui.masterdata;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * \Unit test class for {@link MasterDataController}.
 *
 * @author Neelabh Tripathi
 * @since 04/16/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MasterDataControllerTest {

    @Autowired
    private MasterDataController masterDataController;

    @MockBean
    private MasterDataService masterDataService;

    private MasterDataResponse getMasterDataResponse() {
        MasterDataResponse response = new MasterDataResponse();

        Fleet fleet = new Fleet();
        fleet.setFleetCode("737");

        Station station = new Station();
        station.setStationCode("DFW");

        List<Fleet> fleets = new ArrayList<>();
        fleets.add(fleet);

        List<Station> stations = new ArrayList<>();
        stations.add(station);

        response.setFleet(fleets);
        response.setStation(stations);

        return response;
    }

    @Test
    public void getMasterData() {
        given(masterDataService.getMasterData("LAA")).willReturn(getMasterDataResponse());

        MasterDataResponse masterDataResponse = masterDataController.getMasterData("LAA");

        assertThat(masterDataResponse).isNotNull();
        assertThat(masterDataResponse.getFleet().get(0).getFleetCode()).isEqualToIgnoringCase("737");
        assertThat(masterDataResponse.getStation().get(0).getStationCode()).isEqualToIgnoringCase("DFW");
    }
}