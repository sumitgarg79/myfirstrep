package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiRepositoryException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link FleetRepository}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/18/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class FleetRepositoryTest {

    @Autowired
    FleetRepository fleetRepository;

    @Test
    public void getFleets() {
        List<String> fleetCodes = fleetRepository.getFleets();

        assertThat(fleetCodes).isNotNull().isNotEmpty();
        assertThat(fleetCodes.size()).isEqualTo(5);
        assertThat(fleetCodes.get(0)).isEqualToIgnoringCase("330");
    }

    @Test
    public void getFleetsAndSubfleets() throws SharedApiRepositoryException {
        List<FleetSubfleetEntity> fleetdetails = fleetRepository.getFleetsAndSubfleets();

        assertThat(fleetdetails).isNotNull().isNotEmpty();
        assertThat(fleetdetails).hasSize(5);
        assertThat(fleetdetails.get(0).getFleet()).isEqualToIgnoringCase("330");
        assertThat(fleetdetails.get(0).getSubfleet()).isNotEmpty();
        assertThat(fleetdetails.get(0).getAirlineCode()).isNotEmpty().isEqualToIgnoringCase("LUS");

    }
}
