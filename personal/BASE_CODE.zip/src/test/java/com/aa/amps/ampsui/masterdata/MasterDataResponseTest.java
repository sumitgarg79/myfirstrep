package com.aa.amps.ampsui.masterdata;

import com.aa.amps.ampsui.restclients.AircraftResponseEntity;
import com.aa.amps.ampsui.restclients.FleetResponseEntity;
import com.aa.amps.ampsui.restclients.StationEntity;
import com.aa.amps.ampsui.restclients.StationResponseEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Unit test class for {@link MasterDataResponse}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/8/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class MasterDataResponseTest {
    public static final String SUBFLEET_737_300 = "737-300";
    public static final String SUBFLEET_737_200 = "737-200";
    public static final String FLEET_737 = "737";
    public static final String SUBFLEET_787_8 = "7878";
    public static final String SUBFLEET_787_9 = "7879";
    public static final String FLEET_787 = "787";
    public static final String AIRLINE_CODE_LAA = "LAA";
    public static final String LINE_STATION = "L";

    private static final Logger LOG = LoggerFactory.getLogger(MasterDataResponseTest.class);

    private List<FleetResponseEntity> getFleetResponseEntityData() {
        FleetResponseEntity fleet1 = new FleetResponseEntity();

        List<String> subfleet737 = new ArrayList<>();
        subfleet737.add(SUBFLEET_737_200);
        subfleet737.add(SUBFLEET_737_300);

        fleet1.setAirlineCode(AIRLINE_CODE_LAA);
        fleet1.setFleet(FLEET_737);
        fleet1.setSubfleet(subfleet737);

        FleetResponseEntity fleet2 = new FleetResponseEntity();
        List<String> subfleet747 = new ArrayList<>();
        subfleet747.add(SUBFLEET_787_8);
        subfleet747.add(SUBFLEET_787_9);

        fleet2.setAirlineCode(AIRLINE_CODE_LAA);
        fleet2.setFleet(FLEET_787);
        fleet2.setSubfleet(subfleet747);

        List<FleetResponseEntity> fleetData = new ArrayList<>();

        fleetData.add(fleet1);
        fleetData.add(fleet2);

        return fleetData;
    }

    private List<AircraftResponseEntity> getAircraftResponseEntities() {
        AircraftResponseEntity entity1 = new AircraftResponseEntity();

        entity1.setAircraftNumber("3AH");
        entity1.setFleet(FLEET_737);
        entity1.setAirlineCode(AIRLINE_CODE_LAA);
        entity1.setSubfleet(SUBFLEET_737_200);

        AircraftResponseEntity entity2 = new AircraftResponseEntity();

        entity2.setAircraftNumber("3BA");
        entity2.setFleet(FLEET_737);
        entity2.setAirlineCode(AIRLINE_CODE_LAA);
        entity2.setSubfleet(SUBFLEET_737_300);

        AircraftResponseEntity entity3 = new AircraftResponseEntity();

        entity3.setAircraftNumber("8AA");
        entity3.setFleet(FLEET_787);
        entity3.setAirlineCode(AIRLINE_CODE_LAA);
        entity3.setSubfleet(SUBFLEET_787_8);

        List<AircraftResponseEntity> aircraft = new ArrayList<>();
        aircraft.add(entity1);
        aircraft.add(entity2);
        aircraft.add(entity3);

        return aircraft;
    }

    private StationResponseEntity getStationResponseEntity() {
        StationEntity stnEntity1 = new StationEntity();

        stnEntity1.setMntncStnCd("DFW");
        stnEntity1.setMntncStnAliasCd("Dallas Fort Worth");
        stnEntity1.setMntncStnTypCd("L");

        StationEntity stnEntity2 = new StationEntity();

        stnEntity2.setMntncStnCd("CLT");
        stnEntity2.setMntncStnTypCd("L");

        StationEntity stnEntity3 = new StationEntity();

        stnEntity3.setMntncStnCd("PHX");
        stnEntity3.setMntncStnTypCd("L");

        List<StationEntity> stations = new ArrayList<>();
        stations.add(stnEntity1);
        stations.add(stnEntity2);
        stations.add(stnEntity3);

        StationResponseEntity responseEntity = new StationResponseEntity();
        responseEntity.setStationEntityList(stations);

        return responseEntity;
    }

    @Test
    public void setMasterDataResponseWithFleet() {
        MasterDataResponse response = new MasterDataResponse();

        MasterDataResponse.setMasterDataResponseWithFleet(response, getFleetResponseEntityData());

        assertThat(response.getFleet()).isNotEmpty().hasSize(2);
        assertThat(response.getFleet().get(0).getFleetCode()).isNotBlank().isEqualToIgnoringCase(FLEET_737);
        assertThat(response.getFleet().get(0).getSubfleet()).isNotEmpty().hasSize(2);
        assertThat(response.getFleet().get(0).getSubfleet().get(0).getSubfleetCode()).isNotBlank()
                .isEqualToIgnoringCase(SUBFLEET_737_200);

        assertThat(response.getFleet().get(1).getFleetCode()).isNotBlank().isEqualToIgnoringCase(FLEET_787);
    }

    @Test
    public void setMasterDataResponseWithAircraft() {
        MasterDataResponse response = new MasterDataResponse();

        MasterDataResponse.setMasterDataResponseWithFleet(response, getFleetResponseEntityData());
        MasterDataResponse.setMasterDataResponseWithAircraft(response, getAircraftResponseEntities());

        assertThat(response.getFleet()).isNotEmpty().hasSize(2);

        assertThat(response.getFleet().get(0).getFleetCode()).isNotBlank().isEqualToIgnoringCase(FLEET_737);
        assertThat(response.getFleet().get(0).getSubfleet()).isNotEmpty().hasSize(2);

        assertThat(response.getFleet().get(0).getSubfleet().get(0).getSubfleetCode()).isNotBlank()
                .isEqualToIgnoringCase(SUBFLEET_737_200);
        assertThat(response.getFleet().get(0).getSubfleet().get(0).getAircraft()).isNotEmpty().hasSize(1);
        assertThat(response.getFleet().get(0).getSubfleet().get(0).getAircraft().get(0).getAircraftNumber())
                .isNotBlank().isEqualToIgnoringCase("3AH");

        assertThat(response.getFleet().get(0).getSubfleet().get(1).getSubfleetCode()).isNotBlank()
                .isEqualToIgnoringCase(SUBFLEET_737_300);
        assertThat(response.getFleet().get(0).getSubfleet().get(1).getAircraft().get(0).getAircraftNumber())
                .isNotBlank().isEqualToIgnoringCase("3BA");

        assertThat(response.getFleet().get(1).getFleetCode()).isNotBlank().isEqualToIgnoringCase(FLEET_787);
        assertThat(response.getFleet().get(1).getSubfleet().get(0).getSubfleetCode()).isNotBlank()
                .isEqualToIgnoringCase(SUBFLEET_787_8);
        assertThat(response.getFleet().get(1).getSubfleet().get(0).getAircraft().get(0).getAircraftNumber())
                .isNotBlank().isEqualToIgnoringCase("8AA");

        //787-9 subfleet's aircraft should be null
        assertThat(response.getFleet().get(1).getSubfleet().get(1).getAircraft()).isEmpty();

    }


    @Test
    public void setMasterDataResponseWithStations() {
        MasterDataResponse response = new MasterDataResponse();

        MasterDataResponse.setMasterDataResponseWithStations(response, getStationResponseEntity(), LINE_STATION);

        assertThat(response).isNotNull();
        assertThat(response.getStation()).isNotEmpty().hasSize(3);
        assertThat(response.getStation().get(0).getStationCode()).isNotBlank().isEqualToIgnoringCase("DFW");

    }

    @Test
    public void setMasterDataResponseWithStations_EmptyStationTypeCode() {
        MasterDataResponse response = new MasterDataResponse();

        MasterDataResponse.setMasterDataResponseWithStations(response, getStationResponseEntity(), null);

        assertThat(response).isNotNull();
        assertThat(response.getStation()).isNotEmpty().hasSize(3);
        assertThat(response.getStation().get(0).getStationCode()).isNotBlank().isEqualToIgnoringCase("DFW");

    }
}
