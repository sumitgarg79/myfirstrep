package com.aa.amps.cwlv.manHours;

import com.aa.amps.cwlv.exception.InValidDateException;
import com.aa.amps.cwlv.manHours.LaaRodManHrs.LaaRodManHrsService;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.FeatureSwitchUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code {@link RodAndRonManHrsService}}.
 *
 * @author RAMESH RUDRA(842020)
 * Created on 4/29/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class RodAndRonManHrsServiceTest {


    @Autowired
    private RodAndRonManHrsController rodAndRonManHrsController;

    @Autowired
    private RodAndRonManHrsService rodAndRonManHrsService;

    private List<RodAndRonManHrsEntity> lusRonEntity;

    private List<RodAndRonManHrsEntity> lusRodEntity;

    private List<RodAndRonManHrsEntity> laaRonEntity;

    private List<RodAndRonManHrsEntity> laaRodEntity;

    @MockBean
    private RodAndRonManHrsRepository rodAndRonManHrsRepository;

    @MockBean
    private LaaRodManHrsService rodManHrsService;

    @Autowired
    private FeatureSwitchUtil featureSwitchUtil;







    @Before
    public void setUp() throws Exception {

        lusRonEntity = new ArrayList<>();
        RodAndRonManHrsEntity ob1 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob2 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob7 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob8 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity p00 = new RodAndRonManHrsEntity();

        ob1.setPriorityCode(2L);
        ob1.setStation("DFW");
        ob1.setTotalManHrsOfpriorityCode(25F);

        ob2.setPriorityCode(3L);
        ob2.setStation("DFW");
        ob2.setTotalManHrsOfpriorityCode(25F);

        ob7.setPriorityCode(3L);
        ob7.setStation("CLT");
        ob7.setTotalManHrsOfpriorityCode(0F);

        ob8.setPriorityCode(2L);
        ob8.setStation("CLT");
        ob8.setTotalManHrsOfpriorityCode(100F);

        p00.setPriorityCode(0L);
        p00.setStation("DFW");
        p00.setTotalManHrsOfpriorityCode(0F);

        lusRonEntity.add(ob1);
        lusRonEntity.add(ob2);
        lusRonEntity.add(ob7);
        lusRonEntity.add(ob8);
        lusRonEntity.add(p00);


        lusRodEntity = new ArrayList<>();

        RodAndRonManHrsEntity ob3 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob4 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob9 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob10 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity p01 = new RodAndRonManHrsEntity();


        ob3.setPriorityCode(2L);
        ob3.setStation("DFW");
        ob3.setTotalManHrsOfpriorityCode(25F);

        ob4.setPriorityCode(3L);
        ob4.setStation("DFW");
        ob4.setTotalManHrsOfpriorityCode(25F);

        ob9.setPriorityCode(3L);
        ob9.setStation("CLT");
        ob9.setTotalManHrsOfpriorityCode(0F);

        p01.setPriorityCode(0L);
        p01.setStation("DFW");
        p01.setTotalManHrsOfpriorityCode(25F);



        lusRodEntity.add(ob3);
        lusRodEntity.add(ob4);
        lusRodEntity.add(ob9);
        lusRodEntity.add(p01);

        laaRonEntity = new ArrayList<>();

        RodAndRonManHrsEntity ob5 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob6 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob11 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob12 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity n3 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity p02 = new RodAndRonManHrsEntity();

        ob5.setPriorityCode(2L);
        ob5.setStation("DFW");
        ob5.setTotalManHrsOfpriorityCode(25F);

        ob6.setPriorityCode(3L);
        ob6.setStation("DFW");
        ob6.setTotalManHrsOfpriorityCode(25F);

        ob11.setPriorityCode(3L);
        ob11.setStation("CLT");
        ob11.setTotalManHrsOfpriorityCode(22F);

        ob12.setPriorityCode(2L);
        ob12.setStation("CLT");
        ob12.setTotalManHrsOfpriorityCode(25F);

        p02.setPriorityCode(0L);
        p02.setStation("DFW");
        p02.setTotalManHrsOfpriorityCode(25F);

        laaRonEntity.add(ob5);
        laaRonEntity.add(ob6);
        laaRonEntity.add(ob11);
        laaRonEntity.add(ob12);
        laaRonEntity.add(p02);

        laaRodEntity = new ArrayList<>();
        RodAndRonManHrsEntity ob13 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob14 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob15 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity ob16 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity p03 = new RodAndRonManHrsEntity();

        ob13.setPriorityCode(2L);
        ob13.setStation("DFW");
        ob13.setTotalManHrsOfpriorityCode(25F);

        ob14.setPriorityCode(3L);
        ob14.setStation("DFW");
        ob14.setTotalManHrsOfpriorityCode(25F);

        ob15.setPriorityCode(3L);
        ob15.setStation("CLT");
        ob15.setTotalManHrsOfpriorityCode(35F);

        ob16.setPriorityCode(2L);
        ob16.setStation("CLT");
        ob16.setTotalManHrsOfpriorityCode(25F);

        p03.setPriorityCode(0L);
        p03.setStation("DFW");
        p03.setTotalManHrsOfpriorityCode(25F);

        laaRodEntity.add(ob13);
        laaRodEntity.add(ob14);
        laaRodEntity.add(ob15);
        laaRodEntity.add(ob16);
        laaRodEntity.add(p03);
    }

    /**
     * Test case for getting all Total ManHrs(Ron and Rod) for Both Lus and Laa
     */
    @Test
    public void getTotalManHrs_Success() {

        String date="2018-04-23";
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.MAN_HRS_DATE, date);

        given(this.rodAndRonManHrsRepository.getLusRonManHrs(date)).willReturn(lusRonEntity);
        given(this.rodAndRonManHrsRepository.getLusRodManHrs(date)).willReturn(lusRodEntity);
        given(this.rodAndRonManHrsRepository.getLaaRonManHrs(date)).willReturn(laaRonEntity);
        given(this.rodManHrsService.getLaaRodManHrs(searchCriteria)).willReturn(laaRodEntity);

        List<RodAndRonManHours> result = rodAndRonManHrsService.getTotalManHrs(searchCriteria);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
        if(featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N"))  {
            assertThat(result.get(0).getRonTotalManHours()).isEqualTo(100);
            assertThat(result.get(0).getRodTotalManHours()).isEqualTo(100);
        }else{
            assertThat(result.get(0).getRonTotalManHours()).isEqualTo(125);
            assertThat(result.get(0).getRodTotalManHours()).isEqualTo(150);
        }

    }

    /**
     * Test case for validating null date
     */
    @Test
    public void getTotalManHrs_nulldate() {

        String date=null;
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

        boolean result=false;
        given(this.rodAndRonManHrsRepository.getLusRonManHrs(date)).willReturn(lusRonEntity);
        given(this.rodAndRonManHrsRepository.getLusRodManHrs(date)).willReturn(lusRodEntity);
        given(this.rodAndRonManHrsRepository.getLaaRonManHrs(date)).willReturn(laaRonEntity);

        try {
            List<RodAndRonManHours> rodAndRonManHours = rodAndRonManHrsService.getTotalManHrs(searchCriteria);
        }catch (InValidDateException e){
             result = true;
        }
       assertThat(result).isEqualTo(true);


    }

    /**
     * Test case for validating empty String date
     */
    @Test
    public void getTotalManHrs_empty() {

        String date="";
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

        boolean result=false;
        given(this.rodAndRonManHrsRepository.getLusRonManHrs(date)).willReturn(lusRonEntity);
        given(this.rodAndRonManHrsRepository.getLusRodManHrs(date)).willReturn(lusRodEntity);
        given(this.rodAndRonManHrsRepository.getLaaRonManHrs(date)).willReturn(laaRonEntity);

        try {
            List<RodAndRonManHours> rodAndRonManHours = rodAndRonManHrsService.getTotalManHrs(searchCriteria);
        }catch (InValidDateException e){
            result = true;
        }
        assertThat(result).isEqualTo(true);


    }

    /**
     * Test case for Invalid Date Format
     */
    @Test
    public void getTotalManHrs_invalidDateFormat() {
        String date="221-05-03";
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

        boolean result=false;
        given(this.rodAndRonManHrsRepository.getLusRonManHrs(date)).willReturn(lusRonEntity);
        given(this.rodAndRonManHrsRepository.getLusRodManHrs(date)).willReturn(lusRodEntity);
        given(this.rodAndRonManHrsRepository.getLaaRonManHrs(date)).willReturn(laaRonEntity);

        try {
            List<RodAndRonManHours> rodAndRonManHours = rodAndRonManHrsService.getTotalManHrs(searchCriteria);
        }catch (InValidDateException e){
            result = true;
        }
        assertThat(result).isEqualTo(true);


    }

    /**
     * TestCase for creating ronManHoursRecord for priority2
     */
    @Test
    public void addCombinedRonPriority2and3_Priority2_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(2L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        RodAndRonManHours rodAndRonManHours= new RodAndRonManHours();
        rodAndRonManHours.setStation("DFW");
        rodAndRonManHours.setRonPriority1And2(1f);
        rodAndRonManHours.setRonPriority3(2f);

        finalRecord.put("DFW",rodAndRonManHours);
       try {
           rodAndRonManHrsService.addCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
       }catch (Exception e){
           result=false;
       }
       assertThat(result).isEqualTo(true);

    }

    /**
     * TestCase for creating ronManHoursRecord for priority3
     */
    @Test
    public void addCombinedRonPriority2and3_Priority3_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(3L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        RodAndRonManHours rodAndRonManHours= new RodAndRonManHours();
        rodAndRonManHours.setStation("DFW");
        rodAndRonManHours.setRonPriority1And2(1f);
        rodAndRonManHours.setRonPriority3(2f);

        finalRecord.put("DFW",rodAndRonManHours);
        try {
            rodAndRonManHrsService.addCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);

    }

    /**
     * TestCase for updating ronManHoursRecord for priority2
     */
    @Test
    public void createCombinedRonPriority2and3_priority2_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(2L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        try {
            rodAndRonManHrsService.createCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for updating ronManHoursRecord for priority3
     */
    @Test
    public void createCombinedRonPriority2and3_priority3_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(3L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        try {
            rodAndRonManHrsService.createCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for creating rodManHoursRecord for priority2
     */
    @Test
    public void addCombinedRodPriority2and3_Priority2_Success(){
        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(2L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        RodAndRonManHours rodAndRonManHours= new RodAndRonManHours();
        rodAndRonManHours.setStation("DFW");
        rodAndRonManHours.setRodPriority1And2(1f);
        rodAndRonManHours.setRodPriority3(2f);

        finalRecord.put("DFW",rodAndRonManHours);
        try {
            rodAndRonManHrsService.addCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for creating rodManHoursRecord for priority3
     */
    @Test
    public void addCombinedRodPriority2and3_Priority3_Success(){
        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(3L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        RodAndRonManHours rodAndRonManHours= new RodAndRonManHours();
        rodAndRonManHours.setStation("DFW");
        rodAndRonManHours.setRodPriority1And2(1f);
        rodAndRonManHours.setRodPriority3(2f);

        finalRecord.put("DFW",rodAndRonManHours);
        try {
            rodAndRonManHrsService.addCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for creating rodManHoursRecord for priority2
     */
    @Test
    public void addCombinedRodPriority2and3_Priority2_Null(){
        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(2L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        RodAndRonManHours rodAndRonManHours= new RodAndRonManHours();
        rodAndRonManHours.setStation("DFW");
        rodAndRonManHours.setRodPriority1And2(null);
        rodAndRonManHours.setRodPriority3(null);

        finalRecord.put("DFW",rodAndRonManHours);
        try {
            rodAndRonManHrsService.addCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for updating rodManHoursRecord for priority2
     */
    @Test
    public void createCombinedRodPriority2and3_Priority2_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(2L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        try {
            rodAndRonManHrsService.createCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    /**
     * TestCase for updating rodManHoursRecord for priority3
     */
    @Test
    public void createCombinedRodPriority2and3_Priority3_Success(){

        Boolean result=true;
        RodAndRonManHrsEntity rodAndRonManHrsEntity= new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setStation("DFW");
        rodAndRonManHrsEntity.setPriorityCode(3L);
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(100f);

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        try {
            rodAndRonManHrsService.createCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
        }catch (Exception e){
            result=false;
        }
        assertThat(result).isEqualTo(true);
    }

    @Test
    public void ronAndRodManHoursRoundOff_Success(){
        List<RodAndRonManHours> rodAndRonManHoursList = new ArrayList<RodAndRonManHours>();
        RodAndRonManHours manHours= new RodAndRonManHours();
        manHours.setRonPriority0(56.65F);
        manHours.setRonPriority1And2(56.788f);
        manHours.setRonPriority3(78.8888f);
        manHours.setRodPriority0(78.55f);
        manHours.setRodPriority1And2(78.56778f);
        manHours.setRodPriority3(8989.90f);
        rodAndRonManHoursList.add(manHours);


        List<RodAndRonManHours> rodAndRonManHours = rodAndRonManHrsService.ronAndRodManHoursRoundOff(rodAndRonManHoursList);
        assertThat(rodAndRonManHours.get(0).getRonPriority0()).isEqualTo(56.7f);
        assertThat(rodAndRonManHours.get(0).getRodPriority1And2()).isEqualTo(78.6f);
        assertThat(rodAndRonManHours.get(0).getRonPriority3()).isEqualTo(78.9f);

    }
}
