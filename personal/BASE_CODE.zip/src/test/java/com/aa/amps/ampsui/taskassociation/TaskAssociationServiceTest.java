package com.aa.amps.ampsui.taskassociation;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Test class for TaskAssociationService.
 *
 * @author HCL
 * @since 9/03/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class TaskAssociationServiceTest {

    @Autowired
    private TaskAssociationService taskAssociationService;

    @Value("${ampsui.taskassociation.api}")
    private String taskAssociationRetrieveAPI;

    @Value("${ampsui.taskassociation.api.save}")
    private String taskAssociationSaveAPI;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void setUp() {
        mockServer = MockRestServiceServer.
                createServer(taskAssociationService.getRestTemplate());
    }

    private Map<String, String> getResultMap() {

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put(Constants.STATUS, Constants.RES_SUCCESS);

        return resultMap;
    }

    @Test
    public void saveTaskAssociationsData() throws JsonProcessingException, URISyntaxException,
            AmpsuiServiceException {
        mockServer.expect(ExpectedCount.once(), requestTo(new URI(taskAssociationSaveAPI)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getResultMap())));

        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("26-3210-9-0067 2796");
        taskAssociationRequest.setIncExcBlockedJobsWrapperList(getLUSTaskAssociationsData());

        Map<String, String> resultMap = taskAssociationService.
                saveTaskAssociations(taskAssociationRequest);
        mockServer.verify();
        Assert.assertEquals(Constants.RES_SUCCESS, resultMap.get(Constants.STATUS));
    }

    @Test
    public void getTaskAssociations() throws JsonProcessingException, URISyntaxException,
            AmpsuiServiceException {

        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("100-100");

        taskAssociationRetrieveAPI = taskAssociationRetrieveAPI + Constants.MNTNC_ID +
                taskAssociationRequest.getTaskId();

        mockServer.expect(ExpectedCount.once(), requestTo(new URI(taskAssociationRetrieveAPI)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(mapper.writeValueAsString(getTaskAssociationsData())));


        List<TaskAssociations> taskAssociationsList;
        taskAssociationsList = taskAssociationService.getTaskAssociations(taskAssociationRequest);
        mockServer.verify();
        assertThat(taskAssociationsList).isNotEmpty().hasSize(2);
        assertThat(taskAssociationsList.get(0).getAsoMntncCode().
                equalsIgnoreCase("EXE"));
        assertThat(taskAssociationsList.get(0).getLusAsoMntncId().
                equalsIgnoreCase("205-205"));
    }

    private static List<TaskAssociations> getTaskAssociationsData() {

        List<TaskAssociations> taskAssociationsList = new ArrayList<>();

        TaskAssociations taskAssociations = new TaskAssociations();
        taskAssociations.setAsoMntncCode("EXC");
        taskAssociations.setLusAsoMntncId("205-205");
        taskAssociationsList.add(taskAssociations);
        TaskAssociations taskAssociations1 = new TaskAssociations();
        taskAssociations1.setAsoMntncCode("EXC");
        taskAssociations1.setLusAsoMntncId("207-207");
        taskAssociationsList.add(taskAssociations1);
        return taskAssociationsList;
    }

    private static List<TaskAssociations> getLUSTaskAssociationsData() {

        List<TaskAssociations> taskAssociationsList = new ArrayList<>();
        TaskAssociations taskAssociations = new TaskAssociations();
        taskAssociations.setAssocTaskId("26-3211-9-0004 3094");
        taskAssociations.setExclusionsInd("true");
        taskAssociationsList.add(taskAssociations);
        return taskAssociationsList;
    }
}
