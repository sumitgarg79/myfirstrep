package com.aa.amps.base.bow.actions;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@code BOWStatusActionRepository}.
 *
 * @author HCL(296319)
 * @since 6/01/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BOWStatusActionRepositoryTest {

    @Autowired
    private BOWStatusActionRepository bowStatusActionRepository;

    @Before
    public void setUp() {
    }

    /**
     * Test case for getAllActions. Happy Path scenario.
     */
    @Test
    public void getAllActions() {
        List<String> strActions = Arrays.asList(new String[]{"Edit","Copy","Delete","Export To Excel","PDF"});
        List<String> result = bowStatusActionRepository.getAllActions();
        assertThat(result).isNotNull();
        Assert.assertEquals(strActions.size(),result.size());
    }
}