package com.aa.amps.ampsui.restclients;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

/**
 * Unit test class {@link StationClientService}.
 *
 * @author Neelabh Tripathi
 * @since 04/22/2019
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@WebAppConfiguration
public class StationClientServiceTest {
    private static final String STATION_TYPE_QUERY_PARAM = "stationType";
    private static final String LINE_STATION = "line";

    @Value("${ampsui.station.api.url}")
    private String stationApiUrl;

    @Autowired
    private StationClientService stationClientService;

    private MockRestServiceServer mockServer;
    private ObjectMapper mapper = new ObjectMapper();

    @Before
    public void init() {
        mockServer = MockRestServiceServer.createServer(stationClientService.getRestTemplate());
    }

    public StationResponseEntity getStationsData() {
        List<StationEntity> stationEntities = new ArrayList<>();
        StationEntity ob1 = new StationEntity();

        ob1.setMntncStnCd("JFK");
        ob1.setMntncStnTypCd("L");

        stationEntities.add(ob1);

        StationEntity ob2 = new StationEntity();

        ob2.setMntncStnCd("DFW");
        ob2.setMntncStnTypCd("L");

        stationEntities.add(ob2);

        StationResponseEntity responseEntity = new StationResponseEntity();
        responseEntity.setStationEntityList(stationEntities);

        return responseEntity;
    }

    @Test
    public void getLineMaintenanceStations() throws URISyntaxException, JsonProcessingException {
        String stationUrl = stationApiUrl + "?" + STATION_TYPE_QUERY_PARAM + "=" + LINE_STATION;

        mockServer.expect(ExpectedCount.once(), requestTo(new URI(stationUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(getStationsData())));

        StationResponseEntity stationResponseEntity = stationClientService.getLineMaintenanceStations();

        mockServer.verify();

        assertThat(stationResponseEntity).isNotNull();
        assertThat(stationResponseEntity.getStationEntityList()).isNotEmpty().hasSize(2);
        assertThat(stationResponseEntity.getStationEntityList().get(0).getMntncStnCd()).isNotBlank()
                .isEqualToIgnoringCase("JFK");

    }

    @Test
    public void getLineMaintenanceStations_NullResponseBody() throws URISyntaxException, JsonProcessingException {
        String stationUrl = stationApiUrl + "?" + STATION_TYPE_QUERY_PARAM + "=" + LINE_STATION;

        mockServer.expect(ExpectedCount.once(), requestTo(new URI(stationUrl)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK)
                                    .contentType(MediaType.APPLICATION_JSON)
                                    .body(mapper.writeValueAsString(null)));

        StationResponseEntity stationResponseEntity = stationClientService.getLineMaintenanceStations();

        mockServer.verify();

        assertThat(stationResponseEntity).isNotNull();
    }
}