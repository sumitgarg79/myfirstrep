package com.aa.amps.base.mxtypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This is test class for {{@link MxTypesRepository}}
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since 06/04/2018.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MxTypesRepositoryTest {
    @Autowired
    private MxTypesRepository mxTypesRepository;

    @Before
    public void setUp() {
    }

    @Test
    public void getAllActiveStations() {
        List<String> mxTypeEntities = mxTypesRepository.getAllMxTypes();
        assertThat(mxTypeEntities).isNotNull();
        assertThat(mxTypeEntities.size()).isGreaterThan(1); // We expect more that 1 mx type
        assertThat(mxTypeEntities.get(2).equals("BASE")).isTrue();
    }
}
