package com.aa.amps.base.bowstatustypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This is test class for {{@link BowStatusRepository}}
 *
 * @author Paul Verner(650196):American Airlines
 * @since 06/07/2018.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BowStatusRepositoryTest {
    @Autowired
    private BowStatusRepository bowStatusRepository;

    @Before
    public void setUp() {
    }

    @Test
    public void getAllActiveStations() {
        List<String> bowStatusList = bowStatusRepository.getAllBowStatusTypes();
        assertThat(bowStatusList).isNotNull();
        assertThat(bowStatusList.size()).isGreaterThan(1); // We expect more that 1 mx type
        assertThat(bowStatusList.get(0).equals("DRAFT")).isTrue();
    }
}
