package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.TaskEntity;
import com.aa.amps.base.task.WorkPackageEntity;
import com.aa.amps.cwlv.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@Link WorkPackageService}.
 *
 * @author Shyam Sundar Ashok(202571)
 * @since on 10/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class WorkPackageServiceTest {

    @Autowired
    private WorkPackageService workPackageService;

    @MockBean
    private WorkPackageRepository workPackageRepository;

    private List<WorkPackageEntity> workPackageEntityList;

    private WorkPackageEntity wrkPkgEntity;

    @Before
    public void setUp() {
        workPackageEntityList = new ArrayList<>();
        wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(1010L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("2018-08-18");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND TEST LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292148");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setTaskId("26-0500-8-0027 0981");
        taskEntity.setDescription("CKC, TRANSIT, 26L00005003, ARBS, TRANSIT CK");
        taskEntity.setDueDate(DateUtil.getDateFromString("2019-07-18", DateUtil.Basic_Date_Format));
        taskEntity.setPlannedDateAsString("");
        taskEntity.setTtgHours(532);
        taskEntity.setTtgCycles(null);
        taskEntity.setTtgDays(null);
        taskEntity.setPlannedStation("");
        taskEntity.setTaskTypeCode("ME8");
        taskEntity.setManHours(15);
        taskEntity.setRouteControlCode("U");
        taskEntity.setDni(false);
        taskEntity.setDeferralLockInd(false);
        List<TaskEntity> objTaskEntityList = new ArrayList<>();
        objTaskEntityList.add(taskEntity);
        taskEntity.setStatus("OPEN");
        wrkPkgEntity.setTaskEntityList(objTaskEntityList);
        workPackageEntityList.add(wrkPkgEntity);
    }

    /**
     * Test case for getting BOW/work package of given Draft ID.
     */
    @Test
    public void testGetBOW() throws BaseServiceException {
        long workPkgId = 1010l;
        given(this.workPackageRepository.getBowDetail(workPkgId)).willReturn(wrkPkgEntity);
        Optional<WorkPackageEntity> result = workPackageService.getBowDetail(workPkgId);
        assertThat(result).isNotNull();

        long workPackageId = result.map(WorkPackageEntity::getWorkPkgId).orElse(1L);
        assertEquals(1010, workPackageId);
    }


    @Test
    public void testGetBOW_NullInput() throws BaseServiceException {
        Long workPkgId = null;
        Optional<WorkPackageEntity> result = workPackageService.getBowDetail(workPkgId);

        assertThat(result.isPresent()).isFalse();
    }
}
