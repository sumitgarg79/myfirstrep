package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.WorkPackageEntity;
import com.aa.amps.base.util.sysparam.SysParamService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.util.BaseConstants.DRAFT_STATUS_FINALIZE_ROLE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@link BOWStatusSearchService}.
 *
 * @author HCL(296319)
 * @since on 8/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BOWStatusSearchServiceTest {

    @Autowired
    private BOWStatusSearchService bowStatusSearchService;

    @MockBean
    private BOWStatusSearchRepository bowStatusSearchRepository;

    @MockBean
    private SysParamService sysParamService;

    private List<WorkPackageEntity> workPackageEntityList;

    @Before
    public void setUp() {
        workPackageEntityList = new ArrayList<>();
        WorkPackageEntity wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(101L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("10/07/2018");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("XYZ");
        wrkPkgEntity.setWorkPkgTxt("GROUND TEST LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292147");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");
        workPackageEntityList.add(wrkPkgEntity);
    }

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void testGetWorkPackage() throws BaseServiceException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setFromDate("10/07/2018");
        searchCriteria.setToDate("10/07/2018");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("DRAFT");
        searchCriteria.setUserRole("50");

        Map<String, Object> searchMap = searchCriteria.getSearchCriteriaAsMap();

        given(this.bowStatusSearchRepository.getWorkPackages(searchMap, searchCriteria.getUserRole())).willReturn
                (workPackageEntityList);
        given(this.sysParamService.getParamValue(DRAFT_STATUS_FINALIZE_ROLE)).willReturn(searchCriteria.getUserRole());

        List<WorkPackageEntity> result = bowStatusSearchService.getWorkPackages(searchMap);

        assertThat(result).isNotNull();
        assertEquals(workPackageEntityList.size(), result.size());
    }


    @Test(expected = BaseServiceException.class)
    public void testGetWorkPackage_ParseExceptionHandler() throws BaseServiceException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setFromDate("10-07-2018");
        searchCriteria.setToDate("10-07-2018");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("DRAFT");
        searchCriteria.setUserRole("50");

        Map<String, Object> searchMap = searchCriteria.getSearchCriteriaAsMap();

        given(this.bowStatusSearchRepository.getWorkPackages(searchMap, searchCriteria.getUserRole())).willReturn(workPackageEntityList);

        bowStatusSearchService.getWorkPackages(searchMap);
        // No Assert statements as it is expected that this test case will throw BaseServiceException
        // Please see expected = BaseServiceException.class on the @Test annotation.
    }

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void testGetWorkPackage_NullInput() throws BaseServiceException {
        List<WorkPackageEntity> result;
        result = bowStatusSearchService.getWorkPackages(null);

        assertThat(result).isNotNull();
        assertThat(result.size()).isZero();
    }
}
