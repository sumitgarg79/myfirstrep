package com.aa.amps.cwlv.crossutil;

import com.aa.amps.cwlv.crossutil.audit.CrossUtilAuditService;
import com.aa.amps.cwlv.util.ServiceResponseMessage;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.aa.amps.cwlv.crossutil.CrossUtilService.CROSS_UTIL_STATION_DEL;
import static com.aa.amps.cwlv.crossutil.CrossUtilService.MNTNC_STN_CD_NULL_INVALID;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseDescription.*;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatus.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code CrossUtilService}.
 *
 * @author Neelabh Tripathi(847697)
 * Created on 3/24/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CrossUtilServiceTest {
    @Autowired
    private CrossUtilService crossUtilService;

    private List<CrossUtilEntity> crossUtilEntitiesResult;

    @MockBean
    private CrossUtilRepository crossUtilRepository;

    @MockBean
    private CrossUtilAuditService crossUtilAuditService;

    @Before
    public void setUp() throws Exception {
        crossUtilEntitiesResult = new ArrayList<>();

        CrossUtilEntity ob1 = new CrossUtilEntity();
        CrossUtilEntity ob2 = new CrossUtilEntity();

        ob1.setMntncStnCode("DFW");
        ob2.setMntncStnCode("CLT");

        crossUtilEntitiesResult.add(ob1);
        crossUtilEntitiesResult.add(ob2);
    }

    /**
     * Test case for getting all the XUtil records from DB.
     */
    @Test
    public void getCrossUtililzionDetails() {
        given(this.crossUtilRepository.getAllActiveStations()).willReturn(crossUtilEntitiesResult);

        List<CrossUtilEntity> result = crossUtilService.getCrossUtililzionDetails();

        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getMntncStnCode()).isEqualToIgnoringCase("DFW");
    }

    /**
     * Test case for updating the Xutil record. This is the success scenario.
     */
    @Test
    public void updateCrossUtilRecord_Success() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(2222L);
        recordToUpdate.setRodCapacity(2222L);
        recordToUpdate.setCrossUtilFlag('Y');

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(1);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for updating the Xutil record. This is the success scenario.
     */
    @Test
    public void updateCrossUtilRecord_LowerCaseStation() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("dfw");
        recordToUpdate.setRonCapacity(3333L);
        recordToUpdate.setRodCapacity(4444L);
        recordToUpdate.setCrossUtilFlag('Y');

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(1);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for updating the Xutil record. This is the failure scenario where record is not found.
     */
    @Test
    public void updateCrossUtilRecord_StationNotFound() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("ZSD");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(0);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.get().getMessage()).isEqualTo(RECORD_NOT_FOUND_DESC.toString());
    }

    /**
     * Test case for updating the Xutil record. This is the failure scenario where Null argument is passed to this
     * method.
     */
    @Test
    public void updateCrossUtilRecord_NullInputArgument() {
        CrossUtilEntity recordToUpdate = null;

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(NULL_REQUEST);
    }

    /**
     * Test case for updating the Xutil record. This is the failure scenario where station code is passed as empty
     * String.
     */
    @Test
    public void updateCrossUtilRecord_EmptyStation() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode(" ");

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(0);
        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.get().getMessage()).isEqualTo(MNTNC_STN_CD_NULL_INVALID.toString());
    }

    /**
     * Test case for updating the Xutil record. This is the failure scenario where station code is passed as null.
     */
    @Test
    public void updateCrossUtilRecord_NullStation() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode(null);
        recordToUpdate.setRonCapacity(-100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(0);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.get().getMessage()).isEqualTo(MNTNC_STN_CD_NULL_INVALID.toString());
    }

    /**
     * Test case for updating the Xutil record. This is the success scenario where RON Capacity is passed as 0.
     */
    @Test
    public void updateCrossUtilRecord_RonCapacityAsZero() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(0L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(1);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat((result.get().getStatus())).isEqualTo(SUCCESS);
        assertThat(result.get().getMessage()).isEqualTo(RECORD_UPDATED_SUCCESSSFULLY.toString());
    }

    /**
     * Test case for updating the Xutil record. This is the failure scenario where RON Capacity is passed as negative.
     */
    @Test
    public void updateCrossUtilRecord_RonCapacityAsNegative() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(-100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);
        assertThat(result.isPresent()).isTrue();
        assertThat((result.get().getStatus())).isEqualTo(EXCEPTION);
    }

    /**
     * Test case for updating the Xutil record. This is the success scenario.
     */
    @Test
    public void updateCrossUtilRecord_RodCapacityZero() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(3333L);
        recordToUpdate.setRodCapacity(0L);
        recordToUpdate.setCrossUtilFlag('Y');

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(1);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for updating the Xutil record. This is the success scenario.
     */
    @Test
    public void updateCrossUtilRecord_CrossUtilFlagLowerCase() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(3333L);
        recordToUpdate.setRodCapacity(0L);
        recordToUpdate.setCrossUtilFlag('y');

        given(this.crossUtilRepository.updateStation(recordToUpdate)).willReturn(1);

        Optional<ServiceResponseMessage> result = crossUtilService.updateCrossUtilRecord(recordToUpdate);

        assertThat(result.isPresent()).isTrue();
        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for setResponseForFailure where null request is passed.
     */
    @Test
    public void setResponseForFailure_NullRecordToUpdate() {
        CrossUtilEntity recordToUpdate = null;

        ServiceResponseMessage result = crossUtilService.setResponseForFailure(recordToUpdate);
        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(NULL_REQUEST);
        assertThat(result.getMessage()).isEqualTo(NULL_REQUEST_DATA.toString());
    }

    /**
     * Test case for setResponseForFailure where Station code is passed as null or empty.
     */
    @Test
    public void setResponseForFailure_BlankMntncCode() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("");
        recordToUpdate.setRonCapacity(-100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        ServiceResponseMessage result = crossUtilService.setResponseForFailure(recordToUpdate);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.getMessage()).isEqualTo(MNTNC_STN_CD_NULL_INVALID);
    }

    /**
     * Test case for setResponseForFailure where RON capacity is passed as negative value.
     */
    @Test
    public void setResponseForFailure_RonCapacityNegative() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(-100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        ServiceResponseMessage result = crossUtilService.setResponseForFailure(recordToUpdate);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.getMessage()).isEqualTo(CrossUtilService.RON_CAPACITY_INVALID);
    }

    /**
     * Test case for setResponseForFailure where ROD capacity is passed as negative value.
     */
    @Test
    public void setResponseForFailure_RodCapacityNegative() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(-10L);

        ServiceResponseMessage result = crossUtilService.setResponseForFailure(recordToUpdate);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.getMessage()).isEqualTo(CrossUtilService.ROD_CAPACITY_INVALID);
    }

    /**
     * Test case for setResponseForFailure where ROD capacity is passed as negative value.
     */
    @Test
    public void setResponseForFailure_CrossUtilFlagNotYN() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Z');
        recordToUpdate.setRodCapacity(10L);

        ServiceResponseMessage result = crossUtilService.setResponseForFailure(recordToUpdate);

        assertThat(result).isNotNull();
        assertThat(result.getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.getMessage()).isEqualTo(CrossUtilService.CROSS_UTIL_FLAG_INVALID);
    }

    /**
     * Test for isValidStationFormat success scenario.
     */
    @Test
    public void isValidStationFormat_Success() {
        boolean result = crossUtilService.isValidStationFormat("DFW");

        assertThat(result).isTrue();
    }

    /**
     * Test for isValidStationFormat method.
     */
    @Test
    public void isValidStationFormat_NonAlphabetsChars() {
        boolean resultStationWithNumbers = crossUtilService.isValidStationFormat("DF2");
        boolean resultStationWithSpecialChars = crossUtilService.isValidStationFormat("DF!");

        assertThat(resultStationWithNumbers).isFalse();
        assertThat(resultStationWithSpecialChars).isFalse();
    }

    /**
     * Test for isValidRodCapacity method.
     */
    @Test
    public void isValidRodCapacity_NullInput() {
        boolean result = crossUtilService.isValidRodCapacity(null);

        assertThat(result).isFalse();
    }

    /**
     * Test for isValidRonCapacity method.
     */
    @Test
    public void isValidRonCapacity_Success() {
        boolean result = crossUtilService.isValidRonCapacity(100L);

        assertThat(result).isTrue();
    }

    /**
     * Test for isValidRonCapacity method.
     */
    @Test
    public void isValidRonCapacity_ZeroAndNegativeValue() {
        boolean result = crossUtilService.isValidRonCapacity(-10L);
        boolean resultZero = crossUtilService.isValidRonCapacity(0L);

        assertThat(result).isFalse();
        assertThat(resultZero).isTrue();
    }

    /**
     * Test for isValidRonCapacity method.
     */
    @Test
    public void isValidRonCapacity_NullInput() {
        boolean result = crossUtilService.isValidRonCapacity(null);

        assertThat(result).isFalse();
    }

    /**
     * Test for isValidRonCapacity method.
     */
    @Test
    public void isValidRodCapacity_Success() {
        boolean result = crossUtilService.isValidRodCapacity(100L);
        boolean resultZero = crossUtilService.isValidRodCapacity(0L);

        assertThat(result).isTrue();
        assertThat(resultZero).isTrue();
    }

    /**
     * Test for isValidRodCapacity method.
     */
    @Test
    public void isValidRodCapacity_Negative() {
        boolean result = crossUtilService.isValidRodCapacity(-100L);

        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossUtilFlag method.
     */
    @Test
    public void isValidCrossUtilFlag_Success() {
        boolean resultY = crossUtilService.isValidCrossUtilFlag('Y');
        boolean resultN = crossUtilService.isValidCrossUtilFlag('Y');
        boolean resultLowercaseY = crossUtilService.isValidCrossUtilFlag('y');
        boolean resultLowerCaseN = crossUtilService.isValidCrossUtilFlag('N');

        assertThat(resultY).isTrue();
        assertThat(resultN).isTrue();
        assertThat(resultLowercaseY).isTrue();
        assertThat(resultLowerCaseN).isTrue();
    }

    /**
     * Test for isValidCrossUtilFlag method.
     */
    @Test
    public void isValidCrossUtilFlag_NonYNInputCharacters() {
        boolean result = crossUtilService.isValidCrossUtilFlag('Q');

        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossUtilFlag method.
     */
    @Test
    public void isValidCrossUtilFlag_NullInput() {
        boolean result = crossUtilService.isValidCrossUtilFlag(null);

        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossEntityRecord.
     */
    @Test
    public void isValidCrossEntityRecord_success() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        boolean result = crossUtilService.isValidCrossEntityRecord(recordToUpdate);
        assertThat(result).isTrue();
    }

    /**
     * Test for isValidCrossEntityRecord.
     */
    @Test
    public void isValidCrossEntityRecord_StationInvalid() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DF1");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        boolean result = crossUtilService.isValidCrossEntityRecord(recordToUpdate);
        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossEntityRecord.
     */
    @Test
    public void isValidCrossEntityRecord_RonCapacityInvalid() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(-100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(10L);

        boolean result = crossUtilService.isValidCrossEntityRecord(recordToUpdate);
        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossEntityRecord.
     */
    @Test
    public void isValidCrossEntityRecord_RodCapacityInvalid() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Y');
        recordToUpdate.setRodCapacity(-10L);

        boolean result = crossUtilService.isValidCrossEntityRecord(recordToUpdate);
        assertThat(result).isFalse();
    }

    /**
     * Test for isValidCrossEntityRecord.
     */
    @Test
    public void isValidCrossEntityRecord_CrossUtilFlagInvalid() {
        CrossUtilEntity recordToUpdate = new CrossUtilEntity();

        recordToUpdate.setMntncStnCode("DFW");
        recordToUpdate.setRonCapacity(100L);
        recordToUpdate.setCrossUtilFlag('Z');
        recordToUpdate.setRodCapacity(10L);

        boolean result = crossUtilService.isValidCrossEntityRecord(recordToUpdate);
        assertThat(result).isFalse();
    }

    /**
     * Test case for adding a new station successfully.
     */
    @Test
    public void addStation_SuccessWithFreshRecord() {
        CrossUtilEntity entityToAdd = new CrossUtilEntity();

        entityToAdd.setMntncStnCode("XYZ");
        entityToAdd.setCrossUtilFlag('Y');
        entityToAdd.setRodCapacity(1999L);
        entityToAdd.setRonCapacity(4999L);

        given(this.crossUtilRepository.getStation(entityToAdd.getMntncStnCode())).willReturn(new CrossUtilEntity());
        given(this.crossUtilRepository.addStation(entityToAdd)).willReturn(1);

        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToAdd);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for adding a station successfully.
     */
    @Test
    public void addStation_SuccessWithExistingRecord() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();

        entityToUpdateAdd.setMntncStnCode("XYZ");
        entityToUpdateAdd.setCrossUtilFlag('Y');
        entityToUpdateAdd.setRodCapacity(1999L);
        entityToUpdateAdd.setRonCapacity(4999L);

        CrossUtilEntity getStationResponse = new CrossUtilEntity();

        getStationResponse.setMntncStnCode("XYZ");
        getStationResponse.setCrossUtilFlag('Y');
        getStationResponse.setRodCapacity(200L);
        getStationResponse.setRonCapacity(300L);
        getStationResponse.setActiveFlag('N');

        given(this.crossUtilRepository.getStation("XYZ")).willReturn(getStationResponse);
        given(this.crossUtilRepository.updateStationToActive(entityToUpdateAdd)).willReturn(1);

        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToUpdateAdd);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(SUCCESS);
    }

    /**
     * Test case for adding a station success Scenario;
     */
    @Test
    public void addStation_StationExist() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();

        entityToUpdateAdd.setMntncStnCode("XYZ");
        entityToUpdateAdd.setCrossUtilFlag('Y');
        entityToUpdateAdd.setRodCapacity(1999L);
        entityToUpdateAdd.setRonCapacity(4999L);
        entityToUpdateAdd.setActiveFlag('Y');

        given(this.crossUtilRepository.getStation("XYZ")).willReturn(entityToUpdateAdd);


        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToUpdateAdd);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(serviceResponseMessage.get().getMessage()).isEqualTo(STATION_ALREADY_EXSIST.toString());
    }

    /**
     * Test case for adding a new station Failure.
     */
    @Test
    public void addStation_WithFreshRecord() {
        CrossUtilEntity entityToAddFailure = new CrossUtilEntity();

        entityToAddFailure.setMntncStnCode("XYZ");
        entityToAddFailure.setCrossUtilFlag('Y');
        entityToAddFailure.setRodCapacity(1999L);
        entityToAddFailure.setRonCapacity(4999L);
        entityToAddFailure.setUserId("847697");

        given(this.crossUtilRepository.getStation(entityToAddFailure.getMntncStnCode()))
            .willReturn(new CrossUtilEntity());

        given(this.crossUtilRepository.addStation(entityToAddFailure)).willReturn(1);

        given(this.crossUtilAuditService.audit(entityToAddFailure)).willReturn(true);

        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToAddFailure);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(SUCCESS);
        assertThat(serviceResponseMessage.get().getMessage()).isEqualTo(RECORD_ADDED_SUCCESSSFULLY.toString());

    }

    /**
     * Test case for add station failure.
     */
    @Test
    public void addStation_FailureWithExistingRecord() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();

        entityToUpdateAdd.setMntncStnCode("XYZ");
        entityToUpdateAdd.setCrossUtilFlag('Y');
        entityToUpdateAdd.setRodCapacity(199L);
        entityToUpdateAdd.setRonCapacity(499L);

        CrossUtilEntity getStationResponse = new CrossUtilEntity();

        getStationResponse.setMntncStnCode("XYZ");
        getStationResponse.setCrossUtilFlag('Y');
        getStationResponse.setRodCapacity(200L);
        getStationResponse.setRonCapacity(300L);
        getStationResponse.setActiveFlag('N');

        given(this.crossUtilRepository.getStation("XYZ")).willReturn(getStationResponse);
        given(this.crossUtilRepository.updateStationToActive(entityToUpdateAdd)).willReturn(0);

        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToUpdateAdd);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(serviceResponseMessage.get().getMessage()).isEqualTo(RECORD_NOT_ADDED_DESC.toString());
    }

    /**
     * Test case for  station validation failure while adding station.
     */
    @Test
    public void addStation_validationFailure() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();

        entityToUpdateAdd.setMntncStnCode("");
        entityToUpdateAdd.setCrossUtilFlag('Y');
        entityToUpdateAdd.setRodCapacity(199L);
        entityToUpdateAdd.setRonCapacity(499L);
        entityToUpdateAdd.setActiveFlag('N');

        given(this.crossUtilRepository.getStation("XYZ")).willReturn(entityToUpdateAdd);
        given(this.crossUtilRepository.updateStationToActive(entityToUpdateAdd)).willReturn(0);

        Optional<ServiceResponseMessage> serviceResponseMessage = crossUtilService.addStation(entityToUpdateAdd);

        assertThat(serviceResponseMessage.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(serviceResponseMessage.get().getMessage()).isEqualTo(MNTNC_STN_CD_NULL_INVALID);
    }

    /**
     * Test case for  station validation failure while adding station.
     */
    @Test
    public void getStation_success() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();
        entityToUpdateAdd.setMntncStnCode("DFW");
        given(this.crossUtilRepository.getStation(entityToUpdateAdd.getMntncStnCode())).willReturn(entityToUpdateAdd);
        CrossUtilEntity result = crossUtilService.getStation(entityToUpdateAdd.getMntncStnCode());
        assertThat(result).isNotNull();
    }

    /**
     * Test case for  station validation failure while adding station.
     */
    @Test
    public void getStation_successLowerCase() {
        CrossUtilEntity entityToUpdateAdd = new CrossUtilEntity();
        entityToUpdateAdd.setMntncStnCode("dfw");
        given(this.crossUtilRepository.getStation(entityToUpdateAdd.getMntncStnCode())).willReturn(entityToUpdateAdd);
        CrossUtilEntity result = crossUtilService.getStation(entityToUpdateAdd.getMntncStnCode());
        assertThat(result).isNotNull();
    }


    /**
     * Test case for  delete Station happyPath.
     */
    @Test
    public void deleteStation_success() {
        String stn = "DFW";
        String userId = "847697";

        given(this.crossUtilRepository.deleteStation(stn)).willReturn(1);
        Optional<ServiceResponseMessage> result = crossUtilService.deleteStation(stn, userId);

        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
        assertThat(result.get().getMessage()).isEqualTo(CROSS_UTIL_STATION_DEL);
    }

    /**
     * Test case for  delete Station happyPath.
     */
    @Test
    public void deleteStation_successLowerCase() {
        String stn = "dfw";
        String userId = "847697";

        given(this.crossUtilRepository.deleteStation(stn)).willReturn(1);
        Optional<ServiceResponseMessage> result = crossUtilService.deleteStation(stn, userId);

        assertThat(result.get().getStatus()).isEqualTo(SUCCESS);
        assertThat(result.get().getMessage()).isEqualTo(CROSS_UTIL_STATION_DEL);
    }

    /**
     * Test case for  delete Station happyPath.
     */
    @Test
    public void deleteStation_NullInput() {
        String stn = null;
        String userId = null;

        given(this.crossUtilRepository.deleteStation(null)).willReturn(0);

        Optional<ServiceResponseMessage> result = crossUtilService.deleteStation(stn, userId);

        assertThat(result.get().getStatus()).isEqualTo(EXCEPTION);
        assertThat(result.get().getMessage()).isEqualTo(ServiceResponseMessage
                                                            .ServiceResponseDescription.RECORD_NOT_FOUND_DESC
                                                            .toString());
    }

    /**
     * Test Case for Cross Util Station list. The cross util flag should be Y for the response stations.
     */
    @Test
    public void getCrossUtilStations_Success() {

        List<CrossUtilEntity> crossUtilEntities = new ArrayList<>();

        CrossUtilEntity ob1 = new CrossUtilEntity();
        CrossUtilEntity ob2 = new CrossUtilEntity();

        ob1.setMntncStnCode("DFW");
        ob1.setCrossUtilFlag('Y');
        ob1.setActiveFlag('Y');

        ob2.setMntncStnCode("CLT");
        ob2.setCrossUtilFlag('N');
        ob2.setActiveFlag('Y');

        crossUtilEntities.add(ob1);
        crossUtilEntities.add(ob2);

        given(this.crossUtilRepository.getAllActiveStations()).willReturn(crossUtilEntities);

        List<String> stationList = crossUtilService.getCrossUtilizationStation();

        assertThat(stationList).isNotNull();
        assertThat(stationList.size()).isEqualTo(1);
        assertThat(stationList.get(0)).isEqualToIgnoringCase("DFW");
    }

    @Test
    public void getCrossUtilStations_EmptyResult() {

        List<CrossUtilEntity> crossUtilEntities = new ArrayList<>();

        given(this.crossUtilRepository.getAllActiveStations()).willReturn(crossUtilEntities);

        List<String> stationList = crossUtilService.getCrossUtilizationStation();

        assertThat(stationList).isNotNull();
        assertThat(stationList.size()).isEqualTo(0);
    }
}
