package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.TaskEntity;
import com.aa.amps.base.task.TaskService;
import com.aa.amps.base.task.WorkPackageEntity;
import com.aa.amps.cwlv.util.DateUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@Link WorkPackageController}.
 *
 * @author HCL(296319)
 * @since on 8/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class WorkPackageControllerTest {

    @Autowired
    private WorkPackageController workPackageController;
    @MockBean
    private WorkPackageService workpackageService;
    @MockBean
    private TaskService taskService;

    private TaskEntity taskEntity = new TaskEntity();
    private List<TaskEntity> objTaskEntityList = new ArrayList<>();
    private WorkPackageEntity wrkPkgEntity;

    @Before
    public void setUp() {

        wrkPkgEntity = new WorkPackageEntity();
        wrkPkgEntity.setWorkPkgId(2424L);
        wrkPkgEntity.setAircraftNbr("824");
        wrkPkgEntity.setPkgSchdDt("2018-07-18");
        wrkPkgEntity.setPlanStationCd("DFW");
        wrkPkgEntity.setTrackTypeCd("ME8");
        wrkPkgEntity.setSpan(1L);
        wrkPkgEntity.setWorkOrderJobCd("1234");
        wrkPkgEntity.setSceptreMntncWorkPkgId("1111");
        wrkPkgEntity.setDockCd("58");
        wrkPkgEntity.setWorkPkgTxt("GROUND TEST LEFT");
        wrkPkgEntity.setWorkPkgStatusCd("DRAFT");
        wrkPkgEntity.setUserId("292148");
        wrkPkgEntity.setUpdatedTime("2018-07-10 00:00:00");

        taskEntity.setTaskId("26-0500-8-0027 0981");
        taskEntity.setDescription("CKC, TRANSIT, 26L00005003, ARBS, TRANSIT CK");
        taskEntity.setDueDate(DateUtil.getDateFromString("2019-07-18", DateUtil.Basic_Date_Format));
        taskEntity.setPlannedDateAsString("");
        taskEntity.setTtgHours(532);
        taskEntity.setTtgCycles(null);
        taskEntity.setTtgDays(null);
        taskEntity.setPlannedStation("");
        taskEntity.setTaskTypeCode("ME8");
        taskEntity.setManHours(15);
        taskEntity.setRouteControlCode("U");
        taskEntity.setDni(false);
        taskEntity.setDeferralLockInd(false);
        taskEntity.setStatus("OPEN");

        objTaskEntityList.add(taskEntity);
    }

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void getBOW() throws BaseServiceException {
        Long workPkgId = 2424L;

        given(this.workpackageService.getBowDetail(workPkgId)).willReturn(Optional.of(wrkPkgEntity));
        given(this.taskService.getWorkPackageTasks(workPkgId)).willReturn(objTaskEntityList);
        WorkPackageEntity result = workPackageController.retrieveBow(workPkgId);

        assertThat(result).isNotNull();
        assertThat(result.getTaskEntityList()).isNotNull();

        assertEquals(2424, result.getWorkPkgId().longValue());
    }

    /**
     * Test case for deleting work package of given search inputs.
     */
    @Test
    public void deleteBOW() throws BaseServiceException {
        Long workPkgId = 2424L;
        String userId = "922166";
        given(this.taskService.deleteBaseBOW(workPkgId, userId)).willReturn(true);
        boolean result = workPackageController.deleteBow(workPkgId, userId);

        assertThat(result).isNotNull();
        assertTrue("Expected true as a response", result);
    }
}
