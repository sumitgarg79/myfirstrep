package com.aa.amps.base.preset;

import com.aa.amps.base.exception.BaseRepositoryException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;


/**
 * Test class for {@Link PresetController}.
 *
 * @author Ramesh Rudra(842020)
 * @since on 8/20/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class PresetControllerTest {

    List<PresetResponse> presetResponses;
    @Autowired
    private PresetController presetController;
    @MockBean
    private PresetService presetService;

    private static final String SEARCH_TXT = "\"{\\\"pageCount\\\":0,\\\"searchCriteria\\\"" +
            ":{\\\"statusPlanned\\\":true,\\\"sortedItems\\\":[\\\"FleetCode\\\"" +
            ",\\\"AircraftNum\\\",\\\"Criticality\\\"],\\\"allowOTRTypes\\\":false" +
            ",\\\"fleetCode\\\":[787],\\\"airlineCode\\\":\\\"US\\\",\\\"statusOpen\\\"" +
            ":true,\\\"recordCount\\\":false}}\"";

    @Before
    @Transactional
    public void setUp() {

        presetResponses = new ArrayList<>();
        PresetResponse response = new PresetResponse();
        response.setSno("123");
        response.setPresetCreatedDt("10-07-18");
        response.setPresetData("abc");
        response.setPresetDesc("description");
        response.setPresetTypeCd("F");
        response.setPresetUpdatedDt("10-07-18");
        presetResponses.add(response);
    }

    @Test
    public void getPresets() throws ParseException {

        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("842020");
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        given(this.presetService.findByUserIdAndSearchCriterTypeCd(presetRequest)).willReturn(presetResponses);
        List<PresetResponse> presets = presetController.getPresets(presetRequest);

        assertThat(presets.size()).isNotNull();
        assertThat(presets.size()).isEqualTo(1);
        assertThat(presets.get(0).getSno()).isEqualTo("123");

    }

    @Test
    public void addPreset() throws ParseException, BaseRepositoryException {
        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("842020");
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        given(this.presetService.addPreset(presetRequest)).willReturn(presetResponses);
        List<PresetResponse> presets = presetController.addPreset(presetRequest);

        assertThat(presets.size()).isNotNull();
        assertThat(presets.size()).isEqualTo(1);
        assertThat(presets.get(0).getSno()).isEqualTo("123");

    }

    @Test
    public void updatePreset() throws ParseException, BaseRepositoryException {
        PresetRequest presetRequest = new PresetRequest();
        presetRequest.setSearchCriterCd("T");
        presetRequest.setUserId("842020");
        presetRequest.setSearchCriterId(2);
        presetRequest.setSearchCriterTxt(SEARCH_TXT);

        given(this.presetService.updatePreset(presetRequest)).willReturn(presetResponses);
        List<PresetResponse> presets = presetController.updatePreset(presetRequest);

        assertThat(presets.size()).isNotNull();
        assertThat(presets.size()).isEqualTo(1);
        assertThat(presets.get(0).getSno()).isEqualTo("123");

    }

    @Test
    public void deletePreset() throws ParseException, BaseRepositoryException {
        PresetRequest request = new PresetRequest();
        request.setSearchCriterCd("T");
        request.setUserId("842020");
        request.setSearchCriterId(2);

        when(this.presetService.deletePreset(request)).thenReturn(presetResponses);
        List<PresetResponse> presets = presetController.deletePreset(request.getUserId(), request.getSearchCriterId()
                , request.getSearchCriterCd());

        assertThat(presets.size()).isNotNull();
        assertThat(presets.size()).isEqualTo(1);

    }
}