package com.aa.amps.cwlv.crossutil.audit;

import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Neelabh Tripathi(847697) on 6/18/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class CrossUtilAuditRepositoryTest {

    @Autowired
    private CrossUtilAuditRepository crossUtilAuditRepository;

    @Test
    public void addAuditRecord_Success() {
        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setMntncStnCode("DFW");
        recordToAudit.setActiveFlag('Y');
        recordToAudit.setRonCapacity(400L);
        recordToAudit.setRodCapacity(200L);
        recordToAudit.setCrossUtilFlag('Y');
        recordToAudit.setUserId("847697");

        int rowsUpdated = crossUtilAuditRepository.addAuditRecord(recordToAudit);

        assertThat(rowsUpdated).isEqualTo(1);
    }

    @Test
    public void addAuditRecord_nullCrossUtilFlag() {
        CrossUtilEntity recordToAudit = new CrossUtilEntity();
        recordToAudit.setMntncStnCode("DFW");
        recordToAudit.setRonCapacity(400L);
        recordToAudit.setRodCapacity(200L);
        recordToAudit.setActiveFlag('Y');
        recordToAudit.setUserId("847697");

        int rowsUpdated = crossUtilAuditRepository.addAuditRecord(recordToAudit);

        assertThat(rowsUpdated).isEqualTo(1);
    }
}
