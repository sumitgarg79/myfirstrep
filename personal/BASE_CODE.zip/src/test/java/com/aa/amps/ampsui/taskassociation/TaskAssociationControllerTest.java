package com.aa.amps.ampsui.taskassociation;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.Constants;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for TaskAssociationController.
 *
 * @author HCL
 * @since 09/03/2019
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class TaskAssociationControllerTest {

    @Autowired
    private TaskAssociationController taskAssociationController;

    @MockBean
    private TaskAssociationService taskAssociationService;

    @Test
    public void saveLUSTaskAssociationsData() throws AmpsuiServiceException {
        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("26-3210-9-0067 2796");
        taskAssociationRequest.setIncExcBlockedJobsWrapperList(getLUSTaskAssociationsData());
        given(taskAssociationService.saveTaskAssociations(taskAssociationRequest)).willReturn(getResponseMap());
        Map<String, String> responseMap = taskAssociationController.saveTaskAssociations(taskAssociationRequest);
        Assert.assertEquals(Constants.RES_SUCCESS, responseMap.get(Constants.STATUS));
    }

    @Test
    public void getLUSTaskAssociationsList() throws AmpsuiServiceException {
        TaskAssociationRequest taskAssociationRequest = new TaskAssociationRequest();
        taskAssociationRequest.setTaskId("100-100");
        given(taskAssociationService.getTaskAssociations(taskAssociationRequest)).willReturn(getTaskAssociationsData());
        List<TaskAssociations> taskAssociationsList = taskAssociationController.getTaskAssociationsList(taskAssociationRequest);
        assertThat(taskAssociationsList).isNotNull().isNotEmpty().hasSize(2);
        assertThat(taskAssociationsList.get(0).getAsoMntncCode().equalsIgnoreCase("EXC"));
    }

    private static List<TaskAssociations> getLUSTaskAssociationsData() {

        List<TaskAssociations> taskAssociationsList = new ArrayList<>();
        TaskAssociations taskAssociations = new TaskAssociations();
        taskAssociations.setAssocTaskId("26-3211-9-0004 3094");
        taskAssociations.setExclusionsInd("true");
        taskAssociationsList.add(taskAssociations);
        return taskAssociationsList;
    }

    private static List<TaskAssociations> getTaskAssociationsData() {

        List<TaskAssociations> taskAssociationsList = new ArrayList<>();

        TaskAssociations taskAssociations = new TaskAssociations();
        taskAssociations.setAsoMntncCode("EXC");
        taskAssociations.setLusAsoMntncId("205-205");
        taskAssociationsList.add(taskAssociations);
        TaskAssociations taskAssociations1 = new TaskAssociations();
        taskAssociations1.setAsoMntncCode("EXC");
        taskAssociations1.setLusAsoMntncId("207-207");
        taskAssociationsList.add(taskAssociations1);
        return taskAssociationsList;
    }

    private Map<String, String> getResponseMap() {

        Map<String, String> responseMap = new HashMap<>();
        responseMap.put(Constants.STATUS, Constants.RES_SUCCESS);

        return responseMap;
    }
}

