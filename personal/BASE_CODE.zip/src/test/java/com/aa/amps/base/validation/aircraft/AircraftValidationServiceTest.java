package com.aa.amps.base.validation.aircraft;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@Link AircraftValidationService}.
 *
 * @author HCL(296319)
 * @since on 7/27/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class AircraftValidationServiceTest {
    List<AircraftValidationEntity> aircraftEntities = new ArrayList<>();
    @Autowired
    private AircraftValidationService aircraftValidationService;
    @MockBean
    private AircraftValidationRepository aircraftValidationRepository;

    @Before
    public void setup() {

        AircraftValidationEntity entity1 = new AircraftValidationEntity();
        entity1.setAircraftNumber("3AB");
        entity1.setAirlineCode("LAA");
        entity1.setFleet("737");

        aircraftEntities.add(entity1);

        AircraftValidationEntity entity2 = new AircraftValidationEntity();
        entity2.setAircraftNumber("A98");
        entity2.setAirlineCode("LUS");
        entity2.setFleet("A321");

        aircraftEntities.add(entity2);
    }

    /**
     * Test case for isValidAircraft.
     */
    @Test
    public void isActiveAircraft_LUS() {
        String aircraftNumber = "A98";
        String airlineCode = "LUS";
        String fleet = "A321";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LAA() {
        String aircraftNumber = "3AB";
        String airlineCode = "LAA";
        String fleet = "737";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LaaLowerCaseInput() {
        String aircraftNumber = "3ab";
        String airlineCode = "Laa";
        String fleet = "737";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LusLowerCaseInput() {
        String aircraftNumber = "a98";
        String airlineCode = "Lus";
        String fleet = "a321";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LaaAircraftNumberOnlyInput() {
        String aircraftNumber = "3ab";
        String airlineCode = "";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LusAircraftNumberOnlyInput() {
        String aircraftNumber = "A98";
        String airlineCode = "";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LaaAircraftNumberAndAirlineCodeOnly() {
        String aircraftNumber = "3ab";
        String airlineCode = "LAA";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LusAircraftNumberAndAirlineCodeOnly() {
        String aircraftNumber = "A98";
        String airlineCode = "LUS";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LaaAircraftNumberAndFleetOnly() {
        String aircraftNumber = "3AB";
        String airlineCode = "";
        String fleet = "737";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LusAircraftNumberAndFleetOnly() {
        String aircraftNumber = "A98";
        String airlineCode = "";
        String fleet = "A321";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isTrue();
    }

    @Test
    public void isActiveAircraft_LaaAircraftNumberNotMatchingFleet() {
        String aircraftNumber = "3AB";
        String airlineCode = "";
        String fleet = "747";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isFalse();
    }

    @Test
    public void isActiveAircraft_LusAircraftNumberNotMatchingFleet() {
        String aircraftNumber = "A98";
        String airlineCode = "";
        String fleet = "A322";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isFalse();
    }

    @Test
    public void isActiveAircraft_LaaAircraftNumberNotMatchingAirlineCode() {
        String aircraftNumber = "3AB";
        String airlineCode = "LUS";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isFalse();
    }

    @Test
    public void isActiveAircraft_LusAircraftNumberNotMatchingAirlineCode() {
        String aircraftNumber = "A98";
        String airlineCode = "LAA";
        String fleet = "";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        assertThat(isActive).isFalse();
    }

    @Test
    public void isActiveAircraft_NullInput() {
        //empty or blank string input for aircraft number.
        boolean value = aircraftValidationService.isActiveAircraft(null, null, null);
        assertThat(value).isFalse();
    }

    @Test
    public void isActiveAircraft_InvalidAircraft() {
        //invalid aircraft number case.
        String aircraftNumber = "100";
        boolean value = aircraftValidationService.isActiveAircraft(aircraftNumber, null, null);
        assertThat(value).isFalse();
    }

    @Test
    public void getAircraftDetails_LaaHappyPath() {
        String aircraftNumber = "3AB";
        String airlineCode = "LAA";
        String fleet = "737";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        AircraftValidationEntity aircraft = aircraftValidationService.getAircraftDetails(aircraftNumber);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase(aircraftNumber);
        assertThat(aircraft.getAirlineCode()).isNotEmpty().isEqualToIgnoringCase(airlineCode);
        assertThat(aircraft.getFleet()).isNotEmpty().isEqualToIgnoringCase(fleet);
    }

    @Test
    public void getAircraftDetails_LusHappyPath() {
        String aircraftNumber = "A98";
        String airlineCode = "LUS";
        String fleet = "A321";

        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        AircraftValidationEntity aircraft = aircraftValidationService.getAircraftDetails(aircraftNumber);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNotEmpty().isEqualToIgnoringCase(aircraftNumber);
        assertThat(aircraft.getAirlineCode()).isNotEmpty().isEqualToIgnoringCase(airlineCode);
        assertThat(aircraft.getFleet()).isNotEmpty().isEqualToIgnoringCase(fleet);
    }

    @Test
    public void getAircraftDetails_NullInput() {
        given(this.aircraftValidationRepository.getAircraftList()).willReturn(aircraftEntities);
        AircraftValidationEntity aircraft = aircraftValidationService.getAircraftDetails(null);

        assertThat(aircraft).isNotNull();
        assertThat(aircraft.getAircraftNumber()).isNullOrEmpty();
    }
}
