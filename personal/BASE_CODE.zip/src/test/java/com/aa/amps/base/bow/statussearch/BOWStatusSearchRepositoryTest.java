package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.task.WorkPackageEntity;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.PKG_SCHD_FROM;
import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.PKG_SCHD_TO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test class for {@link BOWStatusSearchRepository}.
 *
 * @author HCL(296319)
 * @since on 8/15/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BOWStatusSearchRepositoryTest {

    @Autowired
    private BOWStatusSearchRepository bowStatusSearchRepository;

    /**
     * Test case for getting work package of given search inputs.
     */
    @Test
    public void testGetWorkPackage() throws ParseException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        String finalizeRole = "52";
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("DRAFT");

        Map<String, Object> paramMap = searchCriteria.getSearchCriteriaAsMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // this format is important!
        Date fromDate = sdf.parse("2018-10-07");
        Date toDate = sdf.parse("2018-10-07");

        paramMap.put(PKG_SCHD_FROM, fromDate);
        paramMap.put(PKG_SCHD_TO, toDate);

        List<WorkPackageEntity> result = bowStatusSearchRepository.getWorkPackages(paramMap, finalizeRole);
        assertThat(result).isNotNull();
        assertEquals(1, result.size());
        assertEquals(2424, result.get(0).getWorkPkgId().intValue());
    }

    /**
     * Test case to check default order by for work package of given search inputs.
     */
    @Test
    public void testGetWorkPackageDefaultOrderBy() throws ParseException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        String finalizeRole = "52";
        searchCriteria.setAircraftNumber("824");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("DRAFT");

        Map<String, Object> paramMap = searchCriteria.getSearchCriteriaAsMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // this format is important!
        Date fromDate = sdf.parse("2018-10-07");
        Date toDate = sdf.parse("2018-10-08");

        paramMap.put(PKG_SCHD_FROM, fromDate);
        paramMap.put(PKG_SCHD_TO, toDate);

        List<WorkPackageEntity> result = bowStatusSearchRepository.getWorkPackages(paramMap, finalizeRole);

        assertThat(result).isNotNull();
        assertEquals(2, result.size());
        sdf = new SimpleDateFormat("MM/dd/yyyy");
        assertTrue(sdf.parse(result.get(0).getPkgSchdDt()).before(sdf.parse(result.get(1).getPkgSchdDt())));
    }

    /**
     * Since Aircraft is mandatory field then there should not be any result.
     */
    @Test
    public void testGetWorkPackage_NoAircraftNumber() {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();
        searchCriteria.setUserRole("52");
        List<WorkPackageEntity> result = bowStatusSearchRepository
                .getWorkPackages(searchCriteria.getSearchCriteriaAsMap(), searchCriteria.getUserRole());
        assertThat(result).isNotNull();
        assertEquals(0, result.size());
    }

    /**
     * Test case for getting work package of given search inputs for visitor role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for visitor role.
     */
    @Test
    public void testGetWorkPackageForVisitor() throws ParseException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();

        searchCriteria.setAircraftNumber("824");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("FINALIZED");
        searchCriteria.setUserRole("52");

        Map<String, Object> paramMap = searchCriteria.getSearchCriteriaAsMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // this format is important!
        Date fromDate = sdf.parse("2018-10-05");
        Date toDate = sdf.parse("2018-10-05");

        paramMap.put(PKG_SCHD_FROM, fromDate);
        paramMap.put(PKG_SCHD_TO, toDate);

        List<WorkPackageEntity> result = bowStatusSearchRepository.getWorkPackages(paramMap, searchCriteria.getUserRole());
        assertThat(result).isNotNull();
        assertEquals(1, result.size());
        assertEquals("FINALIZED", result.get(0).getWorkPkgStatusCd());
    }

    /**
     * Test case for getting work package of given search inputs for planner role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for planner role.
     */
    @Test
    public void testGetWorkPackageForPlanner() throws ParseException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();

        searchCriteria.setAircraftNumber("824");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("FINALIZED");
        searchCriteria.setUserRole("50");

        Map<String, Object> paramMap = searchCriteria.getSearchCriteriaAsMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // this format is important!
        Date fromDate = sdf.parse("2018-10-05");
        Date toDate = sdf.parse("2018-10-05");

        paramMap.put(PKG_SCHD_FROM, fromDate);
        paramMap.put(PKG_SCHD_TO, toDate);

        List<WorkPackageEntity> result = bowStatusSearchRepository.getWorkPackages(paramMap, searchCriteria
                .getUserRole());
        assertThat(result).isNotNull();
        assertEquals(1, result.size());
        assertEquals("FINALIZED", result.get(0).getWorkPkgStatusCd());
    }

    /**
     * Test case for getting work package of given search inputs for checker role.
     * Only the finalized work package should come. workPkgStatusCd will always be finalized for checker role.
     */
    @Test
    public void testGetWorkPackageForChecker() throws ParseException {
        StatusSearchFilterRequest searchCriteria = new StatusSearchFilterRequest();

        searchCriteria.setAircraftNumber("824");
        searchCriteria.setStations(new String[]{"DFW"});
        searchCriteria.setKeyword("TEST");
        searchCriteria.setStatus("FINALIZED");
        searchCriteria.setUserRole("59");

        Map<String, Object> paramMap = searchCriteria.getSearchCriteriaAsMap();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // this format is important!
        Date fromDate = sdf.parse("2018-10-05");
        Date toDate = sdf.parse("2018-10-05");

        paramMap.put(PKG_SCHD_FROM, fromDate);
        paramMap.put(PKG_SCHD_TO, toDate);

        List<WorkPackageEntity> result = bowStatusSearchRepository.getWorkPackages(paramMap, searchCriteria.getUserRole());
        assertThat(result).isNotNull();
        assertEquals(1, result.size());
        assertEquals("FINALIZED", result.get(0).getWorkPkgStatusCd());
    }

}
