package com.aa.amps.base.station;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;

/**
 * Test class for {@code StationService}.
 *
 * @author HCL(922166)
 * Created on 5/18/2018.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class StationServiceTest {

    @Autowired
    private StationService stationService;

    private List<StationEntity> stationEntities;

    @MockBean
    private StationRepository stationRepository;


    @Before
    public void setUp() {
        stationEntities = new ArrayList<>();
        StationEntity ob1 = new StationEntity();

        ob1.setMntncStnCd("JFK");
        ob1.setMntncStnTypCd("L");

        stationEntities.add(ob1);

        StationEntity ob2 = new StationEntity();

        ob2.setMntncStnCd("DWH");
        ob2.setMntncStnTypCd("H");

        stationEntities.add(ob2);
    }

    /**
     * Test case for getting all the active stations.
     */
    @Test
    public void getAllActiveStations() {
        given(this.stationRepository.getAllActiveStations()).willReturn(stationEntities);

        List<StationEntity> result = stationService.getAllActiveStations();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getMntncStnCd()).isEqualToIgnoringCase("JFK");
    }

    /**
     * Test case to get all the base stations.
     */
    @Test
    public void getActiveStationsForBase() {
        String stationType = "base";
        given(this.stationRepository.getAllActiveStations()).willReturn(stationEntities);
        List<StationEntity> result = stationService.getActiveStations(stationType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMntncStnCd()).isEqualToIgnoringCase("DWH");
    }

    /**
     * Test case to get all the line stations.
     */
    @Test
    public void getActiveStationsForLine() {
        String stationType = "line";
        given(this.stationRepository.getAllActiveStations()).willReturn(stationEntities);
        List<StationEntity> result = stationService.getActiveStations(stationType);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getMntncStnCd()).isEqualToIgnoringCase("JFK");
    }

    /**
     * Test case to get active stations for input null.
     */
    @Test
    public void getActiveStations_NullInput() {
        List<StationEntity> result = stationService.getActiveStations(null);
        assertThat(result).isNotNull().hasSize(0);
    }

    /**
     * Test case to get active stations for input empty.
     */
    @Test
    public void getActiveStations_EmptyInput() {
        String stationType = "";
        List<StationEntity> result = stationService.getActiveStations(stationType);
        assertThat(result).isNotNull().hasSize(0);
    }

    /**
     * Test case for getting all the active stations with Order Station Type.
     */
    @Test
    public void getAllActiveStations_OrderStnType() {
        given(this.stationRepository.getAllActiveStations()).willReturn(stationEntities);
        List<StationEntity> result = stationService.getAllStnOrderStnType();
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getMntncStnCd()).isEqualToIgnoringCase("DWH");
        assertThat(result.get(1).getMntncStnCd()).isEqualToIgnoringCase("JFK");
    }
}
