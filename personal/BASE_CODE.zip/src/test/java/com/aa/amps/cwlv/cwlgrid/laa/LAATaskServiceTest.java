package com.aa.amps.cwlv.cwlgrid.laa;

import com.aa.amps.cwlv.cwlgrid.CwlRestClientService;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.model.AircraftRoutingInfo;
import com.aa.amps.cwlv.model.Flight;
import com.aa.amps.cwlv.timetogo.TimeCycleDaysService;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.BDDMockito.given;

@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class LAATaskServiceTest {

    public static final String TC_106D = "-106 D";
    public static final String TC_361H = "-361.0 H";
    public static final String DT_21MAY2018 = "21May2018";
    public static final String SCHD_DT = "2018-05-21";
    public static final String DT_20180204 = "2018-02-04";

    List<CombinedTaskDetail> mockedRonCombinedTaskDetails = Collections.emptyList();
    List<CombinedTaskDetail> mockedRodCombinedTaskDetails = Collections.emptyList();
    List<CombinedTaskDetail> mockedRodNoMatchingLegs = Collections.emptyList();
    Map<String, AircraftRoutingInfo> mockedAircraftRoutingInfos = Collections.emptyMap();
    Map<String, AircraftRoutingInfo> mockedAircraftRoutingECORON = Collections.emptyMap();

    @MockBean
    private LAATaskRepository laaTaskRepository;
    @MockBean
    private CwlRestClientService restClientService;
    @Autowired
    private TimeCycleDaysService timeCycleDaysService;
    private LAATaskService laaTaskService;

    @Before
    public void setUp() throws Throwable {
        mockedRonCombinedTaskDetails = getMockRonCombinedTaskDetails();
        mockedRodCombinedTaskDetails = getMockRodCombinedTaskDetails();
        mockedAircraftRoutingInfos = getMockedAircraftRoutingInfos();
        mockedRodNoMatchingLegs = getMockRodNoMatchingLegs();
        mockedAircraftRoutingECORON = getRoutingforECORON();

        laaTaskService = new LAATaskService(laaTaskRepository, restClientService, timeCycleDaysService);
    }

    @Test
    public void getCombinedTasksDetailsRonWithNoFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRonCombinedTaskDetails);
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn
                (mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(2);
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase("-373.0 H");

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("DFW");

    }

    @Test
    public void getCombinedTasksDetailsRonWithFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRonCombinedTaskDetails);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(true));
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(2);
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("DFW");

    }

    @Test
    public void getCombinedTasksDetailsRonWithMultipleMatchingFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRonCombinedTaskDetails);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(true));
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(true));

        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(3);
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(1).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(2).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(2).getStnCd()).isEqualToIgnoringCase("DFW");
        assertThat(responseLAA.get(2).getTimeCycle()).isEqualToIgnoringCase(TC_106D);
    }

    @Test
    public void getCombinedTasksDetailsRodWithNoFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRodCombinedTaskDetails);
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(1);
/*
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).isInvalidRecord());

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("DFW");
*/

    }

    @Test
    public void getCombinedTasksDetailsRodWithFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRodCombinedTaskDetails);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(false));
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(2);
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("DFW");
        assertThat(responseLAA.get(1).getTimeCycle()).isEqualToIgnoringCase(TC_106D);
    }

    @Test
    public void getCombinedTasksDetailsRodWithMultipleMatchingFlightLeg() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRodCombinedTaskDetails);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(false));
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(false));

        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(3);
        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(1).getAircftNbr()).isEqualToIgnoringCase("425");
        assertThat(responseLAA.get(1).getStnCd()).isEqualToIgnoringCase("CVG");
        assertThat(responseLAA.get(1).getTimeCycle()).isEqualToIgnoringCase(TC_361H);

        assertThat(responseLAA.get(2).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(2).getStnCd()).isEqualToIgnoringCase("DFW");
        assertThat(responseLAA.get(2).getTimeCycle()).isEqualToIgnoringCase(TC_106D);
    }

    @Test
    public void testRemoveThroughFlightsWithGroundTimeLessThan6Hours() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRodCombinedTaskDetails);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedThroughFlights(false));
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(1);

        assertThat(responseLAA.get(0).getAircftNbr()).isEqualToIgnoringCase("4XB");
        assertThat(responseLAA.get(0).getStnCd()).isEqualToIgnoringCase("DFW");
        assertThat(responseLAA.get(0).getTimeCycle()).isEqualToIgnoringCase(TC_106D);
    }

    @Test
    public void testRODWithNoMatchingLegs() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(mockedRodNoMatchingLegs);
        mockedAircraftRoutingInfos.get("425").getFlights().addAll(getMockedFlights(false));
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingInfos);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

        assertThat(responseLAA).isNotNull();
        assertThat(responseLAA.size()).isEqualTo(0);

    }


    @Test
    public void testECORONIncorrectYellowHighlighted() {

        given(laaTaskRepository.getCombinedTasksDetails(Mockito.anyMap())).willReturn(getECORONRecord());
        mockedAircraftRoutingECORON.get("3NF").getFlights().addAll(getTestFlight(true));
        given(restClientService.getRoutingsFromAmps(Mockito.anyList(), Mockito.anyMap())).willReturn(mockedAircraftRoutingECORON);

        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(new HashMap<>());

    }

    // Below code is for test Data preparation

    private List<Flight> getTestFlight(boolean isTerminator) {
        Flight flight = new Flight();
        flight.setArrivalCity("DFW");
        flight.setArrivalDate("29Jun2018");
        flight.setArrivalTime("1859");
        flight.setTerminator(isTerminator);
        flight.setFlightNumber("0355");
        flight.setTotalShipCycles((long) 48196);
        flight.setTotalShipTime((long) 5345970);
        flight.setDepartureDate("29Jun2018");
        flight.setJmocaGroundTime((long) 741);

        return Arrays.asList(flight);
    }

    private List<Flight> getMockedFlights(boolean isTerminator) {
        Flight flight = new Flight();
        flight.setArrivalCity("CVG");
        flight.setArrivalDate(DT_21MAY2018);
        flight.setArrivalTime("1803");
        flight.setTerminator(isTerminator);
        flight.setFlightNumber("1174");
        flight.setTotalShipCycles((long) 48196);
        flight.setTotalShipTime((long) 5345970);
        flight.setDepartureDate(DT_21MAY2018);
        flight.setArrivalDate(DT_21MAY2018);
        flight.setJmocaGroundTime((long) 579);

        return Arrays.asList(flight);
    }

    private List<Flight> getMockedThroughFlights(boolean isTerminator) {
        Flight flight = new Flight();
        flight.setArrivalCity("CVG");
        flight.setArrivalDate(DT_21MAY2018);
        flight.setArrivalTime("1803");
        flight.setTerminator(isTerminator);
        flight.setFlightNumber("1174");
        flight.setTotalShipCycles((long) 48196);
        flight.setTotalShipTime((long) 5345970);
        flight.setDepartureDate(DT_21MAY2018);
        flight.setArrivalDate(DT_21MAY2018);
        flight.setJmocaGroundTime((long) 123); // if groundTime < 6 hours, then its consider as throughFligh

        return Arrays.asList(flight);
    }

    private Map<String, AircraftRoutingInfo> getMockedAircraftRoutingInfos() {

        Map<String, AircraftRoutingInfo> aircraftRoutingInfos = new HashMap<>();
        AircraftRoutingInfo aircraftRoutingInfo1 = new AircraftRoutingInfo();
        aircraftRoutingInfo1.setNoseId("425");

        AircraftRoutingInfo aircraftRoutingInfo2 = new AircraftRoutingInfo();
        aircraftRoutingInfo2.setNoseId("4XB");

        aircraftRoutingInfos.put("425", aircraftRoutingInfo1);
        aircraftRoutingInfos.put("4XB", aircraftRoutingInfo2);

        return aircraftRoutingInfos;
    }

    private Map<String, AircraftRoutingInfo> getRoutingforECORON() {

        Map<String, AircraftRoutingInfo> aircraftRoutingInfos = new HashMap<>();
        AircraftRoutingInfo aircraftRoutingInfo1 = new AircraftRoutingInfo();
        aircraftRoutingInfo1.setNoseId("3NF");

        aircraftRoutingInfos.put("3NF", aircraftRoutingInfo1);

        return aircraftRoutingInfos;
    }

    private List<CombinedTaskDetail> getECORONRecord() {
        List<CombinedTaskDetail> cmTaskList = new ArrayList<>();

        CombinedTaskDetail combinedTaskDetail1 = new CombinedTaskDetail();
        combinedTaskDetail1.setAircftNbr("3NF");
        combinedTaskDetail1.setLogo("DECS");
        combinedTaskDetail1.setFleetCd("737");
        combinedTaskDetail1.setStnCd("DFW");
        combinedTaskDetail1.setTaskId("J2178AB");
        combinedTaskDetail1.setTaskDesc("E/F - INSTALLATION OF AVSAX FI");
        combinedTaskDetail1.setSchdDt("2018-06-29");
        combinedTaskDetail1.setForecastDt(null);
        combinedTaskDetail1.setTaskTypeCd("ECO");
        combinedTaskDetail1.setRodRon("RON");
        combinedTaskDetail1.setMechHour("1");
        combinedTaskDetail1.setAircftMntncCycle(null);
        combinedTaskDetail1.setAircftMntncHours(null);
        combinedTaskDetail1.setAircftMntncDays(null);
        combinedTaskDetail1.setAircftShipCycles("48199");
        combinedTaskDetail1.setAircftShipTime("89111.28");
        combinedTaskDetail1.setAvgCyclesPerDay("4.7");
        combinedTaskDetail1.setAvgHoursPerDay("10");
        combinedTaskDetail1.setPriority("3");

        cmTaskList.add(combinedTaskDetail1);

        return cmTaskList;
    }

    private List<CombinedTaskDetail> getMockRonCombinedTaskDetails() {

        List<CombinedTaskDetail> cmTaskList = new ArrayList<>();

        CombinedTaskDetail combinedTaskDetail1 = new CombinedTaskDetail();
        combinedTaskDetail1.setAircftNbr("425");
        combinedTaskDetail1.setLogo("DECS");
        combinedTaskDetail1.setFleetCd("S80");
        combinedTaskDetail1.setStnCd("CVG");
        combinedTaskDetail1.setTaskId("7924");
        combinedTaskDetail1.setTaskDesc("ENGINE 4TH STAGE TURBINE BLADES-ISOTOPE");
        combinedTaskDetail1.setSchdDt(SCHD_DT);
        combinedTaskDetail1.setForecastDt("2018-04-15");
        combinedTaskDetail1.setTaskTypeCd("SIC");
        combinedTaskDetail1.setRodRon("RON");
        combinedTaskDetail1.setMechHour("13");
        combinedTaskDetail1.setAircftMntncCycle(null);
        combinedTaskDetail1.setAircftMntncHours("88738.92");
        combinedTaskDetail1.setAircftMntncDays(null);
        combinedTaskDetail1.setAircftShipCycles("48199");
        combinedTaskDetail1.setAircftShipTime("89111.28");
        combinedTaskDetail1.setAvgCyclesPerDay("4.7");
        combinedTaskDetail1.setAvgHoursPerDay("10");
        combinedTaskDetail1.setPriority("3");

        CombinedTaskDetail combinedTaskDetail2 = new CombinedTaskDetail();
        combinedTaskDetail2.setAircftNbr("4XB");
        combinedTaskDetail2.setLogo("DECS");
        combinedTaskDetail2.setFleetCd("S80");
        combinedTaskDetail2.setStnCd("DFW");
        combinedTaskDetail2.setTaskId("5916");
        combinedTaskDetail2.setTaskDesc("DFGS RETURN-TO-SERVICE (RTS) TEST");
        combinedTaskDetail2.setSchdDt(SCHD_DT);
        combinedTaskDetail2.setForecastDt(DT_20180204);
        combinedTaskDetail2.setTaskTypeCd("SIC");
        combinedTaskDetail2.setRodRon("RON");
        combinedTaskDetail2.setMechHour("1");
        combinedTaskDetail2.setAircftMntncCycle(null);
        combinedTaskDetail2.setAircftMntncHours(null);
        combinedTaskDetail2.setAircftMntncDays(DT_20180204);
        combinedTaskDetail2.setAircftShipCycles("28630");
        combinedTaskDetail2.setAircftShipTime("57883.52");
        combinedTaskDetail2.setAvgCyclesPerDay("4.7");
        combinedTaskDetail2.setAvgHoursPerDay("9.8");
        combinedTaskDetail2.setPriority("1");

        cmTaskList.add(combinedTaskDetail1);
        cmTaskList.add(combinedTaskDetail2);

        return cmTaskList;
    }

    private List<CombinedTaskDetail> getMockRodCombinedTaskDetails() {

        List<CombinedTaskDetail> cmTaskList = new ArrayList<>();

        CombinedTaskDetail combinedTaskDetail1 = new CombinedTaskDetail();
        combinedTaskDetail1.setAircftNbr("425");
        combinedTaskDetail1.setLogo("DECS");
        combinedTaskDetail1.setFleetCd("S80");
        combinedTaskDetail1.setStnCd("CVG");
        combinedTaskDetail1.setTaskId("7924");
        combinedTaskDetail1.setTaskDesc("ENGINE 4TH STAGE TURBINE BLADES-ISOTOPE");
        combinedTaskDetail1.setSchdDt(SCHD_DT);
        combinedTaskDetail1.setForecastDt("2018-04-15");
        combinedTaskDetail1.setTaskTypeCd("SIC");
        combinedTaskDetail1.setRodRon("ROD");
        combinedTaskDetail1.setMechHour("13");
        combinedTaskDetail1.setFlightNbr("1174");
        combinedTaskDetail1.setAircftMntncCycle(null);
        combinedTaskDetail1.setAircftMntncHours("88738.92");
        combinedTaskDetail1.setAircftMntncDays(null);
        combinedTaskDetail1.setAircftShipCycles("48199");
        combinedTaskDetail1.setAircftShipTime("89111.28");
        combinedTaskDetail1.setAvgCyclesPerDay("4.7");
        combinedTaskDetail1.setAvgHoursPerDay("10");
        combinedTaskDetail1.setPriority("3");

        CombinedTaskDetail combinedTaskDetail2 = new CombinedTaskDetail();
        combinedTaskDetail2.setAircftNbr("4XB");
        combinedTaskDetail2.setLogo("DECS");
        combinedTaskDetail2.setFleetCd("S80");
        combinedTaskDetail2.setStnCd("DFW");
        combinedTaskDetail2.setTaskId("5916");
        combinedTaskDetail2.setTaskDesc("DFGS RETURN-TO-SERVICE (RTS) TEST");
        combinedTaskDetail2.setSchdDt(SCHD_DT);
        combinedTaskDetail2.setForecastDt(DT_20180204);
        combinedTaskDetail2.setTaskTypeCd("SIC");
        combinedTaskDetail2.setRodRon("RON");
        combinedTaskDetail2.setMechHour("1");
        combinedTaskDetail2.setAircftMntncCycle(null);
        combinedTaskDetail2.setAircftMntncHours(null);
        combinedTaskDetail2.setAircftMntncDays(DT_20180204);
        combinedTaskDetail2.setAircftShipCycles("28630");
        combinedTaskDetail2.setAircftShipTime("57883.52");
        combinedTaskDetail2.setAvgCyclesPerDay("4.7");
        combinedTaskDetail2.setAvgHoursPerDay("9.8");
        combinedTaskDetail2.setPriority("1");

        cmTaskList.add(combinedTaskDetail1);
        cmTaskList.add(combinedTaskDetail2);

        return cmTaskList;
    }

    private List<CombinedTaskDetail> getMockRodNoMatchingLegs() {

        List<CombinedTaskDetail> cmTaskList = new ArrayList<>();

        CombinedTaskDetail combinedTaskDetail1 = new CombinedTaskDetail();
        combinedTaskDetail1.setAircftNbr("425");
        combinedTaskDetail1.setLogo("DECS");
        combinedTaskDetail1.setFleetCd("S80");
        combinedTaskDetail1.setStnCd("CVG");
        combinedTaskDetail1.setTaskId("7924");
        combinedTaskDetail1.setTaskDesc("ENGINE 4TH STAGE TURBINE BLADES-ISOTOPE");
        combinedTaskDetail1.setSchdDt("2018-06-13");
        combinedTaskDetail1.setForecastDt("2018-06-13");
        combinedTaskDetail1.setTaskTypeCd("SIC");
        combinedTaskDetail1.setRodRon("ROD");
        combinedTaskDetail1.setMechHour("13");
        combinedTaskDetail1.setFlightNbr("1174");
        combinedTaskDetail1.setAircftMntncCycle(null);
        combinedTaskDetail1.setAircftMntncHours("88738.92");
        combinedTaskDetail1.setAircftMntncDays(null);
        combinedTaskDetail1.setAircftShipCycles("48199");
        combinedTaskDetail1.setAircftShipTime("89111.28");
        combinedTaskDetail1.setAvgCyclesPerDay("4.7");
        combinedTaskDetail1.setAvgHoursPerDay("10");
        combinedTaskDetail1.setPriority("3");

        CombinedTaskDetail combinedTaskDetail2 = new CombinedTaskDetail();
        combinedTaskDetail2.setAircftNbr("425");
        combinedTaskDetail2.setLogo("DECS");
        combinedTaskDetail2.setFleetCd("S80");
        combinedTaskDetail2.setStnCd("JFK");
        combinedTaskDetail2.setTaskId("5916");
        combinedTaskDetail2.setTaskDesc("DFGS RETURN-TO-SERVICE (RTS) TEST");
        combinedTaskDetail2.setSchdDt(SCHD_DT);
        combinedTaskDetail2.setForecastDt(DT_20180204);
        combinedTaskDetail2.setTaskTypeCd("SIC");
        combinedTaskDetail2.setRodRon("ROD");
        combinedTaskDetail2.setMechHour("1");
        combinedTaskDetail2.setAircftMntncCycle(null);
        combinedTaskDetail2.setAircftMntncHours(null);
        combinedTaskDetail2.setAircftMntncDays(DT_20180204);
        combinedTaskDetail2.setAircftShipCycles("28630");
        combinedTaskDetail2.setAircftShipTime("57883.52");
        combinedTaskDetail2.setAvgCyclesPerDay("4.7");
        combinedTaskDetail2.setAvgHoursPerDay("9.8");
        combinedTaskDetail2.setPriority("1");

        cmTaskList.add(combinedTaskDetail1);
        cmTaskList.add(combinedTaskDetail2);

        return cmTaskList;
    }
}