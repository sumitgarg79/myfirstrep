package com.aa.amps.cwlv.web.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test class for {@link LogoutController}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/14/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class LogoutControllerTest {

    @Autowired
    LogoutController logoutController;

    @Test
    public void getLogoutUrl() {
        Map<String, String> response = logoutController.getLogoutUrl();

        assertThat(response).isNotNull().isNotEmpty();
        assertThat(response.get(LogoutController.LOGOUTURL_KEY)).isNotBlank();
    }
}
