package com.aa.amps.base.util;

import com.aa.amps.base.task.TaskConstants;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Paul Verner(650196) on 10/31/2018.
 */
public class TaskUtilTest {

    @Test
    public void determineForecastDaysToGoCategory_LessThanZero() {
        String categoryOverTime = TaskUtil.determineForecastDaysToGoCategory("01/01/2000");
        assertThat(categoryOverTime).isEqualTo(TaskConstants.OVER_TIME);
    }

    @Test
    public void determineForecastDaysToGoCategory_LessThanFour() {
        String categoryHighTime = TaskUtil.determineForecastDaysToGoCategory(DateUtil.getCurrentDateAsString());
        assertThat(categoryHighTime).isEqualTo(TaskConstants.HIGH_TIME);
    }

    @Test
    public void determineForecastDaysToGoCategory_FourOrGreater() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 4);
        String datePlusFour = new SimpleDateFormat(DateUtil.DATE_FORMAT_MMDDYYYY).format(cal.getTime());
        String categoryHighTime = TaskUtil.determineForecastDaysToGoCategory(datePlusFour);
        assertThat(categoryHighTime).isEqualTo("");
    }

    @Test
    public void determineBowType() {
        String bowTypeLine = TaskUtil.determineBowType("01");
        assertThat(bowTypeLine).isEqualTo(TaskConstants.BOW_TYPE_LINE);
        String bowTypeBase = TaskUtil.determineBowType("03");
        assertThat(bowTypeBase).isEqualTo(TaskConstants.BOW_TYPE_BASE);
    }

    /**
     *  Test case to verify that ME8 task with description starting with REP becomes taskType: ME8-TC
     */
    @Test
    public void determineTaskType_TC() {
        String taskType = TaskUtil.determineTaskType("ME8", "REP, 19L21034003, 757, NDB UPLOAD 28NOV-05DEC");
        assertThat(taskType).isEqualTo(TaskConstants.ME8_TC);
    }

    /**
     *  Test case to verify that ME8 task with description starting with MON becomes taskType: ME8-MON
     */
    @Test
    public void determineTaskType_MON() {
        String taskType = TaskUtil.determineTaskType("ME8", "MON, 0277, 6834544, REP 3000 FC/18 MONTHS");
        assertThat(taskType).isEqualTo(TaskConstants.ME8_MON);
    }

    /**
     *  Test case to verify that ME8 task with description starting with INS becomes taskType: ME8-EO
     */
    @Test
    public void determineTaskType_EO() {
        String taskType = TaskUtil.determineTaskType("ME8", "INS, AD, 5215U163-003, INSP FWD CARGO DOOR");
        assertThat(taskType).isEqualTo(TaskConstants.ME8_EO);
    }

    /**
     *  Test case to verify that ME8 task with description starting with CKC becomes taskType: ME8-CKC
     */
    @Test
    public void determineTaskType_CKC() {
        String taskType = TaskUtil.determineTaskType("ME8", "CKC, A01, A330, A-CHECK 1        ");
        assertThat(taskType).isEqualTo(TaskConstants.ME8_CKC);
    }

    /**
     *  Test case to verify that ME8 task with description starting with DNS becomes taskType: ME8-DNS
     */
    @Test
    public void determineTaskType_DNS() {
        String taskType = TaskUtil.determineTaskType("ME8", "DNS,");
        assertThat(taskType).isEqualTo(TaskConstants.ME8_DNS);
    }
}
