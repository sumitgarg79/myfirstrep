package com.aa.amps.cwlv.manHours;

import com.aa.amps.cwlv.crossutil.CrossUtilController;
import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import com.aa.amps.cwlv.crossutil.CrossUtilService;
import com.aa.amps.cwlv.manHours.LaaRodManHrs.LaaRodManHrsService;
import com.aa.amps.cwlv.util.Constants;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.BDDMockito.given;

/**
 * This the test class for {@code {@link RodAndRonManHrsController}}.
 *
 * @author Ramesh Rudra(842020)
 * create on 4/23/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class RodAndRonManHrsControllerTest {

    @Autowired
    private RodAndRonManHrsController rodAndRonManHrsController;

    private List<RodAndRonManHours> rodAndRonManHours;

    private List<RodAndRonManHrsEntity> rodAndRonManHrsEntities;

    @MockBean
    private RodAndRonManHrsService rodAndRonManHrsService;


    @MockBean
    private LaaRodManHrsService laaRodManHrsService;

    @Before
    public void setUp() throws Exception {
        rodAndRonManHours = new ArrayList<>();

        RodAndRonManHours ob1 = new RodAndRonManHours();
        RodAndRonManHours ob2 = new RodAndRonManHours();

        ob1.setStation("DFW");
        ob1.setRodPriority1And2(5F);
        ob1.setRonTotalManHours(100F);
        ob2.setStation("CLT");
        ob2.setRodPriority1And2(4F);
        ob2.setRonTotalManHours(300F);

        rodAndRonManHours.add(ob1);
        rodAndRonManHours.add(ob2);

        rodAndRonManHrsEntities = new ArrayList<>();

        RodAndRonManHrsEntity o1 = new RodAndRonManHrsEntity();
        RodAndRonManHrsEntity o2 = new RodAndRonManHrsEntity();

        o1.setStation("DFW");
        o1.setIsRon(false);
        o1.setPriorityCode(2L);
        o1.setTotalManHrsOfpriorityCode(100F);

        o2.setStation("CLT");
        o2.setIsRon(Boolean.TRUE);
        o2.setPriorityCode(3L);
        o2.setTotalManHrsOfpriorityCode(200F);

        rodAndRonManHrsEntities.add(o1);
        rodAndRonManHrsEntities.add(o2);
    }
    /**
     * Test case for getTotalManhrs. Happy Path scenario.
     */
    @Test
    public void getRodAndRonManHrsTest() {
        String date=null;
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

        given(this.rodAndRonManHrsService.getTotalManHrs(Mockito.anyMap())).willReturn(rodAndRonManHours);

        ManHrsFilterRequest manHrsFilterRequest = new ManHrsFilterRequest();
        manHrsFilterRequest.setDate(date);

        List<RodAndRonManHours> result = rodAndRonManHrsController.getRodAndRonManHrs(manHrsFilterRequest);
        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
    }

    @Test
    public void getRodAndRonManHrs() {

        String date=null;
        Map<String, Object> searchCriteria = new HashMap<>();
        searchCriteria.put(Constants.PLANNED_DATE_FROM, date);

        given(this.laaRodManHrsService.getLaaRodManHrs(Mockito.anyMap())).willReturn(rodAndRonManHrsEntities);

        ManHrsFilterRequest manHrsFilterRequest = new ManHrsFilterRequest();
        manHrsFilterRequest.setDate(date);
        List<RodAndRonManHrsEntity> result = rodAndRonManHrsController.getRodManHrs(manHrsFilterRequest);

        assertThat(result).isNotNull();
        assertThat(result).hasSize(2);
        assertThat(result.get(0).getStation()).isEqualToIgnoringCase("DFW");
    }


}