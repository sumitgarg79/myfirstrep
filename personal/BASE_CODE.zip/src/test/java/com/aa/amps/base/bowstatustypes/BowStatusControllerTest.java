package com.aa.amps.base.bowstatustypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This the test class for {@code BowStatusController}.
 *
 * @author Paul Verner
 * @since 5/31/2018.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class BowStatusControllerTest {
    @Autowired
    private BowStatusController bowStatusController;

    @Before
    public void setUp() {
    }

    /**
     * Test case for getBowStatusList()
     */
    @Test
    public void getBowStatusListTest() {
        List<String> bowStatusTypes = bowStatusController.getBowStatusList();
        assertThat(bowStatusTypes).isNotNull();
        assertThat(bowStatusTypes).hasSize(2);
    }
}
