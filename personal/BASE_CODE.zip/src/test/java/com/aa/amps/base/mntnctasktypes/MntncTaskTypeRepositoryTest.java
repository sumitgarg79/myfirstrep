package com.aa.amps.base.mntnctasktypes;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * This is test class for {{@link MntncTaskTypeRepository}}
 *
 * @author Sudeep(842019)
 * @since 5/22/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class MntncTaskTypeRepositoryTest {

    @Autowired
    MntncTaskTypeRepository mntncTaskTypeRepository;

    @Before
    public void setUp() {

    }

    @Test
    public void getAllMntncTaskTypes() {
        String appType = "";
        List<MntncTaskTypeEntity> mntncTaskTypeEntityList = mntncTaskTypeRepository.getAllMntncTaskTypes(appType);
        assertThat(mntncTaskTypeEntityList).isNotNull();
        assertThat(mntncTaskTypeEntityList.get(0).getAcftMntncTaskType().equals("CDL")).isTrue();
    }

    @Test
    public void getBaseMntncTaskTypes() {
        String appType = "B";
        List<MntncTaskTypeEntity> mntncTaskTypeEntityList = mntncTaskTypeRepository.getAllMntncTaskTypes(appType);
        assertThat(mntncTaskTypeEntityList).isNotNull();
        assertThat(mntncTaskTypeEntityList.get(0).getAcftMntncTaskType().equals("CDL")).isTrue();
    }

    @Test
    public void getLineBaseMntncTaskTypes() {
        String appType = "L";
        List<MntncTaskTypeEntity> mntncTaskTypeEntityList = mntncTaskTypeRepository.getAllMntncTaskTypes(appType);
        assertThat(mntncTaskTypeEntityList).isNotNull();
        assertThat(mntncTaskTypeEntityList.get(0).getAcftMntncTaskType().equals("CDL")).isTrue();
    }
}