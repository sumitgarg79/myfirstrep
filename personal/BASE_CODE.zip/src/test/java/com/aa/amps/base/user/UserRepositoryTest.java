package com.aa.amps.base.user;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

/**
 * Test class for {@code UserRepository}.
 *
 * @author Paul Verner (650196)
 * @since 9/13/2018
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ActiveProfiles("test")
public class UserRepositoryTest {
    @Autowired
    private UserRepository userRepository;

    private UserRequest userRequest;

    @Before
    public void setUp() {

    }

    /**
     * Test Case for userIdExistsInAmpsUser() - check to see if userId exists in AMPS_USER table
     *
     * @throws Exception
     */
    @Test
    public void userExistsTest() throws Exception {
        boolean exists = userRepository.userIdExistsInAmpsUser("998877");
        assertFalse(exists);
    }

    /**
     * Test Case for userIdExistsInAmpsUserLogin() - check to see if userId exists in AMPS_USER_LOGIN table
     *
     * @throws Exception
     */
    @Test
    public void userLoginExistsInAmpsUserLoginTest() throws Exception {
        boolean exists = userRepository.userIdExistsInAmpsUserLogin("998877");
        assertFalse(exists);
    }

    /**
     * TestCase for insertAmpsUser() - insert row into AMPS_USER table
     *
     * @throws Exception
     */
    @Test
    public void insertUserTest() throws Exception {
        UserRequest user = new UserRequest();
        user.setUserId("00999988");
        user.setFirstName("NINETY");
        user.setLastName("EIGHT");
        userRepository.insertAmpsUser(user);
        // check to see if record has been inserted successfully
        boolean exists = userRepository.userIdExistsInAmpsUser(user.getUserId());
        assertTrue(exists);
    }

    /**
     * TestCase for updateAmpsUser() - update row in AMPS_USER table
     *
     * @throws Exception
     */
    @Test
    public void updateAmpsUserTest() throws Exception {
        UserRequest user = new UserRequest();
        user.setUserId("00999933");
        user.setFirstName("FIRST");
        user.setLastName("LAST");
        userRepository.insertAmpsUser(user);
        int count = userRepository.updateAmpsUser(user);
        assertEquals(1, count);
    }

    /**
     * Test Case for insertAmpsUserLogin() - insert row into AMPS_USER_LOGIN
     *
     * @throws Exception
     */
    @Test
    public void insertUserLoginTest() throws Exception {
        userRequest = new UserRequest();
        userRequest.setUserId("00999955");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");
        userRepository.insertAmpsUser(userRequest);

        // set up complete, proceed with test
        int insertLoginCount = userRepository.insertAmpsUserLogin(userRequest.getUserId());
        assertEquals(1, insertLoginCount);
        boolean exists = userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId());
        assertTrue(exists);
    }

    @Test
    public void updateUserLoginTest() throws Exception {

        userRequest = new UserRequest();
        userRequest.setUserId("00999944");
        userRequest.setFirstName("FIRST");
        userRequest.setLastName("LAST");
        userRepository.insertAmpsUser(userRequest);
        userRepository.insertAmpsUserLogin(userRequest.getUserId());
        // set up complete, proceed with test
        int updateCount = userRepository.updateUserLogin(userRequest.getUserId());
        assertEquals(1, updateCount);
    }

}
