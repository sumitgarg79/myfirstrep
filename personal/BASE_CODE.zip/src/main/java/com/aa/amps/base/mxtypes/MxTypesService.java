package com.aa.amps.base.mxtypes;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * All the Business Logic associated with Mx(maintenance)Types need to be defined here.
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since 06/01/2018.
 */

@Service
@Transactional
public class MxTypesService {

    private MxTypesRepository mxTypesRepository;

    public MxTypesService(MxTypesRepository mxTypesRepository) {
        this.mxTypesRepository = mxTypesRepository;
    }

    /**
     * Fetches the mx(maintenance) types
     *
     * @return {@code List} of mx(maintenance) types
     */
    @Transactional(readOnly = true)
    public List<String> getMxTypes() {
        return mxTypesRepository.getAllMxTypes();
    }
}
