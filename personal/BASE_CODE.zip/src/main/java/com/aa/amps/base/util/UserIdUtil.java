package com.aa.amps.base.util;

import org.apache.commons.lang.StringUtils;

/**
 * Util Class for UserId.
 *
 * @author Paul Verner
 * @since 09/19/2018
 */
public class UserIdUtil {

    private UserIdUtil() {
        throw new IllegalStateException("Utility class");
    }

    /**
     *   Remove first 2 characters of 8 character userId.  Example: 00123456 --> 123456
     * @param userId
     * @return - 6 character userId (first 2 characters removed).
     */
    public static String shortenUserIdTo6Characters(String userId) {
        return StringUtils.right(userId, 6);
    }
}
