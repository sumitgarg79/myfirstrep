package com.aa.amps.cwlv.manHours;

import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * RonAndRodManHours bean class represents data for ManHrs Screen
 *
 * @author Ramesh Rudra(842020)
 * @since 4/17/2018.
 */
@Repository
@Data
public class RodAndRonManHours {

    private String station;

    private Float ronPriority0;

    private Float ronPriority1And2;

    private Float ronPriority3;

    private Float ronTotalManHours;

    private Float rodPriority0;

    private Float rodPriority1And2;

    private Float rodPriority3;

    private Float rodTotalManHours;

}
