package com.aa.amps.cwlv.timetogo;

import com.aa.amps.cwlv.util.DateTimeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * This is a Business class to calculate TWD for LAA.
 *
 * @author Naseer Mohammed (842018)
 * @since 05/10/2018
 */

@Service
public class TimeCycleDaysService {

    private static final Logger logger = LoggerFactory.getLogger(TimeCycleDaysService.class);

    /**
     * This public method exposed to calculate TWD for the given {@code TtgCriteria}.
     *
     * @param criteria object holds all the input parameters calculateTWD.
     * @return minimum TTG value e.g -12C or -230H or -9D
     */
    public String calculateTWD(TtgCriteria criteria) {
        String timeCycle = "";

        try {
            TimeToGo timeToGo = new TimeToGo();

            // Calculate ToGo values from TWD and aircraft ship time
            if (null != criteria.getDueDate()) {
                Timestamp a = new Timestamp(criteria.getDueDate().getTime());
                Timestamp b = new Timestamp(DateTimeUtil.getCurrentDay().getTime());
                if (criteria.getSchdDate() != null) {
                    b = new Timestamp(criteria.getSchdDate().getTime());
                }
                Long diffInDays = DateTimeUtil.getDifferenceInDays(a, b);
                timeToGo.setDaysToGo(diffInDays.intValue());
            }

            if (null != criteria.getDueTime() && criteria.getDueTime().longValue() > 0 && null != criteria
                    .getShipTime()) {
                timeToGo.setHoursToGo((criteria.getDueTime() - criteria.getShipTime()) / 1D);
            }

            if (null != criteria.getDueCycles() && criteria.getDueCycles().intValue() > 0 && null != criteria
                    .getShipCycles()) {
                timeToGo.setCyclesToGo(criteria.getDueCycles().intValue() - criteria.getShipCycles().intValue());
            }

            //Average utilization obtained from sub-fleet table.
            timeToGo.setAvgHourPerDay(criteria.getAvgHoursPerDay() == null ? null : criteria.getAvgHoursPerDay());
            timeToGo.setAvgCyclePerDay(criteria.getAvgCyclesPerDay() == null ? null : criteria.getAvgCyclesPerDay());

            timeCycle = setMinTTG(timeToGo);
        } catch (Exception e) {
            logger.error("Exception while calculating TWD ", e);
        }

        return timeCycle;
    }

    /**
     * This helper method will calculate the minimum TTG and set it to the minTTG.
     *
     * @param timeToGo - Holds all the input to calculate Minimum TTG value.
     * @return - Minimum TTG value.
     */
    private String setMinTTG(TimeToGo timeToGo) {
        Double hoursInDaysToGo = Double.MAX_VALUE;
        Double cyclesInDaysToGo = Double.MAX_VALUE;

        final SortedMap<Double, String> map = new TreeMap<>();

        final java.sql.Date currentDate = java.sql.Date.valueOf(DateTimeUtil.getCurrentDay().toString());

        if (timeToGo.getDaysToGo() != null) {
            Double dtg = Double.valueOf(timeToGo.getDaysToGo());
            map.put(dtg, TtgConstants.DAYS);
        }

        if ((timeToGo.getHoursToGo() != null) && (timeToGo.getAvgHourPerDay() != null)) {
            // convert hours to days to go
            hoursInDaysToGo = timeToGo.getHoursToGo() / timeToGo.getAvgHourPerDay();
            map.put(hoursInDaysToGo, TtgConstants.HOURS);
        }
        if ((timeToGo.getCyclesToGo() != null) && (timeToGo.getAvgCyclePerDay() != null)) {
            // convert cycles to days to go
            cyclesInDaysToGo = timeToGo.getCyclesToGo() / timeToGo.getAvgCyclePerDay();
            map.put(cyclesInDaysToGo, TtgConstants.CYCLES);
        }

        final StringBuilder str = new StringBuilder();
        if (!map.isEmpty()) {
            timeToGo.setMinTTGinDays(map.firstKey());
            if (map.get(map.firstKey()).equals(TtgConstants.DAYS)) {
                str.append(timeToGo.getDaysToGo());
                str.append(TtgConstants.SPACE); //US723357
                str.append(TtgConstants.DAYS);

                timeToGo.setMinTTGValue(timeToGo.getDaysToGo().doubleValue());
                timeToGo.setMinTTGUnit(TtgConstants.DAYS);
                timeToGo.setHighTime(timeToGo.getDaysToGo() <= TtgConstants.DAY_TO_GO_LIMIT);
                timeToGo.setForeCastDate(DateTimeUtil.getRolledDate(currentDate, timeToGo.getDaysToGo()));

            } else if (map.get(map.firstKey()).equals(TtgConstants.HOURS)) {
                str.append((DateTimeUtil.toTwoDecimalPtFormat(timeToGo.getHoursToGo())).toString());
                str.append(TtgConstants.SPACE);
                str.append(TtgConstants.HOURS);
                timeToGo.setMinTTGValue(timeToGo.getHoursToGo());

                timeToGo.setMinTTGUnit(TtgConstants.HOURS);
                timeToGo.setHighTime(timeToGo.getHoursToGo() <= TtgConstants.HR_CYCLE_TO_GO_LIMIT);
                timeToGo.setForeCastDate(DateTimeUtil.getRolledDate(currentDate, hoursInDaysToGo.intValue()));
            } else if (map.get(map.firstKey()).equals(TtgConstants.CYCLES)) {
                str.append(timeToGo.getCyclesToGo());
                str.append(TtgConstants.SPACE); //US723357
                str.append(TtgConstants.CYCLES);
                timeToGo.setMinTTGValue(timeToGo.getCyclesToGo().doubleValue());
                timeToGo.setMinTTGUnit(TtgConstants.CYCLES);

                timeToGo.setHighTime(timeToGo.getCyclesToGo() <= TtgConstants.HR_CYCLE_TO_GO_LIMIT);

                timeToGo.setForeCastDate(DateTimeUtil.getRolledDate(currentDate, cyclesInDaysToGo.intValue()));
            }
        }

        return str.toString();
    }
}
