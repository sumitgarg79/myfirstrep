package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import com.aa.amps.cwlv.crossutil.CrossUtilService;
import com.aa.amps.cwlv.manHours.RodAndRonManHours;
import com.aa.amps.cwlv.manHours.RodAndRonManHrsService;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.FeatureSwitchUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Service class that exposes all the methods related to station capacity summary. This summary has details on the
 * scheduled Man-hours and man hours capacity for the cross utilized stations.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/16/2018.
 */
@Service
public class StationCapacitySummaryService {
    private static final String ZERO = "0";
    private RodAndRonManHrsService manHrsService;
    private CrossUtilService crossUtilService;
    private FeatureSwitchUtil featureSwitchUtil;


    /**
     * Parameterized constructor.
     *
     * @param manHrsService    man hours service
     * @param crossUtilService cross util service
     */
    public StationCapacitySummaryService(RodAndRonManHrsService manHrsService, CrossUtilService
            crossUtilService, FeatureSwitchUtil featureSwitchUtil) {
        this.manHrsService = manHrsService;
        this.crossUtilService = crossUtilService;
        this.featureSwitchUtil = featureSwitchUtil;
    }

    /**
     * The proxy method to {@link #getStationCapacitySumm(Map)} with Async operation.
     *
     * @param searchCriteria Map for stations list and date.
     * @return the {@code CompletableFuture} of the
     */
    @Async
    public CompletableFuture<List<StationCapacitySummary>> getStationCapacitySummAsync(Map<String, Object> searchCriteria) {
        return CompletableFuture.completedFuture(getStationCapacitySumm(searchCriteria));
    }

    /**
     * Method to fetch the station capacity summary for the provided list of stations and date. The capacity summary
     * includeds -
     * <ul>
     * <li>Scheduled total Rod/Ron man hours from Man Hours service</li>
     * <li>Rod/Rod hours capacity of the station from Cross Utilization service.</li>
     * </ul>
     *
     * @param searchCriteria as map.
     * @return the list of {@code StationCapacitySummary}
     */
    public List<StationCapacitySummary> getStationCapacitySumm(Map<String, Object> searchCriteria) {
        List<String> stations = (List<String>) searchCriteria.get(Constants.STATION_PLANNED);
        String fromDate = String.valueOf(searchCriteria.get(Constants.PLANNED_DATE_FROM));

        List<StationCapacitySummary> capSummary = null;

        if (!CollectionUtils.isEmpty(stations) && StringUtils.isNotEmpty(fromDate)) {
            //converting input stations to upper case
            stations = stations.stream()
                    .map(String::toUpperCase)
                    .collect(Collectors.toList());

            capSummary = initializeStnCapSumm(stations);

            Optional<List<RodAndRonManHours>> schdManHours = getSchdManHour(searchCriteria);
            Optional<List<CrossUtilEntity>> crossUtil = getCrossUtil(stations);

            setManHrsAndXutilInResult(schdManHours, crossUtil, capSummary);
        } else {
            capSummary = new ArrayList<>();
        }

        return capSummary;
    }

    /**
     * Method to set the scheduled ROD/RON man hour and capacity data into the provided {@code stationCapSumm}
     * parameter.
     *
     * @param schdManHours   scheduled man hours details for a list of stations
     * @param crossUtil      man hour capacity details for a list of stations
     * @param stationCapSumm list of {@code StationCapacitySummary} with empty scheduled man hours and rod/ron capacity
     */
    private void setManHrsAndXutilInResult(Optional<List<RodAndRonManHours>> schdManHours,
                                           Optional<List<CrossUtilEntity>> crossUtil, List<StationCapacitySummary> stationCapSumm) {
        List<RodAndRonManHours> schdManHoursList = schdManHours.orElse(new ArrayList<RodAndRonManHours>());

        List<CrossUtilEntity> crossUtilList = crossUtil.orElse(new ArrayList<CrossUtilEntity>());

        Map<String, StationCapacitySummary> resultMap = stationCapSumm.stream()
                .collect(Collectors.toMap(StationCapacitySummary::getStation, Function.identity()));

        schdManHoursList.forEach(m -> {
            StationCapacitySummary s = resultMap.get(m.getStation());
            s.setTotalSchdRON(Float.toString(m.getRonTotalManHours()));
            s.setTotalSchdROD(Float.toString(m.getRodTotalManHours()));
        });

        //Setting the value of the
        crossUtilList.forEach(c -> {
            StationCapacitySummary s = resultMap.get(c.getMntncStnCode());
            s.setRonCapacity(Long.toString(c.getRonCapacity()));
            s.setRodCapacity(Long.toString(c.getRodCapacity()));
        });
    }


    /**
     * Method to get scheduled man hour for the supplied list of stations and date.
     *
     * @param searchCriteria as a map.
     * @return man hours data for the passed stations
     */
    private Optional<List<RodAndRonManHours>> getSchdManHour(Map<String, Object> searchCriteria) {
        List<String> stations = (List<String>) searchCriteria.get(Constants.STATION_PLANNED);

        List<RodAndRonManHours> manHrsAllStn = manHrsService.getTotalManHrs(searchCriteria);

        List<RodAndRonManHours> schdManHrsSelectStn = null;

        //map function excluding priority3
        //conditional check to provide switchCase for Priority0
        if (featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N")) {
            schdManHrsSelectStn = manHrsAllStn
                    .stream()
                    .filter(t -> stations.contains(t.getStation()))
                    .map(temp -> {
                        RodAndRonManHours obj = new RodAndRonManHours();
                        obj.setStation(temp.getStation());
                        obj.setRonTotalManHours(temp.getRonPriority1And2());
                        obj.setRodTotalManHours(temp.getRodPriority1And2());
                        return obj;
                    })
                    .collect(Collectors.toList());
        } else {
            schdManHrsSelectStn = manHrsAllStn
                    .stream()
                    .filter(t -> stations.contains(t.getStation()))
                    .map(temp -> {
                        RodAndRonManHours obj = new RodAndRonManHours();
                        obj.setStation(temp.getStation());
                        obj.setRonTotalManHours(temp.getRonPriority0() + temp.getRonPriority1And2());
                        obj.setRodTotalManHours(temp.getRodPriority0() + temp.getRodPriority1And2());
                        return obj;
                    })
                    .collect(Collectors.toList());
        }
        return Optional.ofNullable(schdManHrsSelectStn);
    }

    /**
     * Method to get capacity(man hours) for the list of stations. Capacity is not date dependant.
     *
     * @param stations stations list
     * @return capacity data for requested stations
     */
    private Optional<List<CrossUtilEntity>> getCrossUtil(List<String> stations) {
        List<CrossUtilEntity> crosUtilAll = crossUtilService.getCrossUtililzionDetails();

        List<CrossUtilEntity> crossUtilSelectStn = crosUtilAll
                .stream()
                .filter(t -> stations.contains(t.getMntncStnCode()))
                .collect(Collectors.toList());

        return Optional.ofNullable(crossUtilSelectStn);
    }

    /**
     * Creates a new list of {@code StationCapacitySummary} and initializes it with provided stations.
     *
     * @param stations stations to initialize list with
     * @return initialized {@code List} of {@code StationCapacitySummary}
     */
    private List<StationCapacitySummary> initializeStnCapSumm(List<String> stations) {
        List<StationCapacitySummary> result = new ArrayList<>();

        if (!CollectionUtils.isEmpty(stations)) {
            stations.forEach(s -> {
                StationCapacitySummary scs = new StationCapacitySummary();

                scs.setStation(s.toUpperCase());
                scs.setRodCapacity(ZERO);
                scs.setRonCapacity(ZERO);
                scs.setTotalSchdROD(ZERO);
                scs.setTotalSchdRON(ZERO);

                result.add(scs);
            });
        }

        return result;
    }
}
