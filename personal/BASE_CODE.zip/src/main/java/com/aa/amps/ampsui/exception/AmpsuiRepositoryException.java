package com.aa.amps.ampsui.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * This Class is the base exception class which all other exception classes in base package extends.
 *
 * @author Neelabh Tripathi
 * @since 12/11/2018
 */
@Getter
@Setter
public class AmpsuiRepositoryException extends Exception {

    public static final String RECORD_ADD_FAILED = "Failed to Add Record. Please see logs for details";
    public static final String RECORD_UPDATE_FAILED = "Failed to Update Record. Please see logs for details";
    public static final String RECORD_DELETE_FAILED = "Failed to Delete Record. Please see logs for details";
    public static final String RECORD_EXIST = "Description you entered already exists please rename and try again.";
    public static final String RECORD_NOT_FOUND_DESC = "No matching record found.";

    private final String statusCode;

    public AmpsuiRepositoryException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
