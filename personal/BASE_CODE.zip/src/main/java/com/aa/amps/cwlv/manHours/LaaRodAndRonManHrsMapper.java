package com.aa.amps.cwlv.manHours;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link RodAndRonManHrsEntity} of LAA Records.
 *
 * @author Ramesh Rudra(842020)
 * @since 4/23/2018.
 */
public class LaaRodAndRonManHrsMapper implements org.springframework.jdbc.core.RowMapper {
    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        RodAndRonManHrsEntity rodAndRonManHrsEntity = new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setPriorityCode(rs.getLong("MNTNC_SCHD_IMPACT_CD"));
        rodAndRonManHrsEntity.setStation(rs.getString("STATION_CD"));
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(rs.getFloat("TOTALMANHRS"));

        return rodAndRonManHrsEntity;
    }
}

