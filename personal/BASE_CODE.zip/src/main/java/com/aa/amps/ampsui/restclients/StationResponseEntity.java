package com.aa.amps.ampsui.restclients;

import lombok.Data;

import java.util.List;

/**
 * Data class for storing response from Station API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/9/2019
 */
@Data
public class StationResponseEntity {
    private List<StationEntity> stationEntityList;
}
