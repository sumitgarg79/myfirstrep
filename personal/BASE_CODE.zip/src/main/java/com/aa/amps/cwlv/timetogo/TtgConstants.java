package com.aa.amps.cwlv.timetogo;

public class TtgConstants {

    public static final Integer DAY_TO_GO_LIMIT = 5;
    public static final Integer HR_CYCLE_TO_GO_LIMIT = 50;

    public static final String HOURS = "H";
    public static final String DAYS = "D";
    public static final String CYCLES = "C";
    public static final String SPACE = " ";

}
