package com.aa.amps.ampsui.yieldmangement;

import lombok.Data;
import java.util.List;

/**
 * Request class for YieldManagementRequest.
 *
 * @author Thanuja
 * @since 05/13/2019.
 */
@Data
public class YieldManagementRequest {
    private String airlineCode;
    private String smSession;
    List<YieldManagement> yieldManagementList ;
}
