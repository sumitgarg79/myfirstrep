package com.aa.amps.base.task;

import lombok.Data;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.Date;

/**
 * Entity that represents the AIRCFT_MNTNC_TASK_PLAN DB table.
 *
 * @author Paul Verner(650196)
 * @since 6/8/2018.
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@Repository
@Data
public class TaskEntity {

    private String aircraftNbr;
    private String taskId;
    private String status;
    private String priority;
    private String description;
    private String taskTypeCode;
    /**
     * Intentionally appended String to resolve naming conflict on UI.
     */
    private String forecastDateAsString;
    private Integer ttgHours;
    private Integer ttgDays;
    private Integer ttgCycles;
    private Integer manHours;

    private String routeControlCode;
    private boolean deferralLockInd;
    private String ataCode;

    //Don't issue Indicator
    private boolean dni;

    /**
     * Intentionally appended String to resolve naming conflict on UI.
     */
    private String plannedDateAsString;
    private String plannedStation;
    private String fleetCode;
    private String softTimes;

    // Work Control no from SCEPTRE
    private Integer workControl;

    // US756399:[Draft] Functionality for the "Save" button
    private String wrkPkgTaskStatus;
    private Long workPkgId;
    private String userId;
    private Timestamp updatedTime;

    private Date dueDate;
    private Date createDate;
    private String taskDetailText;
    private String trackNbr;

    //US865009 - for order of task type according to the business
    private Integer taskTypeSorting;

    /**
     * categorize forecast Days To Go value("", "HIGHTIME", "OVERTIME")
     * if forecast DTG < 0 --> "OVERTIME",
     * 0 <= forecast DTG < 4 --> "HIGHTIME",
     * no forecast date or forcast DTG >= 4 --> ""
     */
    private String forecastDtgCategory;

    /**
     * bowType
     * - "LINE" indicates trackType in Line Category - "01", "04", "05", "06", "07", "08", "09", "02", "98", "99",
     * "1000"
     * - "BASE" indicates trackType in Base Category - "03", "10", "11", "12", "100"
     */
    private String bowType;

}
