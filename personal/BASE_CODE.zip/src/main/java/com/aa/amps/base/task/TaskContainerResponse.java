package com.aa.amps.base.task;

import lombok.Data;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Entity that holds data to be returned from Task query.
 *
 * @author Paul Verner(650196)
 * @since 7/17/2018.
 */

@Component
@Data
public class TaskContainerResponse {
    private List<TaskEntity> taskList;
    private String workCodeJobOrder;
    private String aircraftNumber;
    private Double grandTotalManHours;

}
