package com.aa.amps.base.bow.statussearch;

/**
 * This is the constants class for work package search.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 * HCL 08/10/2018 : US89830: [BOW Status] - Visitor will only have Finalized available BOW no Draft
 */
public class BOWStatusSearchConstants {
    public static final String AIRCRAFT_NO = "aircraftNumber";
    public static final String STATIONS = "stations";
    public static final String PKG_STATUS_CD = "status";
    public static final String PKG_SCHD_FROM = "fromDate";
    public static final String PKG_SCHD_TO = "toDate";
    public static final String KEYWORD = "keyword";
    public static final String USER_ROLE = "userRole";

    public static final String BOW_STATUS_DELETED = "DELETED";

    private BOWStatusSearchConstants() {
        throw new IllegalStateException("BOW Status Search constants class");
    }
}
