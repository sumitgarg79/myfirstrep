package com.aa.amps.cwlv.accessControl;

import org.springframework.web.bind.annotation.*;

/**
 * Controller class for various APIs for the Role and Access Controller
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */

@CrossOrigin
@RestController
@RequestMapping({"/accessControl"})
public class AccessController {

    private AccessControlService roleControlService;

    public AccessController(AccessControlService roleControlService) {
        this.roleControlService = roleControlService;
    }

    /**
     * This method provide the JSON as string for the Access control for to the Role ID
     * Will return the applications list the given role ID have the access for.
     *
     * @param id for which we have to search the data
     * @return AccessControl
     * @throws Exception In case of File not found
     */
    @GetMapping(path = {"appList/{id}"})
    public String getAppList(@PathVariable("id") int id) throws Exception {
        return roleControlService.getAppList(id);
    }

    /**
     * This method provide the JSON as string for the details access of the
     * application for the given role Id at Tab/Field level of the application.
     *
     * @param id      for which we have to search the data
     * @param appName for which we have to search the data
     * @return AccessControl
     * @throws Exception In case of File not found
     */
    @GetMapping(path = {"roleApp/{id}/{appName}"})
    public String getRoleAccess(@PathVariable("id") int id, @PathVariable("appName") String appName) throws Exception {
        return roleControlService.getRoleAccess(id, appName);
    }
}
