package com.aa.amps.base.util;

import com.aa.amps.base.exception.BaseServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

/**
 * This Class contains common functionality related to RestClients.
 */
@Component
public class RestClientUtils {

    private static final Logger LOG = LoggerFactory.getLogger(RestClientUtils.class);

    /**
     * This methods provides HttpHeaders with SiteMinderSession
     *
     * @param smeSession to set to the message header
     * @return HttpHeader with SiteMinderSession
     */
    public HttpHeaders getHeaders(String smeSession) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        if (!(smeSession).isEmpty()) {
            LOG.debug("SMSESSION Cookie {}", smeSession);
            headers.add("Cookie", "SMSESSION=" + smeSession);
        }
        return headers;
    }


    /**
     * This Method converts Long workPkgId to JSON String
     *
     * @param workPkgId to create JSON message
     * @return Json String.
     * @throws BaseServiceException if there is any  error while conversion of object to json.
     */
    public String convertToJsonString(Long workPkgId) throws BaseServiceException {
        String jsonInString;

        ObjectMapper mapper = new ObjectMapper();
        try {
            jsonInString = mapper.writeValueAsString(workPkgId);
            return jsonInString;
        } catch (JsonProcessingException e) {
            LOG.error("error while Json Parsing {}", e);
            throw new BaseServiceException(com.aa.amps.base.util.BaseConstants.JSON_PARSING_ERROR, null);
        }
    }


}
