package com.aa.amps.base.task;

import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.util.RepositoryUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.exception.TaskDetailException.TASKDETAIL_LOAD_FAILED;
import static com.aa.amps.base.task.TaskConstants.*;
import static com.aa.amps.base.task.TaskSqlQuery.FORECAST_DT_TASK_TYPE_ASC_ORDER;
import static com.aa.amps.base.util.BaseConstants.TO_DATE;
import static com.aa.amps.base.util.BaseRepositoryConstants.*;
import static com.aa.amps.base.util.DateUtil.*;
import static com.aa.amps.base.util.UserIdUtil.shortenUserIdTo6Characters;

/**
 * This class to search the Task base on search Criteria provided by the user.
 *
 * @author Paul Verner(650196)
 * @since 6/13/2018.
 * <p>
 * HCL 07/03/2018 : US748803  : [Base  BOW] [Filter] Search by - Task Types
 * HCL 06/25/2018 : US748801 : [Base  BOW] [Filter] Search by - Keyword
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 * HCL 07/06/2018 : US786598:[Base Bow] desc field needed {AMPS Database Work}
 * Naseer (842018) 09/12/2018 : US882719 - Item6 - Only planned items should be displayed for the selected stations.
 */
@Repository
public class TaskRepository {

    private static final Logger LOG = LoggerFactory.getLogger(TaskRepository.class);
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    TaskRepository(
            @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Gets task Data by aircraft Number
     *
     * @param searchCriteria Criteria on which tasks will be searched
     * @return List<TaskEntity>
     */
    List<TaskEntity> getTasks(final Map<String, Object> searchCriteria) throws ParseException {

        Map<String, Object> parameterMap = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        sql.append(TaskSqlQuery.SELECT_TASKS_BY_AIRCRAFT);

        appendQueryConditionForAircraft(searchCriteria, sql, parameterMap);

        appendQueryConditionForTaskTypes(searchCriteria, sql, parameterMap);

        addSoftTime(sql, searchCriteria, parameterMap);
        appendQueryConditionsForKeyword(searchCriteria, sql);

        appendQueryConditionForItemsWith(searchCriteria, sql);

        addForecastDateSearchCriteria(sql, searchCriteria, parameterMap);

        appendQueryConditionForStations(sql, searchCriteria, parameterMap);


        //For ordering results by Forecast date
        sql.append(FORECAST_DT_TASK_TYPE_ASC_ORDER);

        LOG.debug("Task sql query : {}", sql);
        List<TaskEntity> result = namedJdbcTemplate.query(sql.toString(), parameterMap, new TaskRowMapper());
        LOG.debug("Row count of tasks from db for given Search Criteria: {}", result.size());

        return result;
    }

    /**
     * Get Aircraft Type Equipment Code (2 digit number) (AIRCFT_TYPE_EQUIP_CD from AIRCFT_REFERNC table) for given
     * aircraftNumber.
     *
     * @param aircraftNumber - aircraft number that will be used to query AIRCFT_REFERNC table
     * @return equipmentTypeCode - represents SABRE fleet code for given aircraft
     */
    String getAircraftEquipmentType(String aircraftNumber) {

        String typeEquipment;
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put("aircraftNumber", aircraftNumber);
        try {
            typeEquipment = namedJdbcTemplate.queryForObject(TaskSqlQuery.SELECT_AIRCRAFT_EQUIP_TYPE, parameterMap, String.class);
        } catch (EmptyResultDataAccessException e) {
            LOG.debug("getAircraftEquipmentType() no result found for equipCd Query for acft: {}", aircraftNumber);
            typeEquipment = null;
        }
        return typeEquipment;
    }

    /**
     * [Base  BOW] [Filter] Search by - AircraftNumber
     * Private method to add the AircraftNumber Search Criteria.
     *
     * @param searchCriteria to get the AircraftNumber
     * @param sql            to append the condition
     * @param parameterMap   contains parameters for sql query.
     */
    private void appendQueryConditionForAircraft(Map<String, Object> searchCriteria, StringBuilder sql, Map<String, Object> parameterMap) {
        if (searchCriteria.containsKey(AIRCRAFT_NO)) {
            sql.append(" AND task.AIRCFT_NBR = :aircraftNumber ");
            parameterMap.put("aircraftNumber", searchCriteria.get(AIRCRAFT_NO));
        }
    }

    /**
     * Private method to add the Task Type Search Criteria.
     * Logic written in the method in case user selects ME8 subtypes (ie. 'ME8-MON') task then
     * We have ME* as an task type and have to find the 'MON' in Description.
     *
     * @param searchCriteria -- task search Criteria from UI
     * @param sql            -- to append SQL conditions for taskType selection
     * @param parameterMap   -- parameterMap for namedJdbcTemplate.query
     */
    private void appendQueryConditionForTaskTypes(Map<String, Object> searchCriteria, StringBuilder sql, Map<String, Object> parameterMap) {
        if (searchCriteria.containsKey(TASK_TYPES)) {
            List<String> taskTypes = (List<String>) searchCriteria.get(TASK_TYPES);

            // create list of taskTypesForQuery (exclude ME8 subtypes from this)
            List<String> taskTypesForQuery = filterTaskTypesByRemovingSubTypes(taskTypes);

            // create list of KEYWORD prefixes associated with ME8 subtypes
            //  (for example: ME8-E0 tasks will have "INS" or "MOD" at start of Description column
            List<String> me8SubTypeKeywords = findKeywordsForME8Subtypes(taskTypes);

            // add taskType condition and subType keyword condition to SQL query
            appendQueryForTaskTypeAndSubtypes(sql, parameterMap, taskTypesForQuery, me8SubTypeKeywords);
        }
    }

    /**
     * Add conditions to SQL query for TaskTypes and subType Keyword Prefixes
     *
     * @param sql                -- to append SQL conditions for taskType selection
     * @param parameterMap       -- parameterMap for namedJdbcTemplate.query
     * @param taskTypesForQuery  -- taskTypes for the Query
     * @param me8SubTypeKeywords -- keyword prefixes for ME8 subtypes
     */
    private void appendQueryForTaskTypeAndSubtypes(StringBuilder sql, Map<String, Object> parameterMap,
                                                   List<String> taskTypesForQuery, List<String> me8SubTypeKeywords) {
        sql.append(" AND ( ");
        if (!taskTypesForQuery.isEmpty()) {
            sql.append(" AIRCFT_MNTNC_TASK_TYPE_CD IN (:taskTypes) ");
            parameterMap.put("taskTypes", taskTypesForQuery);
        }
        // if there are any ME8 Subtypes, we will look for tasks with taskType: ME8 that have one of the subType
        //   keywords (ex. MON, REP, DNS) as the first 3 characters of the taskDescription
        if (!me8SubTypeKeywords.isEmpty() && !taskTypesForQuery.contains(ME8)) {
            if (!taskTypesForQuery.isEmpty()) {
                sql.append(" OR ");
            }
            sql.append(" ( AIRCFT_MNTNC_TASK_TYPE_CD = 'ME8' AND ( ");
            // firstKeyword boolean is used to control adding "OR" to query for second and subsequent me8SubTypeKeywords
            boolean firstKeyword = true;
            for (String keyword : me8SubTypeKeywords) {
                if (!firstKeyword) {
                    sql.append(" OR ");
                }
                firstKeyword = false;
                sql.append(" AIRCFT_MNTNC_TASK_DESC like '")
                        .append(keyword).append("%'");
            }
            sql.append(") )");
        }
        sql.append(" ) ");
    }

    /**
     * Remove subTypes (ie. ME8-MON) from taskTypeList
     *
     * @param taskTypes - taskTypes selected on the UI for querying tasks
     * @return taskTypes without subTypes (ME8-MON, ME8-TC)
     */
    private List<String> filterTaskTypesByRemovingSubTypes(List<String> taskTypes) {
        List<String> taskTypesForQuery = new ArrayList<>();
        for (String taskType : taskTypes) {
            if (!taskType.contains(ME8_HYPHEN)) {
                taskTypesForQuery.add(taskType);
            }
        }
        return taskTypesForQuery;
    }

    /**
     * For each ME8 subType, add list of Keyword prefixes to me8SubTypeKeywords which will be used in Task Query.
     * Examples: ME8-TC --> (REP, INT), ME8-CKC --> (CKC)
     *
     * @param taskTypes - taskTypes that could include subtype (ie. ME8-TC)
     * @return me8SubTypeKeywords - list of subType Keywords (ie. 'MON', 'REP', 'MOD') for Query
     */
    private List<String> findKeywordsForME8Subtypes(List<String> taskTypes) {
        List<String> me8SubTypeKeywords = new ArrayList<>();
        for (String taskType : taskTypes) {
            // add KEYWORD prefixes for ME8 subtype to the list of keywords
            if (ME8_MON.equals(taskType)) {
                me8SubTypeKeywords.addAll(ME8_MON_KEYWORDS);
            }
            if (ME8_TC.equals(taskType)) {
                me8SubTypeKeywords.addAll(ME8_TC_KEYWORDS);
            }
            if (ME8_EO.equals(taskType)) {
                me8SubTypeKeywords.addAll(ME8_EO_KEYWORDS);
            }
            if (ME8_CKC.equals(taskType)) {
                me8SubTypeKeywords.addAll(ME8_CKC_KEYWORDS);
            }
            if (ME8_DNS.equals(taskType)) {
                me8SubTypeKeywords.addAll(ME8_DNS_KEYWORDS);
            }
        }
        return me8SubTypeKeywords;
    }

    /**
     * US748801 : [Base  BOW] [Filter] Search by - Keyword
     *
     * @param searchCriteria to get the task type
     * @param sql            to append the condition
     */
    private void appendQueryConditionsForKeyword(Map<String, Object> searchCriteria, StringBuilder sql) {
        if (searchCriteria.containsKey(TASKNAME_OR_DESC)) {
            sql.append(" and ( UPPER(task.AIRCFT_MNTNC_TASK_ID) like UPPER('%");
            sql.append(searchCriteria.get(TASKNAME_OR_DESC));

            sql.append("%')  or UPPER(task.AIRCFT_MNTNC_TASK_DESC) like UPPER('%");
            sql.append(searchCriteria.get(TASKNAME_OR_DESC));
            sql.append("%')) ");
        }
    }


    /**
     * US748805 - [Filter] Search by -  'Items with' AD/DNI.
     *
     * @param searchCriteria map with user selected ItemsWith AD/DNI value
     * @param sql            query object to append conditions
     */
    private void appendQueryConditionForItemsWith(Map<String, Object> searchCriteria, StringBuilder sql) {
        if (searchCriteria.containsKey(ITEMS_WITH)) {
            boolean isAD = false;
            boolean isDNI = false;
            List<String> itemsWith = (List<String>) searchCriteria.get(ITEMS_WITH);

            sql.append(" AND ( ");
            for (String item : itemsWith) {
                if (item.equalsIgnoreCase(AD)) {
                    sql.append(" task.mntnc_task_airdrctv_ind = 'T' ");
                    isAD = true;
                }

                if (item.equalsIgnoreCase(DNI)) {
                    if (isAD) {
                        sql.append(" OR ");
                    }
                    sql.append(" task.mntnc_task_do_not_issue_ind = 'T' or msi.SMOOTHING_ITEM_DO_NOT_PLAN_IND   = 'Y'" +
                            " ");
                    isDNI = true;
                }

                setQueryWithAdDni(sql, isAD, isDNI, item);
            }
            sql.append(" ) ");
        }
    }

    /**
     * Helper method for appendQueryConditionForItemsWith
     *
     * @param sql   query object to append conditions
     * @param isAD  is true if user select AD.
     * @param isDNI is true if user select DNI
     * @param item  current item from ItemsWith AD/DNI List.
     */
    private void setQueryWithAdDni(StringBuilder sql, boolean isAD, boolean isDNI, String item) {
        if (item.equalsIgnoreCase(AD_DNI)) {
            if (isAD || isDNI) {
                sql.append(" OR ");
            }
            sql.append("(task.mntnc_task_airdrctv_ind = 'T' AND ");
            sql.append("(task.mntnc_task_do_not_issue_ind = 'T' or msi.SMOOTHING_ITEM_DO_NOT_PLAN_IND   = 'Y'))");
        }
    }


    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * To Fetch the data based on noForecast value and between the given foreCastDates
     *
     * @param sql            to append the condition
     * @param searchCriteria to get the task type
     * @param parameterMap   contains parameters for sql query.
     */
    private void addForecastDateSearchCriteria(final StringBuilder sql, Map<String, Object> searchCriteria, Map<String, Object> parameterMap) throws ParseException {
        boolean hasForecastDateRange = searchCriteria.containsKey(FORECAST_FROMDATE) || searchCriteria.containsKey(FORECAST_TODATE);
        boolean hasNoForecast = false;

        if (searchCriteria.containsKey(NO_FORECAST)) {
            hasNoForecast = (boolean) searchCriteria.get(NO_FORECAST);
        }

        // request will not enter into loop if we  get ForecastDate as null or NoForecast as false
        if (hasForecastDateRange || hasNoForecast) {
            sql.append(" AND (");
            if (hasForecastDateRange) {
                appendQueryConditionForForecastDate(sql, searchCriteria, parameterMap);
            }
            if (hasNoForecast) {
                sql.append(" task.MNTNC_TASK_DUE_DT IS NULL ");
            }
            sql.append(")");
        }
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     * To Fetch the data based on noForecast value and between the given foreCastDates
     *
     * @param sql          to append the condition
     * @param parameterMap contains parameters for sql query.
     */
    private void appendQueryConditionForForecastDate(final StringBuilder sql, Map<String, Object> searchCriteria, Map<String, Object> parameterMap) throws ParseException {
        boolean hasNoForecast = false;
        String forecastFromDate = "";
        String forecastToDate = getCurrentDateAsString();

        if (searchCriteria.containsKey(NO_FORECAST)) {
            hasNoForecast = (boolean) searchCriteria.get(NO_FORECAST);
        }

        if (searchCriteria.containsKey(FORECAST_FROMDATE)) {
            forecastFromDate = (String) searchCriteria.get(FORECAST_FROMDATE);
        }

        if (searchCriteria.containsKey(FORECAST_TODATE)) {
            forecastToDate = (String) searchCriteria.get(FORECAST_TODATE);
        }

        if (searchCriteria.containsKey(FORECAST) && Boolean.valueOf((String) searchCriteria.get(FORECAST))) {
            if (StringUtils.isNotEmpty(forecastFromDate) &&
                    isFirstDateAfterSecond(forecastFromDate, getPreviousDateAsString())) {
                sql.append(" TRUNC(task.MNTNC_TASK_DUE_DT) BETWEEN ").append(TO_DATE);
                sql.append("(").append(":forecastFromDate").append(COMMA_DELIM).append(MM_DD_YYYY).append(")");

                sql.append(" AND ").append(TO_DATE).append("(");
                sql.append(":forecastToDate").append(COMMA_DELIM).append(MM_DD_YYYY).append(")");
                if (hasNoForecast) {
                    sql.append(" OR ");
                }

                parameterMap.put("forecastFromDate", forecastFromDate);
                parameterMap.put("forecastToDate", forecastToDate);
            } else {
                sql.append(" TRUNC(task.MNTNC_TASK_DUE_DT) <= ").append(TO_DATE);
                sql.append("(").append(":forecastToDate").append(COMMA_DELIM).append(MM_DD_YYYY).append(")");

                if (hasNoForecast) {
                    sql.append(" OR ");
                }
                parameterMap.put("forecastToDate", forecastToDate);
            }
        }
    }

    /**
     * US803389 : [Base BOW] [Filter] Search by - Forecast
     *
     * @param sql            to append the condition
     * @param searchCriteria to get the task type
     * @param parameterMap   contains parameters for sql query.
     */
    private void addSoftTime(final StringBuilder sql, Map<String, Object> searchCriteria, Map<String, Object> parameterMap) {
        if (searchCriteria.containsKey(SOFT_TIME)) {
            sql.append(" AND task.MNTNC_TASK_PLAN_FLEX_IND = :softTimeInd ");
            parameterMap.put("softTimeInd", getSoftTimeIndicator((String) searchCriteria.get(SOFT_TIME)));
        }
    }

    /**
     * Method to check if workPackageId already exists in DRAFT_WORK_PKG table.
     *
     * @param workPkgEntity Work package to check if it's already exist
     * @return Work package information.
     */
    Map<String, Object> checkWorkPackageExists(final WorkPackageEntity workPkgEntity) {
        Map<String, String> parameterMap = new HashMap<>();
        List<Map<String, Object>> rowMapList;
        Map<String, Object> rowMap;

        parameterMap.put(AIRCRAFT_NUMBER, workPkgEntity.getAircraftNbr());
        parameterMap.put(PKG_SCHD_DATE, workPkgEntity.getPkgSchdDt());
        parameterMap.put(STATION_CODE, workPkgEntity.getPlanStationCd());
        parameterMap.put(TRACK_TYPE_CODE, workPkgEntity.getTrackTypeCd());

        rowMapList = namedJdbcTemplate.queryForList(TaskSqlQuery.CHK_WORK_PKG, parameterMap);
        if (CollectionUtils.isEmpty(rowMapList)) {
            rowMap = null;
        } else {
            rowMap = rowMapList.get(0);
        }
        return rowMap;
    }

    /**
     * Method to get work package sequence id  from database seq: DRAFT_WORK_PKG_SEQ.
     *
     * @return DRAFT_WORK_PKG_SEQ.NEXTVAL as workPkgId
     */
    Long getWorkPackageSeqId() {
        return ((Number) namedJdbcTemplate.queryForList(TaskSqlQuery.GET_WORK_PKG_ID, new HashMap<>
                ()).get(0).get(WORK_PKG_ID_DB)).longValue();
    }

    /**
     * US756399:[Draft] Functionality for the "Save" button.
     * US786598:[Base Bow] desc field needed {AMPS Database Work}.
     * Method to save base work package draft to database.
     *
     * @param workPkgEntity for saving data
     * @param workPkgId     Work Package ID
     * @return {@code true} if draft is saved successful, {@code false} otherwise
     */
    public boolean saveBaseDraft(WorkPackageEntity workPkgEntity, Long workPkgId) {

        StringBuilder sql = new StringBuilder();
        boolean isDataSaved = true;

        // Save base bow draft
        try {
            sql.append(TaskSqlQuery.INSERT_BASE_BOW_DRAFT);
            LOG.debug("saveBaseDraft() : SQL Query - {} ", sql);

            Map<String, Object> parameterMap = getWorkPkgParameterMap(workPkgEntity, workPkgId);
            LOG.debug("saveBaseDraft() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));

            int rowCount = namedJdbcTemplate.update(sql.toString(), parameterMap);
            LOG.debug("saveBaseDraft(): total rows inserted work package - {}", rowCount);

        } catch (Exception e) {
            LOG.error("Exception in saveBaseDraft() ", e);
            isDataSaved = false;
        }

        return isDataSaved;
    }

    /**
     * Method to update base draft work package.
     *
     * @param workPkgEntity Work package which has to be updated
     * @return {@code true} if draft is updated successful, {@code false} otherwise
     */
    public boolean updateWorkPackageEntity(WorkPackageEntity workPkgEntity) {
        boolean isDataSaved = true;
        Map<String, Object> parameterMap = getWorkPkgParameterMap(workPkgEntity, workPkgEntity.getWorkPkgId());
        LOG.debug("updateWorkPackageEntity() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));
        try {
            int rowCount = namedJdbcTemplate.update(TaskSqlQuery.UPDATE_BASE_BOW_DRAFT, parameterMap);
            LOG.debug("updateWorkPackageEntity(): total rows updated - {}", rowCount);
        } catch (Exception e) {
            LOG.error("Exception in updateWorkPackageEntity() ", e);
            isDataSaved = false;
        }
        return isDataSaved;
    }

    /**
     * Method to delete base draft work package.
     *
     * @param workPkgId work package which has to be deleted
     * @param userId    who requested the deletion
     * @return {@code true} if work package is deleted successful, {@code false} otherwise
     */
    public boolean deleteWorkPackageEntity(Long workPkgId, String userId) {
        boolean isDataSaved = true;
        Map<String, Object> parameterMap = new HashMap<>();

        try {
            parameterMap.put(WORK_PACKAGE_ID, workPkgId);
            parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));

            int rowCount = namedJdbcTemplate.update(TaskSqlQuery.DELETE_BASE_BOW_DRAFT, parameterMap);
            LOG.debug("deleteWorkPackageEntity(): total rows updated - {}", rowCount);
        } catch (Exception e) {
            LOG.error("Exception in deleteWorkPackageEntity() ", e);
            isDataSaved = false;
        }
        return isDataSaved;
    }

    /**
     * Method to save/insert base work package tasks to database.
     *
     * @param taskEntities List of tasks inserted in the database
     * @param workPkgId    work package Id
     * @return {@code true} if tasks is saved successful, {@code false} otherwise
     */
    public boolean saveWorkPkgDraftTasks(List<TaskEntity> taskEntities, Long workPkgId) {
        boolean isDataSaved = true;
        try {
            final List<Map<String, Object>> insertParameterMapList
                    = getWorkPkgDraftTasksMaps(taskEntities, workPkgId, CREATE);

            insertTaskEntities(insertParameterMapList);
        } catch (Exception e) {
            LOG.error("Exception in saveWorkPkgDraftTasks() ", e);
            isDataSaved = false;
        }

        return isDataSaved;
    }

    /**
     * This method is to update the tasks.
     *
     * @param taskEntities task list to be udpated
     * @param workPkgId    work pacakge ID
     * @return @return {@code true} if tasks is updated successful, {@code false} otherwise
     */
    public boolean updateWorkPkgDraftTasks(List<TaskEntity> taskEntities, Long workPkgId) {
        boolean isDataSaved = true;
        try {
            final List<Map<String, Object>> updateParameterMapList
                    = getWorkPkgDraftTasksMaps(taskEntities, workPkgId, UPDATE);

            updateTaskEntities(updateParameterMapList);
        } catch (Exception e) {
            LOG.error("Exception in updateWorkPkgDraftTasks() ", e);
            isDataSaved = false;
        }

        return isDataSaved;
    }

    /**
     * This method to get the parameter list of tasks from WorkPackageEntity
     *
     * @param taskEntities list of tasks to insert
     * @param workPkgId    Work package ID of work package
     * @return Parameter list of tasks which have to be saved
     */
    public List<Map<String, Object>> getWorkPkgDraftTasksMaps(List<TaskEntity> taskEntities,
                                                              Long workPkgId, String taskStatus) {
        Map<String, Object> taskParameterMap;
        final List<Map<String, Object>> insertParameterMapList = new ArrayList<>();

        for (final TaskEntity task : taskEntities) {
            task.setWorkPkgId(workPkgId);
            taskParameterMap = this.getNamedParameterMap(task);
            taskParameterMap.put(WORK_PACKAGE_TASK_STATUS, taskStatus);
            LOG.debug("SaveWorkPkgDraftTasks() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(taskParameterMap));

            insertParameterMapList.add(taskParameterMap);
        }
        return insertParameterMapList;
    }

    /**
     * Method to execute query to insert the task into table.
     *
     * @param insertParameterMapList The list of tasks have to inserted into the database
     */
    private void insertTaskEntities(List<Map<String, Object>> insertParameterMapList) {
        String sql = TaskSqlQuery.INSERT_BASE_BOW_TASKS;
        int[] rowCountInsert = namedJdbcTemplate.batchUpdate(sql, insertParameterMapList.toArray(new HashMap[insertParameterMapList.size()]));
        LOG.debug("insertTaskEntities(): total rows added - {}", rowCountInsert);
    }

    /**
     * Method to execute the query for update task.
     *
     * @param updateParameterMapList The list of tasks have to updated into the database
     */
    private void updateTaskEntities(List<Map<String, Object>> updateParameterMapList) {
        String sql = TaskSqlQuery.UPDATE_BASE_BOW_TASKS;
        int[] rowCountUpdate = namedJdbcTemplate.batchUpdate(sql, updateParameterMapList.toArray(new HashMap[updateParameterMapList.size()]));
        LOG.debug("updateTaskEntities(): Total rows updated - {}", rowCountUpdate);
    }

    /**
     * Method to mark the task as deletes from work package.
     *
     * @param workPkgId       work package ID from which tasks have to mark as deleted
     * @param dbTaskEntityMap task which have to be mark as deleted
     */
    public boolean deleteTaskFromWorkPkg(Map<String, Object> dbTaskEntityMap, Long workPkgId, String userId) {
        Map<String, Object> parameterMap = new HashMap<>();
        boolean isDataSaved = true;

        try {
            parameterMap.put(TASK_ID, new ArrayList<>(dbTaskEntityMap.keySet()));
            parameterMap.put(WORK_PACKAGE_ID, workPkgId);
            parameterMap.put(WORK_PACKAGE_TASK_STATUS, DELETE);
            parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));

            int deletedRowCount = namedJdbcTemplate.update(TaskSqlQuery.UPDATE_BASE_BOW_TASKS, parameterMap);
            LOG.debug("deleteTaskFromWorkPkg(): total rows deleted - {}", deletedRowCount);
        } catch (Exception e) {
            LOG.error("Exception in deleteTaskFromWorkPkg() ", e);
            isDataSaved = false;
        }

        return isDataSaved;
    }

    /**
     * Method to mark all the tasks as deleted for a work package.
     *
     * @param workPkgId work package ID for which tasks have to mark as deleted
     * @param userId    of the user who deleted the tasks.
     * @return {@code true} if tasks are deleted successful, {@code false} otherwise
     */
    public boolean deleteAllTasksForWorkPkg(Long workPkgId, String userId) {
        Map<String, Object> parameterMap = new HashMap<>();
        boolean isDataSaved = true;

        try {
            parameterMap.put(WORK_PACKAGE_ID, workPkgId);
            parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));

            int deletedRowCount = namedJdbcTemplate.update(TaskSqlQuery.DELETE_BASE_BOW_TASKS_BY_BOW, parameterMap);
            LOG.debug("deleteAllTasksForWorkPkg(): total rows deleted - {}", deletedRowCount);
        } catch (Exception e) {
            LOG.error("Exception in deleteAllTasksForWorkPkg() ", e);
            isDataSaved = false;
        }

        return isDataSaved;
    }

    /**
     * Method to get all the task entities of Draft from database.
     *
     * @param workPkgId work package ID
     * @return the list of task details
     */
    List<Map<String, Object>> getTaskEntitiesForDraft(Long workPkgId) {
        Map<String, Object> parameterMap = new HashMap<>();
        List<Map<String, Object>> rowMapList;

        parameterMap.put(WORK_PACKAGE_ID, workPkgId);

        SqlParameterSource namedParameters = new MapSqlParameterSource(parameterMap);
        rowMapList = namedJdbcTemplate.queryForList(TaskSqlQuery.GET_TASK_ENTITIES, namedParameters);
        LOG.debug("getTaskEntitiesForDraft(): total task retrieved - {}", rowMapList.size());
        return rowMapList;
    }

    /**
     * Gets the parameter map for task entity : batch update.
     *
     * @param task task entity to create the MAP
     * @return the  parameter map
     */
    private Map<String, Object> getNamedParameterMap(final TaskEntity task) {
        Map<String, Object> parameterMap = new HashMap<>();

        parameterMap.put(WORK_PACKAGE_ID, task.getWorkPkgId());
        parameterMap.put(AIRCRAFT_NUMBER, task.getAircraftNbr());
        parameterMap.put(TASK_ID, task.getTaskId());
        parameterMap.put(WORK_PACKAGE_TASK_STATUS, CREATE); //For Created
        parameterMap.put(USER_ID, shortenUserIdTo6Characters(task.getUserId()));

        return parameterMap;
    }

    /**
     * Gets the parameter map for work package entity.
     *
     * @param workPkgEntity work package entity
     * @param workPkgId     work package ID
     * @return the  parameter map
     */
    public Map<String, Object> getWorkPkgParameterMap(WorkPackageEntity workPkgEntity, Long workPkgId) {
        Map<String, Object> parameterMap = new HashMap<>();

        parameterMap.put(WORK_PACKAGE_ID, workPkgId);
        parameterMap.put(AIRCRAFT_NUMBER, workPkgEntity.getAircraftNbr());
        parameterMap.put(PKG_SCHD_DATE, workPkgEntity.getPkgSchdDt());
        parameterMap.put(STATION_CODE, workPkgEntity.getPlanStationCd());
        parameterMap.put(TRACK_TYPE_CODE, workPkgEntity.getTrackTypeCd());
        parameterMap.put(SPAN, workPkgEntity.getSpan());
        parameterMap.put(WORK_ORDER_JOB_CODE, workPkgEntity.getWorkOrderJobCd());
        parameterMap.put(SCEPTRE_MNTNC_WORK_PKG_ID, workPkgEntity.getSceptreMntncWorkPkgId());
        parameterMap.put(DOCK_CODE, workPkgEntity.getDockCd());
        parameterMap.put(WORK_PKG_TXT, workPkgEntity.getWorkPkgTxt());
        parameterMap.put(WORK_PKG_STATUS_CODE, workPkgEntity.getWorkPkgStatusCd());
        parameterMap.put(USER_ID, shortenUserIdTo6Characters(workPkgEntity.getUserId()));
        parameterMap.put(COMMENTS, workPkgEntity.getComments());

        return parameterMap;
    }

    /**
     * US845027: [Base BOW] [Filter] Search by - Station
     * To Fetch the OPEN And PLAND Tasks for the given stations.
     *
     * @param sql            to append the condition
     * @param searchCriteria to get the OPEN and PLAND tasks
     * @param parameterMap   contains parameters for sql query
     */
    private void appendQueryConditionForStations(final StringBuilder sql, Map<String, Object> searchCriteria, Map<String, Object> parameterMap) {
        if (searchCriteria.containsKey(TaskConstants.STATIONS)) {
            List<String> stations = (List<String>) searchCriteria.get(TaskConstants.STATIONS);
            if (stations.size() > INT_ZERO) {
                sql.append(" AND wp.PLAN_MNTNC_STN_CD IN (:listOfStations) ");
                parameterMap.put("listOfStations", stations);
            }
        }
    }

    /**
     * Gets TaskDetails by list of aircraftNbrs & taskIds.
     *
     * @param taskDetailReqMap holds list of aircraftNbrs & taskIds
     * @return {@link TaskEntity} list
     */
    List<TaskEntity> getTaskDetails(Map<String, Object> taskDetailReqMap) throws TaskDetailException {
        List<TaskEntity> taskDetails;
        Map<String, Object> parameterMap = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        sql.append(TaskSqlQuery.GET_TASK_DETAILS);

        //For ordering results by Forecast date
        sql.append(FORECAST_DT_TASK_TYPE_ASC_ORDER);

        List<String> aircraftNbrs = (List<String>) taskDetailReqMap.get(TaskConstants.AIRCRAFT_NBRS);
        List<String> taskIds = (List<String>) taskDetailReqMap.get(TaskConstants.TASK_IDS);

        parameterMap.put("aircraftNbrs", aircraftNbrs);
        parameterMap.put("taskIds", taskIds);

        LOG.debug("Task sql query : {}", sql);
        LOG.debug("getTaskDetails() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));

        try {
            taskDetails = (List<TaskEntity>) namedJdbcTemplate.query(sql.toString(), parameterMap, new TaskDetailsRowMapper());
            LOG.debug("Row count of TaskDetails from db : {}",
                    !CollectionUtils.isEmpty(taskDetails) ? taskDetails.size() : 0);
        } catch (Exception ex) {
            LOG.error("Error while quering for multiple TaskDetails, {}", ex);
            throw new TaskDetailException(TASKDETAIL_LOAD_FAILED, null);
        }

        return taskDetails;
    }

    /**
     * Gets  list of Tasks of a package/bow by Work Package ID.
     *
     * @param workPkgId parameter on which we have to retrieve the tasks of a particular package/bow
     * @return {@link TaskEntity} List of Tasks
     */

    List<TaskEntity> getWorkPackageTasks(Long workPkgId) {
        List<TaskEntity> result;
        Map<String, Long> parameterMap = new HashMap<>();
        parameterMap.put("workPkgId", workPkgId);
        result = namedJdbcTemplate.query(TaskSqlQuery.GET_WORK_PACKAGE_TASK_ENTITIES, parameterMap, new WorkPackageTaskRowMapper());
        LOG.debug("getTaskEntities(): total task retrieved - {}", result.size());

        return result;
    }
}