package com.aa.amps.cwlv.manHours.LaaRodManHrs;

import lombok.Data;

import java.util.Date;


/**
 * Entity that represents the Laa Terminations ManHours data reterieved from AMPS DB.
 *
 * @author RAMESH RUDRA(842020)
 * @since 4/17/2018.
 */
@Data
public class LaaTerminationEntity {

    private String station;

    private Long priorityCode;

    private String aircraftNbr;

    private String schdFlightNbr;

    private Date schdDate;

    private Float ManHrsOfpriorityCode;
}
