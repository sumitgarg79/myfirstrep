package com.aa.amps.base.util;

import org.apache.commons.lang.StringUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Optional;

/**
 * A Date utility class to do different date operations.
 *
 * @author Naseer Mohammed (842018)
 * @since 07/19/2018
 */
public class DateUtil {

    public static final String DATE_FORMAT_MMDDYYYY = "MM/dd/yyyy";

    private DateUtil() {
        //This class should not be instantiated.
        throw new IllegalStateException("Utility class. Should not be instantiated.");
    }

    /**
     * @return today's date in string format.
     */
    public static String getCurrentDateAsString() {
        return new SimpleDateFormat(DATE_FORMAT_MMDDYYYY).format(new Date());
    }

    /**
     * This method is to evaluate if the firstDate is after secondDate.
     *
     * @param first  date in comparison
     * @param second date in comparison
     * @return true if firstDate is after secondDate, else return false.
     * @throws ParseException if there is any error while parsing string to Date
     */
    public static boolean isFirstDateAfterSecond(String first, String second) throws ParseException {
        boolean result = false;

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT_MMDDYYYY);
        if (StringUtils.isNotEmpty(first) && StringUtils.isNotEmpty(second)) {
            result = simpleDateFormat.parse(first).after(simpleDateFormat.parse(second));
        }

        return result;
    }


    /**
     * Take a {@link java.util.Date} as input and converts it into the request string format. It also converts the
     * case of the string to uppercase(in case months are represented as alphabets e.g., jan) if flag is set to
     * {@code true}.
     *
     * @param date           param to be formatted
     * @param requiredFormat holds the format to return
     * @param upperCase      is returned if true else lowercase (for months as alphabets)
     * @return formatted date as string
     */
    public static String getFormattedDate(Date date, String requiredFormat, boolean upperCase) {
        String dateStr = "";

        if (null != date && StringUtils.isNotEmpty(requiredFormat)) {
            java.util.Date someDate = new Date(date.getTime());
            SimpleDateFormat formatter = new SimpleDateFormat(requiredFormat);

            if (upperCase) {
                dateStr = formatter.format(someDate).toUpperCase();
            } else {
                dateStr = formatter.format(someDate);
            }
        }

        return dateStr;
    }

    /**
     * Utility method to convert a date represented as string in MM/DD/YYYY format into {@link java.util.Date} in
     * MM-DD-YYYY format.
     *
     * @param dateAsString date in string format e.g., "08/31/2018"
     * @return {@link java.util.Date} representation of input string
     * @throws ParseException if there is any error in converting string to {@link java.util.Date}
     */
    public static Optional<Date> getDateFromString(String dateAsString) throws ParseException {
        Date date = null;

        if (StringUtils.isNotEmpty(dateAsString)) {
            date = new SimpleDateFormat(DATE_FORMAT_MMDDYYYY).parse(dateAsString);
        }

        return Optional.ofNullable(date);
    }

    /**
     * Compute number of days from today (Positive for future date, Negative for past date, 0 for today)
     *
     * @param dateAsString (MM/dd/yyyy format)
     * @return number of days from today (Positive for future date, Negative for past date, 0 for today)
     */
    public static Long getNumberOfDaysFromToday(String dateAsString) {

        Long diff = null;
        if (StringUtils.isNotEmpty(dateAsString)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_MMDDYYYY);
            LocalDate forecastDate = LocalDate.parse(dateAsString, formatter);
            LocalDate now = LocalDate.now();
            diff = ChronoUnit.DAYS.between(now, forecastDate);
        }
        return diff;
    }

    /**
     * This method returns the yesterday date as string in MM/dd/yyyy format.
     *
     * @return one date previous than today's date in string format.
     */
    public static String getPreviousDateAsString() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return new SimpleDateFormat(DATE_FORMAT_MMDDYYYY).format(cal.getTime());
    }
}