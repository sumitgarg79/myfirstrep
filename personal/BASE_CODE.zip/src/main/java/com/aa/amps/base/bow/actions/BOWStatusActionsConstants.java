package com.aa.amps.base.bowstatus.actions;

/**
 * This is the constants class to load all the bow status actions.
 *
 * @author HCL(296319)
 * @since 6/04/2018.
 */
public class BOWStatusActionsConstants {
    public static final int INT_ZERO = 0;
    public static final String BOW_STATUS_ACTION = "BOWStatusAction";
    public static final String COMMA = ",";
    public static final String SYS_PARMTR_VAL = "SYS_PARMTR_VAL";
}
