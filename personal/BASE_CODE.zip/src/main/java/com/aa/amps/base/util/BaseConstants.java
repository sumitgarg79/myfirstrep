package com.aa.amps.base.util;

/**
 * This class holds all Controllers, FitlerRequest and Service classes related constants.
 *
 * @author Naseer Mohammed (842018)
 * @since 07/10/2018
 */
public class BaseConstants {

    public static final String TO_DATE = "TO_DATE";

    public static final String BASE_TASK_TYPE_ORDER_PART_ONE = "BASE_TASK_TYPE_ORDER_P1";
    public static final String BASE_TASK_TYPE_ORDER_PART_TWO = "BASE_TASK_TYPE_ORDER_P2";
    public static final String COMMA = ",";
    public static final String DRAFT_STATUS_FINALIZE_ROLE = "DRAFT_STATUS_FINALIZE_ROLE";
    public static final String INTERNAL_AMPS_LINE_ERROR = "exception while data saving for bow in amps line";
    public static final String JSON_PARSING_ERROR = "Json Parsing Failure";
    
    private BaseConstants() {
        throw new IllegalStateException("Utility class");
    }
}
