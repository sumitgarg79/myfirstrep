package com.aa.amps.cwlv.cwlgrid.util;

import java.util.Comparator;

/**
 * @author Naseer Mohammed (842018) - 03/23/2018
 */

public class CombinedTaskDetailComparotor implements Comparator<CombinedTaskDetail> {

    @Override
    public int compare(CombinedTaskDetail o1, CombinedTaskDetail o2) {
        return o1.getAircftNbr().compareTo(o2.getAircftNbr());
    }
}
