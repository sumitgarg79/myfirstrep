package com.aa.amps.cwlv.web.filter;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import java.io.IOException;
import java.util.UUID;

/**
 * This filter adds MDC data for each incoming request. MDC data is a UUID which is used for logging purpose.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/4/2018
 */
@Component
public class RequestFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        //Nothing to code here.
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            String mdcData = String.format("[requestId:%s] ", getRequestId());
            MDC.put("mdcData", mdcData); //Referenced from logging configuration.

            chain.doFilter(request, response);
        } finally {
            MDC.clear();
        }
    }

    /**
     * Generates the UUID(Universally Unique ID) that will be used to identify each request.
     *
     * @return
     */
    private String getRequestId() {
        return UUID.randomUUID().toString();
    }

    @Override
    public void destroy() {
        //Nothing to code here.
    }
}
