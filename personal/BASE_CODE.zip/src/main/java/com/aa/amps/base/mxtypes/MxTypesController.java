package com.aa.amps.base.mxtypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST Controller class to load all the mx(maintenance) types in the UI.
 * Currently defined mx(maintenance) types by Business are : " ", RON and Base
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since 06/01/2018.
 */

@CrossOrigin
@RestController
@RequestMapping("/base/mxTypes")
public class MxTypesController {

    private static final Logger LOG = LoggerFactory.getLogger(MxTypesController.class);
    private MxTypesService mxTypesService;

    public MxTypesController(MxTypesService mxTypesService) {
        this.mxTypesService = mxTypesService;
    }

    /**
     * GET request implementation to retrieve all the mx(maintenance) types.
     *
     * @return all the mx(maintenance) types
     */
    @GetMapping("/getAll")
    public List<String> getMxTypes() {
        LOG.debug("Request to fetch MxTypes");
        return mxTypesService.getMxTypes();
    }
}
