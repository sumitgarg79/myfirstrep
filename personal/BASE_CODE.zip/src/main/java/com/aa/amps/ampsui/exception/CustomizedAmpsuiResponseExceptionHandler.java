package com.aa.amps.ampsui.exception;

import com.aa.amps.ampsui.util.ServiceResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * ControllerAdvice classes that wish to provide centralized exception handling across all RequestMapping methods
 * through ExceptionHandler methods.
 *
 * @author Neelabh Tripathi
 * @since 12/11/2018.
 */

@ControllerAdvice(basePackages = "com.aa.amps.ampsui")
@RestController
public class CustomizedAmpsuiResponseExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(
        CustomizedAmpsuiResponseExceptionHandler.class);
        
    /**
     * Handle All Exceptions.
     *
     * @param ex
     * @param request
     * @return {@link ResponseEntity}
     */
    @ExceptionHandler({Exception.class})
    public final ResponseEntity<ServiceResponseMessage> handleAllExceptions(Exception ex, WebRequest request) {
        LOG.error("Stepped in to default exception handler for AMPSUI request - {} ", request.getDescription(true));
        LOG.error("Caught exception in the application", ex);

        ServiceResponseMessage errorMesage = ServiceResponseMessage.getGenericExceptionStatus();
        return new ResponseEntity<>(errorMesage, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * This method will handle the {@code BaseServiceException} thrown from controller/service/dataAccess layer in BASE.
     *
     * @param ex      {@code BaseServiceException} object
     * @param request the REST request object
     * @return {@code ResponseEntity} with status as {@code Exception} and {@code custom message} message
     */
    @ExceptionHandler(AmpsuiServiceException.class)
    public final ResponseEntity<ServiceResponseMessage> baseExceptionHandler(AmpsuiServiceException ex,
                                                                             WebRequest request) {
        LOG.error("Got exception from AMPSUI.", ex);
        return getResponseEntity(ex.getMessage(), ex.getStatusCode());
    }

    /**
     * This method will handle the {@code BaseRepositoryException} thrown from dataAccess layer in BASE.
     *
     * @param ex      {@code BaseRepositoryException} object
     * @param request the REST request object
     * @return {@code ResponseEntity} with status as {@code Exception} and {@code custom message} message
     */
    @ExceptionHandler(AmpsuiRepositoryException.class)
    public final ResponseEntity<ServiceResponseMessage> baseExceptionHandler(AmpsuiRepositoryException ex,
                                                                             WebRequest request) {
        LOG.error("Got exception from AMPSUI.", ex);
        return getResponseEntity(ex.getMessage(), ex.getStatusCode());
    }

    /**
     * Extracted method to avoid duplicated code..
     *
     * @param message    - Business or exception
     * @param statusCode - optional to set any code to send to UI.
     * @return {@code ResponseEntity} with status as {@code Exception} and {@code custom message} message
     */
    private ResponseEntity<ServiceResponseMessage> getResponseEntity(String message, String statusCode) {
        ServiceResponseMessage errorMessage = ServiceResponseMessage.getGenericExceptionStatus();

        errorMessage.setMessage(message);
        errorMessage.setStatusCode(statusCode);

        return new ResponseEntity<>(errorMessage, HttpStatus.BAD_REQUEST);
    }
}
