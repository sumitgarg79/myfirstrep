package com.aa.amps.base.tracktype;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository class for {@link TrackTypeEntity}.
 * It provides the interfaces for CRUD operations on the entity.
 *
 * @author HCL(292147)
 * @since 5/24/2018.
 */
@Repository
class TrackTypeRepository {

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    TrackTypeRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Get list of base work package track type
     * <b> Note: </b>Fetches data for track types.
     *
     * @return {@code List} of base track type records
     */
    List<TrackTypeEntity> getBaseTrackTypes() {
        List<TrackTypeEntity> result;

        result = namedJdbcTemplate.query(TrackTypeSqlQuery.SELECT_BASE_WORK_PKG_TRACK_TYPE, new TrackTypeRowMapper());

        return result;
    }
}
