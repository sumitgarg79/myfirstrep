package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controller class for MessageBrowser endpoints.
 *
 * @author Ramesh Rudra(842020)
 * @since 1/7/2019
 */
@RestController
@RequestMapping("/messagebrowser")
@CrossOrigin
public class MessageBrowserController {

    private static final Logger LOG = LoggerFactory.getLogger(MessageBrowserController.class);

    private MessageBrowserService messageBrowserService;

    @Value("${ampsui.session.flag}")
    private boolean isSessionCheckRequired;

    private SessionTimeOutUtil sessionTimeOutUtil;

    public MessageBrowserController(MessageBrowserService messageBrowserService, SessionTimeOutUtil sessionTimeOutUtil) {
        this.messageBrowserService = messageBrowserService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }


    /**
     * Post /MessageBrowser endpoint to fetch messageBrowserList of requested input received as part of the messages
     * body
     *
     * @return List of MessageBrowser
     */
    @PostMapping
    public List<MessageBrowser> getMessageBrowserList(@RequestBody MessageBrowserRequest messageBrowseRequest) throws AmpsuiServiceException {
        List<MessageBrowser> messageBrowser = null;

        //validating session
        if (messageBrowseRequest != null && isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(messageBrowseRequest.getSmSession());
        }
        Map<String, Object> requestMap = messageBrowseRequest.getSearchCriteriaAsMap();
        messageBrowser = messageBrowserService.getMessageBrowserList(requestMap);
        return messageBrowser;
    }

    /**
     * Post Delete MessageBrowser endpoint to delete List of messageBrowserList of requested input received as part of
     * the messages body
     *
     * @return Boolean true for success deletion or else false for failure in deleting
     */
    @PostMapping(value = "/delete")
    public Boolean deleteMessageBrowser(@RequestBody List<MessageBrowser> messageBrowser) throws
            AmpsuiServiceException {

        LOG.info("deleteMessageBrowser() - Got request to Delete MessageBrowser Grid Data {}", messageBrowser);

        Boolean valid = false;
        valid = messageBrowserService.deleteMessageBrowser(messageBrowser);

        LOG.info("deleteMessageBrowser() - Response from Amps-web for MessageBrowserDelete {}", valid);

        return valid;
    }

    /**
     * Post Update MessageBrowser endpoint to Update List of messageBrowserList
     *
     * @return Boolean true for success Updated or else false for failure in Updating
     */
    @PostMapping(value = "/update")
    public Boolean updateMessageBrowser(@RequestBody List<MessageBrowser> messageBrowser) throws
            AmpsuiServiceException {

        LOG.info("updateMessageBrowser() - Got request to Update MessageBrowser Grid Data {}", messageBrowser);

        Boolean valid = false;
        valid = messageBrowserService.updateMessageBrowser(messageBrowser);

        LOG.info("updateMessageBrowser() - Response from Amps-web for MessageBrowserUpdate {}", valid);

        return valid;
    }
}
