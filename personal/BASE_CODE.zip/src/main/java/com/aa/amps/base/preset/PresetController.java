package com.aa.amps.base.preset;

import com.aa.amps.base.exception.BaseRepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller class for Preset functionality.
 *
 * @author Naseer Mohammed (842018):American Airlines
 * @since 08/06/2018
 */
@RestController
@RequestMapping("/base/preset")
@CrossOrigin
public class PresetController {

    private static final Logger LOG = LoggerFactory.getLogger(PresetController.class);
    private PresetService presetService;

    public PresetController(PresetService presetService) {
        this.presetService = presetService;
    }

    /**
     * POST request implementation to retrieve Presets using request PresetRequest.
     *
     * @return list of preset
     */
    @PostMapping(path = "/getPresets")
    public List<PresetResponse> getPresets(@RequestBody PresetRequest request) {
        LOG.info("Got request to get Presets for Criteria: {} ", request);

        return this.presetService.findByUserIdAndSearchCriterTypeCd(request);
    }

    /**
     * ADD request implementation to Add Preset to DB.
     *
     * @return list of preset with new added preset.
     */
    @PostMapping(path = "/add")
    public List<PresetResponse> addPreset(@RequestBody PresetRequest request) throws BaseRepositoryException {
        LOG.info("Got request to Add Preset to DB: {} ", request);

        return this.presetService.addPreset(request);
    }

    /**
     * Update request implementation to update Preset to DB.
     *
     * @return list of preset with updated preset
     */
    @PutMapping(path = "/update")
    public List<PresetResponse> updatePreset(@RequestBody PresetRequest request) throws BaseRepositoryException {
        LOG.info("Got request to Update Preset to DB: {} ", request);

        return this.presetService.updatePreset(request);
    }

    /**
     * Delete request implementation to delete Preset from DB using userId & searchCriterId
     *
     * @return list of preset after deleting the selected preset.
     */
    @DeleteMapping(path = "/delete/{userId}/{searchCriterId}/{searchCriterTypeCd}")
    public List<PresetResponse> deletePreset(@PathVariable("userId") String userId,
                                             @PathVariable("searchCriterId") int searchCriterId,
                                             @PathVariable("searchCriterTypeCd") String searchCriterTypeCd) throws BaseRepositoryException {
        LOG.info("Got request to Delete Preset from DB: UserId - {}, SearchCriterId - {}, SearchCriterTypeCd - {} ",
                userId, searchCriterId, searchCriterTypeCd);

        PresetRequest request = new PresetRequest();
        request.setUserId(userId);
        request.setSearchCriterId(searchCriterId);
        request.setSearchCriterCd(searchCriterTypeCd);

        return this.presetService.deletePreset(request);
    }
}
