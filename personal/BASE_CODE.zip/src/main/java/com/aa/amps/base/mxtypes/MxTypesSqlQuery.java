package com.aa.amps.base.mxtypes;

/**
 * Query Constant for {@link MxTypesRepository} .
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since 06/01/2018.
 */
public class MxTypesSqlQuery {

    /**
     * Private default constructor to prevent any instantiation.
     */
    private MxTypesSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    /**
     * Query to get all the mx(maintenance) types from database
     * Currently defined mx(maintenance) types by Business are : " ", RON and Base
     */
    public static final String SELECT_MX__TYPES =
            "SELECT SYS_PARMTR_VAL FROM SYS_PARMTR WHERE SYS_PARMTR_NM = 'MNTNC_TYPES'";

}
