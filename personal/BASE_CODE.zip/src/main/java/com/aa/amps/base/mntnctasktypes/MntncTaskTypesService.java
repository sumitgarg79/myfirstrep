package com.aa.amps.base.mntnctasktypes;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * All the Business Logic associated with Aircraft Maintenance Task Types need to be defined here.
 *
 * @author Sudeep(842019).
 * @since 05/21/2018.
 */

@Service
@Transactional
public class MntncTaskTypesService {
    private MntncTaskTypeRepository mntncTaskTypeRepository;

    public MntncTaskTypesService(MntncTaskTypeRepository mntncTaskTypeRepository) {
        this.mntncTaskTypeRepository = mntncTaskTypeRepository;
    }

    /**
     * This method is used to retrieve All the aircraft maintenance types either 'B' (Base) , 'LB'(All Base and LineBase) and ALL (B,LB).
     *
     * @param appType ,values can be either 'B' ,'LB',when appType is null ALL (B,LB) .
     * @return List of MaintenanceTypes based on the app type .
     **/
    @Transactional(readOnly = true)
    public List<MntncTaskTypeEntity> getMaintenanceTaskTypes(String appType) {
        return mntncTaskTypeRepository.getAllMntncTaskTypes(appType);
    }
}
