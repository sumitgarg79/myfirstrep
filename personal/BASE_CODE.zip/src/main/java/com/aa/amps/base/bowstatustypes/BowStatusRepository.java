package com.aa.amps.base.bowstatustypes;

import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

/**
 * BOW Status Type Repository to perform all the CRUD Operations.  Read BOW Status Types from database table: SYS_PARMTR_NM
 *
 * @author Paul Verner(650196):American Airlines
 * @since 06/01/2018.
 */

@Repository
class BowStatusRepository {

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    BowStatusRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Get list of all BOW Status Types
     * <b> Note: </b>Fetches data for BOW Status types.
     * Currently defined mx(maintenance) types by Business are : DRAFT, FINALIZED
     *
     * @return {@code List} of BOW Status types
     */
    List<String> getAllBowStatusTypes() {
        List<String> result = namedJdbcTemplate.query(BowStatusSqlQuery.SELECT_BOW_STATUS_TYPES, new SingleColumnRowMapper<>());
        if (!CollectionUtils.isEmpty(result))
            result = Arrays.asList(result.get(0).split("\\s*,\\s*"));
        return result;
    }

}
