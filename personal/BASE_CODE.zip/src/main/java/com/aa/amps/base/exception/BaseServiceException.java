package com.aa.amps.base.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * This Class is the base exception class which all other exception classes in base package extends.
 *
 * @author Naseer Mohammed (842018)
 * @since 07/19/2018
 */
@Getter
@Setter
public class BaseServiceException extends Exception {

    private final String statusCode;

    public BaseServiceException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
