package com.aa.amps.base.bow.actions;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * This is the <i>Business Logic</i> class to load all the bow status actions.
 *
 * @author HCL(296319)
 * @since 6/04/2018.
 */
@Service
@Transactional
public class BOWStatusActionService {

    private BOWStatusActionRepository bowStatusActionRepository;

    public BOWStatusActionService(BOWStatusActionRepository bowStatusActionRepository) {
        this.bowStatusActionRepository = bowStatusActionRepository;
    }

    /**
     * Fetches all the active bow status actions.
     * @return List<String>
     */
    @Transactional(readOnly = true)
    public List<String> getAllActions() { return bowStatusActionRepository.getAllActions(); }

}
