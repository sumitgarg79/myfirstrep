package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.TaskService;
import com.aa.amps.base.task.WorkPackageEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


/**
 * This class contains the REST endpoint for the functionality to get bill of work package details and its tasks.
 *
 * @author Shyam Sundar Ashok(AA 202571)
 * @since 10/15/2018.
 */
@CrossOrigin
@RestController
@RequestMapping({"/base/bow/workpackage"})
public class WorkPackageController {
    private static final Logger LOG = LoggerFactory.getLogger(WorkPackageController.class);

    private TaskService taskService;
    private WorkPackageService workpackageService;

    public WorkPackageController(TaskService taskService, WorkPackageService workpackageService) {
        this.taskService = taskService;
        this.workpackageService = workpackageService;
    }

    /**
     * Method to get bill of work package using bowInfo WorkPackageFilterRequest.
     *
     * @param workPkgId Contains selected  draftID input.
     * @return WorkPackageEntity Work package.
     */
    @GetMapping("/retrieveBOW")
    public WorkPackageEntity retrieveBow(
            @RequestParam("workPkgId") Long workPkgId) throws BaseServiceException {
        LOG.info("received request for search BOW for bowInfo: {} ", workPkgId);

        Optional<WorkPackageEntity> objWorkPackageEntity = workpackageService.getBowDetail(workPkgId);
        WorkPackageEntity workPackageEntityResult = null;

        if (objWorkPackageEntity.isPresent()) {
            workPackageEntityResult = objWorkPackageEntity.get();
            workPackageEntityResult.setTaskEntityList(taskService.getWorkPackageTasks(workPkgId));
        }

        return workPackageEntityResult;
    }

    /**
     * Method to delete bill of work package using delete action.
     *
     * @param workPkgId contains selected  draftID input
     * @param userId    requested to delete the work package
     * @return {@code true} if work package deleted successfully {@code false} otherwise.
     */
    @DeleteMapping("/deleteBOW")
    public boolean deleteBow(@RequestParam("workPkgId") Long workPkgId,
                             @RequestParam("userId") String userId) throws BaseServiceException {
        LOG.info("Received request to delete BOW from user ID : {} for workPkgId : {}", userId, workPkgId);

        return taskService.deleteBaseBOW(workPkgId, userId);
    }
}
