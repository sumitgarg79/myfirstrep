package com.aa.amps.base.user;

import com.aa.amps.base.exception.BaseServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST Controller class for Task functionality.
 *
 * @author Paul Verner(650196):American Airlines
 * @since 09/19/2018
 */

@RestController
@RequestMapping("/base/user")
@CrossOrigin
public class UserController {
    private static final Logger LOG = LoggerFactory.getLogger(UserController.class);

    private UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(path = "/loginUser")
    public Map<String, String> loginUser(@RequestBody UserRequest userRequest) throws BaseServiceException {
        LOG.debug("logging in user: {}  ", userRequest);
        Map<String, String> loginResponse = new HashMap<>();

        boolean isLoggedIn = userService.loginUser(userRequest);
        if (isLoggedIn) {
            loginResponse.put("result", "success");
        } else {
            loginResponse.put("result", "failed");
        }

        return loginResponse;
    }
}
