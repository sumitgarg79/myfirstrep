package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiRepositoryException;
import com.aa.amps.sharedapi.exception.SharedApiServiceException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service class for all the functionality related to Fleets and Subfleets.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/17/2018
 */
@Service
public class FleetService {
    private static final Logger LOG = LoggerFactory.getLogger(FleetService.class);

    private FleetRepository fleetRepository;

    public FleetService(FleetRepository fleetRepository) {
        this.fleetRepository = fleetRepository;
    }

    /**
     * Fetches all the fleets, without subfleet, for both LAA and LUS. The results are cached for performance purpose.
     *
     * @return {@code List} of fleet codes
     */
    public List<String> getFleets() {
        LOG.debug("Fetching LAA and LUS fleets.");

        return fleetRepository.getFleets();
    }

    /**
     * Fetches all the fleet and subfleets details. The results are cached for performance purpose.
     *
     * @return {@code List} containing details of fleets, subfleets and airline code
     * @throws SharedApiServiceException if there is error while fetching details from repository
     */
    public List<FleetSubfleetEntity> getFleetSubfleets() throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetDetails = null;
        try {
            fleetDetails = fleetRepository.getFleetsAndSubfleets();
        } catch (SharedApiRepositoryException e) {
            LOG.error("Exception while fetching Fleet details from repository", e);

            throw new SharedApiServiceException("Error while fetching fleet and subfleet details. Please contact " +
                                                    "tech-support.", null);
        }

        return fleetDetails;
    }

    /**
     * Method to fetch the fleet and subfleet of provided airline code. Note that there are only
     * 2 valid airline codes -
     * <ul>
     * <li>LAA</li>
     * <li>LUS</li>
     * </ul>
     *
     * @param airlineCode legacy airline code - LAA or LUS
     * @return all the fleets and subfleets belonging to the provided {@code airlineCode}
     * @throws SharedApiServiceException if there is error while fetching details from repository
     */
    public List<FleetSubfleetEntity> getFleetSubfleets(String airlineCode) throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetDetails = null;

        if (StringUtils.isNotEmpty(airlineCode)) {
            List<FleetSubfleetEntity> allFleets = getFleetSubfleets();

            fleetDetails = allFleets.stream()
                .filter(t -> airlineCode.equalsIgnoreCase(t.getAirlineCode()))
                .collect(Collectors.toList());
        }

        if (CollectionUtils.isEmpty(fleetDetails)) {
            // airline code provided is invalid. Forming a dummy FleetSubfleet object
            // to send a meaningful response.
            FleetSubfleetEntity fleet = new FleetSubfleetEntity();
            fleet.setAirlineCode(airlineCode);

            fleetDetails = new ArrayList<>();
            fleetDetails.add(fleet);
        }

        return fleetDetails;
    }

    /**
     * Fetches the subfleets and airline code for the provided list of fleets.
     *
     * @param fleetToSearch {@code List} of fleets
     * @return subfleets and airline code details
     * @throws SharedApiServiceException if there is error while fetching data from repository
     */
    public List<FleetSubfleetEntity> getFleetSubfleets(List<String> fleetToSearch) throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetDetails = null;

        if (!CollectionUtils.isEmpty(fleetToSearch)) {
            List<FleetSubfleetEntity> allFleet = getFleetSubfleets();

            fleetDetails = allFleet.stream()
                .filter(t -> fleetToSearch.contains(t.getFleet().toUpperCase()))
                .collect(Collectors.toList());

            //Populating the invalid fleet codes to the response object to create a meaningful response
            if (fleetDetails.size() != fleetToSearch.size()) {
                populateUnmatchedFleets(fleetToSearch, fleetDetails);
            }
        } else {
            //creating dummy object for meaningful(non-null) response.
            FleetSubfleetEntity fleet = new FleetSubfleetEntity();
            fleetDetails = new ArrayList<>();
            fleetDetails.add(fleet);
        }

        return fleetDetails;
    }

    /**
     * Utility method to populate the missing fleets in {@code fleetDetails} that are present in {@code fleetToSearch}.
     *
     * @param fleetToSearch the source of fleets list
     * @param fleetDetails object to compare and populate missing fleets
     */
    private void populateUnmatchedFleets(List<String> fleetToSearch, List<FleetSubfleetEntity> fleetDetails) {
        Set<String> allValidFleets = fleetDetails.stream()
            .map(FleetSubfleetEntity::getFleet)
            .collect(Collectors.toSet());

        //Goes through each fleet in fleetToSearch and compare it to the existing fleets in fleetDetails.
        //If there is an unmatched record, it is added to fleetDetails.
        fleetToSearch.forEach(k -> {
            if (!allValidFleets.contains(k)) {
                FleetSubfleetEntity fleet = new FleetSubfleetEntity();
                fleet.setFleet(k);
                fleet.setValidFleetCode(false);

                fleetDetails.add(fleet);
            }
        });
    }

    /**
     * Fetches fleet and subfleets details based on the provided airline code and list of fleets.
     *
     * @param airlineCode    legacy airline code - LAA or LUS
     * @param fleetsToSearch fleets codes
     * @return subfleets and airline code details
     * @throws SharedApiServiceException if there is error while fetching details from repository
     */
    public List<FleetSubfleetEntity> getFleetSubfleets(String airlineCode,
        List<String> fleetsToSearch) throws SharedApiServiceException {
        List<FleetSubfleetEntity> fleetDetails = null;

        if (CollectionUtils.isEmpty(fleetsToSearch) || StringUtils.isEmpty(airlineCode)) {
            //creating dummy object for meaningful(non-null) response.
            FleetSubfleetEntity fleet = new FleetSubfleetEntity();

            fleetDetails = new ArrayList<>();
            fleetDetails.add(fleet);
        } else {
            List<FleetSubfleetEntity> allFleet = getFleetSubfleets();

            fleetDetails = allFleet.stream()
                .filter(t -> fleetsToSearch.contains(t.getFleet().toUpperCase()))
                .filter(t -> airlineCode.equalsIgnoreCase(t.getAirlineCode()))
                .collect(Collectors.toList());
        }

        return fleetDetails;
    }

    /**
     * Method to clear up the all the caches maintained for the Fleet details.
     */
    @CacheEvict(value = {"fleets", "combinedFleet"}, allEntries = true)
    public void refreshFleets() {
        LOG.info("Caches for fleets and combined fleets(CWV) cleared up!");
        //No code needed in this method as spring annotation does all the work!
    }
}
