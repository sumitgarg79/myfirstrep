package com.aa.amps.base.util;

import com.aa.amps.base.task.TaskConstants;

/**
 * Util Class for Task.
 *
 * @author Paul Verner
 * @since 10/31/2018
 */
public class TaskUtil {

    private TaskUtil() {
        throw new IllegalStateException("Utility class");
    }

    private static final String BLANK_STRING = "";

    /**
     * Categorize forecast Days To Go value("", "HIGHTIME", "OVERTIME").
     * if forecast DTG < 0 --> "OVERTIME",
     * 0 <= forecast DTG < 4 --> "HIGHTIME",
     * no forecast date or forcast DTG >= 4 --> ""
     *
     * @param forecastDateAsString - forecastDate in "MM/dd/yyyy" format
     * @return "OVERTIME" for DaysToGo < 0, "HIGHTIME" for 0 <= DaysToGo < 4, "" for DaysToGo >= 4
     */
    public static String determineForecastDaysToGoCategory(String forecastDateAsString) {
        String forecastDtgCategory = BLANK_STRING;
        Long diff = DateUtil.getNumberOfDaysFromToday(forecastDateAsString);
        if (diff != null) {
            if (diff < 0) {
                forecastDtgCategory = TaskConstants.OVER_TIME;
            }
            if (diff >= 0 && diff < 4) {
                forecastDtgCategory = TaskConstants.HIGH_TIME;
            }
        }
        return forecastDtgCategory;
    }

    /**
     * Convert trackTypeCode into "LINE" or "BASE" bowType.
     *
     * @param trackTypeCode - if task is scheduled, this will contain trackTypeCode of the WorkPackage
     * @return "LINE" for line TrackTypeCodes, "BASE" for base trackTypeCodes, null for other
     */
    public static String determineBowType(String trackTypeCode) {
        String bowType = null;
        if (TaskConstants.LINE_TRACK_TYPES.contains(trackTypeCode)) {
            bowType = TaskConstants.BOW_TYPE_LINE;
        }
        if (TaskConstants.BASE_TRACK_TYPES.contains(trackTypeCode)) {
            bowType = TaskConstants.BOW_TYPE_BASE;
        }
        return bowType;
    }

    /**
     *   For ME8 taskType, use first 3 characters of description to determine ME8 SubTasktype (MD8-CKC, ME8-DNS,
     *   MD8-E0, ME8-MON, ME8-TC) if any.  If no match, return DB taskType.
     *   For all other taskType, return the DB taskType
     *   if any.
     * @param dbTaskType -- taskTypeCode from DB
     * @param taskDescription -- task description from DB
     * @return -- taskType to be displayed in Task Grid.
     */
    public static String determineTaskType(String dbTaskType, String taskDescription) {
        String taskType = dbTaskType;
        String descriptionFirstThree = null;
        if (taskDescription != null && taskDescription.length() >= 3) {
            descriptionFirstThree = taskDescription.substring(0, 3);
        }
        if (TaskConstants.ME8.equals(dbTaskType) && descriptionFirstThree != null) {
            // use first 3 characters of taskDescription and see if it matches Keyword prefixes for ME8 subtypes below
            if (TaskConstants.ME8_CKC_KEYWORDS.contains(descriptionFirstThree)) {
                taskType = TaskConstants.ME8_CKC;
            }
            if (TaskConstants.ME8_DNS_KEYWORDS.contains(descriptionFirstThree)) {
                taskType = TaskConstants.ME8_DNS;
            }
            if (TaskConstants.ME8_EO_KEYWORDS.contains(descriptionFirstThree)) {
                taskType = TaskConstants.ME8_EO;
            }
            if (TaskConstants.ME8_MON_KEYWORDS.contains(descriptionFirstThree)) {
                taskType = TaskConstants.ME8_MON;
            }
            if (TaskConstants.ME8_TC_KEYWORDS.contains(descriptionFirstThree)) {
                taskType = TaskConstants.ME8_TC;
            }
        }
        return taskType;
    }
}
