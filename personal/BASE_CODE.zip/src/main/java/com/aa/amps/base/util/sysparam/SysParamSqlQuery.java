package com.aa.amps.base.util.sysparam;

/**
 * Query constant for the {@link SysParamRepository} class.
 *
 * @author HCL(922166)
 * Created on 8/29/2018.
 */
public class SysParamSqlQuery {

    /**
     * Query to get the data from SYS_PARMTR table.
     */
    public static final String SYSTEM_PARAM_VALUE = "SELECT * FROM SYS_PARMTR";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private SysParamSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
