package com.aa.amps.base.exception;

/**
 * This class to define all Exceptions related to TaskDetail.
 *
 * @author Naseer Mohammed (842018)
 * @since 09/13/2018
 */
public class TaskDetailException extends BaseServiceException {

    public static final String AIRCRAFT_LIST_MISSING = "AircraftNbr list is required!";
    public static final String TASKID_LIST_MISSING = "TaskId list is required!";

    public static final String TASKDETAIL_LOAD_FAILED = "Exception loading TaskDetails, please see logs for details.";

    public TaskDetailException(String message, String statusCode) {
        super(message, statusCode);
    }
}
