package com.aa.amps.cwlv.util;


/**
 * Constant class holds constants used in LAA/LUS service class.
 *
 * @author Naseer Mohammed
 * @since 5/16/2018
 */

public class BeanConstants {

    public static final String JMOCA_Date_Format = "ddMMMyyyy";
    public static final String JMOCA_TimeStamp_Format = "ddMMMyyyy HHmm";

    public static final int TERMINATION_ARRIVAL_TIME_THRESHOLD_HOURS = 3;

    private BeanConstants() {
        throw new IllegalStateException("Utility class");
    }
}