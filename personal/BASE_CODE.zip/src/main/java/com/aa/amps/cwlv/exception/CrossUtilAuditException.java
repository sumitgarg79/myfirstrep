package com.aa.amps.cwlv.exception;

/**
 * Custom exception class for {@link com.aa.amps.cwlv.crossutil.audit.CrossUtilAuditService}. If required data is not
 * present for the audit, this exception will be thrown.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/19/2018.
 */
public class CrossUtilAuditException extends RuntimeException {

    /**
     * Overloaded constructor.
     *
     * @param exceptionMessage user friendly message about the cause
     */
    public CrossUtilAuditException(String exceptionMessage) {
        super(exceptionMessage);
    }
}
