package com.aa.amps.cwlv.cwlgrid.laa;

import com.aa.amps.cwlv.cwlgrid.CwlRestClientService;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetailComparotor;
import com.aa.amps.cwlv.model.AircraftRoutingInfo;
import com.aa.amps.cwlv.model.Flight;
import com.aa.amps.cwlv.timetogo.TimeCycleDaysService;
import com.aa.amps.cwlv.timetogo.TtgCriteria;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.DateUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

/**
 * This is a Business class to get LAA Combined Task details with RoutingCacheData and TimeCycle calculation.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Service
public class LAATaskService {

    private static final Logger LOGGER = LoggerFactory.getLogger(LAATaskService.class);

    private LAATaskRepository laaTaskRepo;
    private CwlRestClientService restClientSvc;
    private TimeCycleDaysService timeCycleDaysService;

    private Map<String, AircraftRoutingInfo> routingCacheMap;

    public LAATaskService(LAATaskRepository laaTaskRepo, CwlRestClientService restClientSvc, TimeCycleDaysService timeCycleDaysService) {
        this.laaTaskRepo = laaTaskRepo;
        this.restClientSvc = restClientSvc;
        this.timeCycleDaysService = timeCycleDaysService;
    }

    /**
     * This is the only public method to get the Combined Task details for LAA with searchCriteria. It goes over
     * multiple steps to completely populate the task details as described
     *
     * @param searchCriteria - Input Parameter map to get the data for.
     * @return initialized {@code List} of {@code CombinedTaskDetail}
     */
    public List<CombinedTaskDetail> getCombinedTasksDetails(Map<String, Object> searchCriteria) {

        /**
         * Step1: Pulling the data from the DB with searchCriteria.
         */
        List<CombinedTaskDetail> cmTaskDetails = laaTaskRepo.getCombinedTasksDetails(searchCriteria);
        LOGGER.info("Total cmbTaskDetails for LAA {}", cmTaskDetails.size());

        /**
         * Step2: Making a rest call to get the Aircraft Routing info from AMPS with list of aircraft numbers.
         */
        routingCacheMap = restClientSvc.getRoutingsFromAmps(getAircraftNbrs(cmTaskDetails), searchCriteria);

        /**
         * Step3: populating the LAA combinedtaskDetials with Routing Info from AMPS Cache.
         */
        List<CombinedTaskDetail> cmTaskDetailsWithRoutings = populateRoutingsFromCache(cmTaskDetails);

        /**
         * Step3.1: Remove the throughFlight/Inconsistent records from the combinedTaskDetail list.
         */
        cmTaskDetailsWithRoutings.removeIf(c -> c.getRodRon().equalsIgnoreCase(Constants.ROD) &&
                (c.isThroughFlight() || c.isInconsistentRecord()));

        /**
         * Step4: populate the LAA combinedTaskDetails with calculated TimeCycleDays value.
         */
        populateTWD(cmTaskDetailsWithRoutings);

        /**
         * Step5: sort the collection with ascending AircftNbrs. this may need for those scenario's where we some new
         * CombinedTaskDetails are added.
         */
        Collections.sort(cmTaskDetailsWithRoutings, new CombinedTaskDetailComparotor());

        return cmTaskDetailsWithRoutings;
    }

    /**
     * Helper method to populate the combinedTaskDetail object with routings information from cache.
     *
     * @param cmTaskDetails list of CombinedTaskDetails from DB.
     * @return list of CombinedTaskDetails with Routing info
     */
    private List<CombinedTaskDetail> populateRoutingsFromCache(List<CombinedTaskDetail> cmTaskDetails) {
        if (!CollectionUtils.isEmpty(cmTaskDetails)) {
            List<CombinedTaskDetail> newCMTaskDetailsForROD = new ArrayList<>();
            // here its processing the ROD's and then RON's
            cmTaskDetails.stream()
                    .filter(c -> c.getRodRon().equalsIgnoreCase(Constants.ROD))
                    .forEach(c ->
                            newCMTaskDetailsForROD.addAll(getCMTaskDetailsForRODRON(c)));

            cmTaskDetails.stream()
                    .filter(c -> c.getRodRon().equalsIgnoreCase(Constants.RON))
                    .forEach(c ->
                            newCMTaskDetailsForROD.addAll(getCMTaskDetailsForRODRON(c)));

            if (!CollectionUtils.isEmpty(newCMTaskDetailsForROD)) {
                cmTaskDetails.addAll(newCMTaskDetailsForROD);
            }

            LOGGER.info("Total newCMTaskList for LAA {}", cmTaskDetails.size());
        }

        return cmTaskDetails;
    }

    /**
     * Helper method to populate the combinedTaskDetail object with calculated TimecycleDays value.
     *
     * @param cmTaskDetailsWithRoutings list of combinedTaskDetails with routing info, needed for calculating TWD.
     */
    private void populateTWD(List<CombinedTaskDetail> cmTaskDetailsWithRoutings) {

        for (CombinedTaskDetail combinedTaskDetail : cmTaskDetailsWithRoutings) {
            final AircraftRoutingInfo routingsFromCache = this.routingCacheMap.get(combinedTaskDetail.getAircftNbr());
            if (null != routingsFromCache) {
                for (Flight flight : routingsFromCache.getFlights()) {
                    setTimeCycleFromFlight(combinedTaskDetail, flight);
                }

                // scenario when flight available, then we will calculate timeCycle from DB values and record is still
                // valid
                if (combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.RON) &&
                    StringUtils.isEmpty(combinedTaskDetail.getTimeCycle()) &&
                    !CollectionUtils.isEmpty(routingsFromCache.getFlights())) {

                    combinedTaskDetail.setTimeCycle(getTimeCycle(combinedTaskDetail, null, false));
                }

                // scenario when no flight available, then we will calculate timeCycle from DB values & set record as
                // invalid.
                if (combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.RON) &&
                    StringUtils.isEmpty(combinedTaskDetail.getTimeCycle()) &&
                    CollectionUtils.isEmpty(routingsFromCache.getFlights())) {
                    combinedTaskDetail.setTimeCycle(getTimeCycle(combinedTaskDetail, null, false));
                }
            }

            if (combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.ROD) &&
                StringUtils.isEmpty(combinedTaskDetail.getFlightNbr())) {
                combinedTaskDetail.setInvalidRecord(true);
            }
        }
    }

    /**
     * Helper method to determine the matched flight leg for RON/ROD.
     *
     * @param combinedTaskDetail
     * @param flight
     */
    private void setTimeCycleFromFlight(CombinedTaskDetail combinedTaskDetail, Flight flight) {
        if (DateUtil.getDateFromString(DateUtil.getTerminationDate(flight.getArrivalDate(), flight
                .getArrivalTime()), DateUtil.JMOCA_Date_Format).equals
                (DateUtil.getDateFromString(combinedTaskDetail.getSchdDt(), DateUtil.Basic_Date_Format)) &&
                flight.getArrivalCity().equalsIgnoreCase(combinedTaskDetail.getStnCd())) {

            if (combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.RON)) {
                if (flight.isTerminator()) {
                    combinedTaskDetail.setTimeCycle(getTimeCycle(combinedTaskDetail, flight, true));
                }
            } else { // ROD
                if (!flight.isTerminator() &&
                        flight.getFlightNumber().equalsIgnoreCase(combinedTaskDetail.getFlightNbr())) {
                    combinedTaskDetail.setTimeCycle(getTimeCycle(combinedTaskDetail, flight, true));
                } else {
                    combinedTaskDetail.setTimeCycle(getTimeCycle(combinedTaskDetail, null, false));
                }
            }
        }
    }

    /**
     * Helper method to get TWD value from {@link TimeCycleDaysService} based on routing found.
     *
     * @param combinedTaskDetail - To set the timeCycle value for this object.
     * @param flight             - if no matching leg is found then this parameter is null.
     * @param isRouting          - If routing is found then isRouting is true else false. if false, shiptime/shipcycles need to
     *                           take from the aircraft table.
     * @return TWD string value from {@link TimeCycleDaysService}
     */
    private String getTimeCycle(CombinedTaskDetail combinedTaskDetail, Flight flight, boolean isRouting) {
        TtgCriteria timeToGoCriteria = new TtgCriteria();

        if (null != combinedTaskDetail.getAircftMntncHours()) {
            timeToGoCriteria.setDueTime((long) (Double.parseDouble(combinedTaskDetail.getAircftMntncHours())));
        } else {
            timeToGoCriteria.setDueTime(null);
        }

        if (null != combinedTaskDetail.getAircftMntncDays()) {
            timeToGoCriteria.setDueDate(DateUtil.getDateFromString(combinedTaskDetail.getAircftMntncDays(), DateUtil.Basic_Date_Format));
        } else {
            timeToGoCriteria.setDueDate(null);
        }

        if (null != combinedTaskDetail.getAircftMntncCycle()) {
            timeToGoCriteria.setDueCycles((long) Double.parseDouble(combinedTaskDetail.getAircftMntncCycle()));
        } else {
            timeToGoCriteria.setDueCycles(null);
        }

        if (isRouting) {
            timeToGoCriteria.setShipCycles(flight.getTotalShipCycles());
            timeToGoCriteria.setShipTime(flight.getTotalShipTime() / 60);
        } else {
            timeToGoCriteria.setShipCycles((long) Double.parseDouble(combinedTaskDetail.getAircftShipCycles()));
            timeToGoCriteria.setShipTime((long) Double.parseDouble(combinedTaskDetail.getAircftShipTime()));
        }

        timeToGoCriteria.setAvgHoursPerDay(Double.parseDouble(combinedTaskDetail.getAvgHoursPerDay()));
        timeToGoCriteria.setAvgCyclesPerDay(Double.parseDouble(combinedTaskDetail.getAvgCyclesPerDay()));
        timeToGoCriteria.setSchdDate(DateUtil.getDateFromString(combinedTaskDetail.getSchdDt(), DateUtil.Basic_Date_Format));
        return this.timeCycleDaysService.calculateTWD(timeToGoCriteria);
    }

    /**
     * Helper method to populate the flight leg information for ROD/RON
     *
     * @param combinedTaskDetail - to populate the flight leg information for this object.
     * @return - return a {@code List} of {@code CombinedTaskDetail} if multiple flight legs found for the same
     * aircraft.
     */
    private List<CombinedTaskDetail> getCMTaskDetailsForRODRON(CombinedTaskDetail combinedTaskDetail) {
        List<CombinedTaskDetail> cmTaskDetailsForROD = new ArrayList<>();
        List<Flight> rodronFlights = filterCMTaskDetailForRODRON(combinedTaskDetail);
        boolean firstFlightInList = true;

        for (Flight flight : rodronFlights) {
            if (firstFlightInList) {
                LOGGER.trace("Adding flight details for aircarft {} & flightNbr {}", combinedTaskDetail.getAircftNbr(),
                        flight.getFlightNumber());
                combinedTaskDetail.setFlightNbr(flight.getFlightNumber());
                combinedTaskDetail.setEtd(flight.getDepartureDate());
                combinedTaskDetail.setEta(flight.getArrivalDate());
                combinedTaskDetail.setGroundTime(DateUtil.convertMinutesToHHMM(flight.getJmocaGroundTime()));
                firstFlightInList = false;

            } else {
                LOGGER.trace("Multiple flight details for aircarft {} & flightNbr {}", combinedTaskDetail.getAircftNbr(),
                        flight.getFlightNumber());
                CombinedTaskDetail newCombinedTaskDetail = combinedTaskDetail;
                newCombinedTaskDetail.setFlightNbr(flight.getFlightNumber());
                newCombinedTaskDetail.setEtd(flight.getDepartureDate());
                newCombinedTaskDetail.setEta(flight.getArrivalDate());
                newCombinedTaskDetail.setGroundTime(DateUtil.convertMinutesToHHMM(flight.getJmocaGroundTime()));
                cmTaskDetailsForROD.add(newCombinedTaskDetail);
            }
        }
        return cmTaskDetailsForROD;
    }

    /**
     * Helper method to eliminating through-flights from ROD's and find the matched flight legs for ROD/RON.
     *
     * @param combinedTaskDetail - to determine the matched flight leg in ROD/RON for this object.
     * @return - {@code List} of {@code Flight}
     */
    private List<Flight> filterCMTaskDetailForRODRON(CombinedTaskDetail combinedTaskDetail) {
        List<Flight> filteredFlightsforRODRON = new ArrayList<>();
        final AircraftRoutingInfo routingsFromCache = this.routingCacheMap.get(combinedTaskDetail.getAircftNbr());
        if (null != routingsFromCache) {

            for (Flight flight : routingsFromCache.getFlights()) {
                filterMatchedFlightLegsForRODRON(combinedTaskDetail, filteredFlightsforRODRON, flight);
            }

            if (CollectionUtils.isEmpty(filteredFlightsforRODRON) &&
                    combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.ROD) &&
                    !combinedTaskDetail.isThroughFlight() && !combinedTaskDetail.isInvalidRecord()) {
                LOGGER.debug("Inconsistent Record {}", combinedTaskDetail.toString());
                combinedTaskDetail.setInconsistentRecord(true);
            }

            if (CollectionUtils.isEmpty(filteredFlightsforRODRON) &&
                    combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.RON)) {
                LOGGER.debug("Invalid RON Record {}", combinedTaskDetail.toString());
                combinedTaskDetail.setFlightNbr(null);
                combinedTaskDetail.setInvalidRecord(true);
            }

        } else {
            //do Nothing..
        }

        return filteredFlightsforRODRON;
    }

    /**
     * Helper method to matched Flight legs & eliminate thru-flights ROD's and find the matched flight legs for
     * ROD/RON.
     *
     * @param combinedTaskDetail
     * @param filteredFlightsforRODRON - add to the list of matched flight legs.
     * @param flight
     */
    private void filterMatchedFlightLegsForRODRON(CombinedTaskDetail combinedTaskDetail, List<Flight> filteredFlightsforRODRON, Flight flight) {
        if (combinedTaskDetail.getRodRon().equalsIgnoreCase(Constants.ROD)) {

            if (flight.getArrivalCity().equalsIgnoreCase(combinedTaskDetail.getStnCd()) &&
                    DateUtil.getDateFromString(DateUtil.getTerminationDate(flight.getArrivalDate(),
                            flight.getArrivalTime()), DateUtil.JMOCA_Date_Format).equals
                            (DateUtil.getDateFromString(combinedTaskDetail.getSchdDt(), DateUtil.Basic_Date_Format))) {

                if (flight.getFlightNumber().equalsIgnoreCase(combinedTaskDetail.getFlightNbr())) {
                    if (isGroundTimeGreaterEqualto6Hours(DateUtil.convertMinutesToHHMM(flight.getJmocaGroundTime()))) {
                        filteredFlightsforRODRON.add(flight);
                    } else {
                        combinedTaskDetail.setThroughFlight(true);
                    }
                } else {
                    combinedTaskDetail.setInvalidRecord(true);
                }
            }
        } else { // this is for RON's
            if (flight.getArrivalCity().equalsIgnoreCase(combinedTaskDetail.getStnCd()) &&
                    DateUtil.getDateFromString(DateUtil.getTerminationDate(flight.getArrivalDate(),
                            flight.getArrivalTime()), DateUtil.JMOCA_Date_Format).equals
                            (DateUtil.getDateFromString(combinedTaskDetail.getSchdDt(), DateUtil.Basic_Date_Format)) &&
                    flight.isTerminator()) {

                filteredFlightsforRODRON.add(flight);
            }
        }
    }

    /**
     * Helper method to determine the Groundtime is greater or equal to 6 hours.
     *
     * @param groundTime - from the flight leg data.
     * @return true if groundtime is >= 6 else false
     */
    private boolean isGroundTimeGreaterEqualto6Hours(String groundTime) {
        boolean condition = false;
        if (StringUtils.isNotEmpty(groundTime)) {
            String[] time = groundTime.split(":");
            if (Integer.parseInt(time[0]) >= 6) {
                condition = true;
            }
        }
        return condition;
    }

    /**
     * Helper method to get the {@code Set} of aircraft numbers from the CombinedTaskDetails list
     *
     * @param cmTaskList - CombinedTaskDetails list from LAA DB query.
     * @return {@code List} of aircraft numbers.
     */
    private List<String> getAircraftNbrs(List<CombinedTaskDetail> cmTaskList) {
        Set<String> aircrafts = cmTaskList.stream().map(CombinedTaskDetail::getAircftNbr).collect(Collectors.toSet());
        return new ArrayList(aircrafts);
    }
}
