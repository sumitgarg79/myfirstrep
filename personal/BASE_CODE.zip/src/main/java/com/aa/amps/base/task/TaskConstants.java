package com.aa.amps.base.task;

import java.util.Arrays;
import java.util.List;

/**
 * This class holds all Repository related constants.
 *
 * @author 922166
 * @since 07/18/2018
 */

public class TaskConstants {

    public static final String AD = "ad";
    public static final String DNI = "dni";
    public static final String AD_DNI = "ad_dni";
    public static final String WORK_PACKAGE_ID = "workPkgId";
    public static final String AIRCRAFT_NUMBER = "aircraftNbr";
    public static final String USER_ID = "userId";
    public static final String TASK_ID = "taskId";
    public static final String ROUTE_CONTROL_CODE = "routeControlCode";
    public static final String DEFERRAL_LOCK_INDICATOR = "deferralLockInd";
    public static final String WORK_PACKAGE_TASK_STATUS = "wrkPkgTaskStatus";
    public static final String PKG_SCHD_DATE = "pkgSchdDt";
    public static final String STATION_CODE = "planStationCd";
    public static final String TRACK_TYPE_CODE = "trackTypeCd";
    public static final String SPAN = "span";
    public static final String WORK_ORDER_JOB_CODE = "workOrderJobCd";
    public static final String SCEPTRE_MNTNC_WORK_PKG_ID = "sceptreMntncWorkPkgId";
    public static final String DOCK_CODE = "dockCd";
    public static final String WORK_PKG_TXT = "workPkgTxt";
    public static final String WORK_PKG_STATUS_CODE = "workPkgStatusCd";
    public static final String DELETED = "DELETED";
    public static final String DRAFT_WORK_PKG_ID_DB = "DRAFT_WORK_PKG_ID";
    public static final String WORK_PKG_ID_DB = "WORK_PKG_ID";
    public static final String AIRCFT_MNTNC_TASK_ID_DB = "AIRCFT_MNTNC_TASK_ID";
    public static final String DRAFT_WORK_PKG_STATUS_CD = "DRAFT_WORK_PKG_STATUS_CD";
    public static final String T_STRING = "T";
    public static final String F_STRING = "F";

    public static final String ROUTE_CNTRL_TYPE_CD_DB = "ROUTE_CNTRL_TYPE_CD";
    public static final String MNTNC_DFRL_LOCK_IND_DB = "MNTNC_DFRL_LOCK_IND";
    public static final String AIRCFT_NBR_DB = "AIRCFT_NBR";
    public static final String MNTNC_TASK_DO_NOT_ISSUE_IND_DB = "MNTNC_TASK_DO_NOT_ISSUE_IND";
    public static final String COMMENTS = "comments";

    /**
     * These are TaskFilterRequest related constants.
     */
    public static final String AIRCRAFT_NO = "aircraftNo";
    public static final String ITEMS_WITH = "itemsWith";
    public static final String TASKNAME_OR_DESC = "taskNameOrDesc";
    public static final String TASK_TYPES = "taskTypes";
    public static final String SOFT_TIME = "softTimes";
    public static final String NO_FORECAST = "noForecast";
    public static final String FORECAST = "forecast";
    public static final String FORECAST_FROMDATE = "ForecastFromDate";
    public static final String FORECAST_TODATE = "ForecastToDate";
    public static final String STATIONS = "stations";

    /**
     * These are TaskDetailRequest related constants.
     */
    public static final String AIRCRAFT_NBRS = "aircraftNbrs";
    public static final String TASK_IDS = "taskIDs";

    /**
     * WCJO field with SCEPTRE fleetCode + "10323"
     */
    public static final String WORK_CODE_JOB_ORDER_LAST_FIVE_CHARACTERS = "10323";

    public static final String HIGH_TIME = "HIGHTIME";
    public static final String OVER_TIME = "OVERTIME";

    public static final String USER_MERGE_ACTION = "MERGE";
    public static final String USER_OVERRIDE_ACTION = "OVERRIDE";
    public static final String USER_EDIT_ACTION = "EDIT";

    public static final String BOW_TYPE_LINE = "LINE";
    public static final String BOW_TYPE_BASE = "BASE";
    public static final String WORK_PACKAGE_EXIST = "Draft already exist for ";
    public static final String WORK_PACKAGE_NOT_SAVED = "Draft is not saved for ";
    public static final String WORK_PACKAGE_NOT_DELETE = "Draft is not deleted for ";
    public static final List<String> LINE_TRACK_TYPES
            = Arrays.asList("01", "04", "05", "06", "07", "08", "09", "02", "98", "99", "1000");
    public static final List<String> BASE_TRACK_TYPES
            = Arrays.asList("03", "10", "11", "12", "100");

    public static final String ME8 = "ME8";
    public static final String ME8_HYPHEN = "ME8-";
    public static final String ME8_MON = "ME8-MON";
    public static final List<String> ME8_MON_KEYWORDS = Arrays.asList("MON");
    public static final String ME8_TC = "ME8-TC";
    public static final List<String> ME8_TC_KEYWORDS = Arrays.asList("REP", "INT");
    public static final String ME8_EO = "ME8-EO";
    public static final List<String> ME8_EO_KEYWORDS = Arrays.asList("INS", "MOD");
    public static final String ME8_CKC = "ME8-CKC";
    public static final List<String> ME8_CKC_KEYWORDS = Arrays.asList("CKC");
    public static final String ME8_DNS = "ME8-DNS";
    public static final List<String> ME8_DNS_KEYWORDS = Arrays.asList("DNS");

    public static final String FINALIZED = "FINALIZED";

    private TaskConstants() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * This method to return string "T" or "F" for softtime indicator true/false respectively.
     *
     * @param softTime indicator with string value as true is expected
     * @return softtime indicator with string value as "T" or "F" is expected.
     */
    public static String getSoftTimeIndicator(String softTime) {
        return Boolean.valueOf(softTime) ? T_STRING : F_STRING;
    }
}
