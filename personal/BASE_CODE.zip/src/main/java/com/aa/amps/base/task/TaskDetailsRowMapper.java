package com.aa.amps.base.task;

import com.aa.amps.cwlv.util.DateUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link TaskEntity}.
 *
 * @author HCL(292147)
 * @since 7/23/2018.
 */
public class TaskDetailsRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        TaskEntity taskEntity = new TaskEntity();
        taskEntity.setAircraftNbr(rs.getString("AIRCFT_NBR"));
        taskEntity.setTaskId(rs.getString("AIRCFT_MNTNC_TASK_ID"));
        taskEntity.setDueDate(rs.getDate("MNTNC_TASK_DUE_DT"));
        taskEntity.setForecastDateAsString(DateUtil.getFormattedDateStr(rs.getString("MNTNC_TASK_DUE_DT")));
        taskEntity.setCreateDate(rs.getDate("AMPS_ROW_CREATE_TMS"));
        taskEntity.setTaskDetailText(rs.getString("MNTNC_TASK_DETL_TXT"));
        taskEntity.setPlannedDateAsString(DateUtil.getFormattedDateStr(rs.getString("MNTNC_WORK_PKG_SCHD_DT")));
        taskEntity.setPlannedStation(rs.getString("PLAN_MNTNC_STN_CD"));
        taskEntity.setTrackNbr(rs.getString("WORK_PKG_TRACK_TYPE_DESC"));

        return taskEntity;
    }

}