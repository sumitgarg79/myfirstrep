package com.aa.amps.base.tracktype;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * This is the <i>Business Logic</i> class to load the track types.
 * <b>All</b> the functionality associated with Work Package Track Type data load <b><i>must</i></b> be defined here.
 *
 * @author HCL(292147)
 * Created on 5/24/2018.
 */

@Service
@Transactional
public class TrackTypeService {
    private TrackTypeRepository trackTypeRepository;

    public TrackTypeService(TrackTypeRepository trackTypeRepository) {
        this.trackTypeRepository = trackTypeRepository;
    }

    /**
     * Fetches Base work package track type.
     *
     * @return {@code List} of base track type records
     */
    @Transactional(readOnly = true)
    public List<TrackTypeEntity> getBaseTrackTypes() {
        return trackTypeRepository.getBaseTrackTypes();
    }
}
