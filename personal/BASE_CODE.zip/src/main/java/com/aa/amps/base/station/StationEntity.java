package com.aa.amps.base.station;

import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * Entity that represents the AMPSFCST_MNTNC_STN table in the DB.
 *
 * @author HCL(922166)
 * @since 5/18/2018.
 */
@Repository
@Data
public class StationEntity {

    /**
     * The active maintenance station code for line
     */
    private String mntncStnCd;

    /**
     * The active maintenance station type code which tell if its a heavy(base) station or line station
     */
    private String mntncStnTypCd;

    /**
     * The active maintenance station code for Base
     */
    private String mntncStnAliasCd;
}
