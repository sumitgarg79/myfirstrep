package com.aa.amps.ampsui.masterdata;

import com.aa.amps.ampsui.restclients.*;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service class with functionality related to Master Data ,i.e., Fleet, Subfleet and aircraft data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Service
public class MasterDataService {
    private static final Logger LOG = LoggerFactory.getLogger(MasterDataService.class);

    private static final String STATION_TYPE_LINE = "L";

    private FleetClientService fleetClientService;
    private AircraftClientService aircraftClientService;
    private StationClientService stationClientService;

    public MasterDataService(FleetClientService fleetClientService, AircraftClientService aircraftClientService,
            StationClientService stationClientService) {
        this.fleetClientService = fleetClientService;
        this.aircraftClientService = aircraftClientService;
        this.stationClientService = stationClientService;
    }

    /**
     * Fetches the master data by calling 3 services - Fleet, Aircraft and Station.
     *
     * @param airlineCode airline code - LAA or LUS
     * @return master data that contains fleet, subfleet, aircraft and stations in a structured way
     */
    public MasterDataResponse getMasterData(String airlineCode) {
        MasterDataResponse response = new MasterDataResponse();

        if (StringUtils.isBlank(airlineCode)) {
            setMasterDataForAll(response);

        } else {
            setMasterDataForAirlineCode(response, airlineCode);
        }

        StationResponseEntity stations = stationClientService.getLineMaintenanceStations();
        MasterDataResponse.setMasterDataResponseWithStations(response, stations, STATION_TYPE_LINE);

        LOG.debug("getMasterData() - The response being returned - {}", response);

        return response;
    }

    private void setMasterDataForAll(MasterDataResponse response) {
        List<FleetResponseEntity> fleets = fleetClientService.getAllFleets();
        MasterDataResponse.setMasterDataResponseWithFleet(response, fleets);

        List<AircraftResponseEntity> aircraft = aircraftClientService.getAllAircraft();
        MasterDataResponse.setMasterDataResponseWithAircraft(response, aircraft);
    }

    private void setMasterDataForAirlineCode(MasterDataResponse response, String airlineCode) {
        List<FleetResponseEntity> fleets = fleetClientService.getFleets(airlineCode);
        MasterDataResponse.setMasterDataResponseWithFleet(response, fleets);

        List<AircraftResponseEntity> aircraft = aircraftClientService.getAircraft(airlineCode);
        MasterDataResponse.setMasterDataResponseWithAircraft(response, aircraft);
    }
}
