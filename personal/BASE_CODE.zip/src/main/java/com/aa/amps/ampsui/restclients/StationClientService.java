package com.aa.amps.ampsui.restclients;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Service class with functionality to fetch stations data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/9/2019
 */
@Service
public class StationClientService {
    private static final Logger LOG = LoggerFactory.getLogger(StationClientService.class);

    private static final String STATION_TYPE_QUERY_PARAM = "stationType";
    private static final String LINE_STATION = "line";
    RestTemplate restTemplate;
    @Value("${ampsui.station.api.url}")
    private String stationUrl;

    public StationClientService() {
        this.restTemplate = new RestTemplate();
    }

    /**
     * Fetches the line maintenance stations by making a REST API call.
     *
     * @return line station details
     */
    public StationResponseEntity getLineMaintenanceStations() {
        StationResponseEntity stationResponseEntity = null;

        String stationUrlWithQueryParam = stationUrl + "?" + STATION_TYPE_QUERY_PARAM + "=" + LINE_STATION;

        ResponseEntity<StationResponseEntity> responseEntity = restTemplate
                .exchange(stationUrlWithQueryParam, HttpMethod.GET, null,
                          new ParameterizedTypeReference<StationResponseEntity>() {
                          });

        if (responseEntity.getBody() != null) {
            stationResponseEntity = responseEntity.getBody();

        } else {
            stationResponseEntity = new StationResponseEntity();
        }

        LOG.debug("getLineMaintenanceStations() - Got response for line stations - {}", stationResponseEntity);

        return stationResponseEntity;
    }

    /**
     * Getter for the ResTemplate.
     *
     * @return RestTemplate instance of this class
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }
}
