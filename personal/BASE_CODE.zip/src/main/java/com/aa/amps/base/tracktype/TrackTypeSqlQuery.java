package com.aa.amps.base.tracktype;

/**
 * Query constant for the {@link TrackTypeRepository} class.
 *
 * @author HCL(922166)
 * Created on 5/21/2018.
 */
public class TrackTypeSqlQuery {

    /**
     * Private default constructor to prevent any instantiation.
     */
    private TrackTypeSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    /**
     * Query to get Base track types from database
     */
    public static final String SELECT_BASE_WORK_PKG_TRACK_TYPE =
            "SELECT WORK_PKG_TRACK_TYPE_CD , " +
                    "WORK_PKG_TRACK_TYPE_DESC , " +
                    "MENU_DISPLY_IND , " +
                    "BASE_WP_TRACK_TYPE_DESC " +
                    "FROM WORK_PKG_TRACK_TYPE " +
                    "WHERE BASE_WP_TRACK_TYPE_DESC like ('%BASE%')" +
                    "ORDER BY WORK_PKG_TRACK_TYPE_CD";
}
