package com.aa.amps.cwlv.util;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateTimeUtil {

    public static final String Basic_Date_Format = "yyyy-MM-dd";
    private static final int DAYS_IN_LEAP_YEAR = 366;
    private static final int DAYS_IN_YEAR = 365;

    private DateTimeUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static java.sql.Date getCurrentDay() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Basic_Date_Format);
        return java.sql.Date.valueOf(dateFormat.format(calendar.getTime()));
    }

    /**
     * To get the date difference between two time stamp
     *
     * @param firstTimestamp
     * @param secondTimestamp
     * @return A long represented value for diff of 2 timestamps.
     */
    public static Long getDifferenceInDays(Timestamp firstTimestamp, Timestamp secondTimestamp) {
        int factor = 1;
        if (secondTimestamp.getTime() > firstTimestamp.getTime()) {
            factor = -1;
            Timestamp c = firstTimestamp;
            firstTimestamp = secondTimestamp;
            secondTimestamp = c;
        }
        Calendar ca = Calendar.getInstance();
        ca.setTimeInMillis(firstTimestamp.getTime());
        Calendar cb = Calendar.getInstance();
        cb.setTimeInMillis(secondTimestamp.getTime());
        int aDayOfYear = ca.get(Calendar.DAY_OF_YEAR);
        int bDayOfYear = cb.get(Calendar.DAY_OF_YEAR);
        int aYear = ca.get(Calendar.YEAR);
        int bYear = cb.get(Calendar.YEAR);
        int diffDays = 0;
        for (int i = bYear; i < aYear; i++) {
            if (isLeapYear(i))
                diffDays += DAYS_IN_LEAP_YEAR;
            else
                diffDays += DAYS_IN_YEAR;
        }
        return new Long(factor * (diffDays + aDayOfYear - bDayOfYear));
    }

    /**
     * US238217 - New method to check if it's leap year
     *
     * @param year
     * @return
     */
    public static boolean isLeapYear(int year) {
        return (year % 100 == 0 && year % 400 == 0) || (year % 100 != 0 && year % 4 == 0);
    }

    /**
     * @param days
     * @return date +/ days.
     */
    public static java.sql.Date getRolledDate(java.sql.Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(java.sql.Date.valueOf(date.toString()));
        cal.add(Calendar.DATE, days);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * To two decimal pt format.
     *
     * @param number - could be null
     * @return null if it is null else trimmed to two digit double value
     */
    public static Double toTwoDecimalPtFormat(Number number) {
        return number == null ? null : Double.parseDouble(Constants.TWO_DECIMAL_PT_FORMAT.format(number));
    }
}
