package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.model.AircraftRoutingInfo;
import com.aa.amps.cwlv.util.Constants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by Neelabh Tripathi(847697) on 3/9/2018.
 */
@Component
public class CwlRestClientService {

    private static final Logger log = LoggerFactory.getLogger(CwlRestClientService.class);

    @Value("${aircraft.routing.api}")
    private String aircftRoutingAPI;

    /**
     * This public method is exposed to fetch LOF flight leg routing from AMPS cache.
     *
     * @param aircraftNbrList - {@code  List} of aircraftNumbers
     * @param searchCriteria
     * @return Map with aircraftNbr as key and AircraftRoutingInfo object as value.
     */
    public Map<String, AircraftRoutingInfo> getRoutingsFromAmps(List<String> aircraftNbrList, Map<String, Object> searchCriteria) {
        Map<String, AircraftRoutingInfo> routingInfoMap = Collections.emptyMap();
        if (!CollectionUtils.isEmpty(aircraftNbrList)) {
            routingInfoMap = getLOFLegsFromCache(aircraftNbrList, searchCriteria);
        }

        return routingInfoMap;
    }

    /**
     * This helper method is to make a rest call to AMPS to get Lof Flight leg cache data.
     *
     * @param aircrafts - {@code  List} of aircraftNumbers
     * @return - {@code Map} with aircraftNbr as key and {@Code AircraftRoutingInfo} as value.
     */
    private Map<String, AircraftRoutingInfo> getLOFLegsFromCache(List<String> aircrafts, Map<String, Object> searchCriteria) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        log.debug("Getting LOF legs data from AMPS cache for following aircrafts - {}", aircrafts);

        if (searchCriteria.containsKey(Constants.SMSESSION)) {
            log.debug("SMSESSION Cookie {}", searchCriteria.get(Constants.SMSESSION).toString());
            headers.add("Cookie", "SMSESSION=" + searchCriteria.get(Constants.SMSESSION).toString());
        }

        HttpEntity<List<String>> requestEntity = new HttpEntity<>(aircrafts, headers);
        ResponseEntity<Map<String, AircraftRoutingInfo>> routingsFromCache = restTemplate.
                exchange(aircftRoutingAPI, HttpMethod.POST,
                        requestEntity, new ParameterizedTypeReference<Map<String, AircraftRoutingInfo>>() {
                        });

        log.debug("Aircraft Routing from AMPS Cache size - {}", routingsFromCache.getBody().size());

        return routingsFromCache.getBody();
    }
}
