package com.aa.amps.cwlv.cwlgrid.lus;

import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


/**
 * This is a Business class to get LUS Combined Task details from DB.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Service
public class LUSTaskService {
    private static final Logger LOG = LoggerFactory.getLogger(LUSTaskService.class);

    private LUSTaskRepository lusTaskRepo;

    public LUSTaskService(LUSTaskRepository lusTaskRepo) {
        this.lusTaskRepo = lusTaskRepo;
    }

    /**
     * This public method to get the Combined Task details for LUS with searchCriteria.
     *
     * @param searchCriteria - Input Parameter map to get the data for.
     * @return {@code List} of {@code CombinedTaskDetail}
     */
    public List<CombinedTaskDetail> getCombinedTasksDetails(Map<String, Object> searchCriteria) {
        List<CombinedTaskDetail> laaTasks = lusTaskRepo.getCombinedTasksDetails(searchCriteria);
        LOG.debug("Total tasks for LUS {}", laaTasks.size());

        return laaTasks;
    }

}
