package com.aa.amps.base.exception;

/**
 * This class to define all Exceptions related to TaskFilterRequest.
 *
 * @author Naseer Mohammed (842018)
 * @since 07/19/2018
 */
public class TaskFilterRequestException extends BaseServiceException {

    public static final String FORECAST_TO_DATE_MISSING = "ForecastToDate is required.";

    public TaskFilterRequestException(String message, String statusCode) {
        super(message, statusCode);
    }
}
