package com.aa.amps.cwlv.accessControl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;


/**
 * This is the Repository class of Access Control
 * It provides the interfaces for CRUD operations
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */

@Repository
public class AccessControlRepository {

    @Value("${access.control.files}")
    private String accessControlFilesLoc;

    /**
     * This method is to get the list of the applications on base of Role as string of JSON.
     * Will read the file from /resources/accessControl/
     *
     * @param roleId Role ID
     * @return applications list as JSON string
     * @throws Exception In case of File not found
     */
    public String getAppList(int roleId) throws Exception {
        String path = accessControlFilesLoc + roleId + ".json";
        return getContent(path);
    }

    /**
     * This method is to get the access control of Role for the application selected.
     * Will read the file from /resources/accessControl/
     *
     * @param roleId  Role Id
     * @param appName Application Name
     * @return applications list as JSON string
     * @throws Exception In case of File not found
     */
    public String getRoleAccess(int roleId, String appName) throws Exception {
        String path = accessControlFilesLoc + roleId + "_" + appName + ".json";
        return getContent(path);
    }

    /**
     * This method will read the content from the file (access control for User Role) of given path for
     * getAppList and getRoleAccess method's and will return the content as String.
     *
     * @param path From where file has to be read
     * @return String Content of the file which defined the access control of user
     * @throws Exception in case file not found
     */
    private String getContent(String path) throws Exception {
        StringBuilder fileContent = new StringBuilder();
        ClassLoader classLoader = getClass().getClassLoader();
        InputStream contentStream = classLoader.getResourceAsStream(path);

        //If condition as if contentStream is null that's mean file not found.
        if (null != contentStream) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(contentStream))) {
                String line;
                //In all the cases this file should return one JSON line
                while ((line = br.readLine()) != null) {
                    fileContent.append(line).append("\n");
                }
            }
        } else {
            throw new FileNotFoundException("File is not available for Role/Role_Application.");
        }

        return fileContent.toString();
    }
}
