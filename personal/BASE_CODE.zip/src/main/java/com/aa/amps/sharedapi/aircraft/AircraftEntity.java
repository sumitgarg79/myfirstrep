package com.aa.amps.sharedapi.aircraft;

import lombok.Data;

/**
 * Entity class for Aircraft. It holds all the properties that are needed for Aircraft API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/2/2019.
 */
@Data
public class AircraftEntity {
    private String aircraftNumber;
    private String fleet;
    private String subfleet;
    private String airlineCode;
    private String sceptreFleetCode;
}
