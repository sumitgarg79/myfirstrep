package com.aa.amps.cwlv.manHours;


import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link RodAndRonManHrsEntity}.
 *
 * @author Ramesh Rudra(842020)
 * @since 4/23/2018.
 */
public class LusRodAndRonManHrsMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        RodAndRonManHrsEntity rodAndRonManHrsEntity = new RodAndRonManHrsEntity();
        rodAndRonManHrsEntity.setPriorityCode(rs.getLong("MNTNC_TASK_PRIOR_TYPE_CD"));
        rodAndRonManHrsEntity.setStation(rs.getString("PLAN_MNTNC_STN_CD"));
        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(rs.getFloat("TOTALMANHRS"));

        return rodAndRonManHrsEntity;
    }
}
