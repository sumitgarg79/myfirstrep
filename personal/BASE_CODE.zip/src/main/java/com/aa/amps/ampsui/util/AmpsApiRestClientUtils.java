package com.aa.amps.ampsui.util;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * This Class contains common functionality related to RestClients.
 */
@Component
public class AmpsApiRestClientUtils {

    private static final Logger LOG = LoggerFactory.getLogger(AmpsApiRestClientUtils.class);

    /**
     * This methods provides HttpHeaders with SiteMinderSession
     *
     * @param smSession id siteminder cookie SMSESSION
     * @return HttpHeader with SiteMinderSession
     */
    public HttpHeaders getHeaderWithSession(String smSession) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        if (StringUtils.isNotBlank(smSession)) {
            LOG.debug("SMSESSION Cookie {}", smSession);
            headers.add("Cookie", "SMSESSION=" + smSession);
        }

        return headers;
    }


    /**
     * This Method converts java Map<String,Object> to JSON String
     *
     * @param searchCriteria
     * @return Json String.
     * @throws AmpsuiServiceException if there is any  error while conversion of object to json.
     */
    public String convertToJsonString(Map<String, Object> searchCriteria) throws AmpsuiServiceException {
        String jsonInString = null;

        ObjectMapper mapper = new ObjectMapper();
        try {
            jsonInString = mapper.writeValueAsString(searchCriteria);
        } catch (JsonProcessingException e) {
            LOG.error("error while Json Parsing", e);
            throw new AmpsuiServiceException(Constants.JSON_PARSING_ERROR, null);
        }
        return jsonInString;
    }


}
