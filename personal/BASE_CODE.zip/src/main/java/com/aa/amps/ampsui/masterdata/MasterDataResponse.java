package com.aa.amps.ampsui.masterdata;

import com.aa.amps.ampsui.restclients.AircraftResponseEntity;
import com.aa.amps.ampsui.restclients.FleetResponseEntity;
import com.aa.amps.ampsui.restclients.StationEntity;
import com.aa.amps.ampsui.restclients.StationResponseEntity;
import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This is the data class for the Master Data response. It contains functionality to create the object since it is a
 * complex data class.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Data
public class MasterDataResponse {
    private List<Fleet> fleet;
    private List<Station> station;

    /**
     * This method sets the {@code MasterDataResponse} object with the fleet and subfleet information.
     *
     * @param response    master data response object
     * @param fleetEntity fleet and subfleet data
     */
    public static void setMasterDataResponseWithFleet(MasterDataResponse response,
            List<FleetResponseEntity> fleetEntity) {
        List<Fleet> fleets = new ArrayList<>();

        if (CollectionUtils.isEmpty(fleets)) {
            if (CollectionUtils.isEmpty(response.getFleet())) {
                response.setFleet(new ArrayList<>());
            }


            for (FleetResponseEntity entity : fleetEntity) {
                Fleet fleet = new Fleet();

                fleet.setFleetCode(entity.getFleet());
                populateSubfleet(fleet, entity);
                response.getFleet().add(fleet);

            }
        }
    }

    /**
     * Sets the subfleet data into the {@code Fleet} object.
     *
     * @param fleet  fleet object
     * @param entity object containing the fleet and subfleet data
     */
    private static void populateSubfleet(Fleet fleet, FleetResponseEntity entity) {
        List<String> subfleetCodes = entity.getSubfleet();

        List<Subfleet> subfleets = new ArrayList<>();

        subfleetCodes.forEach(
                sf -> {
                    Subfleet sub = new Subfleet();
                    sub.setSubfleetCode(sf);

                    subfleets.add(sub);
                });

        fleet.setSubfleet(subfleets);
    }

    /**
     * Sets the {@code MasterDataResponse} object with the aircraft information - sorting and setting them inside their
     * respective subfleet.
     *
     * @param response         the master data response object
     * @param aircraftEntities a list containing aircraft information
     */
    public static void setMasterDataResponseWithAircraft(MasterDataResponse response,
            List<AircraftResponseEntity> aircraftEntities) {

        List<Fleet> fleets = response.getFleet();
        List<AircraftResponseEntity> allAircraftOfFleet = null;

        if (!CollectionUtils.isEmpty(aircraftEntities)) {
            //for each fleet get the list of aircraft that belongs to the specific fleet
            for (Fleet fleet : fleets) {
                allAircraftOfFleet = aircraftEntities.stream()
                        .filter(a -> a.getFleet().equalsIgnoreCase(fleet.getFleetCode()))
                        .collect(Collectors.toList());

                populateAircraftToSubfleet(fleet, allAircraftOfFleet);
            }
        }
    }

    /**
     * Method to set all the aircraft inside the fleet object, i.e., subfleets. Here is the object hierarchy - Fleet ->
     * (List of Subfleet) -> (List of aircraft).
     *
     * @param fleet              fleet to be set with aircraft data
     * @param allAircraftOfFleet list of aircraft belonging to the provided fleet
     */
    private static void populateAircraftToSubfleet(Fleet fleet, List<AircraftResponseEntity> allAircraftOfFleet) {
        //for each subfleet get the aircraft and add it to the subfleet object in the list
        for (Subfleet sub : fleet.getSubfleet()) {
            List<Aircraft> aircraftOfSubfleet = allAircraftOfFleet.stream()
                    .filter(a -> a.getSubfleet().equalsIgnoreCase(sub.getSubfleetCode()))
                    .map(a -> new Aircraft(a.getAircraftNumber()))
                    .collect(Collectors.toList());

            sub.setAircraft(aircraftOfSubfleet);
        }
    }

    /**
     * Sets the {@code MasterDataResponse} object with the station data.
     *
     * @param response              master data response object to be populated
     * @param stationResponseEntity entity containing station data
     * @param stationTypeCode       type of station - line or base
     */
    public static void setMasterDataResponseWithStations(MasterDataResponse response,
            StationResponseEntity stationResponseEntity, String stationTypeCode) {

        if ((stationResponseEntity != null) && (!CollectionUtils
                .isEmpty(stationResponseEntity.getStationEntityList()))) {
            List<StationEntity> stationEntities = stationResponseEntity.getStationEntityList();

            if (StringUtils.isNotBlank(stationTypeCode)) {

                List<Station> stations = stationEntities.stream()
                        .filter(s -> s.getMntncStnTypCd().equalsIgnoreCase(stationTypeCode))
                        .map(s -> new Station(s.getMntncStnCd()))
                        .collect(Collectors.toList());

                response.setStation(stations);

            } else {
                List<Station> stations = stationEntities.stream()
                        .map(s -> new Station(s.getMntncStnCd()))
                        .collect(Collectors.toList());

                response.setStation(stations);
            }
        }
    }
}
