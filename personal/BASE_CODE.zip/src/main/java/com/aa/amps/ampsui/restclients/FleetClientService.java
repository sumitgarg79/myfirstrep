package com.aa.amps.ampsui.restclients;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Service class with functionality to fetch Fleet data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Service
public class FleetClientService {
    private static final Logger LOG = LoggerFactory.getLogger(FleetClientService.class);

    @Value("${ampsui.fleet.api.url}")
    private String fleetUrl;

    private RestTemplate restTemplate;

    public FleetClientService() {
        this.restTemplate = new RestTemplate();
    }

    /**
     * Gets all the fleets from the Fleet API.
     *
     * @return list of fleets entity
     */
    public List<FleetResponseEntity> getAllFleets() {

        List<FleetResponseEntity> fleetResponseEntities = null;

        ResponseEntity<List<FleetResponseEntity>> responseEntity = restTemplate.
                exchange(fleetUrl, HttpMethod.GET, null, new ParameterizedTypeReference<List<FleetResponseEntity>>() {
                });

        if (responseEntity.getBody() != null) {
            fleetResponseEntities = responseEntity.getBody();
        } else {
            fleetResponseEntities = new ArrayList<>();
        }

        return fleetResponseEntities;
    }

    /**
     * Gets the fleet for the proviedd airline code.
     *
     * @param airlineCode LAA or LUS
     * @return list of fleets entity
     */
    public List<FleetResponseEntity> getFleets(String airlineCode) {
        List<FleetResponseEntity> fleetResponseEntities = null;

        if (StringUtils.isNotBlank(airlineCode)) {
            String aircraftUrlWithAirline = fleetUrl + "?airlineCd=" + airlineCode;

            ResponseEntity<List<FleetResponseEntity>> responseEntity = restTemplate
                    .exchange(aircraftUrlWithAirline, HttpMethod.GET, null,
                              new ParameterizedTypeReference<List<FleetResponseEntity>>() {
                              });

            if (responseEntity.getBody() != null) {
                fleetResponseEntities = responseEntity.getBody();
            } else {
                fleetResponseEntities = new ArrayList<>();
            }

            LOG.debug("getFleets() - Got response for airline code {} - {}", airlineCode, fleetResponseEntities);
        }

        return fleetResponseEntities;
    }

    /**
     * Getter. It is exposed explicitly to be used in the test class.
     *
     * @return RestTemplate instance
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }
}
