package com.aa.amps.base.preset;

import com.aa.amps.base.util.DateTimeUtil;
import com.aa.amps.base.util.UserIdUtil;
import lombok.Data;
import org.springframework.stereotype.Component;

import java.sql.Date;

/**
 * This class contains the properties required for preset that is received from UI.
 *
 * @author Naseer Mohammed(842018)
 * @since 08/06/2018.
 */
@Data
@Component
public class PresetRequest {

    private String userId;
    private int searchCriterId;
    private String searchCriterTxt;
    private String searchCriterCd;
    private String actlSelectTxt;
    private Date rowCreateTms;
    private Date rowUpdtTms;

    public Date getRowUpdtTms() {
        return DateTimeUtil.getCurrentDay();
    }

    /**
     * Remove first 2 characters of 8 character userId as per AMPS impl.
     * eg. 00842018 --> 842018, 00012345 --> 012345
     * @return last 6 characters of UserId
     */
    public String getUserId() {
        return UserIdUtil.shortenUserIdTo6Characters(this.userId);
    }
}
