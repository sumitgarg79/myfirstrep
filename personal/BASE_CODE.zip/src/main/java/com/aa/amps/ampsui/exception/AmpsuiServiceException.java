package com.aa.amps.ampsui.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * This Class is the base exception class which all other exception classes in base package extends.
 *
 * @author Neelabh Tripathi
 * @since 12/11/2018
 */
@Getter
@Setter
public class AmpsuiServiceException extends Exception {

    private final String statusCode;

    public AmpsuiServiceException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
