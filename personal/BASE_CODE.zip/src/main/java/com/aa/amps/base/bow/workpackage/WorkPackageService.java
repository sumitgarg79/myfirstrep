package com.aa.amps.base.bow.workpackage;


import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.WorkPackageEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;


/**
 * This is the <i>Business Logic</i> class for AMPS Base Task Service.
 *
 * @author Shyam Sundar Ashok (202571)
 * * @since 10/01/2018
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@Service
@Transactional
public class WorkPackageService {
    private static final Logger LOG = LoggerFactory.getLogger(WorkPackageService.class);

    private WorkPackageRepository workPackageRepository;

    public WorkPackageService(WorkPackageRepository workPackageRepository) {
        this.workPackageRepository = workPackageRepository;
    }

    /**
     * Fetches details of package/bow.
     *
     * @param workPkgId Parameter on which we have to search the package/bow
     * @return WorkPackageEntity object
     */
    public Optional<WorkPackageEntity> getBowDetail(Long workPkgId) throws
            BaseServiceException {
        WorkPackageEntity workPkgEntity = null;
        try {
            if (workPkgId != null) {
                workPkgEntity = workPackageRepository.getBowDetail(workPkgId);
            }
        } catch (Exception e) {
            LOG.error("Exception while retrieving BOW Details. ", e);
            throw new BaseServiceException("Exception while retrieving BOW Details.", null);
        }
        return Optional.ofNullable(workPkgEntity);
    }

}
