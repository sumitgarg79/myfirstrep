package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.manHours.ManHrsFilterRequest;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.DateUtil;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controller class for various APIs for the Combined Workload View.
 *
 * @author Neelabh Tripathi(847697)
 * @see com.aa.amps.cwlv.crossutil.CrossUtilService
 * @see com.aa.amps.cwlv.manHours.RodAndRonManHrsService
 * @since 1/31/2018
 * <br>
 * <h3>Change log:</h3>
 * Changed to @Autowire dependencies - Naseer Mohammed (842018) on 03/23/2018
 */
@RestController
@RequestMapping("/cwlv")
@CrossOrigin
public class CwlController {
    private static final Logger LOG = LoggerFactory.getLogger(CwlController.class);

    private CombinedWorkLoadService combinedWrkLdSvc;
    private StationCapacitySummaryService stnCapSummService;

    private SessionTimeOutUtil sessionTimeOutUtil;

    @Value("${cwlv.session.flag}")
    private boolean isSessionCheckRequired;

    public CwlController(CombinedWorkLoadService combinedWrkLdSvc, StationCapacitySummaryService stnCapSummService,
        SessionTimeOutUtil sessionTimeOutUtil) {
        this.combinedWrkLdSvc = combinedWrkLdSvc;
        this.stnCapSummService = stnCapSummService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }

    /**
     * This is a test method. It returns a greeting message to confirm if controller is working fine or not.
     *
     * @return json response with greeting message
     */
    @RequestMapping(method = RequestMethod.GET)
    public Map<String, String> greetingMessage() {
        Map<String, String> response = new HashMap<>();

        response.put("name", "AMPS-CWL");
        response.put("message", "Hey, I am up & running!");

        return response;
    }

    /**
     * POST endpoint implementation which accepts the request object and returns the combined workload along with
     * capacity summary.
     * The response contains the list of combined task details of LUS and LAA matching the filter criteria as well
     * as the man hours capacity summary(scheduled and actual) for the requested stations.
     * <br>
     * <b>Note:</b> Although this is a POST implementation, it is effectively treated as GET and there is no change
     * of state on the application. Since the request object is large, it cannot be passed in query params of the GET
     * request.
     *
     * @param request request containing filter criteria
     * @return combined workload data including man-hour capacity summary
     */
    @PostMapping
    public CwlGridResponse getCwlReport(@RequestBody FilterRequest request) {
        LOG.info("Got request for CWL report: {}", request);

        //validating session
        if (request != null && isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(request.getSmSession());
        }

        CwlGridResponse result = new CwlGridResponse();
        Map<String, Object> requestMap = request.getSearchCriteriaAsMap();

        String fromDate = (String) requestMap.get(Constants.PLANNED_DATE_FROM);
        String toDate = (String) requestMap.get(Constants.PLANNED_DATE_TO);

        List<CombinedTaskDetail> combinedTaskDetails = combinedWrkLdSvc.getCombinedWorkLoadTasksDetails(requestMap);
        List<StationCapacitySummary> stationCapSumm = null;

        if (StringUtils.isNotEmpty(fromDate) && StringUtils.equalsIgnoreCase(toDate, fromDate)) {
            try {
                String manHrDate = DateUtil.getDateInManHrFormat(fromDate);

                ManHrsFilterRequest manHrsFilterRequest = new ManHrsFilterRequest();
                manHrsFilterRequest.setDate(manHrDate);
                manHrsFilterRequest.setSmSession(request.getSmSession());
                manHrsFilterRequest.setUserId(request.getUserId());
                manHrsFilterRequest.setStations(request.getStations());

                stationCapSumm = stnCapSummService.getStationCapacitySumm(manHrsFilterRequest.getSearchCriteriaAsMap());

            } catch (RestClientException ex) {
                //Throwing this as it will be caught by the Exception Handler and response will be set appropriately.
                throw ex;
            } catch (Exception ex) {
                LOG.error("Exception while trying to get man hour data.", ex);
                // Do nothing so as to let the task detail response be sent.
            }
        }

        if (CollectionUtils.isEmpty(stationCapSumm)) {
            stationCapSumm = new ArrayList<>();
        }

        result.setCwlvStnCapGrid(stationCapSumm);
        result.setCwlvTaskDetailGrid(combinedTaskDetails);

        return result;
    }
}
