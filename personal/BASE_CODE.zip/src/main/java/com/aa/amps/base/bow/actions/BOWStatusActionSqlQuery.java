package com.aa.amps.base.bow.actions;

import static com.aa.amps.base.bowstatus.actions.BOWStatusActionsConstants.BOW_STATUS_ACTION;

/**
 * This is the query declaration class to load all the bow status actions.
 *
 * @author HCL(296319)
 * @since 6/04/2018.
 */
public class BOWStatusActionSqlQuery {
    /**
     * Private default constructor to prevent any instantiation.
     */
    private BOWStatusActionSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    /**
     * Query to get all the active actions from database
     */
    public static final String SELECT_ALL_BOW_STATUS_ACTIONS = "SELECT SYS_PARMTR_VAL FROM SYS_PARMTR " +
            "where SYS_PARMTR_NM = '" + BOW_STATUS_ACTION + "'";
}
