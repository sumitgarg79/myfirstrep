package com.aa.amps.base.preset;

import com.aa.amps.base.util.DateTimeUtil;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Date;

/**
 * Entity class for AMPS User Preset.
 *
 * @author Naseer Mohammed (842018):American Airlines
 * @since 08/06/2018
 */
@Data
@Entity
@IdClass(PresetId.class)
@Table(name = "AMPS_USER_PRESET")
@Access(value = AccessType.FIELD)
public class PresetEntity implements Serializable {

    @Id
    @Column(name = "AMPS_USER_ID")
    private String userId;

    @Id
    @Column(name = "SEARCH_CRITER_ID")
    private int searchCriterId;

    @Column(name = "SEARCH_CRITER_TXT")
    private String searchCriterTxt;

    @Column(name = "SEARCH_CRITER_TYPE_CD")
    private String searchCriterTypeCd;

    @Column(name = "ACTL_SELECT_TXT")
    private String actlSelectTxt;

    @Column(name = "ROW_CREATE_TMS")
    private Date rowCreateTms;

    @Column(name = "ROW_UPDT_TMS")
    private Date rowUpdtTms;

    public PresetEntity() {

    }

    public PresetEntity(PresetRequest presetRequest) {
        this.userId = presetRequest.getUserId();
        if (presetRequest.getSearchCriterId() != 0) {
            this.searchCriterId = presetRequest.getSearchCriterId();
        }

        this.searchCriterTypeCd = presetRequest.getSearchCriterCd();
        this.searchCriterTxt = presetRequest.getSearchCriterTxt();
        this.actlSelectTxt = presetRequest.getActlSelectTxt();
        this.rowCreateTms = DateTimeUtil.getCurrentDay();
        this.rowUpdtTms = DateTimeUtil.getCurrentDay();
    }

    @Override
    public String toString() {
        return String.format(
                "PresetEntity[userId=%s, searchCriterId='%d', searchCriterCd='%s', searchCriterTxt='%s', " +
                        "actlSelectTxt='%s']",
                this.userId, this.searchCriterId, searchCriterTypeCd, searchCriterTxt, actlSelectTxt);
    }
}
