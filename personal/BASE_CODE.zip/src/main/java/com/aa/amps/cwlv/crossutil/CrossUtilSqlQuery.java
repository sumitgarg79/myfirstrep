package com.aa.amps.cwlv.crossutil;

/**
 * Query constant for the {@link CrossUtilRepository} class.
 *
 * @author Neelabh Tripathi(847697)
 * Created on 3/24/2018.
 */
public final class CrossUtilSqlQuery {

    /**
     * Private default constructor to prevent any instantiation.
     */
    private CrossUtilSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    public static final String SELECT_CROSS_UTIL_ALL =
        "SELECT mntnc_stn_cd, " +
            "cross_utilized_flg, " +
            "rod_capacity, " +
            "ron_capacity, " +
            "active_flg " +
            "FROM CRSS_UTLZD_STN_CAP " +
            "WHERE UPPER(active_flg) = 'Y' " +
            "ORDER BY mntnc_stn_cd";

    public static final String SELECT_CROSS_UTIL_SINGLE_STN =
        "SELECT mntnc_stn_cd, " +
            "cross_utilized_flg, " +
            "rod_capacity, " +
            "ron_capacity, " +
            "active_flg " +
            "FROM CRSS_UTLZD_STN_CAP " +
            "WHERE mntnc_stn_cd = :mntncStnCd " +
            "AND UPPER(active_flg) = 'Y'";

    public static final String UPDATE_CROSS_UTIL =
        "UPDATE crss_utlzd_stn_cap " +
            "SET cross_utilized_flg = :crossUtliFlg, " +
            "rod_capacity = :rodCapacity, " +
            "ron_capacity = :ronCapacity " +
            "WHERE mntnc_stn_cd = :mntncStnCd " +
            "AND UPPER(active_flg) = 'Y'";

    public static final String INSERT_CROSS_UTIL_STATION =
            "INSERT INTO CRSS_UTLZD_STN_CAP(" +
                    "MNTNC_STN_CD," +
                    "CROSS_UTILIZED_FLG," +
                    " ROD_CAPACITY," +
                    " RON_CAPACITY," +
                    " ACTIVE_FLG)" +
                    " VALUES(:mntncStnCode,:crossUtilFlag,:rodCapacity,:ronCapacity,'Y')";


    public static final String DELETE_CROSS_UTIL_SELECTED_STATION =
            "UPDATE crss_utlzd_stn_cap " +
                    "SET ACTIVE_FLG = 'N' " +
                    "WHERE MNTNC_STN_CD = :mntncStnCode ";

    public static final String UPDATE_ADDSTATION_CROSS_UTIL =
            "UPDATE crss_utlzd_stn_cap " +
                    "SET cross_utilized_flg = :crossUtilFlg, " +
                    "rod_capacity = :rodCapacity, " +
                    "ron_capacity = :ronCapacity, " +
                    "active_flg = 'Y'"+
                    " WHERE mntnc_stn_cd = :mntncStnCd ";

    public static final String SELECT_FOR_STATION =
            "SELECT mntnc_stn_cd," +
                    "cross_utilized_flg,"+
                    "rod_capacity," +
                    "ron_capacity," +
                    "active_flg" +
                    " FROM CRSS_UTLZD_STN_CAP " +
                    "WHERE MNTNC_STN_CD = :mntncStnCd";

    public static final String SELECT_CROSS_UTIL_STATION =
            "SELECT mntnc_stn_cd " +
                    "FROM CRSS_UTLZD_STN_CAP " +
                    "WHERE UPPER(active_flg) = 'Y' " +
                    "ORDER BY mntnc_stn_cd";

}
