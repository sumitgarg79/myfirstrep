package com.aa.amps.base.user;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

/**
 * User Repository to perform all the CRUD Operations for AMPS_USER
 * and AMPS_USER_LOGIN_INFO tables.
 *
 * @author Paul Verner:American Airlines
 * @since 09/13/2018.
 */

@Repository
class UserRepository {

    private static final Logger LOG = LoggerFactory.getLogger(UserRepository.class);
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    UserRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Determine if userId exists in AMPS_USER table
     *
     * @param userId user Id
     * @return true if userId is found in AMPS_USER table, false if userId is NOT found
     */
    boolean userIdExistsInAmpsUser(String userId) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userId);
        LOG.debug("userIdExistsInAmpsUser : SQL Query parameter map values - {} ", parameterMap);
        Integer rowCount = namedJdbcTemplate.queryForObject(UserSqlQuery.SELECT_COUNT_AMPS_USER_BY_ID, parameterMap,
                Integer.class);
        return (rowCount != null && rowCount > 0);
    }

    /**
     * Insert userDetails (userId, firstName, lastName) into AMPS_USER table.
     *
     * @param userRequest that has userId, firstName, lastName
     */
    int insertAmpsUser(UserRequest userRequest) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userRequest.getUserId());
        parameterMap.put(UserConstants.EMP_ID, userRequest.getUserId());
        parameterMap.put(UserConstants.FIRST_NAME, userRequest.getFirstName());
        parameterMap.put(UserConstants.LAST_NAME, userRequest.getLastName());

        LOG.debug("insertAmpsUser() : SQL Query parameter map values - {} ", parameterMap);
        int insertCount = namedJdbcTemplate.update(UserSqlQuery.INSERT_AMPS_USER, parameterMap);
        LOG.debug("insertAmpsUser(): {} row(s) inserted", insertCount);
        return insertCount;
    }

    /**
     * Update userId, firstName, lastName, lastUpdatedTms  in AMPS_USER table.
     *
     * @param userRequest that has userId, firstName, lastName
     */
    int updateAmpsUser(UserRequest userRequest) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userRequest.getUserId());
        parameterMap.put(UserConstants.EMP_ID, userRequest.getUserId());
        parameterMap.put(UserConstants.FIRST_NAME, userRequest.getFirstName());
        parameterMap.put(UserConstants.LAST_NAME, userRequest.getLastName());

        LOG.debug("updateAmpsUser() : SQL Query parameter map values - {} ", parameterMap);
        int updateCount = namedJdbcTemplate.update(UserSqlQuery.UPDATE_AMPS_USER, parameterMap);
        LOG.debug("updateAmpsUser() : {} row(s) Updated", updateCount);
        return updateCount;
    }

    /**
     * Determine if userId exists in AMPS_USER_LOGIN_INFO table
     *
     * @param userId user Id
     * @return true if userId is found in AMPS_USER_LOGIN_INFO table, false if userId is NOT found
     */
    boolean userIdExistsInAmpsUserLogin(String userId) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userId);
        LOG.debug("userIdExistsInAmpsUserLogin() : SQL Query parameter map values - {} ", parameterMap);

        Integer rowCount = namedJdbcTemplate.queryForObject(UserSqlQuery.SELECT_COUNT_AMPS_USER_LOGIN_INFO_BY_ID,
                parameterMap, Integer.class);
        return (rowCount != null && rowCount > 0);
    }

    /**
     * Insert user info (userId, lastLoginTms) into AMPS_USER_LOGIN_INFO table.
     *
     * @param userId user Id
     */
    int insertAmpsUserLogin(String userId) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userId);

        LOG.debug("insertAmpsUserLogin() : SQL Query parameter map values - {} ", parameterMap);
        int insertCount = namedJdbcTemplate.update(UserSqlQuery.INSERT_AMPS_USER_LOGIN_INFO, parameterMap);
        LOG.debug("insertAmpsUserLogin() : {} row(s) Inserted.", insertCount);
        return insertCount;
    }

    /**
     * Update lastLoginTms in AMPS_USER_LOGIN_INFO table.
     *
     * @param userId user Id
     */
    int updateUserLogin(String userId) {

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(UserConstants.USER_ID, userId);

        LOG.debug("updateAmpsUserLogin() : SQL Query parameter map values - {} ", parameterMap);
        int updateCount = namedJdbcTemplate.update(UserSqlQuery.UPDATE_AMPS_USER_LOGIN_INFO, parameterMap);
        LOG.debug("updateAmpsUserLogin() : {} row(s) updated", updateCount);
        return updateCount;
    }
}