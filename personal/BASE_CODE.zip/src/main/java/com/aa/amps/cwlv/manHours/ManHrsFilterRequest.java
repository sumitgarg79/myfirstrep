package com.aa.amps.cwlv.manHours;

import com.aa.amps.cwlv.util.Constants;
import lombok.Data;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This class contains the properties required for Manhour Tab filter criteria that is received from UI.
 *
 * @author Naseer Mohammed(847697)
 * @since 06/04/2018.
 */
@Data
public class ManHrsFilterRequest {

    private String[] stations;

    private String date;

    private String smSession;

    private String userId;


    /**
     * Creates a {@code Map} representation of this class properties and their value.
     * <b>Note</b> that stations are stored as a {@code List}.
     *
     * @return {@code map} with class properties
     */
    public Map<String, Object> getSearchCriteriaAsMap() {
        Map<String, Object> criteria = new HashMap<>();

        if (ArrayUtils.isNotEmpty(this.stations)) {
            List<String> stationsList = Arrays.asList(this.stations);

            stationsList.replaceAll(String::trim);
            criteria.put(Constants.STATION_PLANNED, stationsList);
        }

        if (StringUtils.isNotEmpty(this.date))
            criteria.put(Constants.MAN_HRS_DATE, this.date.trim());

        if (StringUtils.isNotEmpty(smSession)) {
            criteria.put(Constants.SMSESSION, this.smSession);
        }

        if (StringUtils.isNotEmpty(userId)) {
            criteria.put(Constants.USERID, this.userId.trim());
        }

        return criteria;
    }
}
