package com.aa.amps.base.preset;

import lombok.Data;

import java.io.Serializable;

/**
 * ID class for Preset. It has userId & searchCriterId as composit key.
 *
 * @author Naseer Mohammed (842018):American Airlines
 * @since 08/06/2018
 */
@Data
public class PresetId implements Serializable {

    private String userId;
    private int searchCriterId;
}
