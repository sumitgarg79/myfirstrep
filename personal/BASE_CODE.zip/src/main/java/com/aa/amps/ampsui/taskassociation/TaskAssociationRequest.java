package com.aa.amps.ampsui.taskassociation;

import lombok.Data;
import java.util.List;

/**
 * Request class for Task Associations.
 *
 * @author HCL
 * @since 09/03/2019.
 */
@Data
public class TaskAssociationRequest {

    private String smSession;
    private String taskId;
    private String  userId;
    private List<TaskAssociations> incExcBlockedJobsWrapperList;

}
