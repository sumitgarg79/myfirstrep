package com.aa.amps.cwlv.cwlgrid;

import lombok.Data;
import org.springframework.stereotype.Component;

/**
 * Bean for station capacity summary grid data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/16/2018.
 */
@Component
@Data
public class StationCapacitySummary {
    private String station;
    private String totalSchdRON;
    private String totalSchdROD;

    private String ronCapacity;
    private String rodCapacity;
}
