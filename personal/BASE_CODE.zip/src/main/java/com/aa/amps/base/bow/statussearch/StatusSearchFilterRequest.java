package com.aa.amps.base.bow.statussearch;

import lombok.Data;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.*;

/**
 * This class contains the properties required for work package filter search criteria that is received from UI.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 * HCL 08/10/2018 : US89830: [BOW Status] - Visitor will only have Finalized available BOW no Draft
 */
@Data
public class StatusSearchFilterRequest {
    private String aircraftNumber;

    private String keyword;
    /**
     * Station List contains all the Line,Base and Vendor Stations.
     **/
    private String[] stations;
    private String status;
    private String fromDate;
    private String toDate;
    private String userRole;

    /**
     * Creates a {@code Map} representation of this class properties and their value.
     *
     * @return {@code map} with class properties
     */
    public Map<String, Object> getSearchCriteriaAsMap() {
        Map<String, Object> criteria = new HashMap<>();

        if (StringUtils.isNotEmpty(this.aircraftNumber)) {
            criteria.put(AIRCRAFT_NO, this.aircraftNumber);
        }

        if (StringUtils.isNotEmpty(this.keyword)) {
            criteria.put(KEYWORD, this.keyword);
        }

        if (ArrayUtils.isNotEmpty(this.stations)) {
            List<String> stationList = Arrays.asList(this.stations);
            criteria.put(STATIONS, stationList);
        }

        if (StringUtils.isNotEmpty(this.status)) {
            criteria.put(PKG_STATUS_CD, this.status);
        }

        if (StringUtils.isNotEmpty(this.fromDate)) {
            criteria.put(PKG_SCHD_FROM, this.fromDate);
        }

        if (StringUtils.isNotEmpty(this.toDate)) {
            criteria.put(PKG_SCHD_TO, this.toDate);
        }

        if (StringUtils.isNotEmpty(this.userRole)) {
            criteria.put(USER_ROLE, this.userRole);
        }

        return criteria;
    }

}
