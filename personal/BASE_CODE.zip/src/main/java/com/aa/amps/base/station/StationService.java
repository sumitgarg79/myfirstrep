package com.aa.amps.base.station;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * This is the <i>Business Logic</i> class to load all the active station.
 * <b>All</b> the functionality associated with Station master data load <b><i>must</i></b> be defined here.
 *
 * @author HCL(922166)
 * Created on 5/18/2018.
 */

@Service
@Transactional
public class StationService {
    private static final String STATION_TYPE_BASE = "H";
    private static final String STATION_TYPE_LINE = "L";
    private static final String STR_BASE = "base";
    private static final String STR_LINE = "line";

    private StationRepository stationRepository;

    public StationService(StationRepository stationRepository) {
        this.stationRepository = stationRepository;
    }

    /**
     * Fetches all the active stations(i.e., all the maintenance stations).
     *
     * @return {@code List} of active stations
     */
    @Transactional(readOnly = true)
    public List<StationEntity> getAllActiveStations() {
        return stationRepository.getAllActiveStations();
    }

    /**
     * Retrieves the list for particular type of station for the provided input type of station.
     *
     * @param stationType stations to be filtered
     * @return {@code List} of stations of {@code stationType}
     */
    public List<StationEntity> getActiveStations(String stationType) {
        List<StationEntity> stationEntityList;
        List<StationEntity> allStations = stationRepository.getAllActiveStations();

        if (StringUtils.isNotEmpty(stationType) && !CollectionUtils.isEmpty(allStations)) {
            stationEntityList = allStations
                    .stream()
                    .filter(s -> {
                        boolean isBase = false;
                        if (stationType.equalsIgnoreCase(STR_BASE) && StringUtils.isNotEmpty(s.getMntncStnTypCd())) {
                            isBase = s.getMntncStnTypCd().equalsIgnoreCase(STATION_TYPE_BASE);
                        } else if (stationType.equalsIgnoreCase(STR_LINE)) {
                            isBase = s.getMntncStnTypCd().equalsIgnoreCase(STATION_TYPE_LINE);
                        }
                        return isBase;
                    })
                    .collect(Collectors.toList());
        } else {
            stationEntityList = new ArrayList<>(); //avoids NPE at the calling method.
        }

        return stationEntityList;
    }

    /**
     * ches all the active stations but the list contains first Base stations then Line station in Asc order.
     *
     * @return {@code List} of active stations
     */
    public List<StationEntity> getAllStnOrderStnType() {
        List<StationEntity> stationEntityList = new ArrayList<>();
        List<StationEntity> stationEntityLineList = new ArrayList<>();
        List<StationEntity> allStations = stationRepository.getAllActiveStations();

        for (StationEntity stn : allStations) {
            if (StringUtils.isNotEmpty(stn.getMntncStnTypCd())) {
                if (STATION_TYPE_BASE.equalsIgnoreCase(stn.getMntncStnTypCd()))
                    stationEntityList.add(stn);
                else
                    stationEntityLineList.add(stn);
            }
        }
        stationEntityList.addAll(stationEntityLineList);
        return stationEntityList;
    }
}
