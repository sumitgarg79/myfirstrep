package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.util.Constants;
import lombok.Data;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * This class contains the properties required for filter criteria that is received from UI.
 * <p>
 * Created by Neelabh Tripathi(847697) on 2/14/2018.
 * </p>
 */
@Data
public class FilterRequest {

    /**
     * Contains a comma(,) delimited string of stations e.g., "DFW,CLT,MIA"
     */
    private String[] stations;
    private String aircraftNumber;
    private String[] fleets;

    private String fromDate;
    private String toDate;
    private String taskId;

    private String descKey;

    /**
     * Holds either of these values RON OR ROD OR BOTH
     */
    private String[] rodRon;

    private String[] typeCd;

    private String smSession;

    private String userId;

    /**
     * Creates a {@code Map} representation of this class properties and their value.
     * <b>Note</b> that stations are stored as a {@code List}.
     *
     * @return {@code map} with class properties
     */
    public Map<String, Object> getSearchCriteriaAsMap() {
        Map<String, Object> criteria = new HashMap<>();

        if (ArrayUtils.isNotEmpty(this.stations)) {
            List<String> stationsList = Arrays.asList(this.stations);

            stationsList.replaceAll(String::trim);
            Collections.sort(stationsList);

            criteria.put(Constants.STATION_PLANNED, stationsList);
        }

        if (StringUtils.isNotEmpty(this.aircraftNumber)) {
            criteria.put(Constants.AIRCRAFT_NO, this.aircraftNumber.toUpperCase().trim());
        }

        if (ArrayUtils.isNotEmpty(this.fleets)) {
            List<String> fleetsList = Arrays.asList(this.fleets);

            if (!CollectionUtils.isEmpty(fleetsList)) {
                fleetsList.replaceAll(String::toUpperCase);
                fleetsList.replaceAll(String::trim);
                Collections.sort(fleetsList);
            }

            criteria.put(Constants.FLEET_CODE, fleetsList);
        }

        if (StringUtils.isNotEmpty(this.fromDate)) {
            criteria.put(Constants.PLANNED_DATE_FROM, this.fromDate.trim());
        }

        if (StringUtils.isNotEmpty(this.toDate)) {
            criteria.put(Constants.PLANNED_DATE_TO, this.toDate.trim());
        }

        if (StringUtils.isNotEmpty(this.taskId)) {
            criteria.put(Constants.MNTNC_ID, this.taskId.toUpperCase());
        }

        if (StringUtils.isNotEmpty(this.descKey)) {
            criteria.put(Constants.TASK_KEYWORD, this.descKey);
        }

        if (ArrayUtils.isNotEmpty(this.rodRon)) {
            String rodRonStr = Constants.ALL;
            if (this.rodRon.length == 1) {
                rodRonStr = this.rodRon[0];
            }
            criteria.put(Constants.ROD_RON, rodRonStr.trim());
        }

        if (ArrayUtils.isNotEmpty(this.typeCd)) {
            criteria.put(Constants.MNTNC_TYPE, Arrays.asList(this.typeCd));
        }

        if (StringUtils.isNotEmpty(smSession)) {
            criteria.put(Constants.SMSESSION, this.smSession);
        }

        if (StringUtils.isNotEmpty(userId)) {
            criteria.put(Constants.USERID, this.userId.trim());
        }

        return criteria;
    }
}
