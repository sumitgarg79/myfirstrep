package com.aa.amps.base.preset;

import com.aa.amps.base.exception.BaseRepositoryException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.aa.amps.base.exception.BaseRepositoryException.*;

/**
 * This is the <i>Business Logic</i> class for AMPS Base Preset Service.
 *
 * @author Naseer Mohammed (842018)
 * @since 08/09/2018
 */
@Service
@Transactional
public class PresetService {

    private static final Logger LOG = LoggerFactory.getLogger(PresetService.class);
    private PresetRepository presetRepository;
    private static final int MAX_PRESET = 15;

    public PresetService(PresetRepository repository) {
        this.presetRepository = repository;
    }

    /**
     * This method return presets by UserId & SearchCriterTypeCd.
     *
     * @param presetRequest holds all the input parameters from UI.
     * @return List of PresetResponse
     */
    public List<PresetResponse> findByUserIdAndSearchCriterTypeCd(PresetRequest presetRequest) {
        List<PresetEntity> presetEntities = new ArrayList<>();

        if (null != presetRequest) {
            presetEntities = this.presetRepository.findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(presetRequest.getUserId(),
                    presetRequest.getSearchCriterCd());
            LOG.info("Got Response for findByUserIdAndSearchCriterTypeCd: {} ", presetEntities.size());
        }

        return ResponseMapper.mapToPresetResponse(presetEntities);
    }


    /**
     * This method insert new preset. It gets the Next Max value of searchCriterId as primary key.
     *
     * @param presetRequest holds all the input parameters from UI.
     * @return list of PresetResponse
     */
    public List<PresetResponse> addPreset(PresetRequest presetRequest) throws BaseRepositoryException {
        if (null != presetRequest) {

            if (verifyPresetWithDescExist(presetRequest)) {
                throw new BaseRepositoryException(RECORD_EXIST, null);
            }

            if (this.presetRepository.countByUserIdAndSearchCriterTypeCd(presetRequest
                    .getUserId(), presetRequest.getSearchCriterCd()) >= MAX_PRESET) {
                throw new BaseRepositoryException(MAX_PRESET_EXCEED, null);
            }

            try {
                PresetEntity entity = new PresetEntity(presetRequest);
                entity.setSearchCriterId(getNextId(presetRequest));

                this.presetRepository.save(entity);
                LOG.info("Preset saved successfully..");
            } catch (Exception ex) {

                LOG.error("Exception from addPreset: {}", ex);
                throw new BaseRepositoryException(RECORD_ADD_FAILED, null);
            }
        }

        return findByUserIdAndSearchCriterTypeCd(presetRequest);
    }

    /**
     * Helper method to query if preset exist for userId, SearchCriteriaTypeCd and SearchCriteriaTxt.
     *
     * @param presetRequest - holds preset request parameters to pass in query.
     * @return true if preset found else false.
     */
    protected boolean verifyPresetWithDescExist(PresetRequest presetRequest) {
        boolean isPresetFound = false;
        if (null != presetRequest) {
            List<PresetEntity> descList = this.presetRepository.findByUserIdAndSearchCriterTypeCd(presetRequest.getUserId(),
                    presetRequest.getSearchCriterCd());

            if (!CollectionUtils.isEmpty(descList)) {
                long found = descList.stream()
                        .map(PresetEntity::getSearchCriterTxt)
                        .filter(Objects::nonNull)
                        .filter(searchCriteriaTxt -> searchCriteriaTxt.equalsIgnoreCase(presetRequest.getSearchCriterTxt()))
                        .count();

                if (found > 0) {
                    isPresetFound = true;
                }
            }
        }

        return isPresetFound;
    }

    /**
     * This method update existing preset. It fetches the existing preset by userId and searchCriteriaId and then save
     * with updated data.
     *
     * @param presetRequest holds all the input parameters from UI.
     * @return List of PresetResponse
     */
    public List<PresetResponse> updatePreset(PresetRequest presetRequest) throws BaseRepositoryException {
        if (null != presetRequest) {
            PresetEntity existingPreset = this.presetRepository.findByUserIdAndSearchCriterIdAndSearchCriterTypeCd(
                    presetRequest.getUserId(), presetRequest.getSearchCriterId(), presetRequest.getSearchCriterCd());

            if (null != existingPreset) {
                if (!StringUtils.equalsIgnoreCase(presetRequest.getSearchCriterTxt(), existingPreset.getSearchCriterTxt())
                        && verifyPresetWithDescExist(presetRequest)) {
                    throw new BaseRepositoryException(RECORD_EXIST, null);
                }

                existingPreset.setSearchCriterTxt(presetRequest.getSearchCriterTxt());
                existingPreset.setActlSelectTxt(presetRequest.getActlSelectTxt());

                existingPreset.setRowUpdtTms(presetRequest.getRowUpdtTms());
                existingPreset.setSearchCriterTypeCd(presetRequest.getSearchCriterCd());
                try {
                    this.presetRepository.save(existingPreset);
                    LOG.info("Preset updated successfully..");
                } catch (Exception ex) {

                    LOG.error("Exception from updatePreset: {}", ex);
                    throw new BaseRepositoryException(RECORD_UPDATE_FAILED, null);
                }
            } else {
                throw new BaseRepositoryException(RECORD_NOT_FOUND_DESC, null);
            }
        }

        return findByUserIdAndSearchCriterTypeCd(presetRequest);
    }

    /**
     * This method Delete existing preset by userId and searchCriterId.
     *
     * @param presetRequest holds all the input parameters from UI.
     * @return List of PresetResponse
     */
    public List<PresetResponse> deletePreset(PresetRequest presetRequest) throws BaseRepositoryException {
        if (null != presetRequest) {
            try {
                int id = this.presetRepository.deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd(
                        presetRequest.getUserId(), presetRequest.getSearchCriterId(), presetRequest.getSearchCriterCd());
                LOG.info("Delete Status :{}", id);
            } catch (Exception ex) {

                LOG.error("Exception from deletePreset: {}", ex);
                throw new BaseRepositoryException(RECORD_DELETE_FAILED, null);
            }
        }

        return findByUserIdAndSearchCriterTypeCd(presetRequest);
    }

    /**
     * This helper method to get the next value of searchCriterId.
     *
     * @param presetRequest holds all the input parameters from UI.
     * @return MAX(searchCriteriaId)+1  value
     */
    public int getNextId(PresetRequest presetRequest) throws BaseRepositoryException {
        Long nbr = (long) -1;

        if (null != presetRequest) {
            nbr = this.presetRepository.getMaxOfSearchCriterId(presetRequest.getUserId(), presetRequest
                    .getSearchCriterCd());
        }

        if (nbr.intValue() == -1) {
            throw new BaseRepositoryException(RECORD_ADD_FAILED, null);
        }

        return nbr.intValue() + 1;
    }

}
