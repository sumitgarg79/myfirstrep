package com.aa.amps.ampsui.util;

import lombok.Data;


/**
 * This class holds the values that service classes will set as a response to the calling class(mostly controllers)
 * so as to provide information about success/failure of request processing and relevant message in case of failure.
 *
 * @author Neelabh Tripathi(847697)
 * Created on 4/4/2019.
 */
@Data
public class ServiceResponseMessage {
    private ServiceResponseStatus status;
    private String message;
    private String statusCode;


    /**
     * Default constructor
     */
    ServiceResponseMessage() {
    }

    /**
     * Overloaded constructor.
     *
     * @param status  one of the provided enum values
     * @param message detailed message to set
     */
    public ServiceResponseMessage(ServiceResponseStatus status, String message) {
        this.status = status;
        this.message = message;
    }

    /**
     * Overloaded constructor.
     *
     * @param status  one of the provided enum values
     * @param message detailed message to set
     */
    public ServiceResponseMessage(ServiceResponseStatus status, String message, String statusCode) {
        this.status = status;
        this.message = message;
        this.statusCode = statusCode;
    }

    /**
     * This method returns general purpose error message with EXCEPTION status.
     *
     * @return {@code ServiceResponseMessage} with EXCEPTION status and "internal server error" message
     */
    public static ServiceResponseMessage getGenericExceptionStatus() {
        return new ServiceResponseMessage(ServiceResponseStatus.EXCEPTION, ServiceResponseDescription
            .INTERNAL_SERVER_ERROR.toString());
    }

    /**
     * This method returns <i>SUCCESS</i> status for <i>Insert</i> operation.
     *
     * @return {@code ServiceResponseMessage} with SUCCESS status and "Record inserted successfully" message
     */
    public static ServiceResponseMessage getInsertSuccessStatus() {
        return new ServiceResponseMessage(ServiceResponseStatus.SUCCESS, ServiceResponseDescription
            .RECORD_INSERTED_SUCCESSSFULLY.toString());
    }

    /**
     * This method returns <i>SUCCESS</i> status for <i>Update</i> operation.
     *
     * @return {@code ServiceResponseMessage} with SUCCESS status and "Record updated successfully" message
     */
    public static ServiceResponseMessage getUpdateSuccessStatus() {
        return new ServiceResponseMessage(ServiceResponseStatus.SUCCESS, ServiceResponseDescription
            .RECORD_UPDATED_SUCCESSSFULLY.toString());
    }

    /**
     * This method returns <i>SUCCESS</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with SUCCESS status and {@code null} message
     */
    public static ServiceResponseMessage getSuccessStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.SUCCESS, null);
    }

    /**
     * This method returns <i>EXCEPTION</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with EXCEPTION status and {@code null} message
     */
    public static ServiceResponseMessage getExceptionStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.EXCEPTION, null);
    }

    /**
     * This method returns <i>RECORD_NOT_FOUND</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with RECORD_NOT_FOUND status and {@code null} message
     */
    public static ServiceResponseMessage getRecordNotFoundStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.RECORD_NOT_FOUND, null);
    }

    /**
     * This method returns <i>NULL_REQUEST</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with NULL_REQUEST status and {@code null} message
     */
    public static ServiceResponseMessage getNullRequestStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.NULL_REQUEST, null);
    }

    /**
     * This method returns <i>REQUIRED_DATA_MISSING</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with REQUIRED_DATA_MISSING status and {@code null} message
     */
    public static ServiceResponseMessage getRequiredDataMissingStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.REQUIRED_DATA_MISSING, null);
    }

    /**
     * This method returns <i>REQUIRED_DATA_MISSING</i> status with no message.
     *
     * @return {@code ServiceResponseMessage} with REQUIRED_DATA_MISSING status and {@code null} message
     */
    public static ServiceResponseMessage getStationDataMissingStatusOnly() {
        return new ServiceResponseMessage(ServiceResponseStatus.REQUIRED_DATA_MISSING, null);
    }

    /**
     * Nested {@code Enum} class to store statuses that services can respond with.
     */
    public enum ServiceResponseStatus {
        SUCCESS("success"),
        RECORD_NOT_FOUND("recordNotFound"),
        EXCEPTION("exception"),
        NULL_REQUEST("nullRequestData"),
        REQUIRED_DATA_MISSING("requiredDataMissing");


        private final String value;

        /**
         * Contructor to set the enum value.
         *
         * @param value the value to be set
         */
        ServiceResponseStatus(final String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    /**
     * The {@code Enum} class with general purpose description messages.
     */
    public enum ServiceResponseDescription {
        RECORD_UPDATED_SUCCESSSFULLY("Record updated successfully."),
        RECORD_ADDED_SUCCESSSFULLY("Record added successfully."),
        RECORD_INSERTED_SUCCESSSFULLY("Record inserted successfully."),
        NULL_REQUEST_DATA("Null received as request data."),
        INTERNAL_SERVER_ERROR("Internal sever error. Please see logs for details"), //General purpose error message
        RECORD_NOT_FOUND_DESC("No matching record found."),
        RECORD_NOT_ADDED_DESC("Record was not be added."),
        STATION_ALREADY_EXSIST("Station already exsist"),
        SESSION_TIMED_OUT("SessionTimedOut");

        private final String value;

        /**
         * Contructor to set the enum value.
         *
         * @param value the value to be set
         */
        ServiceResponseDescription(final String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }

    /**
     * {@code ENUM} for the response codes.
     */
    public enum ServiceResponseStatusCode {
        SUCCESS_GENERIC("2000"),
        SUCCESSFULLY_ADDED("2001"),
        SUCCESSFULLY_UPDATED("2002"),
        SUCCESSFULLY_DELETED("2003"),
        UNAUTHORIZED("4001"),
        SESSION_TIMED_OUT("4002"),
        INTERNAL_SERVER_ERROR("5000");

        private final String value;

        ServiceResponseStatusCode(final String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
