package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.ampsui.util.CommonUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.stereotype.Repository;

import java.util.Date;


/**
 * Entity class for MessageBrowser.
 *
 * @author Ramesh Rudra(842020)
 * @since 1/10/2019.
 */
@Repository
@Data
public class MessageBrowser {
    private String stationCode;
    private String aircraftNumber;
    private String fleetCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss")
    private Date beginDate;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss")
    private Date endDate;
    private String userId;
    private String userName;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy HH:mm:ss")
    private Date msgPostTms;
    private String msgTxt;
    private String ampsMsgId;
    private String subFleetCode;
    private String smSession;
    private String airlineCode;

    /**
     * Remove first 2 characters of 8 character userId as per AMPS impl.
     * eg. 00842020 --> 842020, 00012345 --> 012345
     *
     * @return last 6 characters of UserId
     */
    public String getUserId() {
        return CommonUtil.shortenUserIdTo6Characters(this.userId);
    }
}
