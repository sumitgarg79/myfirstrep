package com.aa.amps.base.bowstatustypes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * This is the <i>Business Logic</i> class for AMPS Base BOW Status drop-down List.
 *
 * @author Paul Verner
 * @since 05/31/2018
 */
@Service
@Transactional
public class BowStatusService {
    private BowStatusRepository bowStatusRepository;

    public BowStatusService(@Autowired BowStatusRepository bowStatusRepository) {
        this.bowStatusRepository = bowStatusRepository;
    }

    /**
     * Fetches list of all BOW Status Types ("DRAFT", "FINALIZED").
     *
     * @return {@code List} of BOW Status Types
     */
    @Transactional(readOnly = true)
    public List<String> getBowStatusTypes() {

        return bowStatusRepository.getAllBowStatusTypes();
    }
}

