package com.aa.amps.base.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * This Class is the base exception class which all other exception classes in base package extends.
 *
 * @author Naseer Mohammed (842018)
 * @since 07/19/2018
 */
@Getter
@Setter
public class BaseRepositoryException extends Exception {

    public static final String RECORD_ADD_FAILED = "Failed to Add Record. Please see logs for details";
    public static final String RECORD_UPDATE_FAILED = "Failed to Update Record. Please see logs for details";
    public static final String RECORD_DELETE_FAILED = "Failed to Delete Record. Please see logs for details";
    public static final String RECORD_EXIST = "Description you entered already exists please rename and try again.";
    public static final String RECORD_NOT_FOUND_DESC = "No matching record found.";
    public static final String MAX_PRESET_EXCEED = "You are allowed a max of 15 presets per user.";

    private final String statusCode;

    public BaseRepositoryException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
