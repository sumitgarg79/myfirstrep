package com.aa.amps.cwlv.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

import java.lang.reflect.Method;

/**
 * Exception handler class for Async functionality. It is required by spring to handle exceptions related to Async
 * calls.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/14/2018.
 */
public class CustomAsyncExceptionHandler implements AsyncUncaughtExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(CustomizedResponseEntityExceptionHandler.class);

    @Override
    public void handleUncaughtException(final Throwable throwable, final Method method, final Object... obj) {
        LOG.error("Exception message - " + throwable.getMessage());
        LOG.error("Method name - " + method.getName());
        for (final Object param : obj) {
            LOG.error("Param - {}", param);
        }
    }
}
