package com.aa.amps.ampsui.restclients;

import lombok.Data;

import java.util.List;

/**
 * Data class for storing response from Fleet API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Data
public class FleetResponseEntity {
    private String fleet;
    private List<String> subfleet;
    private String airlineCode;
    private boolean validFleetCode = false;
}
