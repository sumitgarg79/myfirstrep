package com.aa.amps.base.mntnctasktypes;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * MntncTaskType Repository to perform all the CRUD Operations on the  MntncTaskTypeEntity.
 *
 * @author Sudeep(842019).
 * @since 05/21/2018.
 */
@Repository
class MntncTaskTypeRepository {
    private static final Logger LOG = LoggerFactory.getLogger(MntncTaskTypeRepository.class);
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    MntncTaskTypeRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * This method is used to retrieve All the aircraft maintenance types either 'B' (Base) Or 'LB'(LineBase) Or ALL (B,LB).
     *
     * @param appType ,values can be either 'B' ,'LB',when appType is null ALL (B,LB) .
     * @return List of MaintenanceTypes based on the app type.
     */
    List<MntncTaskTypeEntity> getAllMntncTaskTypes(String appType) {
        List<MntncTaskTypeEntity> result;
        Map<String, String> param = new HashMap<>();
        StringBuilder sql = new StringBuilder(MntncTaskTypesSqlQuery.SELECT_ACFT_MNTNC_TASK_TYPES);
        if (StringUtils.isBlank(appType)) {
            result = namedJdbcTemplate.query(sql.toString(), new MntncTaskTypesRowMapper());
        } else {
            param.put("appType", appType.toUpperCase());
            result = namedJdbcTemplate.query(sql.append(MntncTaskTypesSqlQuery.APP_TYPES).toString(), param, new MntncTaskTypesRowMapper());
        }
        LOG.debug("Row count for Maintenance Task Types from db: {}", result.size());

        return result;
    }
}