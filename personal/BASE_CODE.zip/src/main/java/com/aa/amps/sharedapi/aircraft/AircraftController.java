package com.aa.amps.sharedapi.aircraft;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller class that contains all the REST endpoints related to aircraft details.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/2/2019.
 */
@RestController
@RequestMapping("/sharedapi/aircraft")
@CrossOrigin
public class AircraftController {
    private static final Logger LOG = LoggerFactory.getLogger(AircraftController.class);

    private AircraftService aircraftService;

    public AircraftController(AircraftService aircraftService) {
        this.aircraftService = aircraftService;
    }

    /**
     * /GET endpoint to fetch all the aircraft with option to pass airline code as input to retrieve aircraft for
     * that specific airline code. If no airline code is passed then all aircraft are returned. Valid airline code
     * entries are -
     * <ul>
     * <li>LAA</li>
     * <li>LUS</li>
     * </ul>
     *
     * @param airlineCd airline code - LAA or LUS
     * @return {@code List} of all the aircraft matching the criteria
     */
    @GetMapping
    public List<AircraftEntity> getAllAircraft(@RequestParam(value = "airlineCd", required = false) String airlineCd) {
        LOG.info("getAllAircraft() - Got request to fetch all aircraft with airline code {}", airlineCd);
        List<AircraftEntity> aircraftResponse = null;

        if (StringUtils.isNotBlank(airlineCd)) {
            aircraftResponse = aircraftService.getAllAircraft(airlineCd);

        } else {
            aircraftResponse = aircraftService.getAllAircraft();
        }

        LOG.info("getAllAircraft() -  Returning a list of {} aircraft.", aircraftResponse.size());

        return aircraftResponse;
    }

    /**
     * /GET endpoint to fetch details of a specific aircraft.
     *
     * @param aircraftNumber aircraft number e.g., 3AB
     * @return details of the aircraft, if no matching aircraft is found then empty {@code AircraftEntity} is returned
     */
    @GetMapping("/{aircraftNum}")
    public AircraftEntity getAircraft(@PathVariable("aircraftNum") String aircraftNumber) {
        LOG.info("getAircraft() - Got request to fetch details for aircraft {}", aircraftNumber);

        AircraftEntity aircraftResponse = aircraftService.getAircraft(aircraftNumber);
        LOG.info("getAircraft() - Returning aircraft details {}", aircraftResponse);

        return aircraftResponse;
    }

    /**
     * /POST endpoint to refresh the aircraft cache.
     *
     * @return {@code List} of freshly loaded aircraft details
     */
    @PostMapping("/refreshCache")
    public List<AircraftEntity> refreshAircraftCache() {
        LOG.info("refreshAircraftCache() - Got request to refresh aircraft cache.");

        aircraftService.clearAircraftCache();
        LOG.info("refreshAircraftCache() - Aircraft cache cleared.");

        LOG.info("refreshAircraftCache() - Loading the fresh aircraft data into the cache.");
        List<AircraftEntity> response = aircraftService.getAllAircraft();

        return response;
    }
}
