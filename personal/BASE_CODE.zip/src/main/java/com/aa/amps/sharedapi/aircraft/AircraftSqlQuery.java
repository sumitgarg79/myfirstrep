package com.aa.amps.sharedapi.aircraft;

/**
 * SQL query constant class for Aircraft API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/2/2019.
 */
public class AircraftSqlQuery {
    /**
     * Query to get all the active aircraft details.
     */
    public static final String GET_ACTIVE_AIRCRAFT_QUERY = "SELECT distinct aircft.AIRCFT_NBR as AIRCFT_NBR, " +
        "         'LUS' as AIRLINE_CD, " +
        "         subfleet.FLEET_CD as FLEET_CD, subfleet.SUBFLEET_TXT as SUBFLEET_CD, " +
        "         subfleet.SCEPTRE_AIRCFT_TYPE_EQUIP_CD as SCEPTRE_FLEET_CD " +
        "         FROM AIRCFT_REFRNC aircft, FLEET_GUI subfleet " +
        "         WHERE subfleet.AIRCFT_TYPE_EQUIP_CD = aircft.AIRCFT_TYPE_EQUIP_CD " +
        "         AND subfleet.FLEET_CD IS NOT NULL " +
        "         AND aircft.AIRCFT_DEL_IND = 'F' " +
        " UNION " +
        " SELECT DISTINCT acft.AIRCFT_NBR as AIRCFT_NBR, 'LAA' as AIRLINE_CD, " +
        "         sub.FLEET_CD as FLEET_CD, sub.SUBFLEET_CD as SUBFLEET_CD, '' as SCEPTRE_FLEET_CD " +
        "         FROM AIRCFT acft, AIRCFT_STATUS_HIST hist, SUBFLEET sub,  FOS_FLEET fleet " +
        "         WHERE acft.AIRCFT_NBR = hist.AIRCFT_NBR " +
        "         AND acft.AIRLN_CD = hist.AIRLN_CD " +
        "         AND acft.SUBFLEET_CD = sub.SUBFLEET_CD " +
        "         AND fleet.FOS_FLEET_CD = sub.FOS_FLEET_CD " +
        "         AND sub.FOS_FLEET_CD IS NOT NULL " +
        "         AND hist.AIRCFT_ACTVTY_STATUS_CD = 'A' " +
        "         AND fleet.FOS_FLEET_STATUS_CD = 'A' " +
        "         AND hist.AIRCFT_STATUS_END_DT IS NULL " +
        " ORDER BY AIRCFT_NBR";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private AircraftSqlQuery() {
        //Nothing goes here. This class should not be instantiated.
    }
}
