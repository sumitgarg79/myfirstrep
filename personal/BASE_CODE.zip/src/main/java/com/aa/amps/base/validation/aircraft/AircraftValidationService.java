package com.aa.amps.base.validation.aircraft;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.aa.amps.base.validation.ValidationConstants.LAA;
import static com.aa.amps.base.validation.ValidationConstants.LUS;

/**
 * Service class for all functionality related to aircraft validations.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@Service
@Transactional
public class AircraftValidationService {
    private static final Logger LOG = LoggerFactory.getLogger(AircraftValidationService.class);

    private AircraftValidationRepository aircraftValidationRepository;

    private Map<String, AircraftValidationEntity> validLaaAircraftsCache = new HashMap<>();
    private Map<String, AircraftValidationEntity> validLusAircraftsCache = new HashMap<>();

    /**
     * Constructor.
     */
    public AircraftValidationService(AircraftValidationRepository aircraftValidationRepository) {
        this.aircraftValidationRepository = aircraftValidationRepository;
    }

    /**
     * Method to refresh the list with latest aircraft values from database.
     */
    @Transactional(readOnly = true)
    public void refreshAircraftList() {
        LOG.debug("Refreshing the cache for LAA and LUS aircrafts.");
        List<AircraftValidationEntity> validAircrafts = aircraftValidationRepository.getAircraftList();

        validLaaAircraftsCache = validAircrafts.stream()
            .filter(k -> k.getAirlineCode().equalsIgnoreCase(LAA))
            .collect(Collectors.toMap(AircraftValidationEntity::getAircraftNumber, Function.identity()));

        validLusAircraftsCache = validAircrafts.stream()
            .filter(k -> k.getAirlineCode().equalsIgnoreCase(LUS))
            .collect(Collectors.toMap(AircraftValidationEntity::getAircraftNumber, Function.identity()));
    }

    /**
     * Method to check the status of aircraft number.
     *
     * @param aircraftNumber 3 character aircraft number e.g., "3AB"
     * @return {@code true} if aircraft is in active state, otherwise {@code false}
     */
    @Transactional(readOnly = true)
    public boolean isActiveAircraft(String aircraftNumber, String airlineCode, String fleet) {
        boolean isActive;

        if (CollectionUtils.isEmpty(validLaaAircraftsCache) || CollectionUtils.isEmpty(validLusAircraftsCache)) {
            refreshAircraftList();
        }

        if (StringUtils.isEmpty(aircraftNumber)) {
            isActive = false;
        } else {
            aircraftNumber = aircraftNumber.toUpperCase();
            AircraftValidationEntity aircraftEntity = validLusAircraftsCache.get(aircraftNumber);

            if (aircraftEntity == null) {
                aircraftEntity = validLaaAircraftsCache.get(aircraftNumber);
            }

            isActive = calculateActiveFlag(airlineCode, fleet, aircraftEntity);
        }

        LOG.debug("Active status determined for the aircraft {} is {}", aircraftNumber, isActive);
        return isActive;
    }

    /**
     * Determines the validity of the aircraft based on the input condition of {@code airline code} and {@code fleet
     * code} with the provided {@code AircraftValidationEntity}. In short, for the matched aircraft number for which
     * the {@code AircraftValidationEntity} belongs to, does the {@code airline Code} and {@code fleet} matches? If
     * they are {@code null} or empty then comparison is not done.<br>
     * E.g.,
     * <br>
     * <code>
     * airlineCode=LUS and fleet=737 <br>
     * aircraftEntity = {aircraftNumber: 3AB, airlineCode: LAA, fleet: 737}
     * <br>
     * Output = false, as airline code did not match
     * </code>
     *
     * @param airlineCode    {@code LAA} or {@code LUS} to be compared to
     * @param fleet          fleet code to be compared to
     * @param aircraftEntity the matched aircraft details from cache
     * @return {@code true} if airline code and fleet code matches against
     */
    private boolean calculateActiveFlag(String airlineCode, String fleet, AircraftValidationEntity aircraftEntity) {
        boolean isActive = false;

        if (null != aircraftEntity) {
            isActive = true;

            if (StringUtils.isNotEmpty(airlineCode) && StringUtils.isNotEmpty(fleet)) {
                airlineCode = airlineCode.toUpperCase();
                fleet = fleet.toUpperCase();

                isActive = StringUtils.equalsIgnoreCase(aircraftEntity.getAirlineCode(), airlineCode) &&
                    StringUtils.equalsIgnoreCase(aircraftEntity.getFleet(), fleet);

            } else if (StringUtils.isNotEmpty(airlineCode)) {
                airlineCode = airlineCode.toUpperCase();
                isActive = StringUtils.equalsIgnoreCase(aircraftEntity.getAirlineCode(), airlineCode);

            } else if (StringUtils.isNotEmpty(fleet)) {
                fleet = fleet.toUpperCase();
                isActive = StringUtils.equalsIgnoreCase(aircraftEntity.getFleet(), fleet);
            }
        }

        return isActive;
    }

    /**
     * Retrieves the aircraft details from the cache for the input aircraft number.
     *
     * @param aircraftNumber aircraft number to be matched
     * @return aircraft details object if matched, {@code empty} object otherwise
     */
    public AircraftValidationEntity getAircraftDetails(String aircraftNumber) {
        LOG.debug("Getting aircraft details from cache for aircraft number {}", aircraftNumber);
        AircraftValidationEntity aircraftDetails = null;

        if (CollectionUtils.isEmpty(validLaaAircraftsCache) || CollectionUtils.isEmpty(validLusAircraftsCache)) {
            refreshAircraftList();
        }

        if (StringUtils.isNotEmpty(aircraftNumber)) {
            aircraftNumber = aircraftNumber.toUpperCase();

            aircraftDetails = validLaaAircraftsCache.get(aircraftNumber);

            if (aircraftDetails == null) {
                aircraftDetails = validLusAircraftsCache.get(aircraftNumber);
            }
        }

        if (aircraftDetails == null) {
            aircraftDetails = new AircraftValidationEntity(); //avoid NPE in calling method.
        }

        return aircraftDetails;
    }
}
