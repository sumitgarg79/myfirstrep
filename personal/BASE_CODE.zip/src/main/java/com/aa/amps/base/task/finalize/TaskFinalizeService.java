package com.aa.amps.base.task.finalize;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.util.BaseConstants;
import com.aa.amps.base.util.RestClientUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

/**
 * Service class for BOW Save API. It will send finalize tasks to line to save in the database and send to the
 * SCEPTER using Rest Template.
 *
 * @author HCL(292147)
 * Created on 01/22/2019.
 */
@Component
public class TaskFinalizeService {

    private static final Logger LOG = LoggerFactory.getLogger(TaskFinalizeService.class);

    @Value("${line.bow.save.api}")
    private String lineBowSaveApi;

    private RestClientUtils restClient;

    @Autowired
    public TaskFinalizeService(RestClientUtils restClient) {
        this.restClient = restClient;
    }

    /**
     * Send finalize tasks to line using RestTemplate Call.
     *
     * @param workPkgId  Work package Id to send to the AMPS
     * @param smeSession session detail to set to the header
     * @return Amps Message
     * @throws BaseServiceException If AMPS send a exception
     */
    public String finalizeTask(Long workPkgId, String smeSession) throws BaseServiceException {

        RestTemplate restTemplate = new RestTemplate();
        String jsonInString = restClient.convertToJsonString(workPkgId);

        HttpHeaders headers = restClient.getHeaders(smeSession);
        HttpEntity<String> requestEntity = new HttpEntity<>(jsonInString, headers);

        try {
            ResponseEntity<String> ampsMsg = restTemplate.
                    exchange(lineBowSaveApi, HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<String>() {
                            });

            return ampsMsg.getBody();
        } catch (Exception e) {
            LOG.error("error from AMPS LINE {}", e);
            throw new BaseServiceException(BaseConstants.INTERNAL_AMPS_LINE_ERROR, null);
        }
    }
}
