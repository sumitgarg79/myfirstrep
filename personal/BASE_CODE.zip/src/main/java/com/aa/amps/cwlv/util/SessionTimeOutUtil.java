package com.aa.amps.cwlv.util;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Utility Class for SessionTimeOut related functionalities.
 *
 * @author Naseer Mohammed
 * @since 06/26/2018
 */
@Component
public class SessionTimeOutUtil {
    private static final Logger LOG = LoggerFactory.getLogger(SessionTimeOutUtil.class);

    private Environment environment;

    @Value("${amps.greeting.api}")
    private String ampsGreetingApiEndpoint;

    public SessionTimeOutUtil(Environment environment) {
        this.environment = environment;
    }

    /**
     * This method validates the passed {@code SMSESSION} cookie value by making a call to the AMPS application. If
     * there is no exception thrown then session is active otherwise if {@code RestClientException} is thrown then it is
     * assumed that the cookie is expired or invalid.
     *
     * @param smSession SMSESSION cookie passed to the endpoint
     */
    public void validateSession(String smSession) {
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();

        headers.setContentType(MediaType.APPLICATION_JSON);

        LOG.debug("Testing session validity for - {}", smSession);

        if (StringUtils.isNotEmpty(smSession)) {
            headers.add("Cookie", "SMSESSION=" + smSession);
        } else {
            throw new RestClientException("SMSESSION cookie not present. Unauthorized request.");
        }

        HttpEntity<List<String>> requestEntity = new HttpEntity<>(headers);

        restTemplate.exchange(ampsGreetingApiEndpoint, HttpMethod.GET,
                requestEntity, new ParameterizedTypeReference<Map<String, String>>() {
                });
    }

    /**
     * Method to the get active profile.
     *
     * @return active profile(e.g., test, dev, stage, prod etc)
     */
    public String getActiveProfile() {
        String[] profile = this.environment.getActiveProfiles();
        String activeProfile = "default";

        if (profile != null && profile.length > 0 && StringUtils.isNotEmpty(profile[0])) {
            activeProfile = profile[0];
        }

        return activeProfile;
    }
}
