package com.aa.amps.sharedapi.aircraft;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * RowMapper class for Aircraft.
 *
 * @author Neelabh Tripathi(847697)
 * @author 1/3/2019.
 */
public class AircraftRowMapper implements RowMapper<AircraftEntity> {

    @Override
    public AircraftEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
        AircraftEntity entity = new AircraftEntity();

        entity.setAircraftNumber(rs.getString("AIRCFT_NBR"));
        entity.setAirlineCode(rs.getString("AIRLINE_CD"));
        entity.setFleet(rs.getString("FLEET_CD"));
        entity.setSubfleet(rs.getString("SUBFLEET_CD"));
        entity.setSceptreFleetCode(rs.getString("SCEPTRE_FLEET_CD"));

        return entity;
    }
}
