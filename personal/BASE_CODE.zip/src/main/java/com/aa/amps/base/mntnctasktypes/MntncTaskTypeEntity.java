package com.aa.amps.base.mntnctasktypes;

import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * Entity That Represents AIRCFT_MNTNC_TASK_TYPE table in AMPSFCST schema in DB.
 *
 * @author Sudeep 842019
 * @since 5/18/2018
 */
@Repository
@Data
public class MntncTaskTypeEntity {

    private String acftMntncTaskType;

}
