package com.aa.amps.base.bow.workpackage;

/**
 * Query constant for the {@link WorkPackageRepository} class.
 *
 * @author Shyam Sundar Ashok(202571)
 * @since 10/01/2018
 */
public class WorkPackageSqlQuery {

    /**
     * Query to get the package/bow details from database
     */
    public static final String SELECT_BOW_BY_WORKPACKAGEID =
            "SELECT DRAFT_WORK_PKG_ID, AIRCFT_NBR,DRAFT_PKG_SCHD_DT,DRAFT_PLAN_STN_CD,DRAFT_TRACK_TYPE_CD,DRAFT_SPAN," +
                    "WORK_ORDER_JOB_CD,SCEPTRE_MNTNC_WORK_PKG_ID,DRAFT_DOCK_CD,DRAFT_WORK_PKG_TXT,DRAFT_WORK_PKG_STATUS_CD," +
                    "COMMENTS, UPDATE_USER_ID,LAST_UPDATE_TIME" +
                    " FROM DRAFT_WORK_PKG WHERE DRAFT_WORK_PKG_ID =:workPkgId";

    private WorkPackageSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}