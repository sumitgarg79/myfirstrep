package com.aa.amps.sharedapi.fleet;

/**
 * Query constant class for Fleet.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/17/2018
 */
class FleetSqlQuery {
    static final String FLEET_QUERY =
        " SELECT sub.FOS_FLEET_CD as FLEET_CD " +
        "         FROM AIRCFT acft, AIRCFT_STATUS_HIST hist, SUBFLEET sub, FOS_FLEET fleet " +
        "         WHERE acft.AIRCFT_NBR = hist.AIRCFT_NBR " +
        "         AND acft.AIRLN_CD = hist.AIRLN_CD " +
        "         AND acft.SUBFLEET_CD = sub.SUBFLEET_CD " +
        "         AND fleet.FOS_FLEET_CD = sub.FOS_FLEET_CD " +
        "         AND fleet.FOS_FLEET_STATUS_CD = 'A' " +
        "         AND sub.FOS_FLEET_CD IS NOT NULL " +
        "         AND hist.AIRCFT_ACTVTY_STATUS_CD = 'A' " +
        "         AND hist.AIRCFT_STATUS_END_DT IS NULL " +
        " UNION         " +
        " SELECT subfleet.FLEET_CD as FLEET_CD " +
        "         FROM AIRCFT_REFRNC aircft, FLEET_GUI subfleet " +
        "         WHERE subfleet.AIRCFT_TYPE_EQUIP_CD = aircft.AIRCFT_TYPE_EQUIP_CD " +
        "         AND subfleet.FLEET_CD IS NOT NULL " +
        "         AND aircft.AIRCFT_DEL_IND = 'F'";


    /**
     * Query to get fleets and their subfleets along with the airline code.
     */
    static final String FLEET_SUBFLEET_QUERY =
        " SELECT distinct sub.FOS_FLEET_CD as FLEET_CD, sub.SUBFLEET_CD as SUBFLEET_CD, 'LAA' as AIRLINE_CD " +
            "         FROM AIRCFT acft, AIRCFT_STATUS_HIST hist, SUBFLEET sub, FOS_FLEET fleet " +
            "         WHERE acft.AIRCFT_NBR = hist.AIRCFT_NBR " +
            "         AND acft.AIRLN_CD = hist.AIRLN_CD " +
            "         AND acft.SUBFLEET_CD = sub.SUBFLEET_CD " +
            "         AND fleet.FOS_FLEET_CD = sub.FOS_FLEET_CD " +
            "         AND fleet.FOS_FLEET_STATUS_CD = 'A' " +
            "         AND sub.FOS_FLEET_CD IS NOT NULL " +
            "         AND hist.AIRCFT_ACTVTY_STATUS_CD = 'A' " +
            "         AND hist.AIRCFT_STATUS_END_DT IS NULL " +
            " UNION         " +
            " SELECT distinct subfleet.FLEET_CD as FLEET_CD, subfleet.SUBFLEET_TXT as SUBFLEET_CD, 'LUS' as " +
            "              AIRLINE_CD " +
            "         FROM AIRCFT_REFRNC aircft, FLEET_GUI subfleet " +
            "         WHERE subfleet.AIRCFT_TYPE_EQUIP_CD = aircft.AIRCFT_TYPE_EQUIP_CD " +
            "         AND subfleet.FLEET_CD IS NOT NULL " +
            "         AND aircft.AIRCFT_DEL_IND = 'F'" +
            " ORDER BY FLEET_CD ";

    private FleetSqlQuery() {
        //Nothing goes here. This class should not be instantiated.
    }
}
