package com.aa.amps.base.station;

import lombok.Data;

import java.util.List;

/**
 * Response data class for the Station API. Its main purpose is to provide UI with all the stations(base + line) along
 * with Base stations separately.
 *
 * @author Neelabh Tripathi(847697)
 * @since 8/7/2018.
 */
@Data
public class StationResponse {
    private List<StationEntity> allStations;

    private List<StationEntity> stationEntityList;
}
