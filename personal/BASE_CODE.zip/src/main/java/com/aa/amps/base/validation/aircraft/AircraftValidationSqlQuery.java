package com.aa.amps.base.validation.aircraft;

/**
 * This is the query declaration class for aircraft validations.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
public class AircraftValidationSqlQuery {

    /**
     * Query to get all the active aircrafts for LUS.
     */
    public static final String GET_LUS_ACTIVE_AIRCRAFT = "SELECT distinct aircft.AIRCFT_NBR as AIRCFT_NBR" +
        " ,subfleet.FLEET_CD as FLEET_CD, aircft.AIRCFT_TYPE_EQUIP_CD as AIRCFT_TYPE_EQUIP_CD" +
        " FROM AIRCFT_REFRNC aircft, FLEET_GUI subfleet" +
        " WHERE subfleet.AIRCFT_TYPE_EQUIP_CD = aircft.AIRCFT_TYPE_EQUIP_CD" +
        " AND subfleet.FLEET_CD IS NOT NULL" +
        " AND aircft.AIRCFT_DEL_IND = :aircraftDelInd";

    /**
     * Query to get all the active aircrafts for LAA.
     */
    public static final String GET_LAA_ACTIVE_AIRCRAFT = "SELECT DISTINCT acft.AIRCFT_NBR as AIRCFT_NBR, " +
        " sub.FLEET_CD as FLEET_CD" +
        " FROM AIRCFT acft, AIRCFT_STATUS_HIST hist, SUBFLEET sub" +
        " WHERE acft.AIRCFT_NBR = hist.AIRCFT_NBR" +
        " AND acft.AIRLN_CD = hist.AIRLN_CD" +
        " AND acft.SUBFLEET_CD = sub.SUBFLEET_CD" +
        " AND sub.FOS_FLEET_CD IS NOT NULL" +
        " AND hist.AIRCFT_ACTVTY_STATUS_CD = 'A'";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private AircraftValidationSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
