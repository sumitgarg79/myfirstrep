package com.aa.amps.base.station;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller class to load all the maintenance station at UI.
 *
 * @author HCL(922166)
 * Created on 5/18/2018.
 */

@CrossOrigin
@RestController
@RequestMapping({"/base/station"})
public class StationController {

    private static final Logger LOG = LoggerFactory.getLogger(StationController.class);
    private StationService stationControlService;

    public StationController(StationService stationControlService) {
        this.stationControlService = stationControlService;
    }

    /**
     * This method receives the request to fetch all the station based upon station type.
     *
     * @param stationType parameter received for station type (line/base).
     * @return response api holding a list of line/base stations based on the input (station type) provided.
     */
    @GetMapping("/getStations")
    public StationResponse getActiveStations(@RequestParam(value = "stationType") String stationType) {
        LOG.info("Got request to fetch {} stations for BASE API.", stationType);
        StationResponse stationResponse = new StationResponse();

        stationResponse.setStationEntityList(stationControlService.getActiveStations(stationType));

        return stationResponse;
    }

    /**
     * GET request implementation to retrieve all the active maintenance station.
     *
     * @return all the maintenance stations.
     */
    @GetMapping("/getAll")
    public StationResponse getAllActiveStations() {
        LOG.info("Got request to fetch all stations for BASE API.");
        StationResponse stationResponse = new StationResponse();

        List<StationEntity> allStations = stationControlService.getAllActiveStations();
        stationResponse.setAllStations(allStations);

        return stationResponse;
    }

    /**
     * GET request to retrieve first base then Line station in Asc order for all the active
     * maintenance stations.
     *
     * @return all the maintenance stations
     */
    @GetMapping("/getAllOrdrByStnTyp")
    public StationResponse getAllStnOrderStnType() {
        LOG.info("Got request to fetch first base and vendor station then Line station in Asc order for Base API.");
        StationResponse stationResponse = new StationResponse();

        List<StationEntity> allStations = stationControlService.getAllStnOrderStnType();
        stationResponse.setAllStations(allStations);

        return stationResponse;
    }

}
