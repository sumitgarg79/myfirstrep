package com.aa.amps.base.util;

import com.aa.amps.base.util.sysparam.SysParamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST Controller class for Utility.
 *
 * @author HCL(922166)
 * Created on 8/29/2018.
 */

@CrossOrigin
@RestController
@RequestMapping({"/base/utility"})
public class UtilityController {

    private static final Logger LOG = LoggerFactory.getLogger(UtilityController.class);
    private SysParamService sysParamService;

    public UtilityController(SysParamService sysParamService) {
        this.sysParamService = sysParamService;
    }

    /**
     * This method receives the request to refresh(clear and reload cache) System Parameter from the database.
     *
     * @return updated {@link Map} of system parameter.
     */
    @PostMapping("/refreshSysParam")
    public Map<String, String> refreshSysParam() {
        LOG.info("Got request to refresh system parameter for BASE.");
        sysParamService.clearCache();
        LOG.info("Cache for Sys Parameter cleared successfully.");
        return sysParamService.refreshSysParamMap();
    }

    /**
     * This method will return the System Parameter from the cache.
     *
     * @return {@link Map} of system parameter from cache.
     */
    @GetMapping("/getSysParam")
    public Map<String, String> getSysParam() {
        LOG.info("Got request to get system parameter for Cache.");
        return sysParamService.refreshSysParamMap();
    }
}
