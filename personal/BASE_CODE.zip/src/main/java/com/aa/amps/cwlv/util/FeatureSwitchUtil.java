package com.aa.amps.cwlv.util;

import lombok.Data;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * This is the UtilityClass which stores Sys_Paramtr values in HashMap where its values used to provide
 * switch case for Priority0 M/Hrs
 *
 * @author Ramesh Rudra(842020)
 * Created on 6/18/2018.
 */
@Component
public class FeatureSwitchUtil {

    public static final String SYSTEM_PARAM_VALUE = "SELECT * FROM SYS_PARMTR";
    public Map<String, String> paramMap;
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    public FeatureSwitchUtil(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * getParamValue method is where HashMap key is passed as String to get the value of it.
     *
     * @param paramName switch parameter name
     * @return value of the parameter
     */
    public String getParamValue(String paramName) {
        String value = null;

        if (StringUtils.isNotEmpty(paramName)) {
            if (CollectionUtils.isEmpty(paramMap)) {
                refreshMap();
            }

            value = paramMap.get(paramName);
        }

        return value;
    }

    /**
     * This Method will refresh with latest SysParamtr values from database
     */
    public void refreshMap() {
        List<SysParmtr> parmtrList = namedJdbcTemplate.query(SYSTEM_PARAM_VALUE, new SysParmtrMapper());
        paramMap = null;
        paramMap = parmtrList.stream().collect(Collectors.toMap(x -> x.getParmtrName(), x -> x.getParmtrValue()));
    }

    /**
     * SysParmtr class represents data for systemParameter.
     */
    @Data
    private class SysParmtr {

        private String parmtrName;

        private String parmtrValue;
    }

    /**
     * RowMapper for {@link SysParmtr}
     */
    private class SysParmtrMapper implements RowMapper {

        @Override
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            SysParmtr parmtr = new SysParmtr();

            parmtr.setParmtrName(rs.getString("SYS_PARMTR_NM"));
            parmtr.setParmtrValue(rs.getString("SYS_PARMTR_VAL"));
            return parmtr;
        }
    }

}
