package com.aa.amps.cwlv.crossutil.audit;

import com.aa.amps.cwlv.exception.CrossUtilAuditException;
import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service class for Cross Util audit functionalities.
 *
 * @author Neelabh Tripathi(847697)
 * @see com.aa.amps.cwlv.crossutil.CrossUtilService
 * @since 6/12/2018
 */
@Service
@Transactional
public class CrossUtilAuditService {
    private static final Logger LOG = LoggerFactory.getLogger(CrossUtilAuditService.class);

    private CrossUtilAuditRepository crossUtilAuditRepository;

    public CrossUtilAuditService(CrossUtilAuditRepository crossUtilAuditRepository) {
        this.crossUtilAuditRepository = crossUtilAuditRepository;
    }

    /**
     * Method to insert the cross util transactions in the audit table.
     *
     * @param recordToAudit cross util record to audit
     * @return {@code true} if audit is successful, {@code false} otherwise
     */
    public boolean audit(CrossUtilEntity recordToAudit) {
        boolean auditResult = false;

        if (recordToAudit != null) {
            if (StringUtils.isNotEmpty(recordToAudit.getMntncStnCode()) && StringUtils
                .isNotEmpty(recordToAudit.getUserId())) {

                LOG.debug("Record to be inserted into audit is {}", recordToAudit);

                int rowsInserted = crossUtilAuditRepository.addAuditRecord(recordToAudit);
                auditResult = true;

                LOG.debug("Number of audit records inserted is {}, audit result - {}", rowsInserted, auditResult);
            } else if (StringUtils.isEmpty(recordToAudit.getMntncStnCode()) || StringUtils
                .isEmpty(recordToAudit.getUserId())) {
                LOG.error(
                    "Either station code or User Id or both empty. Both of these fields are required for audit. stn" +
                        " cd - {}, user id - {}. Transaction rolled back.", recordToAudit.getMntncStnCode(),
                    recordToAudit.getUserId());

                String message = "Either station code or User Id or both not provided";
                throw new CrossUtilAuditException(message);
            }
        } else {
            LOG.error("Got null cross util record to audit. Input param to audit - {}. Transaction rolled back.",
                      recordToAudit);
            throw new CrossUtilAuditException("Exception while auditing the cross util transaction. Null record " +
                                                  "received");
        }

        LOG.debug("Audit completed with audit result as {}", auditResult);

        return auditResult;
    }
}
