package com.aa.amps.cwlv.manHours.LaaRodManHrs;


/**
 * Query constant for the {@link LaaRodManHrsRepository} class.
 *
 * @author Ramesh Rudra(842020)
 * Created on 5/09/2018.
 */
public class LaaRodManHrsSqlQuery {

    private LaaRodManHrsSqlQuery() {}

    public static final String ROD_MANHRS_LAA_QUERY =
            "SELECT mnt.STATION_CD," +
                    " NVL(mnt.MNTNC_SCHD_IMPACT_CD,3) as MNTNC_SCHD_IMPACT_CD," +
                    " mnt.AIRCFT_NBR," +
                    " mnt.SCHD_FLIGHT_NBR," +
                    " mnt.Mntnc_Schd_Dt," +
                    " SUM(DECODE(amt.MNTNC_TM,NULL,0,amt.MNTNC_TM)" +
                    " + DECODE(amt.AVIONICS_MANHR_QTY,NULL,0,amt.AVIONICS_MANHR_QTY))/(60) as TotalManHrs" +
                    " FROM aircraft_maint amt," +
                    " MNTNC_SCHD_STATE mnt" +
                    " WHERE TRUNC(mnt.Mntnc_Schd_Dt) = to_date(:date,'YYYY-MM-DD')" +
                    " AND mnt.Mntnc_Schd_Dt > CURRENT_TIMESTAMP - 30" +
                    " AND mnt.Mntnc_Status_Cd       = 'G'" +
                    " AND mnt.BILL_OF_WORK_TYPE_CD   = 'T'" +
                    " AND mnt.mntnc_id =amt.mntnc_id" +
                    " AND mnt.AIRCFT_NBR=amt.AIRCFT_NBR" +
                    " GROUP BY mnt.STATION_CD,NVL(mnt.MNTNC_SCHD_IMPACT_CD,3)," +
                    " mnt.AIRCFT_NBR,mnt.SCHD_FLIGHT_NBR," +
                    " mnt.Mntnc_Schd_Dt ORDER BY mnt.STATION_CD";
}
