package com.aa.amps.ampsui.util;

public class Constants {

    public static final String INTERNAL_AMPSWEB_ERROR = "exception while fetching message browser data from amps-web";
    public static final String JSON_PARSING_ERROR = "Json Parsing Failure";
    public static final String SMSESSION = "smSession";
    public static final String AIRLINE_CODE = "?airlineCode=";
    public static final String RES_SUCCESS= "SUCCESS";
    public static final String RES_FALIURE= "FAILED";
    public static final String REQ_SUCCESS= "Request Processed Successfully";
    public static final String REQ_FALIURE= "Issue in Processing Request";
    public static final String STATUS= "Status";
    public static final String MNTNC_ID = "?mntncId=";
    
    private Constants() {
        // intentionally left blank.
    }
}
