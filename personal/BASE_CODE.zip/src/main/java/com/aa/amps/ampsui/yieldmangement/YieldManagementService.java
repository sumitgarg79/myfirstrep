package com.aa.amps.ampsui.yieldmangement;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.AmpsApiRestClientUtils;
import com.aa.amps.ampsui.util.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Service class for Yield Management API.
 * Yield Management related APIs are hosted on AMPS Line application which will be called from the methods in this class.
 *
 * @author Thanuja
 * @since 5/13/2019.
 */
@Component
public class YieldManagementService {

    private static final Logger LOGGER = LoggerFactory.getLogger(YieldManagementService.class);

    public static final String INTERNAL_AMPSWEB_YIELD_SAVE_ERROR = "Exception while saving Yield management data through amps-web rest api";

    public static final String INTERNAL_AMPSWEB_YIELD_DELETE_ERROR = "Exception while deleting Yield management data through amps-web rest api";

    @Value("${ampsui.yieldmanagement.api}")
    private String yieldManagementAPI;

    @Value("${ampsui.yieldmanagement.api.save}")
    private String yieldManagementSaveAPI;

    @Value("${ampsui.yieldmanagement.api.delete}")
    private String yieldManagementDeleteAPI;

    private AmpsApiRestClientUtils apiRestClient;

    private RestTemplate restTemplate;

    public YieldManagementService(AmpsApiRestClientUtils apiRestClient) {
        this.apiRestClient = apiRestClient;
        this.restTemplate = new RestTemplate();
    }

    /**
     * Gets YieldManagementList from amps-web Interface using RestTemplate Call.
     *
     * @param yieldRequest request on which yield data is requested
     * @return List of YieldManagement
     */
    public List<YieldManagement> getYieldManagementList(YieldManagementRequest yieldRequest) {

        LOGGER.info("Request for yield Service to AMPS-WEB {}", yieldRequest.getAirlineCode());

        HttpHeaders httpHeaders = apiRestClient.getHeaderWithSession(yieldRequest.getSmSession());
        HttpEntity<String> requestEntity = new HttpEntity<>(httpHeaders);
        String apiURLWithQueryParam = yieldManagementAPI + "?airlineCode=" + yieldRequest.getAirlineCode();

        ResponseEntity<List<YieldManagement>> yieldList = restTemplate.
                exchange(apiURLWithQueryParam, HttpMethod.GET,
                        requestEntity, new ParameterizedTypeReference<List<YieldManagement>>() {
                        });
        return yieldList.getBody();
    }

    /**
     * Getter method for restTemplate
     *
     * @return restTemplate
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * This method calls amps-web Interface using RestTemplate Call to save yield management data.
     *
     * @param yieldRequest contains airline code , session String and yield management list to be saved
     * @return {@code 'Request processed successfully'} if save api call is successful else {@code 'Issue in processing request'}
     * @throws AmpsuiServiceException in case of exception while saving Yield management data
     */
    public Map<String, String> saveYieldManagementData(YieldManagementRequest yieldRequest) throws AmpsuiServiceException {

        LOGGER.info("Request for save yield Service to AMPS-WEB {}", yieldRequest.getAirlineCode());
        HttpHeaders httpHeaders = apiRestClient.getHeaderWithSession(yieldRequest.getSmSession());
        String yieldMngmtSaveApiURL = yieldManagementSaveAPI + Constants.AIRLINE_CODE + yieldRequest.getAirlineCode();
        ResponseEntity<Map<String, String>> ampsMsg;

        try {
            final ObjectMapper mapper = new ObjectMapper();
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(yieldRequest.getYieldManagementList()), httpHeaders);
            ampsMsg = restTemplate.
                    exchange(yieldMngmtSaveApiURL, HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<Map<String, String>>() {
                            });
        } catch (Exception e) {
            LOGGER.error("Exception while saving Yield management data ", e);
            throw new AmpsuiServiceException(INTERNAL_AMPSWEB_YIELD_SAVE_ERROR, null);
        }

        return ampsMsg.getBody();
    }

    /**
     * This method calls amps-web Interface using RestTemplate Call to delete yield management data.
     *
     * @param yieldRequest contains airline code , session String and yield management list to be deleted
     * @return {@code SUCCESS} if delete api call is successful else {@code FAILED}
     * @throws AmpsuiServiceException in case of exception while deleting Yield management data
     */
    public Map<String, String> deleteYieldManagementData(YieldManagementRequest yieldRequest) throws AmpsuiServiceException {

        LOGGER.debug("deleteYieldManagementData() - Request for delete yield Service to AMPS-WEB {}", yieldRequest.getAirlineCode());
        HttpHeaders httpHeaders = apiRestClient.getHeaderWithSession(yieldRequest.getSmSession());
        String yieldMngmtDeleteApiURL = yieldManagementDeleteAPI + Constants.AIRLINE_CODE + yieldRequest.getAirlineCode();
        ResponseEntity<Map<String, String>> ampsMsg;

        try {
            final ObjectMapper mapper = new ObjectMapper();
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(yieldRequest.getYieldManagementList()), httpHeaders);
            ampsMsg = restTemplate.
                    exchange(yieldMngmtDeleteApiURL, HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<Map<String, String>>() {
                            });
        } catch (Exception e) {
            LOGGER.error("Exception while deleting Yield management data ", e);
            throw new AmpsuiServiceException(INTERNAL_AMPSWEB_YIELD_DELETE_ERROR, null);
        }

        return ampsMsg.getBody();
    }
}
