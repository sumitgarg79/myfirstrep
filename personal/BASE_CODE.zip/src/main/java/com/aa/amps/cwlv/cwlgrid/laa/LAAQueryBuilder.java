package com.aa.amps.cwlv.cwlgrid.laa;

/**
 * Query constant for the {@link LAATaskRepository} class.
 *
 * @author Naseer Mohammed 842018)
 * @since 04/11/2018.
 */
public class LAAQueryBuilder {

    public static final String LAA_QUERY = "select " +
            "  mss.AIRCFT_NBR as aircftNbr," +
            "  'DECS' as logo, " +
            "  subfleet.FOS_FLEET_CD as fleetCd, " +
            "  mss.STATION_CD as stnCd, " +
            "  CASE " +
            "    WHEN (m.positn_id != '0') THEN " +
            "       mm.mntnc_nm || '-' || m.positn_id " +
            "    ELSE mm.mntnc_nm " +
            "  END AS taskId, " +
            "  m.mntnc_desc as taskDesc," +
            "  CASE " +
            "    WHEN (mm.MNTNC_TYPE_CD = 'FMR') THEN" +
            "      fmr.FMR_TYPE_ID" +
            "    ELSE " +
            "      mm.MNTNC_TYPE_CD" +
            "    END as taskTypeCd," +
            "  CASE " +
            "    WHEN (mss.BILL_OF_WORK_TYPE_CD = 'O') THEN" +
            "       'RON'" +
            "    ELSE " +
            "       'ROD'" +
            "   END as rodRon," +
            "  mss.MNTNC_SCHD_DT as schdDt," +
            "  am.FORCST_DT as forecastDt," +
            "  mss.SCHD_FLIGHT_NBR as flightNbr," +
            "  am.mntnc_due_aircft_tsc_qty as aircftMntncCycle," +
            "  ROUND(am.MNTNC_DUE_AIRCFT_TST_QTY/60,2) as aircftMntncHours," +
            "  CASE " +
            "   WHEN (am.MNTNC_DUE_CALNDR_DT is null) THEN " +
            "       am.MAINT_AIRCFT_DEADLINE " +
            "   else " +
            "       am.MNTNC_DUE_CALNDR_DT " +
            "   END as aircftMntncDays," +
            "  (NVL(am.AVIONICS_MANHR_QTY, 0) + NVL(am.MNTNC_TM, 0))/60 as mechHour," +
            "  mss.MNTNC_SCHD_IMPACT_CD as priority, " +
            "  aircft.AIRCFT_CURR_TSC_QTY as aircftShipCycles," +
            "  ROUND(aircft.AIRCFT_CURR_TST_QTY/60,2) as aircftShipTime," +
            "  subfleet.AVG_CYCLE_PER_DAY_QTY as avgCyclesPerDay," +
            "  subfleet.AVG_FLY_HR_PER_DAY_QTY as avgHoursPerDay" +
            "  FROM MNTNC_SCHD_STATE mss " +
            "  join aircraft_maint am " +
            "  ON mss.AIRCFT_NBR = am.AIRCFT_NBR " +
            "  AND mss.MNTNC_ID = am.MNTNC_ID " +
            "  JOIN mntnc m on am.MNTNC_ID = m.MNTNC_ID " +
            "  JOIN mntnc_master mm on (m.MNTNC_MASTER_ID = mm.MNTNC_MASTER_ID) " +
            "  left JOIN FMR fmr on fmr.MNTNC_ID = am.MNTNC_ID " +
            "  JOIN AIRCFT aircft on am.AIRCFT_NBR = aircft.AIRCFT_NBR " +
            "  JOIN SUBFLEET subfleet on aircft.SUBFLEET_CD = subfleet.SUBFLEET_CD " +
            "  WHERE " +
            "  subfleet.FOS_FLEET_CD IS NOT NULL " +
            "  AND mss.MNTNC_STATUS_CD = 'G' ";
    public static final String ORDER_BY_AIRCRAFT = " ORDER BY aircftNbr ASC";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private LAAQueryBuilder() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
