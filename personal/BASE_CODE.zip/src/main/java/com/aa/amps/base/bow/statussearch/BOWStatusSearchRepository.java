package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.task.WorkPackageEntity;
import com.aa.amps.base.util.RepositoryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.*;

import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.*;

/**
 * Repository class for all operations related to work package search.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 * HCL 08/10/2018 : US89830: [BOW Status] - Visitor will only have Finalized available BOW no Draft
 */
@Repository
class BOWStatusSearchRepository {
    private static final Logger LOG = LoggerFactory.getLogger(BOWStatusSearchRepository.class);
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    BOWStatusSearchRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Method to get list of bill of work package information of given search inputs.
     *
     * @param searchCriteria Criteria on which work package will be searched.
     * @param finalizeRole   User Role
     * @return List<WorkPackageEntity>
     */
    List<WorkPackageEntity> getWorkPackages(final Map<String, Object> searchCriteria, String finalizeRole) {
        List<WorkPackageEntity> result = new ArrayList<>();

        if (searchCriteria.containsKey(AIRCRAFT_NO)) {
            Map<String, Object> parameterMap = new HashMap<>();
            StringBuilder sql = new StringBuilder();

            sql.append(BOWStatusSearchSqlQuery.SELECT_DRAFT_BASE_BOW);

            appendQueryConditionForDraftBaseBow(searchCriteria, sql, parameterMap, finalizeRole);

            sql.append(BOWStatusSearchSqlQuery.SELECT_DRAFT_BASE_BOW_DEFAULT_ORDER_BY);

            LOG.debug("Work package sql query : {}", sql);
            LOG.debug("getWorkPackage() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));
            result = namedJdbcTemplate.query(sql.toString(), parameterMap, new StatusSearchRowMapper());
            LOG.debug("Row count of work package from db for given search criteria: {}", result.size());
        }

        return result;
    }

    /**
     * Private method to add the work package Search Criteria based on
     * aircraft nbr, Station, bow status, induction date & keyword
     *
     * @param searchCriteria Criteria on which work package will be searched
     * @param sql            to append the condition
     * @param parameterMap   contains parameters for sql query
     * @param finalizeRoles  Comma separated User Roles (56, 57) for which only the finalize draft will come
     */
    private void appendQueryConditionForDraftBaseBow(Map<String, Object> searchCriteria, StringBuilder sql,
                                                     Map<String, Object> parameterMap, String finalizeRoles) {

        //Converting comma separated string to list of string.
        List<String> finalizeRoleList = Arrays.asList(finalizeRoles.split("\\s*,\\s*"));

        if (searchCriteria.containsKey(AIRCRAFT_NO)) {
            sql.append(" AND AIRCFT_NBR = :aircraftNbr ");
            parameterMap.put("aircraftNbr", searchCriteria.get(AIRCRAFT_NO));
        }

        if (searchCriteria.containsKey(STATIONS)) {
            List<String> stations = (List<String>) searchCriteria.get(STATIONS);
            if (!CollectionUtils.isEmpty(stations)) {
                sql.append(" AND DRAFT_PLAN_STN_CD IN (:listOfStations)");
                parameterMap.put("listOfStations", stations);
            }
        }

        // DRAFT_WORK_PKG_STATUS_CD is the Status of BOW (like Draft/Finalized)
        // Checking the role if user role is in the list then return only the finalized Draft.
        if (searchCriteria.containsKey(USER_ROLE) &&
                (finalizeRoleList.contains(searchCriteria.get(USER_ROLE)))) {
            sql.append(" AND DRAFT_WORK_PKG_STATUS_CD = 'FINALIZED'");
        } else if (searchCriteria.containsKey(PKG_STATUS_CD)) {
            sql.append(" AND DRAFT_WORK_PKG_STATUS_CD = :workPkgStatusCd ");
            parameterMap.put("workPkgStatusCd", searchCriteria.get(PKG_STATUS_CD));
        } else { // Exclude BOW with "DELETED" PKG_STATUS_CD
            sql.append(" AND DRAFT_WORK_PKG_STATUS_CD != :workPkgStatusCd ");
            parameterMap.put("workPkgStatusCd", BOWStatusSearchConstants.BOW_STATUS_DELETED);
        }

        //PKG_SCHD_FROM and PKG_SCHD_TO are Induction Date of package.
        if (searchCriteria.containsKey(PKG_SCHD_FROM) && searchCriteria.containsKey(PKG_SCHD_TO)) {
            sql.append(" AND DRAFT_PKG_SCHD_DT BETWEEN :pkgSchdDtfrom AND :pkgSchdDtTo ");
            parameterMap.put("pkgSchdDtfrom", searchCriteria.get(PKG_SCHD_FROM));
            parameterMap.put("pkgSchdDtTo", searchCriteria.get(PKG_SCHD_TO));
        }

        if (searchCriteria.containsKey(KEYWORD)) {
            sql.append(" AND ( UPPER(DRAFT_WORK_PKG_TXT) LIKE UPPER('%");
            sql.append(searchCriteria.get(KEYWORD));
            sql.append("%'))");
            parameterMap.put("keyword", searchCriteria.get(KEYWORD));
        }
    }

}
