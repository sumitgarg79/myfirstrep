package com.aa.amps.base.validation;

/**
 * This is the constants class for validation framework.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
public class ValidationConstants {
    public static final String AIRCFT_NBR = "AIRCFT_NBR";
    public static final String FLEET_CD = "FLEET_CD";

    public static final String LAA = "LAA";
    public static final String LUS = "LUS";

    public static final String CHAR_FALSE = "F";
    public static final String AIRCFT_DEL_IND = "aircraftDelInd";
    public static final String TRUE = "true";
    public static final String FALSE = "false";

    private ValidationConstants() {
        throw new IllegalStateException("Validation constants class");
    }
}
