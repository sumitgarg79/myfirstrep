package com.aa.amps.base.task;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.task.finalize.TaskFinalizeService;
import com.aa.amps.base.util.sysparam.SysParamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.task.TaskConstants.*;

/**
 * This is the <i>Business Logic</i> class for AMPS Base Task Service.
 *
 * @author Paul Verner
 * @since 06/10/2018
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@Service
@Transactional
public class TaskService {
    private static final Logger LOG = LoggerFactory.getLogger(TaskService.class);
    private TaskRepository taskRepository;
    private SysParamService sysParamService;
    private TaskFinalizeService taskFinalizeService;

    public TaskService(TaskRepository taskRepository, SysParamService sysParamService, TaskFinalizeService taskFinalizeService) {
        this.taskRepository = taskRepository;
        this.sysParamService = sysParamService;
        this.taskFinalizeService = taskFinalizeService;
    }

    /**
     * Fetches list of Tasks by searchCriteria
     *
     * @param searchCriteria Parameter on which we have to search the tasks
     * @return {@code List} of TaskEntity objects
     */
    public List<TaskEntity> getTasksBySearchCriteria(Map<String, Object> searchCriteria) throws
            ParseException {
        return taskRepository.getTasks(searchCriteria);
    }

    /**
     * Fetches TaskContainerResponse which consist of Tasks, aircraftNbr, workCodeJobOrder &
     * grandTotalManHours for input searchCriteria.
     *
     * @param searchCriteria Parameter on which we have to search the tasks
     * @return {@link TaskContainerResponse} object
     */
    public TaskContainerResponse getTaskContainerBySearchCriteria(Map<String, Object> searchCriteria) throws
            ParseException {

        String aircraftNumber = (String) searchCriteria.get(TaskConstants.AIRCRAFT_NO);
        TaskContainerResponse taskContainer = new TaskContainerResponse();
        List<TaskEntity> taskEntityList = getTasksBySearchCriteria(searchCriteria);

        //Used to store totalManHours for the maintenance.
        Double grandTotalManHours = 0D;

        //US865009 -- Below logic is to assign the order fTaskRepository or task type according to the business
        Map<String, Integer> taskTypesOrder = sysParamService.getTaskTypeOrder();

        for (TaskEntity taskEntity : taskEntityList) {
            taskEntity.setTaskTypeSorting(taskTypesOrder.get(taskEntity.getTaskTypeCode()));
            grandTotalManHours += taskEntity.getManHours();
        }
        taskContainer.setGrandTotalManHours(grandTotalManHours);

        taskContainer.setTaskList(taskEntityList);
        taskContainer.setAircraftNumber(aircraftNumber);
        String equipmentTypeCode = taskRepository.getAircraftEquipmentType(aircraftNumber);
        if (equipmentTypeCode != null) {
            taskContainer.setWorkCodeJobOrder(equipmentTypeCode + TaskConstants.WORK_CODE_JOB_ORDER_LAST_FIVE_CHARACTERS);
        }

        return taskContainer;
    }

    /**
     * US756399:[Draft] Functionality for the "Save" button
     * To save or Update the Base Draft in Database.
     *
     * @param workPkgEntity for saving data
     * @return {@code true} if draft is saved successful, {@code false} otherwise
     */
    public boolean saveBaseDraft(WorkPackageEntity workPkgEntity) throws BaseServiceException {
        boolean isDraftSaved;
        long dbWorkPackageId;
        Map<String, Object> dbWorkPkgEntity = taskRepository.checkWorkPackageExists(workPkgEntity);

        // Below if conditions defined the user action.
        if (USER_EDIT_ACTION.equalsIgnoreCase(workPkgEntity.getUserAction())) {
            isDraftSaved = editBaseDraft(workPkgEntity, dbWorkPkgEntity);
        } else if (USER_MERGE_ACTION.equalsIgnoreCase(workPkgEntity.getUserAction()) ||
                USER_OVERRIDE_ACTION.equalsIgnoreCase(workPkgEntity.getUserAction())) {
            //In case user want to Merge/Override the work package.
            dbWorkPackageId = ((BigDecimal) dbWorkPkgEntity.get(DRAFT_WORK_PKG_ID_DB)).longValue();
            isDraftSaved = updateBaseDraft(workPkgEntity, dbWorkPackageId);
        } else { // In case user want to create new Draft.
            isDraftSaved = createBaseDraft(workPkgEntity, dbWorkPkgEntity);
        }

        if (!isDraftSaved) {
            throw new BaseServiceException(getExceptionMessage(WORK_PACKAGE_NOT_SAVED, workPkgEntity), null);
        }

        //Call AMPS Lines Endpoint for finalized draft work package from base backend.
        if (FINALIZED.equalsIgnoreCase(workPkgEntity.getWorkPkgStatusCd())) {
            String ampsMsg = taskFinalizeService.finalizeTask
                    (workPkgEntity.getWorkPkgId(), workPkgEntity.getSmSession());
            LOG.info("saveBaseDraft Response from finalize : {}", ampsMsg);
        }
        return true;
    }

    /**
     * This method is to create new base draft.
     *
     * @param workPkgEntity   work package details to be saved in database.
     * @param dbWorkPkgEntity DB work package details if exist.
     * @return {@code true} if data saved successfully {@code false} otherwise
     * @throws BaseServiceException in case draft already exist in the DB
     */
    private boolean createBaseDraft(WorkPackageEntity workPkgEntity,
                                    Map<String, Object> dbWorkPkgEntity) throws BaseServiceException {
        boolean isDraftSaved;
        if (!CollectionUtils.isEmpty(dbWorkPkgEntity)) {
            //Work package already exist for the station, date and Track type; Check if not deleted throw Exception.
            if (!DELETED.equalsIgnoreCase(dbWorkPkgEntity.get(DRAFT_WORK_PKG_STATUS_CD).toString())) {
                throw new BaseServiceException(getExceptionMessage(WORK_PACKAGE_EXIST, workPkgEntity), null);
            } else { // If package already exist but deleted then update the same.
                isDraftSaved = updateBaseDraft(workPkgEntity,
                        ((BigDecimal) dbWorkPkgEntity.get(DRAFT_WORK_PKG_ID_DB)).longValue());
            }
        } else { // Create new Package.
            Long workPkgId = taskRepository.getWorkPackageSeqId();
            isDraftSaved = taskRepository.saveBaseDraft(workPkgEntity, workPkgId);
            if (isDraftSaved) {
                // Save data in DRAFT_WORK_PKG_TASK table
                isDraftSaved = taskRepository.saveWorkPkgDraftTasks(workPkgEntity.getTaskEntityList(), workPkgId);
            }
        }
        return isDraftSaved;
    }

    /**
     * Edit the existing draft (user select Edit action from UI).
     *
     * @param workPkgEntity   work package edited by the user
     * @param dbWorkPkgEntity DB work package details if exist
     * @return {@code true} if data saved successfully {@code false} otherwise
     * @throws BaseServiceException in case draft already exist in the DB
     */
    private boolean editBaseDraft(WorkPackageEntity workPkgEntity,
                                  Map<String, Object> dbWorkPkgEntity) throws BaseServiceException {
        long dbWorkPackageId;
        boolean isDraftSaved;
        if (!CollectionUtils.isEmpty(dbWorkPkgEntity)) {
            dbWorkPackageId = ((BigDecimal) dbWorkPkgEntity.get(DRAFT_WORK_PKG_ID_DB)).longValue();
            if (dbWorkPackageId != workPkgEntity.getWorkPkgId()
                    && !DELETED.equalsIgnoreCase(dbWorkPkgEntity.get(DRAFT_WORK_PKG_STATUS_CD).toString())) {
                //Throw Exception if draft already exist in the DB.
                throw new BaseServiceException(getExceptionMessage(WORK_PACKAGE_EXIST, workPkgEntity), null);
            } else {// User want to Update The existing work package through Edit.
                isDraftSaved = updateBaseDraft(workPkgEntity, dbWorkPackageId);
            }
        } else {// User want to create new work package by Changing station, Date, Track type.
            isDraftSaved = updateBaseDraft(workPkgEntity, workPkgEntity.getWorkPkgId());
        }
        return isDraftSaved;
    }

    /**
     * This method is to create the message for Exception.
     *
     * @param message       For what is exception about
     * @param workPkgEntity information for the message
     * @return Message for the Exception
     */
    private String getExceptionMessage(String message, WorkPackageEntity workPkgEntity) {
        return message +
                "aircraft : " + workPkgEntity.getAircraftNbr() +
                ", schedule date : " + workPkgEntity.getPkgSchdDt() +
                ", schedule station : " + workPkgEntity.getPlanStationCd() +
                " and track type : " + workPkgEntity.getTrackTypeCd();
    }

    /**
     * This method update the tasks (add, update and delete) of draft.
     *
     * @param workPkgEntity   Contains the tasks user added/updated from the UI
     * @param dbWorkPackageId work package ID from DB
     * @return {@code true} if data saved successfully {@code false} otherwise
     */
    private boolean updateBaseDraft(WorkPackageEntity workPkgEntity, long dbWorkPackageId) throws BaseServiceException {
        //Get the old work package ID in case we Merge/Override as we have to delete the old Package.
        Long workPkgIdToDelete = workPkgEntity.getWorkPkgId();
        //Update Work Package
        workPkgEntity.setWorkPkgId(dbWorkPackageId);
        boolean isDraftSaved = taskRepository.updateWorkPackageEntity(workPkgEntity);

        // Update work package Task Entity
        if (isDraftSaved) {
            //Get the tasks from database.
            List<Map<String, Object>> dbTaskEntityList = taskRepository.getTaskEntitiesForDraft(workPkgEntity.getWorkPkgId());

            Map<String, Object> dbTaskEntityMap = new HashMap<>();
            final List<TaskEntity> insertTaskEntity = new ArrayList<>();
            final List<TaskEntity> updateTaskEntity = new ArrayList<>();

            //Create a MAP of database tasks with task ID as Key so that we can compare the DB tasks with UI.
            if (!CollectionUtils.isEmpty(dbTaskEntityList)) {
                dbTaskEntityList.forEach(taskEntity ->
                        dbTaskEntityMap.put((String) taskEntity.get(AIRCFT_MNTNC_TASK_ID_DB), taskEntity));
            }

            //loop at UI tasks to segregate the add, update and delete tasks in different lists.
            workPkgEntity.getTaskEntityList().forEach(taskEntity -> {
                if (null != dbTaskEntityMap.get(taskEntity.getTaskId())) {
                    //Tasks need to updated in the database.
                    updateTaskEntity.add(taskEntity);
                    //Removing the updated tasks - remaining will be the task list which have to be deleted from DB.
                    dbTaskEntityMap.remove(taskEntity.getTaskId());
                } else {
                    //Tasks need to insert in the database.
                    insertTaskEntity.add(taskEntity);
                }
            });

            //Update the tasks for the draft.
            isDraftSaved = updateDraftTasks(workPkgEntity, dbTaskEntityMap, insertTaskEntity, updateTaskEntity);

            //Delete the old package in case it exist
            if (isDraftSaved && null != workPkgIdToDelete && dbWorkPackageId != workPkgIdToDelete) {
                isDraftSaved = deleteBaseBOW(workPkgIdToDelete, workPkgEntity.getUserId());
            }
        }

        return isDraftSaved;
    }

    /**
     * This method is uset to insert/update/delete the task for draft.
     *
     * @param workPkgEntity    to get work package id and user id
     * @param dbTaskEntityMap  tasks list to be deleted from DB
     * @param insertTaskEntity tasks list to be inserted into the DB
     * @param updateTaskEntity tasks list to be updated into the DB
     * @return {@code true} if tasks is saved successful, {@code false} otherwise
     */
    private boolean updateDraftTasks(WorkPackageEntity workPkgEntity, Map<String, Object> dbTaskEntityMap,
                                     List<TaskEntity> insertTaskEntity, List<TaskEntity> updateTaskEntity) {
        boolean isDraftSaved = true;

        //Insert tasks in database
        if (!insertTaskEntity.isEmpty())
            isDraftSaved = taskRepository.saveWorkPkgDraftTasks(insertTaskEntity, workPkgEntity.getWorkPkgId());

        //Update tasks in database
        if (isDraftSaved && !updateTaskEntity.isEmpty()) {
            isDraftSaved = taskRepository.updateWorkPkgDraftTasks(updateTaskEntity, workPkgEntity.getWorkPkgId());
        }

        //Delete tasks from database in case user select override for already exist package
        if (isDraftSaved && !dbTaskEntityMap.isEmpty()
                && !(USER_MERGE_ACTION.equalsIgnoreCase(workPkgEntity.getUserAction()))) {
            isDraftSaved = taskRepository.deleteTaskFromWorkPkg(dbTaskEntityMap,
                    workPkgEntity.getWorkPkgId(), workPkgEntity.getUserId());
        }
        return isDraftSaved;
    }

    /**
     * To delete the bill of work package.
     *
     * @param workPkgId work package ID User Input
     * @param userId    User Id requested to delete the work package
     * @return {@code true} if draft is deleted successful, {@code false} otherwise
     */
    public boolean deleteBaseBOW(Long workPkgId, String userId) throws BaseServiceException {
        boolean isBOWDeleted;

        //Delete the Work package
        isBOWDeleted = taskRepository.deleteWorkPackageEntity(workPkgId, userId);

        //Delete all the tasks of work package.
        if (isBOWDeleted) {
            isBOWDeleted = taskRepository.deleteAllTasksForWorkPkg(workPkgId, userId);
        }

        if (!isBOWDeleted) {
            throw new BaseServiceException(WORK_PACKAGE_NOT_DELETE + workPkgId, null);
        }

        LOG.info("BOW and related tasks has been deleted for work package ID :{} by : {} ", workPkgId, userId);

        return true;
    }

    /**
     * Gets task details  by Aircraft Number and TaskId.
     *
     * @param taskDetailReqMap holds list of aircraftNbrs & taskIds
     * @return {@link TaskEntity} list
     */
    public List<TaskEntity> getTaskDetails(Map<String, Object> taskDetailReqMap) throws TaskDetailException {
        return taskRepository.getTaskDetails(taskDetailReqMap);
    }

    /**
     * Gets  list of Tasks of a package/bow by Work Package ID.
     *
     * @param workPkgId parameter on which we have to retrieve the tasks of a particular package/bow
     * @return {@link TaskEntity} list
     */
    public List<TaskEntity> getWorkPackageTasks(Long workPkgId) throws BaseServiceException {
        try {
            List<TaskEntity> taskEntityList = taskRepository.getWorkPackageTasks(workPkgId);

            //Assign and group by the task list according to the specified order of task type.
            Map<String, Integer> taskTypesOrder = sysParamService.getTaskTypeOrder();
            for (TaskEntity taskEntity : taskEntityList) {
                taskEntity.setTaskTypeSorting(taskTypesOrder.get(taskEntity.getTaskTypeCode()));
            }

            return taskEntityList;
        } catch (Exception e) {
            LOG.error("Exception while retrieving BOW/Package Tasks. ", e);
            throw new BaseServiceException("Exception while retrieving BOW/Package Tasks.", null);
        }
    }
}