package com.aa.amps.base.task;

/**
 * Query constant for the {@link TaskRepository} class.
 *
 * @author Paul Verner(650196)
 * @since 6/08/2018
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
class TaskSqlQuery {

    /**
     * Query to get all the task entities from database for a  work package/BOW
     */
    static final String GET_WORK_PACKAGE_TASK_ENTITIES =
            "SELECT dt.AIRCFT_MNTNC_TASK_ID, " +
                    "dt.AIRCFT_NBR, " +
                    "dt.DRAFT_WORK_PKG_ID, " +
                    "t.AIRCFT_MNTNC_TASK_DESC, " +
                    "TO_CHAR(t.MNTNC_TASK_DUE_DT,'MM/DD/YYYY') AS MNTNC_TASK_DUE_DT, " +
                    "TO_CHAR(mw.MNTNC_WORK_PKG_SCHD_DT, 'MM/DD/YYYY') AS MNTNC_WORK_PKG_SCHD_DT, " +
                    "t.MNTNC_REMAIN_HR_QTY, " +
                    "t.MNTNC_REMAIN_CYCLE_QTY, " +
                    "t.MNTNC_REMAIN_DAY_QTY, " +
                    "mw.PLAN_MNTNC_STN_CD, mw.WORK_PKG_TRACK_TYPE_CD, " +
                    "t.AIRCFT_MNTNC_TASK_TYPE_CD, " +
                    "t.MNTNC_REQUIR_MECH_HR_QTY, " +
                    "t.ROUTE_CNTRL_TYPE_CD, " +
                    "t.MNTNC_TASK_DO_NOT_ISSUE_IND, " +
                    "t.MNTNC_DFRL_LOCK_IND, " +
                    "decode(t.MNTNC_TASK_STATUS_TYPE_CD, null, 'CLOSE', " +
                    " t.MNTNC_TASK_STATUS_TYPE_CD) as MNTNC_TASK_STATUS_TYPE_CD  " +
                    "FROM DRAFT_WORK_PKG_TASK dt " +
                    "left outer join  AIRCFT_MNTNC_TASK_PLAN t " +
                    "on t.AIRCFT_MNTNC_TASK_ID = dt.AIRCFT_MNTNC_TASK_ID " +
                    "and t.AIRCFT_NBR = dt.AIRCFT_NBR " +
                    "left outer join MNTNC_WORK_PKG mw " +
                    "on mw.MNTNC_WORK_PKG_ID = t.MNTNC_WORK_PKG_ID " +
                    "where  dt.DRAFT_WORK_PKG_ID =:workPkgId " +
                    "and dt.DRAFT_WORK_PKG_TASK_STATUS NOT IN ('D') ";

    /**
     * Query to get all the active station from database
     */
    static final String SELECT_TASKS_BY_AIRCRAFT =
            "SELECT task.AIRCFT_MNTNC_TASK_ID, " +
                    "task.AIRCFT_NBR, " +
                    "MNTNC_TASK_STATUS_TYPE_CD, " +
                    "MNTNC_TASK_PRIOR_TYPE_CD, " +
                    "AIRCFT_MNTNC_TASK_DESC, " +
                    "AIRCFT_MNTNC_TASK_TYPE_CD, " +
                    "TO_CHAR(MNTNC_TASK_DUE_DT,'MM/DD/YYYY') AS FORECAST_DT, " +
                    "MNTNC_REMAIN_HR_QTY, MNTNC_REMAIN_DAY_QTY, MNTNC_REMAIN_CYCLE_QTY, " +
                    "MNTNC_REQUIR_MECH_HR_QTY, " +
                    "ROUTE_CNTRL_TYPE_CD, MNTNC_DFRL_LOCK_IND, ATA_CHAPTR_SECTN_CD, " +
                    "DECODE(msi.SMOOTHING_ITEM_DO_NOT_PLAN_IND, 'Y', 'T', MNTNC_TASK_DO_NOT_ISSUE_IND) as MNTNC_TASK_DO_NOT_ISSUE_IND, " +
                    "TO_CHAR(wp.MNTNC_WORK_PKG_SCHD_DT,'MM/DD/YYYY') AS MNTNC_WORK_PKG_SCHD_DT," +
                    "wp.PLAN_MNTNC_STN_CD, wp.WORK_PKG_TRACK_TYPE_CD, " +
                    "DECODE(SIGN(wp.SCEPTRE_MNTNC_WORK_PKG_ID),- 1,null,1,wp.SCEPTRE_MNTNC_WORK_PKG_ID, " +
                    "wp.SCEPTRE_MNTNC_WORK_PKG_ID)AS SCEPTRE_MNTNC_WORK_PKG_ID , " +
                    "fleet.FLEET_CD ," +
                    "task.MNTNC_TASK_PLAN_FLEX_IND " +
                    "FROM AIRCFT_MNTNC_TASK_PLAN task " +
                    "LEFT JOIN MNTNC_WORK_PKG wp ON task.AIRCFT_NBR = wp.AIRCFT_NBR " +
                    "AND task.MNTNC_WORK_PKG_ID = wp.MNTNC_WORK_PKG_ID " +
                    "JOIN AIRCFT_REFRNC aircft ON aircft.AIRCFT_NBR = task.AIRCFT_NBR " +
                    "JOIN FLEET_GUI fleet ON aircft.AIRCFT_TYPE_EQUIP_CD = fleet.AIRCFT_TYPE_EQUIP_CD " +
                    "LEFT JOIN MNTNC_SMOOTHING_ITEM msi ON task.aircft_mntnc_task_id LIKE concat(msi.aircft_mntnc_task_id,'%') AND msi.aircft_type_equip_cd = fleet.fleet_cd " +
                    "WHERE MNTNC_TASK_DEL_IND = 'F' ";

    static final String FORECAST_DT_TASK_TYPE_ASC_ORDER = " ORDER BY MNTNC_TASK_DUE_DT, AIRCFT_MNTNC_TASK_TYPE_CD ASC ";

    static final String SELECT_AIRCRAFT_EQUIP_TYPE = "SELECT AIRCFT_TYPE_EQUIP_CD " +
            " FROM AIRCFT_REFRNC WHERE AIRCFT_NBR = :aircraftNumber ";

    /**
     * Query to save all the base drafts in database table: DRAFT_WORK_PKG
     */
    static final String INSERT_BASE_BOW_DRAFT =
            "INSERT  INTO DRAFT_WORK_PKG " +
                    "(DRAFT_WORK_PKG_ID, AIRCFT_NBR, DRAFT_PKG_SCHD_DT, DRAFT_PLAN_STN_CD, DRAFT_TRACK_TYPE_CD, " +
                    "DRAFT_SPAN, WORK_ORDER_JOB_CD, SCEPTRE_MNTNC_WORK_PKG_ID, DRAFT_DOCK_CD, DRAFT_WORK_PKG_TXT, " +
                    "DRAFT_WORK_PKG_STATUS_CD, UPDATE_USER_ID, COMMENTS, LAST_UPDATE_TIME) " +
                    "(Select :workPkgId, :aircraftNbr, to_date(:pkgSchdDt,'MM-DD-YYYY'), :planStationCd, :trackTypeCd, :span, " +
                    ":workOrderJobCd, :sceptreMntncWorkPkgId, :dockCd, NVL(:workPkgTxt,'DRAFT'), :workPkgStatusCd, " +
                    ":userId, " +
                    ":comments, " +
                    "SYSDATE from dual)";

    /**
     * Query to save all the task details in database table: DRAFT_WORK_PKG_TASK
     */
    static final String INSERT_BASE_BOW_TASKS =
            "INSERT  INTO DRAFT_WORK_PKG_TASK " +
                    "(DRAFT_WORK_PKG_ID, AIRCFT_NBR, AIRCFT_MNTNC_TASK_ID, " +
                    " DRAFT_WORK_PKG_TASK_STATUS, UPDATE_USER_ID, LAST_UPDATE_TIME) " +
                    "(SELECT :workPkgId, :aircraftNbr, :taskId, " +
                    ":wrkPkgTaskStatus, " +
                    ":userId, SYSDATE from dual)";

    /**
     * Query to update base draft in database table: DRAFT_WORK_PKG
     */
    static final String UPDATE_BASE_BOW_DRAFT =
            "UPDATE DRAFT_WORK_PKG SET " +
                    "DRAFT_PLAN_STN_CD=:planStationCd, " +
                    "DRAFT_PKG_SCHD_DT=to_date(:pkgSchdDt,'MM-DD-YYYY'), " +
                    "DRAFT_TRACK_TYPE_CD=:trackTypeCd, " +
                    "DRAFT_SPAN=:span, " +
                    "WORK_ORDER_JOB_CD=:workOrderJobCd, " +
                    "SCEPTRE_MNTNC_WORK_PKG_ID=:sceptreMntncWorkPkgId, " +
                    "DRAFT_DOCK_CD=:dockCd, " +
                    "DRAFT_WORK_PKG_TXT=:workPkgTxt, " +
                    "DRAFT_WORK_PKG_STATUS_CD=NVL(:workPkgStatusCd,'DRAFT'), " +
                    "UPDATE_USER_ID=:userId, " +
                    "COMMENTS=:comments, " +
                    "LAST_UPDATE_TIME = SYSDATE " +
                    "WHERE DRAFT_WORK_PKG_ID=:workPkgId";

    /**
     * Query to delete base draft in database table: DRAFT_WORK_PKG
     */
    static final String DELETE_BASE_BOW_DRAFT =
            "UPDATE DRAFT_WORK_PKG SET " +
                    "DRAFT_WORK_PKG_STATUS_CD= 'DELETED', " +
                    "UPDATE_USER_ID=:userId, LAST_UPDATE_TIME = SYSDATE " +
                    "WHERE DRAFT_WORK_PKG_ID=:workPkgId";

    /**
     * Query to update task detail in database table: DRAFT_WORK_PKG_TASK
     */
    static final String UPDATE_BASE_BOW_TASKS =
            "UPDATE DRAFT_WORK_PKG_TASK SET " +
                    "DRAFT_WORK_PKG_TASK_STATUS = :wrkPkgTaskStatus, " +
                    "UPDATE_USER_ID = :userId , LAST_UPDATE_TIME = SYSDATE " +
                    "WHERE DRAFT_WORK_PKG_ID = :workPkgId AND AIRCFT_MNTNC_TASK_ID in (:taskId) ";

    /**
     * Query to delete task details for a package from database table: DRAFT_WORK_PKG_TASK
     */
    static final String DELETE_BASE_BOW_TASKS_BY_BOW =
            "UPDATE DRAFT_WORK_PKG_TASK SET " +
                    "DRAFT_WORK_PKG_TASK_STATUS = 'D', " +
                    "UPDATE_USER_ID = :userId , LAST_UPDATE_TIME = SYSDATE " +
                    "WHERE DRAFT_WORK_PKG_ID = :workPkgId ";

    /**
     * Query to check if work package id exists from database table: DRAFT_WORK_PKG
     */
    static final String CHK_WORK_PKG =
            "SELECT DRAFT_WORK_PKG_ID, AIRCFT_NBR,DRAFT_PKG_SCHD_DT, DRAFT_PLAN_STN_CD, " +
                    "DRAFT_WORK_PKG_STATUS_CD FROM DRAFT_WORK_PKG " +
                    "WHERE AIRCFT_NBR =:aircraftNbr AND DRAFT_PKG_SCHD_DT =to_date(:pkgSchdDt,'MM-DD-YYYY')" +
                    "AND DRAFT_PLAN_STN_CD =:planStationCd AND DRAFT_TRACK_TYPE_CD=:trackTypeCd";


    /**
     * Query to get all the task entities from database for a draft work package
     */
    static final String GET_TASK_ENTITIES =
            "SELECT DRAFT_WORK_PKG_ID, AIRCFT_MNTNC_TASK_ID, AIRCFT_NBR," +
                    " DRAFT_WORK_PKG_TASK_STATUS FROM DRAFT_WORK_PKG_TASK " +
                    " WHERE DRAFT_WORK_PKG_ID=:workPkgId ";

    /**
     * Query to get work package id  from database table: DRAFT_WORK_PKG_SEQ
     */
    static final String GET_WORK_PKG_ID =
            "SELECT DRAFT_WORK_PKG_SEQ.NEXTVAL as WORK_PKG_ID from dual";

    /**
     * Query to get  task details.
     */
    static final String GET_TASK_DETAILS =
            "SELECT task.AIRCFT_MNTNC_TASK_ID,task.MNTNC_TASK_DUE_DT,task.AIRCFT_NBR,task.AMPS_ROW_CREATE_TMS," +
                    "task.MNTNC_TASK_DETL_TXT,wp.MNTNC_WORK_PKG_SCHD_DT,wp.PLAN_MNTNC_STN_CD, " +
                    "track.WORK_PKG_TRACK_TYPE_DESC" +
                    " FROM MNTNC_WORK_PKG wp  RIGHT OUTER JOIN  AIRCFT_MNTNC_TASK_PLAN task" +
                    " ON task.MNTNC_WORK_PKG_ID = wp.MNTNC_WORK_PKG_ID" +
                    " LEFT OUTER JOIN WORK_PKG_TRACK_TYPE track" +
                    " ON track.WORK_PKG_TRACK_TYPE_CD = wp.WORK_PKG_TRACK_TYPE_CD" +
                    " WHERE task.AIRCFT_NBR IN (:aircraftNbrs) AND task.AIRCFT_MNTNC_TASK_ID IN (:taskIds)" +
                    " AND task.MNTNC_TASK_STATUS_TYPE_CD != 'CLOSE' ";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private TaskSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}