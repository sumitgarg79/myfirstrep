package com.aa.amps.ampsui.taskassociation;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Controller class for task Associations ( Inclusion , Exclusion , blocked )
 *
 * @author HCL
 * @since 09/03/2019
 */
@RestController
@RequestMapping("/mntncAssociation")
@CrossOrigin
public class TaskAssociationController {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskAssociationController.class);
    private TaskAssociationService taskAssociationService;
    private SessionTimeOutUtil sessionTimeOutUtil;

    @Value("${ampsui.session.flag}")
    private boolean isSessionCheckRequired;

    public TaskAssociationController(TaskAssociationService taskAssociationService,
                                     SessionTimeOutUtil sessionTimeOutUtil) {
        this.taskAssociationService = taskAssociationService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }

    /**
     * This method retrieves LUS task associations (ie Inclusion , Exclusion etc) for a given task id.
     *
     * @param taskAssociationRequest contains session id , task id and list of its task associations
     * @return list of task associations
     */
    @PostMapping
    public List<TaskAssociations> getTaskAssociationsList
    (@RequestBody TaskAssociationRequest taskAssociationRequest) throws AmpsuiServiceException {

        List<TaskAssociations> taskAssociations = new ArrayList<>();

        if (taskAssociationRequest != null && taskAssociationRequest.getTaskId() != null) {
            LOGGER.info("getTaskAssociations() - Got request to fetch task Associations for task id :{} "
                    , taskAssociationRequest.getTaskId());

            if (isSessionCheckRequired) {
                sessionTimeOutUtil.validateSession(taskAssociationRequest.getSmSession());
            }
            taskAssociations = taskAssociationService.getTaskAssociations(taskAssociationRequest);
        }

        return taskAssociations;
    }

    /**
     * This method saves LUS task associations (ie Inclusion , Exclusion etc).
     *
     * @param taskAssociationRequest contains session id , task id and list of its task associations
     * @return {@code SUCCESS} if save api service call is successful else {@code FAILED}
     * @throws AmpsuiServiceException in case of exception while saving yield management data
     */
    @PostMapping("/save")
    public Map<String, String> saveTaskAssociations(
            @RequestBody TaskAssociationRequest taskAssociationRequest)
            throws AmpsuiServiceException {
        LOGGER.info("Got request to save LUS task association Data");
        if (isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(taskAssociationRequest.getSmSession());
        }
        return taskAssociationService.saveTaskAssociations(taskAssociationRequest);
    }
}
