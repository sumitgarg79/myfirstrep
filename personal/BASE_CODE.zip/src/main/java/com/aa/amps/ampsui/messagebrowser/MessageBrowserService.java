package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.AmpsApiRestClientUtils;
import com.aa.amps.ampsui.util.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Service class for MessageBrowser API. It provides MessageBrowserdata by calling external service hosted on ampsweb
 * using Rest Template.
 *
 * @author Ramesh Rudra(842020)
 * @since 1/2/2019.
 */
@Component
public class MessageBrowserService {

    private static final Logger LOG = LoggerFactory.getLogger(MessageBrowserService.class);

    @Value("${ampsui.messagebrowser.api}")
    private String ampsuiMessageBrowserApi;

    @Value("${ampsui.messagebrowserdelete.api}")
    private String messagebrowserDeleteApi;

    @Value("${ampsui.messagebrowserUpdate.api}")
    private String messagebrowserUpdateApi;

    private AmpsApiRestClientUtils restClient;

    private RestTemplate restTemplate;

    @Autowired
    public MessageBrowserService(AmpsApiRestClientUtils restClient) {
        this.restClient = restClient;
        this.restTemplate = new RestTemplate();
    }

    /**
     * Getter. It is exposed explicitly to be used in the test class.
     *
     * @return RestTemplate instance
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * Gets MessageBrowserList from amps-web Interface using RestTemplate Call.
     *
     * @param searchCriteria search conditions to apply
     * @return List of Messages
     * @throws AmpsuiServiceException while fetching data from AMPS-Web Application
     */
    protected List<MessageBrowser> getMessageBrowserList(Map<String, Object> searchCriteria) throws AmpsuiServiceException {

        String jsonInStringMessageBrowserList = restClient.convertToJsonString(searchCriteria);

        LOG.debug("getMessageBrowserList() - Getting MessageBrowserList from AMPS-WEB {}", searchCriteria);
        String smSession = null;

        if (searchCriteria.containsKey(Constants.SMSESSION)) {
            smSession = searchCriteria.get(Constants.SMSESSION).toString();
        }

        HttpHeaders headers = restClient.getHeaderWithSession(smSession);


        //httpEnitity
        HttpEntity<String> requestEntity =
                new HttpEntity<String>(jsonInStringMessageBrowserList, headers);

        ResponseEntity<List<MessageBrowser>> msgList = null;

        try {
            msgList = restTemplate.
                    exchange(ampsuiMessageBrowserApi, HttpMethod.POST,
                            requestEntity, new ParameterizedTypeReference<List<MessageBrowser>>() {
                            });

        } catch (Exception e) {
            LOG.error("getMessageBrowserList() - Error from AMPSUI-Web", e);
            throw new AmpsuiServiceException(Constants.INTERNAL_AMPSWEB_ERROR, null);
        }

        return (List<MessageBrowser>) msgList.getBody();
    }


    /**
     * This method is to delete selected Message Broswer Grid Data.
     *
     * @param messageBrowsers list of messages that needs to be deleted
     * @return {@code true} if saved successfully, {@code false} otherwise
     * @throws AmpsuiServiceException while fetching data from AMPS-Web Application
     */
    protected Boolean deleteMessageBrowser(List<MessageBrowser> messageBrowsers) throws
            AmpsuiServiceException {

        LOG.debug("deleteMessageBrowser() - Deleting Requested MessageBrowserList from AMPS-WEB {}", messageBrowsers);

        //Transforming messageBrowser to JSON String
        String jsonInStringMessageBrowser = convertToJsonStringMessageBrowser(messageBrowsers);

        String smSession = null;
        if (messageBrowsers.get(0).getSmSession() != null) {
            smSession = messageBrowsers.get(0).getSmSession();
        }

        HttpHeaders headers = restClient.getHeaderWithSession(smSession);

        //httpEnitity
        HttpEntity<String> requestEntity =
                new HttpEntity<String>(jsonInStringMessageBrowser, headers);

        ResponseEntity<Boolean> valid = null;
        try {
            valid = restTemplate.
                    exchange(messagebrowserDeleteApi, HttpMethod.POST,
                            requestEntity, new ParameterizedTypeReference<Boolean>() {
                            });

        } catch (Exception e) {
            LOG.error("deleteMessageBrowser() - Error from AMPSUI-Web for deleting messagebrowser list ", e);
            throw new AmpsuiServiceException(Constants.INTERNAL_AMPSWEB_ERROR, null);
        }
        return (Boolean) valid.getBody();
    }

    /**
     * This method is to update selected Message Broswer Grid Data.
     *
     * @param messageBrowsers list of messages that needs to be updated
     * @return {@code true} if saved successfully, {@code false} otherwise
     * @throws AmpsuiServiceException while fetching data from AMPS-Web Application
     */
    protected Boolean updateMessageBrowser(List<MessageBrowser> messageBrowsers) throws
            AmpsuiServiceException {

        LOG.debug("updateMessageBrowser() - update Requested MessageBrowserList from AMPS-WEB {}", messageBrowsers);

        //Transforming messageBrowser to JSON String
        String jsonInStringMessageBrowser = convertToJsonStringMessageBrowser(messageBrowsers);
        String smSession = null;

        if (messageBrowsers.get(0).getSmSession() != null) {
            smSession = messageBrowsers.get(0).getSmSession();
        }

        HttpHeaders headers = restClient.getHeaderWithSession(smSession);

        //httpEnitity
        HttpEntity<String> requestEntity =
                new HttpEntity<String>(jsonInStringMessageBrowser, headers);

        ResponseEntity<Boolean> valid = null;
        try {
            valid = restTemplate.
                    exchange(messagebrowserUpdateApi, HttpMethod.POST,
                            requestEntity, new ParameterizedTypeReference<Boolean>() {
                            });

        } catch (Exception e) {
            LOG.error("updateMessageBrowser() - Error from AMPSUI-Web for deleting messagebrowser list ", e);
            throw new AmpsuiServiceException(Constants.INTERNAL_AMPSWEB_ERROR, null);
        }
        return (Boolean) valid.getBody();
    }


    /**
     * This Method converts java List<MessageBrowser> to MessageBrowser JSON String Object.
     *
     * @param messageBrowser list of messages
     * @return String of MessageBrowser Json
     * @throws AmpsuiServiceException if there is any  error while conversion of object to json
     */
    private String convertToJsonStringMessageBrowser(List<MessageBrowser> messageBrowser) throws
            AmpsuiServiceException {
        String jsonInStringMessageBrowser = null;

        ObjectMapper mapper = new ObjectMapper();
        try {
            jsonInStringMessageBrowser = mapper.writeValueAsString(messageBrowser);
        } catch (JsonProcessingException e) {
            LOG.error("convertToJsonStringMessageBrowser()- error while Json Parsing of MessageBrowser", e);
            throw new AmpsuiServiceException(Constants.JSON_PARSING_ERROR, null);
        }
        return jsonInStringMessageBrowser;
    }
}
