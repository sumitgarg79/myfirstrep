package com.aa.amps.base.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Date/Time Utility class.
 *
 * @author Naseer Mohammed (842018)
 * @since 08/09/2018
 */
public class DateTimeUtil {

    public static final String Basic_Date_Format = "yyyy-MM-dd";

    private DateTimeUtil() {
        throw new IllegalStateException("Utility class");
    }

    /**
     * To get today's date.
     *
     * @return sql formmatted date.
     */
    public static java.sql.Date getCurrentDay() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat(Basic_Date_Format);
        return java.sql.Date.valueOf(dateFormat.format(calendar.getTime()));
    }
}
