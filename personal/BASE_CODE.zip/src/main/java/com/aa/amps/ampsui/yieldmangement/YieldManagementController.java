package com.aa.amps.ampsui.yieldmangement;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Controller class for YieldManagement endpoints.
 *
 * @author Thanuja
 * @since 5/13/2019
 */
@RestController
@RequestMapping("/yield")
@CrossOrigin
public class YieldManagementController {

    private static final Logger LOGGER = LoggerFactory.getLogger(YieldManagementController.class);
    private YieldManagementService yieldManagementService;

    @Value("${ampsui.session.flag}")
    private boolean isSessionCheckRequired;

    private SessionTimeOutUtil sessionTimeOutUtil;

    public YieldManagementController(YieldManagementService yieldManagementService, SessionTimeOutUtil sessionTimeOutUtil) {
        this.yieldManagementService = yieldManagementService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }

    /**
     * Post /yield endpoint to fetch YieldManagementList from request.
     *
     * @param yieldRequest request on which yield data is requested
     * @return List of YieldManagement
     */
    @PostMapping
    public List<YieldManagement> getYieldManagementList(@RequestBody YieldManagementRequest yieldRequest) {
        List<YieldManagement> yieldList = new ArrayList<>();

        if (yieldRequest != null) {
            LOGGER.info("getYieldManagementList() - Got request to fetch yield management data");

            if (isSessionCheckRequired) {
                sessionTimeOutUtil.validateSession(yieldRequest.getSmSession());
            }
            yieldList = yieldManagementService.getYieldManagementList(yieldRequest);
        }
        return yieldList;
    }
    
    /**
     * This method saves Yield management data for a given airline code.
     *
     * @param yieldRequest contains airline code , session String and yield management list to be saved
     * @return {@code SUCCESS} if save api service call is successful else {@code FAILED}
     * @throws AmpsuiServiceException in case of exception while saving yield management data
     */
    @PostMapping("/save")
    public Map<String, String> saveYieldMngmtData(@RequestBody YieldManagementRequest yieldRequest) throws AmpsuiServiceException {
        LOGGER.info("Got request to save yield Data for airline: {} ", yieldRequest);
        
        if (isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(yieldRequest.getSmSession());
        }
        return yieldManagementService.saveYieldManagementData(yieldRequest);
    }

    /**
     * This method deletes Yield management data for a given airline code.
     *
     * @param yieldRequest contains airline code , session String and yield management list to be deleted
     * @return {@code SUCCESS} if delete api service call is successful else {@code FAILED}
     * @throws AmpsuiServiceException in case of exception while deleting yield management data
     */
    @PostMapping("/delete")
    public Map<String, String> deleteYieldMngmtData(@RequestBody YieldManagementRequest yieldRequest) throws AmpsuiServiceException {
        LOGGER.info("deleteYieldMngmtData() - Got request to delete yield Data for airline: {} ", yieldRequest);
        if (isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(yieldRequest.getSmSession());
        }
        return yieldManagementService.deleteYieldManagementData(yieldRequest);
    }
}
