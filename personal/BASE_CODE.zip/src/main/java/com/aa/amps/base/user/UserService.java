package com.aa.amps.base.user;

import com.aa.amps.base.exception.BaseServiceException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static com.aa.amps.base.exception.BaseRepositoryException.RECORD_ADD_FAILED;
import static com.aa.amps.base.exception.BaseRepositoryException.RECORD_UPDATE_FAILED;


/**
 * This is the <i>Business Logic</i> class for AMPS User Service.
 *
 * @author Paul Verner
 * @since 09/19/2018
 */
@Service
@Transactional
public class UserService {
    private UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    private static final Logger LOG = LoggerFactory.getLogger(UserService.class);

    /**
     * Update/Insert row in AMPS_USER table representing userRequest.userId
     *
     * @param userRequest - contains userId, firstName, lastName of user logging into application
     */
    public boolean loginUser(UserRequest userRequest) throws BaseServiceException {
        LOG.debug("Logging in the user {} for loginUser().", userRequest);

        try {
            //  If userId already exists in AMPS_USER table, update the row.
            //  Otherwise, insert new row into AMPS_USER table.
            if (userRepository.userIdExistsInAmpsUser(userRequest.getUserId())) {
                int updateCount = userRepository.updateAmpsUser(userRequest);
                if (updateCount != 1) {
                    LOG.error("Exception when updating AmpsUser for user {} expected rowCount=1, actual rowCount={}",
                            userRequest, updateCount);
                    throw new BaseServiceException(RECORD_UPDATE_FAILED, null);
                }
            } else {
                int insertCount = userRepository.insertAmpsUser(userRequest);
                if (insertCount != 1) {
                    LOG.error("Exception when inserting AmpsUser for user {} expected rowCount=1, actual rowCount={}",
                            userRequest, insertCount);
                    throw new BaseServiceException(RECORD_ADD_FAILED, null);
                }
            }

            // If userId already exists in AMPS_USER_LOGIN_INFO table, update the row with Login Timestamp
            //  Otherwise, insert new row into AMPS_USER_LOGIN_INFO table.
            if (userRepository.userIdExistsInAmpsUserLogin(userRequest.getUserId())) {
                int updateCount = userRepository.updateUserLogin(userRequest.getUserId());
                if (updateCount != 1) {
                    LOG.error("Exception when updating UserLogin for user {} expected rowCount=1, actual rowCount={}",
                            userRequest, updateCount);
                    throw new BaseServiceException(RECORD_UPDATE_FAILED, null);
                }
            } else {
                int insertCount = userRepository.insertAmpsUserLogin(userRequest.getUserId());
                if (insertCount != 1) {
                    LOG.error("Exception when inserting UserLogin for user {} expected rowCount=1, actual rowCount={}",
                            userRequest, insertCount);
                    throw new BaseServiceException(RECORD_ADD_FAILED, null);
                }
            }
        } catch (Exception ex) {
            LOG.error("Exception from loginUser: {}", ex);
            throw new BaseServiceException(RECORD_UPDATE_FAILED, null);
        }
        return true;
    }
}
