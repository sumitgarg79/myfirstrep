package com.aa.amps.cwlv.web.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Rest Controller for the Logout functionality.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/13/2018.
 */
@RestController
@CrossOrigin
@RequestMapping("/logout")
public class LogoutController {
    public static final String LOGOUTURL_KEY = "logoutUrl";

    @Value("${cwlv.logout.url}")
    private String logoutUrl;

    /**
     * GET request to retrieve the logout url.
     * <b>NOTE:</b> This is needed as on the UI side we don't have the environment specific properties file.
     *
     * @return the logout url
     */
    @GetMapping
    public Map<String, String> getLogoutUrl() {
        Map<String, String> logoutUrlResponse = new HashMap<>();
        logoutUrlResponse.put(LOGOUTURL_KEY, logoutUrl);

        return logoutUrlResponse;
    }
}
