package com.aa.amps.ampsui.masterdata;

import lombok.Data;

import java.util.List;

/**
 * Data class for Fleet API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Data
public class Fleet {
    private String fleetCode;

    private List<Subfleet> subfleet;
}
