package com.aa.amps.cwlv.manHours;


import com.aa.amps.cwlv.exception.InValidDateException;
import com.aa.amps.cwlv.manHours.LaaRodManHrs.LaaRodManHrsService;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.FeatureSwitchUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * This is the <i>Business Logic</i> class for RonAndRodMahHrs screen. <b>All</b> the functionalities associated with;
 * that screen <b><i>must</i></b> be defined here.
 *
 * @author Ramesh Rudra(842020)
 * Created on 4/17/2018.
 */
@Service
@Transactional(readOnly = true)
public class RodAndRonManHrsService {
    private static final Logger LOG = LoggerFactory.getLogger(RodAndRonManHrsService.class);

    private RodAndRonManHrsRepository rodAndRonManHrsRepository;

    private LaaRodManHrsService rodManHrsService;

    private FeatureSwitchUtil featureSwitchUtil;


    public RodAndRonManHrsService(RodAndRonManHrsRepository rodAndRonManHrsRepository, LaaRodManHrsService
            rodManHrsService, FeatureSwitchUtil featureSwitchUtil) {
        this.rodAndRonManHrsRepository = rodAndRonManHrsRepository;
        this.rodManHrsService = rodManHrsService;
        this.featureSwitchUtil = featureSwitchUtil;
    }

    /**
     * Gets Combined Total ManHours of RON and ROD of Both LAA AND LUS
     *
     * @param searchCriteria is passed as map to get date from map which is planned date.
     * @return List of RodAndRonManHours
     */
    public List<RodAndRonManHours> getTotalManHrs(Map<String, Object> searchCriteria) {
        String date = null;
        if (searchCriteria.containsKey(Constants.MAN_HRS_DATE)) {
            date = String.valueOf(searchCriteria.get(Constants.MAN_HRS_DATE));
        }

        if (date == null || date.isEmpty() || !isDateValid(date)) {
            throw new InValidDateException("Invalid date " + date + " required format yyyy-mm-dd");
        }

        //Fetches RodAndRonManHrsEntity data of LUS RON Man Hrs
        List<RodAndRonManHrsEntity> lusRonManHrs = rodAndRonManHrsRepository.getLusRonManHrs(date);
        lusRonManHrs.stream().forEach(lusRonManHr -> {
            lusRonManHr.setIsRon(true);
        });

        //Fetches RodAndRonManHrsEntity data of LUS ROD Man Hrs
        List<RodAndRonManHrsEntity> lusRodManHrs = rodAndRonManHrsRepository.getLusRodManHrs(date);
        lusRodManHrs.stream().forEach(lusRodManHr -> {
            lusRodManHr.setIsRon(false);
        });

        //Fetches RodAndRonManHrsEntity data of LAA RON Man Hrs
        List<RodAndRonManHrsEntity> laaRonManHrs = rodAndRonManHrsRepository.getLaaRonManHrs(date);
        laaRonManHrs.stream().forEach(laaRonManHr -> {
            laaRonManHr.setIsRon(true);
        });

        //Fetches RodAndRonManHrsEntity data of LAA ROD Man Hrs
        List<RodAndRonManHrsEntity> laaRodManHrs = rodManHrsService.getLaaRodManHrs(searchCriteria);
        laaRodManHrs.stream().forEach(laaRodManHr -> {
            laaRodManHr.setIsRon(false);
        });


        List<RodAndRonManHrsEntity> lusManHrs = Stream.concat(lusRonManHrs.stream(), lusRodManHrs.stream())
                .collect(Collectors.toList());

        List<RodAndRonManHrsEntity> laaManHrs = Stream.concat(laaRonManHrs.stream(), laaRodManHrs.stream())
                .collect(Collectors.toList());

        List<RodAndRonManHrsEntity> totalManHrs = Stream.concat(lusManHrs.stream(), laaManHrs.stream())
                .collect(Collectors.toList());

        Map<String, RodAndRonManHours> finalRecord = dataTransformation(totalManHrs);

        List<RodAndRonManHours> ronAndRodManHours = new ArrayList<RodAndRonManHours>();

        for (RodAndRonManHours ronAndRodManHour : finalRecord.values()) {
            ronAndRodManHours.add(ronAndRodManHour);
        }

        //setting up default value as zero for ManHours of priorityCode to avoid null values to UI...
        ronAndRodManHours.stream().forEach(ronAndRodManHour -> {
            if (ronAndRodManHour.getRodPriority0() == null) {
                ronAndRodManHour.setRodPriority0(0F);
            }

            if (ronAndRodManHour.getRodPriority1And2() == null) {
                ronAndRodManHour.setRodPriority1And2(0F);
            }
            if (ronAndRodManHour.getRodPriority3() == null) {
                ronAndRodManHour.setRodPriority3(0F);
            }
            if (ronAndRodManHour.getRonPriority0() == null) {
                ronAndRodManHour.setRonPriority0(0F);
            }
            if (ronAndRodManHour.getRonPriority1And2() == null) {
                ronAndRodManHour.setRonPriority1And2(0F);
            }
            if (ronAndRodManHour.getRonPriority3() == null) {
                ronAndRodManHour.setRonPriority3(0F);
            }

        });


        ronAndRodManHoursRoundOff(ronAndRodManHours);

        if (featureSwitchUtil.getParamValue("PRIORITY_0_REQ").equalsIgnoreCase("N")) {
            LOG.debug("Ignoring priority 0 hours for rod/ron. The switch is ON.");

            DecimalFormat df = new DecimalFormat("#.#");

            ///summing up total ManHrs of Priority codes
            ronAndRodManHours.stream().forEach(ronAndRodManHour -> {

                ronAndRodManHour.setRonTotalManHours(Float.valueOf(df.format(ronAndRodManHour
                        .getRonPriority1And2() + ronAndRodManHour
                        .getRonPriority3())));
                ronAndRodManHour.setRodTotalManHours(Float.valueOf(df.format(ronAndRodManHour
                        .getRodPriority1And2() + ronAndRodManHour
                        .getRodPriority3())));
            });
        } else {
            DecimalFormat df = new DecimalFormat("#.#");

            LOG.debug("Considering priority 0 hours for rod/ron. The switch is OFF.");
            ronAndRodManHours.stream().forEach(ronAndRodManHour -> {

                ronAndRodManHour.setRonTotalManHours(Float.valueOf(df.format(ronAndRodManHour.getRonPriority0() + ronAndRodManHour
                        .getRonPriority1And2() + ronAndRodManHour
                        .getRonPriority3())));
                ronAndRodManHour.setRodTotalManHours(Float.valueOf(df.format(ronAndRodManHour.getRodPriority0() + ronAndRodManHour
                        .getRodPriority1And2() + ronAndRodManHour
                        .getRodPriority3())));
            });
        }

        return ronAndRodManHours;
    }

    /**
     * This method roundOff values of ronAndRodManHours of priorities to nearest 10th.
     *
     * @param ronAndRodManHours {code List} of {@code RodAndRonManHours} with priority data
     * @return roundUp float values
     */
    protected List<RodAndRonManHours> ronAndRodManHoursRoundOff(List<RodAndRonManHours> ronAndRodManHours) {

        DecimalFormat df = new DecimalFormat("#.#");

        ronAndRodManHours.stream().forEach(rodAndRonManHour -> {
            rodAndRonManHour.setRonPriority0(Float.valueOf(df.format(rodAndRonManHour.getRonPriority0())));
            rodAndRonManHour.setRonPriority1And2(Float.valueOf(df.format(rodAndRonManHour.getRonPriority1And2())));
            rodAndRonManHour.setRonPriority3(Float.valueOf(df.format(rodAndRonManHour.getRonPriority3())));
            rodAndRonManHour.setRodPriority0(Float.valueOf(df.format(rodAndRonManHour.getRodPriority0())));
            rodAndRonManHour.setRodPriority1And2(Float.valueOf(df.format(rodAndRonManHour.getRodPriority1And2())));
            rodAndRonManHour.setRodPriority3(Float.valueOf(df.format(rodAndRonManHour.getRodPriority3())));
        });

       return ronAndRodManHours;
    }

    /**
     * This method validates whether date format is valid or not.
     *
     * @param date
     * @return boolean isdateValid or not
     */
    private Boolean isDateValid(String date) {

        Pattern pattern = Pattern.compile("[0-9]{4}-[0-9]{2}-[0-9]{2}");
        return pattern.matcher(date).matches();
    }

    /**
     * This method transforms Total Lus and Laa ManHrs which is in the form
     * {@link RodAndRonManHrsEntity} to {@link RodAndRonManHours}
     *
     * @param totalManHrs of both LAA and LUS
     * @return RodAndRonManHours of both LAA and LUS
     */
    private Map<String, RodAndRonManHours> dataTransformation(List<RodAndRonManHrsEntity> totalManHrs) {

        Map<String, RodAndRonManHours> finalRecord = new HashMap<String, RodAndRonManHours>();

        for (RodAndRonManHrsEntity rodAndRonManHrsEntity : totalManHrs) {

            if (finalRecord.containsKey(rodAndRonManHrsEntity.getStation()) && rodAndRonManHrsEntity.getIsRon()) {
                //creates RonManHours Records if station already exist
                addCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
            } else if (rodAndRonManHrsEntity.getIsRon()) {
                //creates RonManHours Records if station doesn't exist
                createCombinedRonPriority2and3(rodAndRonManHrsEntity, finalRecord);
            }
            if (finalRecord.containsKey(rodAndRonManHrsEntity.getStation()) && !rodAndRonManHrsEntity.getIsRon()) {
                //creates RodManHours Records if station already exist
                addCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
            } else if (!rodAndRonManHrsEntity.getIsRon()) {
                //creates RodManHours Records if station doesn't exist
                createCombinedRodPriority2and3(rodAndRonManHrsEntity, finalRecord);
            }
        }
        return finalRecord;
    }

    /**
     * Updates RodAndRonManHours records if already station record is created.
     *
     * @param rodAndRonManHrsEntity of Both LAA and LUS
     * @param finalRecord           is to store values LUS and LAA ManHrs depending on station
     */
    protected void addCombinedRonPriority2and3(RodAndRonManHrsEntity rodAndRonManHrsEntity, Map<String,
            RodAndRonManHours> finalRecord) {

        RodAndRonManHours ronAndRodManHours = finalRecord.get(rodAndRonManHrsEntity.getStation());

        if (rodAndRonManHrsEntity.getPriorityCode() == 0) {
            ronAndRodManHours.setRonPriority0((ronAndRodManHours.getRonPriority0()
                    == null ? 0 : ronAndRodManHours.getRonPriority0())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }

        if (rodAndRonManHrsEntity.getPriorityCode() == 2 || rodAndRonManHrsEntity.getPriorityCode() == 1) {
            ronAndRodManHours.setRonPriority1And2((ronAndRodManHours.getRonPriority1And2()
                    == null ? 0 : ronAndRodManHours.getRonPriority1And2())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }

        if (rodAndRonManHrsEntity.getPriorityCode() == 3) {
            ronAndRodManHours.setRonPriority3((ronAndRodManHours.getRonPriority3()
                    == null ? 0 : ronAndRodManHours.getRonPriority3())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
    }

    /**
     * Adds new record RodAndRonManHours of station that not exist
     *
     * @param rodAndRonManHrsEntity of Both LAA and LUS
     * @param finalRecord           is to store values LUS and LAA ManHrs depending on station
     */
    protected void createCombinedRonPriority2and3(RodAndRonManHrsEntity rodAndRonManHrsEntity, Map<String,
            RodAndRonManHours> finalRecord) {
        RodAndRonManHours ronAndRodManHours = new RodAndRonManHours();

        ronAndRodManHours.setStation(rodAndRonManHrsEntity.getStation());

        if (rodAndRonManHrsEntity.getPriorityCode() == 0) {
            ronAndRodManHours.setRonPriority0(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }

        if (rodAndRonManHrsEntity.getPriorityCode() == 2 || rodAndRonManHrsEntity.getPriorityCode() == 1) {
            ronAndRodManHours.setRonPriority1And2(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        } else if (rodAndRonManHrsEntity.getPriorityCode() == 3) {
            ronAndRodManHours.setRonPriority3(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
        //insert a fresh record
        finalRecord.put(rodAndRonManHrsEntity.getStation(), ronAndRodManHours);
    }

    /**
     * Updates RodAndRonManHours records if already station record is created
     *
     * @param rodAndRonManHrsEntity of Both LAA and LUS
     * @param finalRecord           is to store values LUS and LAA ManHrs depending on station
     */
    protected void addCombinedRodPriority2and3(RodAndRonManHrsEntity rodAndRonManHrsEntity, Map<String,
            RodAndRonManHours> finalRecord) {

        //pull the value for the station key
        RodAndRonManHours ronAndRodManHours = finalRecord.get(rodAndRonManHrsEntity.getStation());

        if (rodAndRonManHrsEntity.getPriorityCode() == 0) {
            ronAndRodManHours.setRodPriority0((ronAndRodManHours.getRodPriority0()
                    == null ? 0 : ronAndRodManHours.getRodPriority0())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
        if (rodAndRonManHrsEntity.getPriorityCode() == 2 || rodAndRonManHrsEntity.getPriorityCode() == 1) {
            ronAndRodManHours.setRodPriority1And2((ronAndRodManHours.getRodPriority1And2()
                    == null ? 0 : ronAndRodManHours.getRodPriority1And2())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        } else if (rodAndRonManHrsEntity.getPriorityCode() == 3) {
            ronAndRodManHours.setRodPriority3((ronAndRodManHours.getRodPriority3()
                    == null ? 0 : ronAndRodManHours.getRodPriority3())
                    + rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
    }

    /**
     * Adds new record RodAndRonManHours of station that not exist
     *
     * @param rodAndRonManHrsEntity of Both LAA and LUS
     * @param finalRecord           is to store values LUS and LAA ManHrs depending on station
     */
    protected void createCombinedRodPriority2and3(RodAndRonManHrsEntity rodAndRonManHrsEntity, Map<String,
            RodAndRonManHours> finalRecord) {

        RodAndRonManHours ronAndRodManHours = new RodAndRonManHours();
        ronAndRodManHours.setStation(rodAndRonManHrsEntity.getStation());

        if (rodAndRonManHrsEntity.getPriorityCode() == 0) {
            ronAndRodManHours.setRodPriority0(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
        if (rodAndRonManHrsEntity.getPriorityCode() == 2 || rodAndRonManHrsEntity.getPriorityCode() == 1) {
            ronAndRodManHours.setRodPriority1And2(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        } else if (rodAndRonManHrsEntity.getPriorityCode() == 3) {
            ronAndRodManHours.setRodPriority3(rodAndRonManHrsEntity.getTotalManHrsOfpriorityCode());
        }
        //insert a fresh record
        finalRecord.put(rodAndRonManHrsEntity.getStation(), ronAndRodManHours);
    }

}
