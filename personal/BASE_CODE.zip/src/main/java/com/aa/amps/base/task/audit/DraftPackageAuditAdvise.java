package com.aa.amps.base.task.audit;

import com.aa.amps.base.task.TaskEntity;
import com.aa.amps.base.task.TaskRepository;
import com.aa.amps.base.task.WorkPackageEntity;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.task.TaskConstants.*;
import static com.aa.amps.base.util.BaseRepositoryConstants.*;
import static com.aa.amps.base.util.UserIdUtil.shortenUserIdTo6Characters;

/**
 * Aop class to log the audit for save/update draft package.
 *
 * @author HCL(296319)
 * @link TaskRepository.java
 * @since 09/26/2018.
 */
@Component
@Aspect
@EnableAspectJAutoProxy(exposeProxy = true)
public class DraftPackageAuditAdvise {

    private static final Logger LOGGER = LoggerFactory.getLogger(DraftPackageAuditAdvise.class);

    private TaskRepository taskRepository;
    private DraftPackageAuditRepository draftPackageAuditRepository;

    public DraftPackageAuditAdvise(TaskRepository taskRepository, DraftPackageAuditRepository draftPackageAuditRepository) {
        this.taskRepository = taskRepository;
        this.draftPackageAuditRepository = draftPackageAuditRepository;
    }

    /**
     * Audit : save base draft package.
     *
     * @param workPkgEntity Entity saved to the database
     * @param workPkgId     Work Package ID
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.saveBaseDraft(..)) && args(workPkgEntity, workPkgId)")
    public void auditSaveBaseDraft(final WorkPackageEntity workPkgEntity, final Long workPkgId) {
        LOGGER.debug("Inside auditSaveBaseDraft()");
        Map<String, Object> parameterMap = taskRepository.getWorkPkgParameterMap(workPkgEntity, workPkgId);
        int rowCount;
        if (!CollectionUtils.isEmpty(parameterMap)) {
            rowCount = draftPackageAuditRepository.createDraftPackageAudit(parameterMap);
            LOGGER.debug("auditSaveBaseDraft : updated row count {}", rowCount);
        }
    }

    /**
     * Audit : update base draft package.
     *
     * @param workPkgEntity Entity saved to the database
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.updateWorkPackageEntity(..)) && args(workPkgEntity)")
    public void auditUpdateBaseDraft(final WorkPackageEntity workPkgEntity) {
        LOGGER.debug("Inside auditUpdateBaseDraft()");
        Map<String, Object> parameterMap = taskRepository.getWorkPkgParameterMap(workPkgEntity, workPkgEntity.getWorkPkgId());

        int rowCount;
        if (null != parameterMap && !parameterMap.isEmpty()) {
            rowCount = draftPackageAuditRepository.createDraftPackageAudit(parameterMap);
            LOGGER.debug("auditUpdateBaseDraft : updated row count {}", rowCount);
        }
    }

    /**
     * Audit : delete base draft package.
     *
     * @param workPkgId for which draft has to be deleted
     * @param userId    deleted the draft
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.deleteWorkPackageEntity(..)) && args(workPkgId, userId)")
    public void auditDeleteBaseDraft(final Long workPkgId, final String userId) {
        LOGGER.debug("Inside auditDeleteBaseDraft()");

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(WORK_PACKAGE_ID, workPkgId);
        parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));
        parameterMap.put(WORK_PACKAGE_TASK_STATUS, DELETE);

        int rowCount;
        rowCount = draftPackageAuditRepository.createDraftPackageAuditForDelete(parameterMap);
        LOGGER.debug("auditDeleteBaseDraft : updated row count {}", rowCount);

    }

    /**
     * Audit : save base draft package Tasks.
     *
     * @param taskEntities Entity saved to the database
     * @param workPkgId    Work Package ID
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.saveWorkPkgDraftTasks(..)) && args(taskEntities, workPkgId)")
    public void auditSaveBaseDraftTasks(final List<TaskEntity> taskEntities, final Long workPkgId) {
        LOGGER.debug("Inside auditSaveBaseDraftTasks()");
        final List<Map<String, Object>> insertParameterMapList
                = taskRepository.getWorkPkgDraftTasksMaps(taskEntities, workPkgId, CREATE);
        int[] rowCount;
        if (!CollectionUtils.isEmpty(insertParameterMapList)) {
            rowCount = draftPackageAuditRepository.createDraftPackageTaskAudit
                    (insertParameterMapList.toArray(new HashMap[insertParameterMapList.size()]));
            LOGGER.debug("auditSaveBaseDraftTasks : insert row count {}", rowCount);
        }
    }

    /**
     * Audit : update draft package task.
     *
     * @param taskEntities Entity saved to the database
     * @param workPkgId    Work Package ID
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.updateWorkPkgDraftTasks(..)) && args(taskEntities,workPkgId)")
    public void auditUpdateWorkPkgDraftTasks(List<TaskEntity> taskEntities, Long workPkgId) {
        LOGGER.debug("Inside auditSaveBaseDraftTasks()");
        final List<Map<String, Object>> updateParameterMapList
                = taskRepository.getWorkPkgDraftTasksMaps(taskEntities, workPkgId, UPDATE);
        int[] rowCount;
        if (!CollectionUtils.isEmpty(updateParameterMapList)) {
            rowCount = draftPackageAuditRepository.createDraftPackageTaskAudit
                    (updateParameterMapList.toArray(new HashMap[updateParameterMapList.size()]));
            LOGGER.debug("auditSaveBaseDraftTasks : insert row count {}", rowCount);
        }
    }

    /**
     * Audit : delete draft package task.
     *
     * @param dbTaskEntityMap DB Entity which has to be deleted in the database
     * @param workPkgId       Work package ID
     * @param userId          User ID
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.deleteTaskFromWorkPkg(..)) && args" +
            "(dbTaskEntityMap, workPkgId, userId)")
    public void auditDeleteBaseDraftTask(Map<String, Object> dbTaskEntityMap, Long workPkgId, String userId) {
        LOGGER.debug("Inside auditDeleteBaseDraftTask()");

        final List<Map<String, Object>> deleteParameterMapList = new ArrayList<>();
        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(WORK_PACKAGE_ID, workPkgId);
        parameterMap.put(DELETED, DELETE);

        new ArrayList<>(dbTaskEntityMap.keySet()).forEach(taskId -> {
            parameterMap.put(TASK_ID, taskId);
            parameterMap.put(AIRCRAFT_NUMBER, ((Map) dbTaskEntityMap.get(taskId)).get(AIRCFT_NBR_DB));
            parameterMap.put(WORK_PACKAGE_TASK_STATUS, DELETE);
            parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));
            deleteParameterMapList.add(parameterMap);
        });

        draftPackageAuditRepository.createDraftPackageTaskAudit
                (deleteParameterMapList.toArray(new HashMap[deleteParameterMapList.size()]));
    }

    /**
     * Audit : delete tasks of base draft package.
     *
     * @param workPkgId work package ID for which draft has to be deleted
     * @param userId    of the user who deleted the draft
     */
    @After("execution(public * com.aa.amps.base.task.TaskRepository.deleteAllTasksForWorkPkg(..)) && args(workPkgId, userId)")
    public void auditDeleteBaseDraftTasks(final Long workPkgId, final String userId) {
        LOGGER.debug("Inside auditDeleteBaseDraftTasks()");

        Map<String, Object> parameterMap = new HashMap<>();
        parameterMap.put(WORK_PACKAGE_ID, workPkgId);
        parameterMap.put(USER_ID, shortenUserIdTo6Characters(userId));
        parameterMap.put(WORK_PACKAGE_TASK_STATUS, DELETE);

        int rowCount;
        rowCount = draftPackageAuditRepository.createDraftPackageTaskAuditForDelete(parameterMap);
        LOGGER.debug("auditDeleteBaseDraftTasks : updated row count {}", rowCount);

    }
}