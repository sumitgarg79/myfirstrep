package com.aa.amps.base.mntnctasktypes;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * RowMapper for {{@link MntncTaskTypeEntity}}.
 *
 * @author Sudeep(842019).
 * @since 05/21/2018.
 */
public class MntncTaskTypesRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        MntncTaskTypeEntity mntncTaskTypeEntity = new MntncTaskTypeEntity();
        mntncTaskTypeEntity.setAcftMntncTaskType(rs.getString("AIRCFT_MNTNC_TASK_TYPE_CD"));

        return mntncTaskTypeEntity;
    }
}


