package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiServiceException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Controller class for Fleet endpoints.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/17/2018
 */
@RestController
@RequestMapping("/sharedapi/fleet")
@CrossOrigin
public class FleetController {
    public static final String STATUS = "status";
    public static final String MESSAGE = "message";
    public static final String CACHE_REFRESH_STATUS_SUCCESS = "SUCCESS";
    public static final String CACHE_REFRESH_MESSAGE = "Caches for fleets cleared successfully.";
    private static final Logger LOG = LoggerFactory.getLogger(FleetController.class);
    private FleetService fleetService;

    public FleetController(FleetService fleetService) {
        this.fleetService = fleetService;
    }

    /**
     * GET /fleet endpoint to fetch all fleet codes. E.g., <br>
     * <code>
     * [ "737", "757", "767", "A321", "E190", "MD80", "SP8N", "ZZ" ]
     * </code>
     *
     * @return {@code List} of fleet codes
     */
    @GetMapping
    public List<String> getFleets() {
        LOG.info("Got request to fetch fleet codes.");

        List<String> fleets = fleetService.getFleets();
        LOG.info("Returning fleet codes : {}", fleets);

        return fleets;
    }

    /**
     * GET /fleet/v2  Second version of the Fleet's GET endpoint. It fetches the fleets along with subfleets and airline
     * code. This method takes {@code airlineCd} and {@code fleet} as query params and gets the results fulfilling the
     * conditions. Both the parameters are optional. <b>If no parameter is passed then it returns all the availables
     * fleets.</b>
     *
     * @param airlineCd     the legacy airline code - LAA or LUS - optional
     * @param fleetToSearch the list of fleets to fetch subfleets - optional
     * @return if no query params is passed then list of all fleets along with subfleet and airline code, otherwise
     * details of fleets matching the query params criteria.
     * @throws SharedApiServiceException if there is any error in fetching the fleets details
     */
    @GetMapping("/v2")
    public List<FleetSubfleetEntity> getFleetAndSubfleetWithParams(
            @RequestParam(value = "airlineCd", required = false) String airlineCd,
            @RequestParam(value = "fleet", required = false) Set<String> fleetToSearch) throws SharedApiServiceException {

        LOG.info("Got request to fetch fleet codes with parameters as - airline code: {}, fleet: {}.", airlineCd,
                 fleetToSearch);
        List<FleetSubfleetEntity> fleetSubfleetResponse = null;

        if (StringUtils.isNotEmpty(airlineCd) && !CollectionUtils.isEmpty(fleetToSearch)) {
            //Getting all the fleets and subfleets for provided airline code and fleets list
            fleetSubfleetResponse = fleetService.getFleetSubfleets(airlineCd, new ArrayList<>(fleetToSearch));
        } else if (StringUtils.isNotEmpty(airlineCd)) {
            //Getting all the fleets and subfleets for provided airline code
            fleetSubfleetResponse = fleetService.getFleetSubfleets(airlineCd);
        } else if (!CollectionUtils.isEmpty(fleetToSearch)) {
            //Getting all the fleets and subfleets for provided fleets list
            fleetSubfleetResponse = fleetService.getFleetSubfleets(new ArrayList<>(fleetToSearch));
        } else {
            // Getting all the fleets and subfleets
            fleetSubfleetResponse = fleetService.getFleetSubfleets();
        }

        LOG.info("Returning total of {} fleets", fleetSubfleetResponse.size());

        return fleetSubfleetResponse;
    }

    /**
     * POST /fleet endpoint to refresh the caches of fleets.
     *
     * @return status and message confirming cache refresh
     * @throws SharedApiServiceException if there is any error in fetching fleets from repository
     */
    @PostMapping
    public Map<String, String> refreshFleets() throws SharedApiServiceException {
        LOG.info("Got request to refresh the fleets cache.");
        fleetService.refreshFleets();

        List<FleetSubfleetEntity> fleets = fleetService.getFleetSubfleets();

        LOG.info("Loaded fleets from DB. Number of fleets loaded = {}", fleets != null ? fleets.size() : 0);

        LOG.info("Cache refresh is complete.");

        Map<String, String> response = new HashMap<>();
        response.put(STATUS, CACHE_REFRESH_STATUS_SUCCESS);
        response.put(MESSAGE, CACHE_REFRESH_MESSAGE);

        return response;
    }
}
