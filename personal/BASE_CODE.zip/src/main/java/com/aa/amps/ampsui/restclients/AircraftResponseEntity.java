package com.aa.amps.ampsui.restclients;

import lombok.Data;

/**
 * Data class for storing response from Aircraft API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/8/2019
 */
@Data
public class AircraftResponseEntity {
    private String aircraftNumber;
    private String fleet;
    private String subfleet;
    private String airlineCode;
    private String sceptreFleetCode;
}
