package com.aa.amps.ampsui.masterdata;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

/**
 * Controller class for all the URIs(End-points) associated with master data functionality.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@RestController
@CrossOrigin
@RequestMapping("/ampsui/masterdata")
public class MasterDataController {
    private static final Logger LOG = LoggerFactory.getLogger(MasterDataController.class);

    private MasterDataService masterDataService;

    public MasterDataController(MasterDataService masterDataService) {
        this.masterDataService = masterDataService;
    }

    /**
     * /GET /ampsui/masterdata
     * <p>
     * Gets the master data for AMPS line UI. Please see the {@link MasterDataResponse} for the object structure.
     *
     * @param airlineCode LAA or LUS, it's an optional field
     * @return master data containing the fleet, subfleet, aircraft and stations
     */
    @GetMapping
    public MasterDataResponse getMasterData(@RequestParam(value = "airlineCd", required = false) String airlineCode) {
        LOG.info("getMasterData() - Got request to fetch master data for airline - {}", airlineCode);

        return masterDataService.getMasterData(airlineCode);
    }
}
