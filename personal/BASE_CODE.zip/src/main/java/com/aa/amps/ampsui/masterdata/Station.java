package com.aa.amps.ampsui.masterdata;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Bean class for Station data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Station {
    private String stationCode;
    private String stationName;

    /**
     * Default constructor
     */
    public Station() {
    }

    /**
     * Parameterized constructor.
     *
     * @param stationCode station code e.g., DFW
     */
    public Station(String stationCode) {
        this.stationCode = stationCode;
    }
}
