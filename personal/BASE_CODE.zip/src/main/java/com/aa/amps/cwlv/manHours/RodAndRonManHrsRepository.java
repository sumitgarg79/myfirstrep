package com.aa.amps.cwlv.manHours;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.cwlv.manHours.ManHoursSqlQuery.*;


/**
 * Repository class for {@link com.aa.amps.cwlv.manHours.RodAndRonManHrsEntity}. It provides the interfaces for CRUD operations
 * on the entity.
 *
 * @author Ramesh Rudra(842020)
 * @since 4/17/2018.
 */
@Repository
public class RodAndRonManHrsRepository {

    private static final Logger LOG = LoggerFactory.getLogger(RodAndRonManHrsRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    RodAndRonManHrsRepository(
            @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }


    /**
     * Gets all the data of LusRonManHrs.
     *
     * @param date is passed as String to pull record of particular date.
     * @return {@code List} of RodAndRonManHrsEntity records
     */
    public List<RodAndRonManHrsEntity> getLusRonManHrs(String date) {
        List<RodAndRonManHrsEntity> result = null;
        Map<String, String> param = new HashMap<>();
        param.put("date", date);

        LOG.debug("RON Manhour LUS query - {}", RON_MANHRS_LUS_QUERY);
        LOG.debug("Querying LAA man hours for date {}", date);

        result = namedJdbcTemplate.query(RON_MANHRS_LUS_QUERY, param, new LusRodAndRonManHrsMapper());
        if (CollectionUtils.isEmpty(result)) {
            LOG.debug("Got null/empty response for LUS_RON ManHrs repository");
        }

        return result;
    }

    /**
     * Gets all the data of LusRodManHrs.
     *
     * @param date is passed as String to pull record of particular date.
     * @return {@code List} of RodAndRonManHrsEntity records
     */
    public List<RodAndRonManHrsEntity> getLusRodManHrs(String date) {
        List<RodAndRonManHrsEntity> result = null;
        Map<String, String> param = new HashMap<>();
        param.put("date", date);

        LOG.debug("ROD Manhour LUS query - {}", ROD_MANHRS_LUS_QUERY);
        LOG.debug("Querying LAA man hours for date {}", date);

        result = namedJdbcTemplate.query(ROD_MANHRS_LUS_QUERY, param, new LusRodAndRonManHrsMapper());
        if (CollectionUtils.isEmpty(result)) {
            LOG.debug("Got null/empty response for LUS_ROD ManHrs repository");
        }

        return result;
    }


    /**
     * Gets all the data of LaaRonManHrs.
     *
     * @param date is passed as String to pull record of particular date.
     * @return {@code List} of RodAndRonManHrsEntity records
     */
    public List<RodAndRonManHrsEntity> getLaaRonManHrs(String date) {
        List<RodAndRonManHrsEntity> result = null;
        Map<String, String> param = new HashMap<>();
        param.put("date", date);

        LOG.debug("RON Manhour LAA query - {}", RON_MANHRS_LAA_QUERY);
        LOG.debug("Querying LAA man hours for date {}", date);

        result = namedJdbcTemplate.query(RON_MANHRS_LAA_QUERY, param, new LaaRodAndRonManHrsMapper());

        if (CollectionUtils.isEmpty(result)) {
            LOG.debug("Got null/empty response for LAA_RON ManHrs repository ");

        }

        return result;
    }
}
