package com.aa.amps.cwlv.cwlgrid.lus;

import com.aa.amps.cwlv.exception.TaskRepositoryException;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetailMapper;
import com.aa.amps.cwlv.cwlgrid.util.RepositoryConstants;
import com.aa.amps.cwlv.util.Constants;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * Repository class for retrieving TaskDetails for the LUS based on the searchCriteria submitted.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Repository
public class LUSTaskRepository {

    private static final Logger LOG = LoggerFactory.getLogger(LUSTaskRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    /**
     * Access modifier for this constructor intentionally kept as package, so can only be accessed through
     * service class.
     *
     * @param namedJdbcTemplate
     */
    LUSTaskRepository(@Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {

        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Builds and execute the SQL Query to retrieves the TaskDetails for LUS based on the searchCriteria.
     *
     * @param searchCriteria - holds all the input values to the query.
     * @return {@code List} of CombinedTaskDetails for LUS
     */
    public List<CombinedTaskDetail> getCombinedTasksDetails(final Map<String, Object> searchCriteria) {
        if (null == searchCriteria) {
            throw new TaskRepositoryException(TaskRepositoryException.NULL_SEARCH_CRITERIA);
        }

        if (searchCriteria.isEmpty()) {
            throw new TaskRepositoryException(TaskRepositoryException.EMPTY_SEARCH_CRITERIA);
        }

        Map<String, Object> parameterMap = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        sql.append(LUSQueryBuilder.LUS_QUERY_1);

        appendQueryConditions(searchCriteria, parameterMap, sql);
        appendQueryConditionsForType(searchCriteria, parameterMap, sql);
        appendQueryConditionsForRodRon(searchCriteria, parameterMap, sql);

        sql.append(" ORDER BY aircftNbr ASC");
        LOG.debug("LUS CombinedTask SQL Query - {}", sql);

        List<String> parameterMapList = new ArrayList<>();
        parameterMap.forEach((k,v) -> parameterMapList.add(k + "=" + v));
        LOG.debug("LUS CombinedTask SQL Query parameter map values - {} ", parameterMapList);

        return (List<CombinedTaskDetail>) namedJdbcTemplate.query(sql.toString(), parameterMap, new CombinedTaskDetailMapper());
    }

    /**
     * To append the query parameter's to the sql query builder for the following conditions -
     * acftNumber, mntncId , taskStatusPlanned, schdDt, stnCd.
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryConditions(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        if (searchCriteria.containsKey(Constants.PLANNED_DATE_FROM) && searchCriteria.containsKey(Constants.PLANNED_DATE_TO)) {
            sql.append(" AND TRUNC(wp.MNTNC_WORK_PKG_SCHD_DT) BETWEEN TO_DATE(:fromDate , 'MM/DD/YYYY') AND TO_DATE" +
                    "(:toDate, 'MM/DD/YYYY')");
            parameterMap.put("fromDate", searchCriteria.get(Constants.PLANNED_DATE_FROM));
            parameterMap.put("toDate", searchCriteria.get(Constants.PLANNED_DATE_TO));
        } else {
            throw new TaskRepositoryException(TaskRepositoryException.PLANNED_DATE_MISSING);
        }

        if (searchCriteria.containsKey(Constants.AIRCRAFT_NO)) {
            sql.append(" AND task.AIRCFT_NBR in (:acftNumber) ");
            parameterMap.put("acftNumber", searchCriteria.get(Constants.AIRCRAFT_NO));
        }

        if (searchCriteria.containsKey(Constants.FLEET_CODE)) {
            sql.append(" AND fleet.FLEET_CD in (:fleetCode) ");
            parameterMap.put("fleetCode", searchCriteria.get(Constants.FLEET_CODE));
        }

        if (searchCriteria.containsKey(Constants.STATION_PLANNED)) {
            sql.append(" AND wp.PLAN_MNTNC_STN_CD in (:stationPlanned)");
            parameterMap.put("stationPlanned", searchCriteria.get(Constants.STATION_PLANNED));
        }

        if (searchCriteria.containsKey(Constants.MNTNC_ID)) {
            sql.append(" AND task.AIRCFT_MNTNC_TASK_ID like (:mntncId) ");
            parameterMap.put("mntncId", "%" + searchCriteria.get(Constants.MNTNC_ID) + "%");
        }
    }

    /**
     * To append the query parameters to the sql query builder for the following conditions -
     * Type - CHK (ME8 + 'CKC' From Task Description )
     * Type - MTC (ME8/MEL/MON/NEF (except ME8 + CKC))
     * Type - ECO (ESI/PSI/TSI)
     * Type - ALL ( query return resultset for all above types)
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryConditionsForType(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        if (searchCriteria.containsKey(Constants.MNTNC_TYPE)) {
            List<String> typeCds = (List<String>) searchCriteria.get(Constants.MNTNC_TYPE);
            boolean isORNeeded = false;

            sql.append(" AND ( ");

            boolean isChkAndMntncSelected = verifyChkAndMntncInRequest(typeCds);
            if (isChkAndMntncSelected) {
                sql.append(" task.AIRCFT_MNTNC_TASK_TYPE_CD in (:mntncTypeCd) ");
                parameterMap.put("mntncTypeCd", Arrays.asList(RepositoryConstants.LUS_MTC_ITEMS));
                isORNeeded = true;
            }

            for (String typeCD : typeCds) {
                if (StringUtils.equalsIgnoreCase(typeCD, Constants.CHK) && !isChkAndMntncSelected) {
                    sql.append(" ( task.AIRCFT_MNTNC_TASK_TYPE_CD in (:mntncTypeCdCHK) ");
                    sql.append(" AND task.AIRCFT_MNTNC_TASK_DESC like (:mntncTypeDesc) ) ");

                    parameterMap.put("mntncTypeCdCHK", RepositoryConstants.ME8);
                    parameterMap.put("mntncTypeDesc", RepositoryConstants.CKC + "%");
                    isORNeeded = true;
                } else if (StringUtils.equalsIgnoreCase(typeCD, Constants.MTC) && !isChkAndMntncSelected) {
                    sql.append(" ( task.AIRCFT_MNTNC_TASK_TYPE_CD in (:mntncTypeCdMTC) ");
                    sql.append(" AND task.AIRCFT_MNTNC_TASK_DESC not like (:mntncTypeDesc) ) ");

                    parameterMap.put("mntncTypeCdMTC", Arrays.asList(RepositoryConstants.LUS_MTC_ITEMS));
                    parameterMap.put("mntncTypeDesc", RepositoryConstants.CKC + "%");
                    isORNeeded = true;
                } else if (StringUtils.equalsIgnoreCase(typeCD, Constants.ECO)) {
                    if (isORNeeded) {
                        sql.append(" OR ");
                    }
                    sql.append(" task.AIRCFT_MNTNC_TASK_TYPE_CD in (:mntncTypeCdECO) ");
                    parameterMap.put("mntncTypeCdECO", Arrays.asList(RepositoryConstants.LUS_ECO_ITEMS));
                } else {
                    /* This means either ALL or None is selected for Type - query will return everything.
                        So intentionally ignoring this block.
                     */
                }
            }

            sql.append(" ) ");
        }
    }

    /**
     * This method to verify if both CHK and MNTNC items got selected, in which case we return all MNTNC Items.
     *
     * @param {@List typeCds} such as 2 for CHK and 3 for MTC
     * @return true if both chk and mntnc is true, else false
     */
    private boolean verifyChkAndMntncInRequest(List<String> typeCds) {
        boolean isChkAndMntnc = false;
        boolean isChk = false;
        boolean isMntnc = false;

        for (String typeCd : typeCds) {
            if (typeCd.equalsIgnoreCase(Constants.CHK))
                isChk = true;
            else if (typeCd.equalsIgnoreCase(Constants.MTC))
                isMntnc = true;
        }

        if (isChk && isMntnc)
            isChkAndMntnc = true;

        return isChkAndMntnc;
    }

    /**
     * To append the query parameters to the sql query builder for the following conditions -
     * Rod/Ron/All. If nothing selected by default it will be queried with 'All' option.
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryConditionsForRodRon(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        String rodRonStr = (String) searchCriteria.get(Constants.ROD_RON);

        sql.append(" AND (");
        if (StringUtils.equalsIgnoreCase(rodRonStr, Constants.ROD)) {
            appendRODTrackTypes(parameterMap, sql);
        } else if (StringUtils.equalsIgnoreCase(rodRonStr, Constants.RON)) {
            appendRONTrackTypes(parameterMap, sql);
        } else {
            appendRODTrackTypes(parameterMap, sql);
            sql.append(" OR ");
            appendRONTrackTypes(parameterMap, sql);
        }
        sql.append(" )");
    }

    /**
     * To append the ROD track types to the sql query.
     *
     * @param parameterMap - holds the parameter values for the sql query
     * @param sql          - query string
     */
    private void appendRONTrackTypes(Map<String, Object> parameterMap, StringBuilder sql) {
        sql.append(" (wp.WORK_PKG_TRACK_TYPE_CD IN (:ronTrackTypes)");
        sql.append(" AND (ars.FLIGHT_CATG_TYPE_CD IS NULL");
        sql.append(" OR ars.FLIGHT_CATG_TYPE_CD = 'T'))");

        parameterMap.put("ronTrackTypes", Arrays.asList(RepositoryConstants.RON_WORK_PKG_TRACKTYPE_CD));
    }

    /**
     * To append the ROD track types to the sql query.
     *
     * @param parameterMap - holds the parameter values for the sql query
     * @param sql          - query string
     */
    private void appendRODTrackTypes(Map<String, Object> parameterMap, StringBuilder sql) {
        sql.append(" (wp.WORK_PKG_TRACK_TYPE_CD IN (:rodTrackTypes)");
        sql.append(" AND ars.FLIGHT_CATG_TYPE_CD = 'D'");
        sql.append("  AND wp.flight_nbr = ars.schd_flight_nbr");
        sql.append("  AND ars.FLIGHT_CATG_TYPE_CD != 'T')");
        parameterMap.put("rodTrackTypes", Arrays.asList(RepositoryConstants.ROD_WORK_PKG_TRACKTYPE_CD));
    }

}
