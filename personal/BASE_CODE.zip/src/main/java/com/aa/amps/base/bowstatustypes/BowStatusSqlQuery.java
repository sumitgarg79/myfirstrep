package com.aa.amps.base.bowstatustypes;

/**
 * SQL Query Constant for {@link BowStatusRepository} .
 *
 * @author Paul Verner(650196):American Airlines
 * @since 06/06/2018.
 */
public class BowStatusSqlQuery {
    /**
     * Private default constructor to prevent any instantiation.
     */
    private BowStatusSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    /**
     * Query to get all the base BOW Status types from database table: SYS_PARMTR_NM
     * Currently defined by Business as : "DRAFT", "FINALIZED".
     */
    public static final String SELECT_BOW_STATUS_TYPES =
            "SELECT SYS_PARMTR_VAL FROM SYS_PARMTR WHERE SYS_PARMTR_NM = 'BASE_BOW_STATUS_TYPES'";
}
