package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.task.WorkPackageEntity;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link WorkPackageEntity}.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 */
public class StatusSearchRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        WorkPackageEntity workPackageEntity = new WorkPackageEntity();

        workPackageEntity.setWorkPkgId((rs.getLong("DRAFT_WORK_PKG_ID")));
        workPackageEntity.setWorkPkgTxt(rs.getString("DRAFT_WORK_PKG_TXT"));
        workPackageEntity.setPkgSchdDt(rs.getString("DRAFT_PKG_SCHD_DT"));
        workPackageEntity.setPlanStationCd(rs.getString("DRAFT_PLAN_STN_CD"));
        workPackageEntity.setUserId(rs.getString("UPDATE_USER_ID"));
        workPackageEntity.setUpdatedTime(rs.getString("LAST_UPDATE_TIME"));
        workPackageEntity.setWorkPkgStatusCd(rs.getString("DRAFT_WORK_PKG_STATUS_CD"));
        workPackageEntity.setComments(rs.getString("COMMENTS"));

        return workPackageEntity;
    }

}
