package com.aa.amps.base.task;

import com.aa.amps.base.util.TaskUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link TaskEntity}.
 *
 * @author Paul Verner (650196)
 * @since 6/08/2018.
 */
public class TaskRowMapper implements RowMapper {
    private static final String T_STRING = "T";
    private static final String U_STRING = "U";
    private static final String BLANK_STRING = "";

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        TaskEntity taskEntity = new TaskEntity();

        taskEntity.setTaskId(rs.getString("AIRCFT_MNTNC_TASK_ID"));
        taskEntity.setAircraftNbr(rs.getString("AIRCFT_NBR"));
        taskEntity.setStatus(rs.getString("MNTNC_TASK_STATUS_TYPE_CD"));
        taskEntity.setPriority(rs.getString("MNTNC_TASK_PRIOR_TYPE_CD"));
        taskEntity.setDescription(rs.getString("AIRCFT_MNTNC_TASK_DESC"));

        taskEntity.setForecastDateAsString(rs.getString("FORECAST_DT"));
        taskEntity.setTtgHours(rs.getInt("MNTNC_REMAIN_HR_QTY"));
        taskEntity.setTtgDays(rs.getInt("MNTNC_REMAIN_DAY_QTY"));
        taskEntity.setTtgCycles(rs.getInt("MNTNC_REMAIN_CYCLE_QTY"));
        taskEntity.setManHours(rs.getInt("MNTNC_REQUIR_MECH_HR_QTY"));
        if (U_STRING.equals(rs.getString("ROUTE_CNTRL_TYPE_CD"))) {
            taskEntity.setRouteControlCode(BLANK_STRING);
        } else {
            taskEntity.setRouteControlCode(rs.getString("ROUTE_CNTRL_TYPE_CD"));
        }
        taskEntity.setDeferralLockInd(setBooleanFromTF(rs, "MNTNC_DFRL_LOCK_IND"));
        taskEntity.setAtaCode(rs.getString("ATA_CHAPTR_SECTN_CD"));
        taskEntity.setDni(setBooleanFromTF(rs, "MNTNC_TASK_DO_NOT_ISSUE_IND"));
        taskEntity.setPlannedDateAsString(rs.getString("MNTNC_WORK_PKG_SCHD_DT"));
        taskEntity.setPlannedStation(rs.getString("PLAN_MNTNC_STN_CD"));
        taskEntity.setFleetCode(rs.getString("FLEET_CD"));
        taskEntity.setWorkControl(rs.getInt("SCEPTRE_MNTNC_WORK_PKG_ID"));
        taskEntity.setSoftTimes(rs.getString("MNTNC_TASK_PLAN_FLEX_IND"));

        taskEntity.setForecastDtgCategory(TaskUtil.determineForecastDaysToGoCategory(taskEntity.getForecastDateAsString()));

        String trackTypeCode = rs.getString("WORK_PKG_TRACK_TYPE_CD");
        taskEntity.setBowType(TaskUtil.determineBowType(trackTypeCode));

        // for ME8 subtypes, set taskType based on first 3 characters of description
        taskEntity.setTaskTypeCode(TaskUtil.determineTaskType(rs.getString("AIRCFT_MNTNC_TASK_TYPE_CD"), taskEntity.getDescription()));

        return taskEntity;
    }

    private boolean setBooleanFromTF(ResultSet rs, String columnName) throws SQLException {
        return T_STRING.equals(rs.getString(columnName));
    }

}