package com.aa.amps.ampsui.masterdata;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Bean for the Aircraft API response.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Data
@AllArgsConstructor
public class Aircraft {
    private String aircraftNumber;
}
