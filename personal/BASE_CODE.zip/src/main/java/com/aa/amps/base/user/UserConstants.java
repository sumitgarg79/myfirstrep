package com.aa.amps.base.user;

/**
 * This class holds all User domain related constants.
 *
 * @author Paul Verner
 * @since 09/20/2018
 */
public class UserConstants {
    public static final String USER_ID = "userId";
    public static final String EMP_ID = "empId";
    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";

    private UserConstants() {
        throw new IllegalStateException("Utility class");
    }
}
