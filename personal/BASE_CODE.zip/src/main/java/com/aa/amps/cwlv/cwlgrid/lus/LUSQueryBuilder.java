package com.aa.amps.cwlv.cwlgrid.lus;

/**
 * This class holds all the static query strings used in LUS SQL Query.
 *
 * @author Naseer Mohammed (842018)
 * @since 04/23/2018
 */
public class LUSQueryBuilder {

    public static final String LUS_QUERY_1 = "SELECT " +
            "  task.AIRCFT_NBR as aircftNbr," +
            "  'SCPT'  AS logo," +
            "  fleet.FLEET_CD AS fleetCd," +
            "  wp.PLAN_MNTNC_STN_CD AS stnCd," +
            "  task.AIRCFT_MNTNC_TASK_ID AS taskId," +
            "  task.AIRCFT_MNTNC_TASK_DESC AS taskDesc," +
            "  task.AIRCFT_MNTNC_TASK_TYPE_CD AS taskTypeCd," +
            "  wp.MNTNC_WORK_PKG_SCHD_DT AS schdDt," +
            "  task.MNTNC_TASK_DUE_DT AS forecastDt," +
            "  CASE " +
            "  WHEN (ars.FLIGHT_CATG_TYPE_CD is null or ars.FLIGHT_CATG_TYPE_CD = 'T') " +
            "  then 'RON'" +
            "  else 'ROD' " +
            "  end AS rodRon," +
            "  task.mntnc_remain_cycle_qty  AS remainCycle," +
            "  task.mntnc_remain_day_qty  AS remainDay," +
            "  task.mntnc_remain_hr_qty  AS remainHr," +
            "  task.mntnc_requir_mech_hr_qty AS mechHour," +
            "  ars.schd_flight_nbr    AS flightNbr," +
            "  ars.flight_dep_tm_txt  AS etd," +
            "  ars.flight_arvl_tm_txt AS eta," +
            "  ars.aircft_ground_tm_qty AS groundTime," +
            "  DECODE(task.MNTNC_TASK_PRIOR_TYPE_CD, NULL, '3', task.MNTNC_TASK_PRIOR_TYPE_CD)AS priority" +
            "  FROM AIRCFT_MNTNC_TASK_PLAN task" +
            " JOIN MNTNC_WORK_PKG wp" +
            " ON task.AIRCFT_NBR = wp.AIRCFT_NBR" +
            " AND task.MNTNC_WORK_PKG_ID = wp.MNTNC_WORK_PKG_ID" +
            " JOIN AIRCFT_REFRNC aircft" +
            " ON aircft.AIRCFT_NBR = task.AIRCFT_NBR" +
            " JOIN FLEET_GUI fleet" +
            " on aircft.AIRCFT_TYPE_EQUIP_CD = fleet.AIRCFT_TYPE_EQUIP_CD" +
            " LEFT JOIN AIRCFT_ROUTE_SCHD ars" +
            " ON wp.AIRCFT_NBR = ars.AIRCFT_NBR" +
            " AND wp.MNTNC_WORK_PKG_SCHD_DT =" +
            "  CASE " +
            "    WHEN ars.flight_arvl_tm_txt < '0300'" +
            "    THEN TRUNC(ars.FLIGHT_ARVL_DT-1)" +
            "    ELSE TRUNC(ars.FLIGHT_ARVL_DT)" +
            "  END " +
            " AND wp.PLAN_MNTNC_STN_CD = ars.FLIGHT_DESTNTN_STN_CD" +
            " AND ( wp.FLIGHT_NBR = ars.schd_flight_nbr or ars.FLIGHT_CATG_TYPE_CD = 'T')" +
            " WHERE task.MNTNC_TASK_STATUS_TYPE_CD != 'CLOSE'" +
            " AND task.MNTNC_TASK_DEL_IND != 'T'" +
            " AND aircft.AIRCFT_DEL_IND = 'F'";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private LUSQueryBuilder() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
