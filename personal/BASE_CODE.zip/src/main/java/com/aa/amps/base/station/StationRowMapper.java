package com.aa.amps.base.station;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link StationEntity}.
 *
 * @author HCL(922166)
 * @since 5/21/2018.
 */
public class StationRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        StationEntity stationEntity = new StationEntity();

        stationEntity.setMntncStnCd(rs.getString("MNTNC_STN_CD"));
        stationEntity.setMntncStnTypCd(rs.getString("MNTNC_STN_TYPE_CD"));
        stationEntity.setMntncStnAliasCd(rs.getString("MNTNC_STN_ALIAS_CD"));

        return stationEntity;
    }
}
