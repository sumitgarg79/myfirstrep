package com.aa.amps.ampsui.messagebrowser;

import com.aa.amps.cwlv.util.Constants;
import lombok.Data;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.*;

/**
 * This class contains the properties required for Message Browser filter criteria that is received from UI.
 * <p>
 * Created by Ramesh Rudra(842020) on 1/10/2019.
 * </p>
 */
@Data
public class MessageBrowserRequest {

    private String stationCode;
    private String aircraftNumber;
    private String[] fleets;
    private String subFleets;
    private String beginDate;
    private String endDate;
    private String postedAfter;
    private String userId;
    private String sortedItems;
    private String smSession;
    private String airlineCode;


    /**
     * Creates a {@code Map} representation of this class properties and their value.
     *
     * @return {@code map} with class properties
     */
    public Map<String, Object> getSearchCriteriaAsMap() {
        Map<String, Object> criteria = new HashMap<>();

        if (StringUtils.isNotEmpty(this.stationCode)) {
            criteria.put(Constants.STATION_CODE, this.stationCode.toUpperCase().trim());
        }

        if (StringUtils.isNotEmpty(this.aircraftNumber))
            criteria.put("aircraftNumber", this.aircraftNumber.toUpperCase().trim());

        if (ArrayUtils.isNotEmpty(this.fleets)) {
            List<String> fleetsList = Arrays.asList(this.fleets);

            fleetsList.replaceAll(String::trim);
            Collections.sort(fleetsList);

            criteria.put(Constants.FLEET_CODE, fleetsList);
        }

        if (StringUtils.isNotEmpty(this.subFleets))
            criteria.put(Constants.SUB_FLEET_CODE, this.subFleets.toUpperCase().trim());

        if (StringUtils.isNotEmpty(beginDate)) {
            criteria.put(Constants.BEGIN_DATE, this.beginDate);
        }

        if (StringUtils.isNotEmpty(endDate)) {
            criteria.put(Constants.END_DATE, this.endDate);
        }

        if (StringUtils.isNotEmpty(postedAfter)) {
            criteria.put("postedAfter", this.postedAfter);
        }

        if (StringUtils.isNotEmpty(userId)) {
            criteria.put(Constants.USERID, this.userId.trim());
        }

        if (StringUtils.isNotEmpty(smSession)) {
            criteria.put(Constants.SMSESSION, this.smSession);
        }

        if (StringUtils.isNotEmpty(airlineCode)) {
            criteria.put(Constants.AIRLINE_CD, this.airlineCode);
        }

        return criteria;
    }

}
