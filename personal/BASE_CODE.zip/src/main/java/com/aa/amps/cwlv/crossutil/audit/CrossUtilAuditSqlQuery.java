package com.aa.amps.cwlv.crossutil.audit;

/**
 * Query constant class for Cross Util Auditing functionality.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/12/2018.
 */
public class CrossUtilAuditSqlQuery {

    public static final String INSERT_CROSS_UTIL_AUDIT =
        "INSERT INTO CRSS_UTLZD_STN_CAP_AUDIT(" +
            " CRSS_UTLZD_STN_CAP_AUDIT_ID, " +
            " MNTNC_STN_CD, " +
            " CROSS_UTILIZED_FLG, " +
            " ROD_CAPACITY, " +
            " RON_CAPACITY, " +
            " ACTIVE_FLG, " +
            " USER_ID) " +
            " VALUES(" +
            " CRSS_UTLZD_STN_CAP_AUDIT_SEQ.nextval, " +
            " :mntncStnCode, " +
            " :crossUtilFlag, " +
            " :rodCapacity, " +
            " :ronCapacity, " +
            " :activeFlag, " +
            " :userId" +
            ")";

    /**
     * Private constructor to prevent any instantiation.
     */
    private CrossUtilAuditSqlQuery() {
    }
}
