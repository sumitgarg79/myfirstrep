package com.aa.amps.cwlv.cwlgrid.util;

import lombok.Data;

/**
 * This Bean holds query resultset object.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Data
public class CombinedTaskDetail {

    private String aircftNbr;
    private String logo;
    private String fleetCd;
    private String stnCd;

    private String taskId;
    private String taskDesc;
    private String taskTypeCd;
    private String schdDt;

    private String forecastDt;
    private String rodRon;
    private String timeCycle;
    private String mechHour;

    private String flightNbr;
    private String etd;
    private String eta;
    private String groundTime;
    private String priority;

    private String aircftMntncCycle;
    private String aircftMntncHours;
    private String aircftMntncDays;
    private String aircftShipCycles;
    private String aircftShipTime;
    private String avgCyclesPerDay;
    private String avgHoursPerDay;

    private boolean invalidRecord;

    private boolean throughFlight;

    private boolean inconsistentRecord;

    @Override
    public boolean equals(Object obj) {
        boolean isEqual = false;
        if (null != obj) {
            CombinedTaskDetail that = (CombinedTaskDetail) obj;
            isEqual = this.getAircftNbr() == that.getAircftNbr();
        }

        return isEqual;
    }
}
