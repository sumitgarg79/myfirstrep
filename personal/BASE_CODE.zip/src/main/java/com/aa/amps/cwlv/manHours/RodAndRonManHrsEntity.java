package com.aa.amps.cwlv.manHours;


import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * Entity that represents the RodAndRodCapacity data reterieved from AMPS DB.
 *
 * @author RAMESH RUDRA(842020)
 * @since 4/17/2018.
 */
@Repository
@Data
public class RodAndRonManHrsEntity {

    private String station;

    private Long priorityCode;

    private Boolean isRon;

    private Float totalManHrsOfpriorityCode;
}
