package com.aa.amps.cwlv.util;

import java.text.DecimalFormat;

/**
 * This class holds all Business related constants.
 *
 * @author Naseer Mohammed (842018) - 03/23/2018
 * <p>
 * Added constant for ROD/RON or Both - US750399 - Naseer Mohammed (842018) - 04/23/2018
 */
public class Constants {

    public static final String AIRCRAFT_NO = "aircraftNo";
    public static final String TASK_ID = "taskId";
    public static final String MNTNC_TYPE = "mntncType";
    public static final String MNTNC_ID = "mntncId";
    public static final String FLEET_CODE = "fleets";
    public static final String SUB_FLEET_CODE = "subFleets";
    public static final String STATUS_PLANNED = "statusPlanned";
    public static final String TASK_KEYWORD = "taskNameOrDesc";
    public static final String PLANNED_DATE_FROM = "plannedDateFrom";
    public static final String PLANNED_DATE_TO = "plannedDateTo";
    public static final String STATION_PLANNED = "plannedStation";
    public static final String CHECKS_ONLY = "checksOnly";
    public static final String UNDERSCORE = "_";
    public static final String ROD_RON = "rodOrRonOrBoth";
    public static final String RON = "RON";
    public static final String ROD = "ROD";
    public static final String ALL = "1";
    public static final int INDEX = 0;
    public static final String CHK = "2";
    public static final String MTC = "3";
    public static final String ECO = "4";

    public static final DecimalFormat TWO_DECIMAL_PT_FORMAT = new DecimalFormat("#.00");
    public static final String SMSESSION = "smSession";
    public static final String AIRLINE_CD = "airlineCode";

    public static final String MAN_HRS_DATE = "date";
    public static final String USERID = "userId";

    public static final String STATION_CODE = "stationCode";
    public static final String BEGIN_DATE = "beginDate";
    public static final String END_DATE = "endDate";
    public static final String POSTED_AFTER = "postedAfter";

    private Constants() {
        throw new IllegalStateException("Utility class");
    }
}
