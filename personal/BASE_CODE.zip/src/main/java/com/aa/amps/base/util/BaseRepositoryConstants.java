package com.aa.amps.base.util;

/**
 * This class holds all Repository related constants.
 *
 * @author 842018
 * @since 07/10/2018
 */
public class BaseRepositoryConstants {

    public static final String COMMA_DELIM = ",";
    public static final String MM_DD_YYYY = "'MM/DD/YYYY'";
    public static final int INT_ZERO = 0;
    public static final int INT_ONE = 1;
    public static final String HYPHEN = "-";
    public static final String TRUE = "Y";
    public static final String FALSE = "N";
    public static final String CREATE = "C";
    public static final String UPDATE = "U";
    public static final String DELETE = "D";

    private BaseRepositoryConstants() {
        throw new IllegalStateException("Utility class");
    }
}
