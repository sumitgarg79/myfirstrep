package com.aa.amps.base.mntnctasktypes;

/**
 * Query Constant for {@link MntncTaskTypeRepository} .
 *
 * @author Sudeep(842019)
 * @since 05/21/2018.
 */
final class MntncTaskTypesSqlQuery {

    static final String SELECT_ACFT_MNTNC_TASK_TYPES =
            "SELECT AIRCFT_MNTNC_TASK_TYPE_CD " +
                    "FROM AIRCFT_MNTNC_TASK_TYPE ";

    static final String APP_TYPES =
            "WHERE APP_APPLICABLE LIKE ('%' || :appType || '%')";

    private MntncTaskTypesSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}

