package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import lombok.Data;

import java.util.List;

/**
 * Response model class for combined workload view grid. This will be used by the controller to send the response.
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/21/2018.
 */
@Data
public class CwlGridResponse {
    private List<CombinedTaskDetail> cwlvTaskDetailGrid;
    private List<StationCapacitySummary> cwlvStnCapGrid;
}
