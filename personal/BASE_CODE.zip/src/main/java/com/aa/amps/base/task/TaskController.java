package com.aa.amps.base.task;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.exception.TaskDetailException;
import com.aa.amps.base.exception.TaskFilterRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.util.List;

/**
 * REST Controller class for Task functionality.
 *
 * @author Paul Verner(650196):American Airlines
 * @since 05/31/2018
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@RestController
@RequestMapping("/base/task")
@CrossOrigin
public class TaskController {

    private static final Logger LOG = LoggerFactory.getLogger(TaskController.class);
    private TaskService taskService;

    public TaskController(@Autowired TaskService taskService) {
        this.taskService = taskService;
    }

    /**
     * GET request implementation to retrieve Tasks using searchCriteria TaskFilterRequest.
     *
     * @return tasks for searchCriteria
     */
    @PostMapping(path = "/getTasks")
    public List<TaskEntity> getTasks(@RequestBody TaskFilterRequest searchCriteria) throws ParseException, TaskFilterRequestException {
        LOG.info("Got request to get Tasks for searchCriteria: {} ", searchCriteria);

        return taskService.getTasksBySearchCriteria(searchCriteria.getSearchCriteriaAsMap());
    }

    /**
     * GET request implementation to retrieve Tasks using searchCriteria TaskFilterRequest.
     *
     * @return tasks for searchCriteria
     */
    @PostMapping(path = "/getTaskContainer")
    public TaskContainerResponse getTaskContainer(@RequestBody TaskFilterRequest searchCriteria) throws ParseException, TaskFilterRequestException {
        LOG.info("Got request to get getTaskContainer for searchCriteria: {} ", searchCriteria);

        return taskService.getTaskContainerBySearchCriteria(searchCriteria.getSearchCriteriaAsMap());
    }

    /**
     * US756399:[Draft] Functionality for the "Save" button.
     * To save or Update the Base Draft in Database. Will throw the exception in case of duplicate entry without a
     * user action of Merge or Override.
     *
     * @param workPkgEntity for saving data
     * @return {@code true} if draft is saved successful, {@code false} otherwise
     */
    @PostMapping(path = "/baseDraft")
    public boolean saveBaseDraft(@RequestBody WorkPackageEntity workPkgEntity) throws BaseServiceException {
        LOG.info("Got request to save the Draft: {} ", workPkgEntity);

        return taskService.saveBaseDraft(workPkgEntity);
    }

    /**
     * To retrieve Tasks Details for {@link TaskDetailRequest} request.
     *
     * @param taskDetailRequest - {@link TaskDetailRequest} object holds request params
     * @return {@link TaskEntity} list
     */
    @PostMapping(path = "/getTaskDetails")
    public List<TaskEntity> getTaskDetails(@RequestBody TaskDetailRequest taskDetailRequest) throws TaskDetailException {
        LOG.info("Got request to get Task Detail for : {} ", taskDetailRequest);

        return taskService.getTaskDetails(taskDetailRequest.getTaskDetailRequestAsMap());
    }
}
