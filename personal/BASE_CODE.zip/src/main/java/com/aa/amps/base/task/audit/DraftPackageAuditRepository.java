package com.aa.amps.base.task.audit;

import com.aa.amps.base.util.RepositoryUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * Repository class for all CRUD operations related to draft package audit.
 *
 * @author HCL(296319)
 * @since 07/09/2018.
 */
@Repository
class DraftPackageAuditRepository {
    private static final Logger LOG = LoggerFactory.getLogger(DraftPackageAuditRepository.class);
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    DraftPackageAuditRepository(
            @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Method to perform audit of work package.
     *
     * @param parameterMap holds query parameters
     * @return rowCount  number of rows inserted/updated
     */
    int createDraftPackageAudit(Map<String, Object> parameterMap) {
        LOG.debug("createDraftPackageAudit() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));
        int rowCount = namedJdbcTemplate.update(DraftPackageAuditSqlQuery.INSERT_BASE_BOW_DRAFT_AUDIT, parameterMap);
        LOG.debug("createDraftPackageAudit(): total rows inserted work package - {}", rowCount);

        return rowCount;
    }

    /**
     * Method to perform audit of deleted work package.
     *
     * @param parameterMap holds query parameters
     * @return rowCount  number of rows inserted/updated
     */
    int createDraftPackageAuditForDelete(Map<String, Object> parameterMap) {
        LOG.debug("createDraftPackageAuditForDelete() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));
        int rowCount = namedJdbcTemplate.update(DraftPackageAuditSqlQuery.INSERT_BASE_BOW_DRAFT_AUDIT_FOR_DELETE, parameterMap);
        LOG.debug("createDraftPackageAuditForDelete(): total rows inserted work package - {}", rowCount);

        return rowCount;
    }


    /**
     * Method to perform audit of tasks for a work package.
     *
     * @param taskEntityMap holds query parameters
     * @return rowCount  number of rows inserted/updated
     */
    int[] createDraftPackageTaskAudit(Map<String, Object>[] taskEntityMap) {
        int[] rowCount = namedJdbcTemplate.batchUpdate(DraftPackageAuditSqlQuery.INSERT_BASE_BOW_TASKS_AUDIT, taskEntityMap);
        LOG.debug("createDraftPackageTasksAudit(): total rows inserted work package task - {}", rowCount);

        return rowCount;
    }

    /**
     * Method to perform audit of all the tasks as deleted for a work package
     *
     * @param parameterMap holds query parameters
     * @return rowCount  number of rows inserted/updated
     */
    int createDraftPackageTaskAuditForDelete(Map<String, Object> parameterMap) {
        LOG.debug("createDraftPackageTaskAuditForDelete() : SQL Query parameter map values - {} ", RepositoryUtil.getParameterList(parameterMap));
        int rowCount = namedJdbcTemplate.update(DraftPackageAuditSqlQuery.INSERT_BASE_BOW_TASKS_AUDIT_FOR_DELETE, parameterMap);
        LOG.debug("createDraftPackageTaskAuditForDelete(): total rows inserted work package - {}", rowCount);

        return rowCount;
    }
}
