package com.aa.amps.cwlv.exception;

import com.aa.amps.cwlv.util.ServiceResponseMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * ControllerAdvice classes that wish to provide centralized exception handling across all RequestMapping methods
 * through ExceptionHandler methods.
 *
 * @author Ramesh Rudra(842020)
 * Created on 4/06/2018.
 */

@ControllerAdvice(basePackages = "com.aa.amps.cwlv")
@RestController
public class CustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(CustomizedResponseEntityExceptionHandler.class);

    @ExceptionHandler({Exception.class, DataAccessException.class})
    public final ResponseEntity<ServiceResponseMessage> handleAllExceptions(Exception ex, WebRequest request) {
        LOG.error("Stepped in to default exception handler for request - {} ", request.getDescription(true));
        LOG.error("Caught exception in the application", ex);

        ServiceResponseMessage errorMesage = ServiceResponseMessage.getGenericExceptionStatus();
        return new ResponseEntity<>(errorMesage, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * stationNotFound Exception class will send serviceResponseMessage with message and status
     *
     * @param ex      StationNotFoundException whose message will be set to the response
     * @param request WebRequest for setting url
     * @return ResponseEntity
     */
    @ExceptionHandler(StationNotFoundException.class)
    public final ResponseEntity<ServiceResponseMessage> stationNotFoundException(StationNotFoundException ex,
        WebRequest request) {
        ServiceResponseMessage errorMesage = ServiceResponseMessage.getRecordNotFoundStatusOnly();
        errorMesage.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorMesage, HttpStatus.NOT_FOUND);
    }


    /**
     * InvalidDate Exception class will send serviceResponseMessage with message and status
     *
     * @param ex      inValidDateException whose message will be set to the response
     * @param request WebRequest for setting url
     * @return ResponseEntity
     */
    @ExceptionHandler(InValidDateException.class)
    public final ResponseEntity<ServiceResponseMessage> inValidDateException(InValidDateException ex,
        WebRequest request) {
        ServiceResponseMessage errorMesage = ServiceResponseMessage.getRecordNotFoundStatusOnly();
        errorMesage.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorMesage, HttpStatus.BAD_REQUEST);
    }

    /**
     * This method will handle the {@link CrossUtilAuditException} and set the appropriate message and HTTP status.
     *
     * @param ex      {@code CrossUtilAuditException} object whose message will be set to the response
     * @param request WebRequest for setting url
     * @return ResponseEntity with set message and HTTP status
     */
    @ExceptionHandler(CrossUtilAuditException.class)
    public final ResponseEntity<ServiceResponseMessage> crossUtilAuditException(CrossUtilAuditException ex,
        WebRequest request) {
        ServiceResponseMessage errorMesage = ServiceResponseMessage.getRequiredDataMissingStatusOnly();

        errorMesage.setMessage(ex.getMessage());
        return new ResponseEntity<>(errorMesage, HttpStatus.BAD_REQUEST);
    }

    /**
     * This method will handle the {@code RestClientException} thrown from the REST client call to AMPS app. If this
     * exception is thrown then we have a session timeout scenario.
     *
     * @param ex {@code RestClientException} object
     * @param request the REST request object
     * @return {@code ResponseEntity} with status as {@code Exception} and {@code Session Timed Out} message
     */
    @ExceptionHandler(RestClientException.class)
    public final ResponseEntity<ServiceResponseMessage> restClientExceptionHandler(RestClientException ex,
        WebRequest request) {
        LOG.error("Got exception while calling AMPS REST endpoint. It could be due to SMSESSION cookie passed is " +
                      "expired or AMPS is down.", ex);
        ServiceResponseMessage errorMesage = ServiceResponseMessage.getGenericExceptionStatus();

        errorMesage.setMessage(ServiceResponseMessage.ServiceResponseDescription.SESSION_TIMED_OUT.toString());
        errorMesage.setStatusCode(ServiceResponseMessage.ServiceResponseStatusCode.SESSION_TIMED_OUT.toString());

        return new ResponseEntity<>(errorMesage, HttpStatus.UNAUTHORIZED);
    }
}
