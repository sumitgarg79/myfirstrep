package com.aa.amps.base.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Util Class for Repository.
 *
 * @author HCL (922166)
 * @since 07/17/2018
 */
public class RepositoryUtil {

    /**
     * Method to return the parameter Map as parameter list for debug.
     *
     * @param parameterMap Parameter Map
     * @return parameterMapList List of Parameter as key value pair
     */
    public static List<String> getParameterList(Map<String, Object> parameterMap) {
        List<String> parameterMapList = new ArrayList<>();
        parameterMap.forEach((k, v) -> parameterMapList.add(k + "=" + v));

        return parameterMapList;
    }
}
