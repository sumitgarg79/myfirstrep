package com.aa.amps.base.task;

import com.aa.amps.base.exception.TaskDetailException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.apache.commons.lang.ArrayUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.task.TaskConstants.AIRCRAFT_NBRS;
import static com.aa.amps.base.task.TaskConstants.TASK_IDS;

/**
 * This class contains the properties required for taskDetail search criteria that is received from UI.
 *
 * @author Naseer Mohammed(842018)
 * @since 9/13/2018.
 */
@Data
public class TaskDetailRequest {

    private String[] aircraftNbrs;
    private String[] taskIds;

    /**
     * Creates a {@code Map} representation of this class properties and their value.
     *
     * @return {@code map} with class properties
     */
    @JsonIgnore
    public Map<String, Object> getTaskDetailRequestAsMap() throws TaskDetailException {
        Map<String, Object> taskDetailReqMap = new HashMap<>();

        if (ArrayUtils.isNotEmpty(this.aircraftNbrs)) {
            List<String> stationList = Arrays.asList(this.aircraftNbrs);
            taskDetailReqMap.put(AIRCRAFT_NBRS, stationList);
        } else {
            throw new TaskDetailException(TaskDetailException.AIRCRAFT_LIST_MISSING, null);
        }

        if (ArrayUtils.isNotEmpty(this.taskIds)) {
            List<String> taskIdList = Arrays.asList(this.taskIds);
            taskDetailReqMap.put(TASK_IDS, taskIdList);
        } else {
            throw new TaskDetailException(TaskDetailException.TASKID_LIST_MISSING, null);
        }

        return taskDetailReqMap;
    }
}
