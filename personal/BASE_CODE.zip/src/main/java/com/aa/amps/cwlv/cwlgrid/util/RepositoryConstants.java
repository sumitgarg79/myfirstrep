package com.aa.amps.cwlv.cwlgrid.util;

/**
 * @author Naseer Mohammed (842018) - 03/23/2018
 * Added RON/ROD WorkPkgTrackTypeCds - US750399 - Naseer Mohammed (842018) - 04/23/2018
 */

public final class RepositoryConstants {

    public static final String LUS_TASK_STATUS_PLAND = "PLAND";
    public static final String[] RON_WORK_PKG_TRACKTYPE_CD = {"01", "04", "05", "06"};
    public static final String[] ROD_WORK_PKG_TRACKTYPE_CD = {"07", "08", "09"};
    public static final String ME8 = "ME8";
    public static final String CKC = "CKC";
    public static final String[] LUS_MTC_ITEMS = {"ME8", "MEL", "MON", "NEF"};
    public static final String[] LUS_ECO_ITEMS = {"ESI", "PSI", "TSI"};
    public static final String[] LAA_MTC_ITEMS = {"SIC", "FMR", "OTR", "CMP"};
    public static final String[] LAA_TYPE_ALL = {"CHK", "SIC", "FMR", "OTR", "CMP", "ECO"};
    public static final String[] LAA_RON = {"O"};
    public static final String[] LAA_ROD = {"T"};
    public static final String[] LAA_RON_ROD = {"O", "T"};
    public static final String CHK = "CHK";
    public static final String ECO = "ECO";
    private RepositoryConstants() {
        throw new IllegalStateException("Final Constant class cannot be instantiated.");
    }
}
