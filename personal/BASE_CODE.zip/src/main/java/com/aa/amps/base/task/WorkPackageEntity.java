package com.aa.amps.base.task;

import lombok.Data;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Entity that represents the DRAFTS_WORK_PKG DB table.
 *
 * @author HCL(292147)
 * @since 6/7/2018.
 * HCL 07/06/2018 : US756399:[Draft] Functionality for the "Save" button
 */
@Repository
@Data
public class WorkPackageEntity {
    private List<TaskEntity> taskEntityList;

    private Long workPkgId;
    private String aircraftNbr;
    private String pkgSchdDt;
    private String planStationCd;
    private String trackTypeCd;
    private Long span;
    private String workOrderJobCd;
    private String sceptreMntncWorkPkgId;
    private String dockCd;
    private String workPkgTxt;
    private String workPkgStatusCd;
    private String userId;
    private String updatedTime;
    private String comments;
    private String userAction;
    private String smSession;

}
