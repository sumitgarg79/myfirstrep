package com.aa.amps.cwlv.timetogo;

import lombok.Data;

/**
 * This Bean holds aircraft days, hours and cycle values needed to calculate the Minimum TTG.
 *
 * @author Naseer Mohammed (842018)
 * @since 05/23/2018
 */

@Data
public class TimeToGo {

    private Integer daysToGo;
    private Double hoursToGo;
    private Integer cyclesToGo;

    private Double avgCyclePerDay;
    private Double avgHourPerDay;

    private String minTTG;
    private Double minTTGinDays;
    private String minTTGUnit;
    private Double minTTGValue;

    private java.sql.Date foreCastDate;
    private boolean highTime = false;
}
