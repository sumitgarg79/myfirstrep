package com.aa.amps.base.task;

import com.aa.amps.base.exception.TaskFilterRequestException;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.exception.TaskFilterRequestException.FORECAST_TO_DATE_MISSING;
import static com.aa.amps.base.task.TaskConstants.*;

/**
 * This class contains the properties required for task filter search criteria that is received from UI.
 *
 * @author Paul Verner(650196)
 * @since 6/13/2018.
 * <p>
 * 292147 03-07-2018 : US748803  : [Base  BOW] [Filter] Search by - Task Types
 * US748801 : [Base  BOW] [Filter] Search by - Keyword
 * 842018 07/10/2018 : US748805 - filter search by ItemsWith(AD/DNI)
 */
@Data
public class TaskFilterRequest {

    private String aircraftNumber;

    private String searchKeyWord; //US748801,DE70713

    /**
     * Task Type list contains -
     */
    private String[] taskTypes;

    /**
     * Station List contains all the Line,Base and Vendor Stations.
     **/
    private String[] stations;


    /**
     * ItemsWith List contains - AD (Airworthiness Directive), DNI (Do Not Issue)
     */
    private String[] itemsWith;

    private String softTime;
    private String forecast;
    private String noForecast;
    private String forecastFromDate;
    private String forecastToDate;

    /**
     * Creates a {@code Map} representation of this class properties and their value.
     *
     * @return {@code map} with class properties
     */
    @JsonIgnore
    public Map<String, Object> getSearchCriteriaAsMap() throws TaskFilterRequestException {
        Map<String, Object> criteria = new HashMap<>();

        if (StringUtils.isNotEmpty(this.aircraftNumber)) {
            criteria.put(AIRCRAFT_NO, this.aircraftNumber);
        }

        if (StringUtils.isNotEmpty(this.searchKeyWord)) {
            criteria.put(TASKNAME_OR_DESC, this.searchKeyWord);
        }

        if (ArrayUtils.isNotEmpty(this.taskTypes)) {
            List<String> taskTypeList = Arrays.asList(this.taskTypes);
            criteria.put(TASK_TYPES, taskTypeList);
        }

        if (ArrayUtils.isNotEmpty(this.stations)) {
            List<String> stationList = Arrays.asList(this.stations);
            criteria.put(STATIONS, stationList);
        }

        if (ArrayUtils.isNotEmpty(this.stations)) {
            List<String> stationList = Arrays.asList(this.stations);
            criteria.put(STATIONS, stationList);
        }

        if (ArrayUtils.isNotEmpty(this.itemsWith)) {
            List<String> itemsWithList = Arrays.asList(this.itemsWith);
            criteria.put(ITEMS_WITH, itemsWithList);
        }
        if (StringUtils.isNotEmpty(this.softTime)) {
            criteria.put(SOFT_TIME, this.softTime);
        }
        if (StringUtils.isNotEmpty(this.forecastFromDate)) {
            criteria.put(FORECAST_FROMDATE, this.forecastFromDate);
        }
        if (StringUtils.isNotEmpty(this.forecastToDate)) {
            criteria.put(FORECAST_TODATE, this.forecastToDate);
        }

        if (StringUtils.isNotEmpty(this.noForecast)) {
            criteria.put(NO_FORECAST, Boolean.valueOf(this.noForecast));
        }

        if (StringUtils.isNotEmpty(this.forecast)) {
            if (!(criteria.containsKey(FORECAST_TODATE) || StringUtils.isNotEmpty(this.forecastToDate))) {
                throw new TaskFilterRequestException(FORECAST_TO_DATE_MISSING, null);
            }

            criteria.put(FORECAST, this.forecast);
        }

        return criteria;
    }
}
