package com.aa.amps.base.validation.aircraft;

import lombok.Data;

/**
 * Data class for aircraft validation.
 *
 * @author Neelabh Tripathi(847697)
 * @since 8/21/2018.
 */
@Data
public class AircraftValidationEntity {
    private String aircraftNumber;
    private String airlineCode; //LAA or LUS
    private String fleet;
}
