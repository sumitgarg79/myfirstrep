package com.aa.amps.base.util.sysparam;

import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.aa.amps.base.util.sysparam.SysParamSqlQuery.SYSTEM_PARAM_VALUE;

/**
 * This is the Repository class to fetch data from Sys_Paramtr table.
 *
 * @author HCL(922166)
 * Created on 8/29/2018.
 */
@Component
class SysParamRepository {
    private static final Logger LOG = LoggerFactory.getLogger(SysParamRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    public SysParamRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * This Method will refresh with latest SysParamtr values from database.
     *
     * @return updated {@link Map} from SysParam table
     */
    @Cacheable("sysParam")
    public Map<String, String> refreshMap() {
        LOG.debug("In refreshMap : Query to fetch Sys Parameters - {}", SYSTEM_PARAM_VALUE);
        List<SysParmtr> parmtrList = namedJdbcTemplate.query(SYSTEM_PARAM_VALUE, new SysParmtrMapper());
        LOG.debug("In refreshMap : query result size - {}", parmtrList.size());

        return parmtrList.stream().collect(Collectors.toMap(SysParmtr::getParmtrName, SysParmtr::getParmtrValue));
    }

    /**
     * SysParmtr class represents data for systemParameter.
     */
    @Data
    private class SysParmtr {
        private String parmtrName;

        private String parmtrValue;
    }

    /**
     * RowMapper for {@link SysParmtr}
     */
    private class SysParmtrMapper implements RowMapper {

        @Override
        public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
            SysParmtr parmtr = new SysParmtr();

            parmtr.setParmtrName(rs.getString("SYS_PARMTR_NM"));
            parmtr.setParmtrValue(rs.getString("SYS_PARMTR_VAL"));
            return parmtr;
        }
    }
}
