package com.aa.amps.cwlv.accessControl;

import org.springframework.stereotype.Service;

/**
 * This is the <i>Business Logic</i> class for Access Control. <b>All</b> the functionalities associated with
 * the access control <b><i>must</i></b> be defined here.
 *
 * @author HCL(922166)
 * @since 05/09/2018.
 */
@Service
public class AccessControlService {

    private AccessControlRepository accessControlRepository;

    public AccessControlService(AccessControlRepository accessControlRepository) {
        this.accessControlRepository = accessControlRepository;
    }

    /**
     * This method is to get the list of the applications on base of Role.
     *
     * @param roleId Role ID
     * @return App list role have access to
     * @throws Exception In case of File not found
     */
    public String getAppList(int roleId) throws Exception {
        return accessControlRepository.getAppList(roleId);
    }

    /**
     * This method is to get the access control of Role for the application selected.
     *
     * @param roleId  Role Id
     * @param appName App Name
     * @return Access control list of app for the role
     * @throws Exception In case of File not found
     */
    public String getRoleAccess(int roleId, String appName) throws Exception {
        return accessControlRepository.getRoleAccess(roleId, appName);
    }
}
