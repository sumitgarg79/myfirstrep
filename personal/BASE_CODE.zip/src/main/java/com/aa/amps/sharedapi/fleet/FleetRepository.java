package com.aa.amps.sharedapi.fleet;

import com.aa.amps.sharedapi.exception.SharedApiRepositoryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Repository class for all the database related CRUD operations for fleet.
 *
 * @author Neelabh Tripathi(847697)
 * @since 9/17/2018.
 */
@Repository
public class FleetRepository {
    private static final Logger LOG = LoggerFactory.getLogger(FleetRepository.class);

    private static final String FLEET_CD = "FLEET_CD";
    private static final String SUBFLEET_CD = "SUBFLEET_CD";
    private static final String AIRLINE_CD = "AIRLINE_CD";

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    public FleetRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Retrieves the fleet codes of both LAA and LUS from database.
     *
     * @return {@code List} of fleet codes
     */
    @Cacheable("combinedFleet")
    public List<String> getFleets() {
        LOG.debug("Query to fetch fleets from DB: {}", FleetSqlQuery.FLEET_QUERY);

        // fleetCodes will never be null even if there are no records from DB.
        List<String> fleetCodes = namedJdbcTemplate.query(FleetSqlQuery.FLEET_QUERY, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                return (rs.getString(FLEET_CD));
            }
        });

        LOG.debug("Fleet codes from DB: {}", fleetCodes);

        return fleetCodes;
    }

    /**
     * Retrieves the fleets along with subfleets and airline code.
     *
     * @return list of all fleets, subfleets and airline code
     * @throws SharedApiRepositoryException if there is any error while querying database
     */
    @Cacheable("fleets")
    public List<FleetSubfleetEntity> getFleetsAndSubfleets() throws SharedApiRepositoryException {
        LOG.debug("Query to fetch fleets and subfleets from DB: {}", FleetSqlQuery.FLEET_SUBFLEET_QUERY);
        Map<String, Object> dummyParameterMap = new HashMap<>();

        // fleetCodes will never be null even if there are no records from DB.
        List<Map<String, Object>> fleetSubfleetCodes = namedJdbcTemplate
            .queryForList(FleetSqlQuery.FLEET_SUBFLEET_QUERY, dummyParameterMap);

        LOG.debug("Got total of {} rows from database.", fleetSubfleetCodes.size());

        return populateFleetSubfleetDetails(fleetSubfleetCodes);

    }

    /**
     * Extracts the data from the database query resultset containing fleets, subfleets and airline code and
     * populates it in the {@code List} of {@code FleetSubfleet} objects.
     *
     * @param fleetSubfleetCodes the resultset of db query containing the result
     * @throws SharedApiRepositoryException if the resultset is null or empty(this should not happen)
     */
    private List<FleetSubfleetEntity> populateFleetSubfleetDetails(
        List<Map<String, Object>> fleetSubfleetCodes) throws SharedApiRepositoryException {

        //Contains fleet as key and subfleet list as value.
        Map<String, FleetSubfleetEntity> fleetMap = new HashMap<>();

        if (CollectionUtils.isEmpty(fleetSubfleetCodes)) {
            throw new SharedApiRepositoryException(SharedApiRepositoryException.DATA_ACCESS_EXCEPTION, null);
        }

        fleetSubfleetCodes.forEach(row -> {
            String fleet = (String) row.get(FLEET_CD);

            String subfleet = (String) row.get(SUBFLEET_CD);
            String airlineCode = (String) row.get(AIRLINE_CD);

            /*Checking if fleet entry is there in the map.
             If not then add one along with FleetSubfleet object.*/
            if (fleetMap.get(row.get(FLEET_CD)) == null) {
                List<String> subFleets = new ArrayList<>();
                subFleets.add(subfleet);

                FleetSubfleetEntity fleetData = new FleetSubfleetEntity();
                fleetData.setFleet(fleet);
                fleetData.setSubfleet(subFleets);
                fleetData.setAirlineCode(airlineCode);
                fleetData.setValidFleetCode(true);

                fleetMap.put((String) row.get(FLEET_CD), fleetData);
            } else {
                //This means that fleet already has an entry in the map.
                //So just add subfleet to the existing FleetSubfleet object.
                FleetSubfleetEntity existingFleetData = fleetMap.get(row.get(FLEET_CD));
                existingFleetData.getSubfleet().add(subfleet);
            }
        });

        return new ArrayList<>(fleetMap.values());
    }
}
