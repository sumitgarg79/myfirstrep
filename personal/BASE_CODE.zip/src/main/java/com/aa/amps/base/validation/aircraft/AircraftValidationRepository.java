package com.aa.amps.base.validation.aircraft;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.validation.ValidationConstants.*;
import static com.aa.amps.base.validation.aircraft.AircraftValidationSqlQuery.GET_LAA_ACTIVE_AIRCRAFT;
import static com.aa.amps.base.validation.aircraft.AircraftValidationSqlQuery.GET_LUS_ACTIVE_AIRCRAFT;

/**
 * Repository class for all CRUD operations related to aircraft validations.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@Component
class AircraftValidationRepository {

    private static final Logger LOG = LoggerFactory.getLogger(AircraftValidationRepository.class);

    private List<AircraftValidationEntity> aircraftValidationEntities = new ArrayList<>();

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    AircraftValidationRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }


    /**
     * Refreshes the list of aircrafts details(as {@code AircraftValidationEntity}).
     *
     * @return {@code List} of aircraft details
     */
    List<AircraftValidationEntity> getAircraftList() {
        aircraftValidationEntities.clear();
        refreshLaaAircrafts();
        refreshLusAircrafts();

        return aircraftValidationEntities;
    }

    /**
     * Fetches the active LUS Aircrafts details from DB.
     */
    private void refreshLusAircrafts() {
        Map<String, Object> parameterMap = new HashMap<>();

        parameterMap.put(AIRCFT_DEL_IND, CHAR_FALSE);
        LOG.debug("SQL to fetch LUS active aircrafts: {}", GET_LUS_ACTIVE_AIRCRAFT);
        LOG.debug("parameterMap values passed - aircraftDelInd : {}", CHAR_FALSE);

        List<Map<String, Object>> rowsMapList = namedJdbcTemplate.queryForList(GET_LUS_ACTIVE_AIRCRAFT, parameterMap);

        populateAircraftValidationEntity(rowsMapList, LUS);

        LOG.debug("Total number of records for LUS aircraft list in refreshAircraftList(): {}",
                aircraftValidationEntities.size());
    }

    /**
     * Fetches the active LAA aircrafts details from DB.
     */
    private void refreshLaaAircrafts() {
        Map<String, Object> dummyParameterMap = new HashMap<>();

        LOG.debug("SQL to fetch LAA active aircrafts - {}", GET_LAA_ACTIVE_AIRCRAFT);

        List<Map<String, Object>> rowsMapList = namedJdbcTemplate
                .queryForList(GET_LAA_ACTIVE_AIRCRAFT, dummyParameterMap);

        populateAircraftValidationEntity(rowsMapList, LAA);

        LOG.debug("Total number of records for LAA aircraft list : {}", aircraftValidationEntities.size());
    }

    /**
     * Aggregates the LUS and LAA aricrafts details in the class property acting as a cache.
     *
     * @param rowsMapList db query resultset rows containing the aircrafts details
     * @param airlineCode {@code LAA} or {@code LUS}
     */
    private void populateAircraftValidationEntity(List<Map<String, Object>> rowsMapList, String airlineCode) {
        for (Map<String, Object> rowsMap : rowsMapList) {
            AircraftValidationEntity entity = new AircraftValidationEntity();

            entity.setAircraftNumber((String) rowsMap.get(AIRCFT_NBR));
            entity.setAirlineCode(airlineCode);
            entity.setFleet((String) rowsMap.get(FLEET_CD));

            aircraftValidationEntities.add(entity);
        }
    }
}
