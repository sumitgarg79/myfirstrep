package com.aa.amps.base.util.sysparam;

import org.apache.commons.lang.StringUtils;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.util.BaseConstants.*;

/**
 * This is the <i>Business Logic</i> class to get the System Parameter from Sys_Parmtr table.
 *
 * @author HCL (922166)
 * @since 08/28/2018
 */

@Service
public class SysParamService {

    private SysParamRepository sysParamRepo;

    public SysParamService(SysParamRepository sysParamRepo) {
        this.sysParamRepo = sysParamRepo;
    }

    /**
     * Retrieves the parameter value from the cache(map) that contains data from <i>SYS_PARAM</i> table.
     *
     * @param paramName parameter name to get the parameter value
     * @return value of the parameter
     */
    public String getParamValue(String paramName) {
        String value = null;

        if (StringUtils.isNotEmpty(paramName)) {
            Map<String, String> paramMap = refreshSysParamMap();
            value = paramMap.get(paramName);
        }

        return value;
    }

    /**
     * This Method will refresh with latest SysParamtr values from database.
     *
     * @return updated {{@link Map}} of system parameter.
     */
    public Map<String, String> refreshSysParamMap() {
        return sysParamRepo.refreshMap();
    }

    @CacheEvict(value = {"sysParam"}, allEntries = true)
    public void clearCache() {
        //Empty
    }

    /**
     * This method return the Order for Task Type according to the business.
     *
     * @return the {@link Map} with Task Type and it's Business Order
     */
    public Map<String, Integer> getTaskTypeOrder() {
        //Checking if taskTypesOrder is empty then refresh it from cache.
        Map<String, Integer> taskTypesOrder = new HashMap<>();
        String taskTypeOrder = getParamValue(BASE_TASK_TYPE_ORDER_PART_ONE) +
                COMMA + getParamValue(BASE_TASK_TYPE_ORDER_PART_TWO);

        //Converting comma separated string to list of string.
        List<String> taskTypeOrderList = Arrays.asList(taskTypeOrder.split("\\s*,\\s*"));

        //We used the Old for loop so that 'order' can be used to assign business order to the Task Type
        for (int order = 1; order <= taskTypeOrderList.size(); order++) {
            taskTypesOrder.put(taskTypeOrderList.get(order - 1), order);
        }
        return taskTypesOrder;
    }

}
