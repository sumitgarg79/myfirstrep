package com.aa.amps.base.user;

/**
 * SQL Query constants for the {@link UserRepository} class.
 *
 * @author Paul Verner:American Airlines
 * @since 09/13/2018.
 */
class UserSqlQuery {

    /**
     * Query to determine if UserId exists in AMPS_USER table
     */
    static final String SELECT_COUNT_AMPS_USER_BY_ID
            = "SELECT COUNT(*) FROM AMPS_USER WHERE AMPS_USER_ID = :userId ";

    // SQL queries for AMPS_USER table
    /**
     * Query to insert row into AMPS_USER table
     */
    static final String INSERT_AMPS_USER =
            "INSERT INTO AMPS_USER " +
                    "(AMPS_USER_ID, EMP_ID, EMP_FIRST_NM, EMP_LAST_NM, ROW_CREATE_TMS) " +
                    "(Select :userId, :empId, :firstName, :lastName," +
                    "SYSDATE from dual)";
    /**
     * Query to update row in AMPS_USER table.
     */
    static final String UPDATE_AMPS_USER =
            "UPDATE AMPS_USER SET EMP_FIRST_NM = :firstName, EMP_LAST_NM = :lastName, ROW_UPDT_TMS = SYSDATE " +
                    "WHERE AMPS_USER_ID = :userId ";
    /**
     * Query to determine if userId exists in AMPS_USER_LOGIN_INFO table.
     */
    static final String SELECT_COUNT_AMPS_USER_LOGIN_INFO_BY_ID =
            "SELECT COUNT(*) FROM AMPS_USER_LOGIN_INFO WHERE AMPS_USER_ID = :userId ";

    // SQL queries for AMPS_USER_LOGIN table
    /**
     * Query to insert row into AMPS_USER_LOGIN_INFO table
     */
    static final String INSERT_AMPS_USER_LOGIN_INFO =
            "INSERT INTO AMPS_USER_LOGIN_INFO " +
                    "(AMPS_USER_ID, AMPS_USER_LOGIN_TMS, ROW_CREATE_TMS, ROW_UPDT_TMS) " +
                    "(SELECT :userId, SYSDATE, SYSDATE, SYSDATE FROM DUAL)";
    /**
     * Query to update row in AMPS_USER_LOGIN_INFO table
     */
    static final String UPDATE_AMPS_USER_LOGIN_INFO =
            "UPDATE AMPS_USER_LOGIN_INFO SET AMPS_USER_LOGIN_TMS = SYSDATE, ROW_UPDT_TMS = " +
                    "SYSDATE WHERE AMPS_USER_ID = :userId ";

    private UserSqlQuery() {
        throw new IllegalStateException("Utility class");
    }

}
