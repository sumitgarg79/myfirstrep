package com.aa.amps.cwlv.manHours.LaaRodManHrs;

import com.aa.amps.cwlv.manHours.RodAndRonManHrsEntity;
import com.aa.amps.cwlv.util.Constants;
import com.aa.amps.cwlv.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * This is the <i>Business Logic</i> class for MAN Hours screen. <b>All</b> the functionalities associated with
 * that screen <b><i>must</i></b> be defined here.
 *
 * @author RAMESH RUDRA(842020)
 * Created on 5/06/2018.
 */
@Service
public class LaaRodManHrsService {

    public static final String JMOCA_Date_Format = "ddMMMyyyy";
    public static final String Constant_UNDERSCORE = "_";
    private static final String BillOfWorkType_ROD_VALUE = "R";

    private static final Logger LOG = LoggerFactory.getLogger(LaaRodManHrsService.class);

    @Autowired
    private LaaRodManHrsRepository laaRodManHrsRepository;

    @Value("${termination.routing.api}")
    private String terminationRoutingAPI;

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.build();
    }

    /**
     * This method fetches RodAndRonManHrsEntity data of LAA ROD Man Hrs. Involves processing of scheduled
     * maintenance with station Terminations Routings
     *
     * @param searchCriteria is passed as map to get date from map which is planned date
     * @return RodAndRonManHrsEntity of LAA ROD MAN Hours
     */
    public List<RodAndRonManHrsEntity> getLaaRodManHrs(Map<String, Object> searchCriteria) {
        String date = null;
        if (searchCriteria.containsKey(Constants.MAN_HRS_DATE)) {
            date = String.valueOf(searchCriteria.get(Constants.MAN_HRS_DATE));
            LOG.debug("Search criteria date is {}", date);
        }

        List<LaaTerminationEntity> laaTerminationEntities = laaRodManHrsRepository.getLaaRodManHrs(date);

        List<RodAndRonManHrsEntity> rodAndRonManHrsEntityList = new ArrayList<>();

        Map<String, Map<String, Map<String, Long>>> stationTerminations = getTerminationRoutingFromCache(searchCriteria);

        if (stationTerminations != null) {
            LOG.debug("Got LAA termination routing details from AMPS with {} records.", stationTerminations.size());
        }

        for (LaaTerminationEntity laaTermination : laaTerminationEntities) {
            Map<String, Map<String, Long>> dateMap = stationTerminations.get(laaTermination.getStation()
                    + BillOfWorkType_ROD_VALUE);

            if (dateMap != null) {
                Map<String, Long> noseMap = dateMap.get(DateUtil.getFormattedDate(laaTermination.getSchdDate(),
                        JMOCA_Date_Format, false));

                if (noseMap != null) {
                    //
                    if (noseMap.containsKey(laaTermination.getAircraftNbr() + Constant_UNDERSCORE + laaTermination
                            .getSchdFlightNbr())) {

                        RodAndRonManHrsEntity rodAndRonManHrsEntity = new RodAndRonManHrsEntity();
                        rodAndRonManHrsEntity.setStation(laaTermination.getStation());
                        rodAndRonManHrsEntity.setTotalManHrsOfpriorityCode(laaTermination.getManHrsOfpriorityCode());

                        rodAndRonManHrsEntity.setPriorityCode(laaTermination.getPriorityCode());
                        rodAndRonManHrsEntityList.add(rodAndRonManHrsEntity);

                        LOG.debug("ROD Assignment : {}", laaTermination.getAircraftNbr() + Constant_UNDERSCORE
                                + laaTermination.getSchdFlightNbr());
                    }
                }
            }
        }

        return rodAndRonManHrsEntityList;
    }


    /**
     * This Method Gets Station Termination Routings of LAA from AMPS Cache Manager
     * <p>
     * Example of response is <br>
     * <code>
     * { "SEAO": { "09May2018": {"903_1350": 336,"3MJ_0134": 418, "3ED_1220": 594,
     * "888_2316": 751,"3JA_2419": 410,"3FK_1438": 1001},
     * </code>
     * @return station termination routing data of LAA
     */
    protected Map<String, Map<String, Map<String, Long>>> getTerminationRoutingFromCache(Map<String, Object> searchCriteria) {
        RestTemplate restTemplate = new RestTemplate();

        LOG.debug("Getting termination routing details from AMPS");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        if (searchCriteria.containsKey(Constants.SMSESSION)) {
            LOG.debug("SMSESSION Cookie {}", searchCriteria.get(Constants.SMSESSION).toString());
            headers.add("Cookie", "SMSESSION=" + searchCriteria.get(Constants.SMSESSION).toString());
        }

        //httpEnitity
        HttpEntity<Map<String, Map<String, Map<String, Long>>>> requestEntity =
                new HttpEntity<Map<String, Map<String, Map<String, Long>>>>(headers);

        ResponseEntity<Map<String, Map<String, Map<String, Long>>>> terminatingRoutingsFromCache = restTemplate.
                exchange(terminationRoutingAPI, HttpMethod.POST,
                        requestEntity, new ParameterizedTypeReference<Map<String, Map<String, Map<String, Long>>>>() {
                        });

        return terminatingRoutingsFromCache.getBody();
    }
}
