package com.aa.amps.base.tracktype;

import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * Entity that represents the WORK_PKG_TRACK_TYPE table in the DB.
 *
 * @author HCL(292147)
 * @since 5/24/2018.
 */
@Repository
@Data
public class TrackTypeEntity {

    /**
     * The work package track type code for line
     */
    private String workPkgTrackTypCd;

    /**
     * The work package track type description for line
     */
    private String workPkgTrackTypDesc;

    /**
     * The work package track type indicator for line
     */
    private String menuDispInd;

    /**
     * The work package track type indicator for base
     */
    private String baseWPTrackTypDesc;
}
