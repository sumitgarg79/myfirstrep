package com.aa.amps.base.bow.actions;

import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.base.bow.actions.BOWStatusActionSqlQuery.SELECT_ALL_BOW_STATUS_ACTIONS;
import static com.aa.amps.base.bowstatus.actions.BOWStatusActionsConstants.*;

/**
 * Repository class for bow status actions.
 * It provides all the actions for bow status.
 *
 * @author HCL(296319)
 * @since 06/04/2018.
 */
@Repository
class BOWStatusActionRepository {
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    BOWStatusActionRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Fetches all the active bow status actions.
     *
     * @return List<String>
     */
    List<String> getAllActions() {
        List<Map<String, Object>> rowMapList;
        rowMapList = namedJdbcTemplate.queryForList(SELECT_ALL_BOW_STATUS_ACTIONS, new HashMap<>());
        String actionsStr = (String) rowMapList.get(INT_ZERO).get(SYS_PARMTR_VAL);
        return Arrays.asList(actionsStr.split(COMMA));
    }
}
