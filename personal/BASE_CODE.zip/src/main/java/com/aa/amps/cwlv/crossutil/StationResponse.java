package com.aa.amps.cwlv.crossutil;

import lombok.Data;
import lombok.NonNull;

/**
 * This is the bean that holds the response for the stations list that CWV screen needs.
 * <code>
 * [{"text":"DFW","checked":false},
 * {"text":"ATL","checked":false}]
 * </code>
 *
 * @author Neelabh Tripathi(847697)
 * @since 5/30/2018.
 */
@Data
public class StationResponse {
    /**
     * Contains the station code.
     */
    @NonNull
    private String text;

    @NonNull
    private boolean checked;
}
