package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.task.WorkPackageEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

/**
 * This class to search the Task base on search Criteria provided by the user.
 *
 * @author Shyam Sunadr Ashok(202571)
 * @since 10/01/2018.
 */
@Repository
public class WorkPackageRepository {

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    WorkPackageRepository(
            @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Gets Package/BOW Data by Work Package Id
     *
     * @param workPkgId Criteria on which paclage/bow will be searched
     * @return List<TaskEntity>
     */
    protected WorkPackageEntity getBowDetail(Long workPkgId) {
        WorkPackageEntity result;
        Map<String, Long> parameterMap = new HashMap<>();
        parameterMap.put("workPkgId", workPkgId);
        result = (WorkPackageEntity) namedJdbcTemplate.queryForObject(WorkPackageSqlQuery.SELECT_BOW_BY_WORKPACKAGEID, parameterMap, new WorkPackageRowMapper());
        return result;
    }

}
