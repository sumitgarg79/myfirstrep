package com.aa.amps.base.validation;

import com.aa.amps.base.validation.aircraft.AircraftValidationEntity;
import com.aa.amps.base.validation.aircraft.AircraftValidationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * REST controller class where all the endpoints related to validations are defined.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@RestController
@CrossOrigin
@RequestMapping("/base/validation")
public class ValidationController {

    private static final Logger LOG = LoggerFactory.getLogger(ValidationController.class);
    private static final String AIRCRAFT_NUMBER = "aircraftNum";
    private static final String VALID = "valid";
    private static final String AIRLINE_CODE = "airlineCode";
    private static final String FLEET = "fleet";

    private AircraftValidationService aircraftValidationService;

    public ValidationController(AircraftValidationService aircraftValidationService) {
        this.aircraftValidationService = aircraftValidationService;
    }


    /**
     * Method to refresh the list of active aircraft.
     */
    @PostMapping("/refreshAircfraftList")
    public void refreshAircfraftList() {
        LOG.info("Received request to refresh the active aircraft list");
        aircraftValidationService.refreshAircraftList();
    }


    /**
     * GET Endpoint for aircraft validation. If a matching record is found then other details like airine code and
     * fleet code are provided as part of the response along with valid status based on the query parameters passed.
     *
     * @param aircraftNumber 3 character airaft number
     * @param airlineCode    {@code LAA} or {@code LUS}
     * @param fleet          fleet code
     * @return a {@code Map} that has the details of the aircraft, validity status along with airline code and fleet
     * code
     */
    @GetMapping("/aircraft")
    public Map<String, String> isValidAircraft(@RequestParam("acNum") String aircraftNumber,
                                               @RequestParam("airlineCd") String airlineCode, @RequestParam("fleet") String fleet) {
        LOG.info("Received request to validate active status for aircraft number: {}, airline code: {}, fleet: {}",
                aircraftNumber, airlineCode, fleet);

        Map<String, String> messageMap = new HashMap<>();

        boolean isActive = aircraftValidationService.isActiveAircraft(aircraftNumber, airlineCode, fleet);
        AircraftValidationEntity aircraftDetails = aircraftValidationService.getAircraftDetails(aircraftNumber);

        if (isActive) {
            messageMap.put(VALID, ValidationConstants.TRUE);
        } else {
            messageMap.put(VALID, ValidationConstants.FALSE);
        }

        messageMap.put(AIRLINE_CODE, aircraftDetails.getAirlineCode());
        messageMap.put(FLEET, aircraftDetails.getFleet());
        messageMap.put(AIRCRAFT_NUMBER, aircraftNumber);

        LOG.info("Aircraft active status returned is: {}", isActive);
        return messageMap;
    }
}
