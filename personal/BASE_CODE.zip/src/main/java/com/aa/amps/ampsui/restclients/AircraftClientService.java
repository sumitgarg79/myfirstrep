package com.aa.amps.ampsui.restclients;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * Service class with functionality to fetch aircraft data.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/9/2019
 */
@Service
public class AircraftClientService {
    private static final Logger LOG = LoggerFactory.getLogger(AircraftClientService.class);

    @Value("${ampsui.aircraft.api.url}")
    private String aircraftUrl;

    private RestTemplate restTemplate;

    public AircraftClientService() {
        this.restTemplate = new RestTemplate();
    }

    /**
     * Fetches all the aircraft from the Aircraft API.
     *
     * @return list of all the aircraft
     */
    public List<AircraftResponseEntity> getAllAircraft() {
        List<AircraftResponseEntity> aircraftResponseEntities = null;

        ResponseEntity<List<AircraftResponseEntity>> responseEntity = restTemplate
                .exchange(aircraftUrl, HttpMethod.GET, null,
                          new ParameterizedTypeReference<List<AircraftResponseEntity>>() {
                          });

        if (responseEntity.getBody() != null) {
            aircraftResponseEntities = responseEntity.getBody();
        } else {
            aircraftResponseEntities = new ArrayList<>(); //to avoid NPE at calling method
        }

        LOG.debug("getAllAircraft() - Got response for all aircraft- {}", aircraftResponseEntities);

        return aircraftResponseEntities;
    }

    /**
     * Fetches aircraft belonging to specific airline code - LAA or LUS.
     *
     * @param airlineCode LAA or LUS
     * @return list of active aircraft
     */
    public List<AircraftResponseEntity> getAircraft(String airlineCode) {
        List<AircraftResponseEntity> aircraftResponseEntities = null;

        if (StringUtils.isNotBlank(airlineCode)) {
            String aircraftUrlWithAirline = aircraftUrl + "?airlineCd=" + airlineCode;

            ResponseEntity<List<AircraftResponseEntity>> responseEntity = restTemplate
                    .exchange(aircraftUrlWithAirline, HttpMethod.GET, null,
                              new ParameterizedTypeReference<List<AircraftResponseEntity>>() {
                              });

            if (responseEntity.getBody() != null) {
                aircraftResponseEntities = responseEntity.getBody();
            } else {
                aircraftResponseEntities = new ArrayList<>();  //to avoid NPE at calling method
            }

            LOG.debug("getAircraft() - Got response for airline code {} - {}", airlineCode, aircraftResponseEntities);
        }

        return aircraftResponseEntities;
    }

    /**
     * Getter for restTemplate. Doing this explicit Getter declaration as we need to use the instance inside the unit
     * test class.
     *
     * @return RestTemplate instance of this class
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }
}
