package com.aa.amps.sharedapi.aircraft;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository class for the aircraft entity. All the database related operations related to Aircraft are implemented
 * here.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/2/2019.
 */
@Repository
public class AircraftRepository {
    private static final Logger LOG = LoggerFactory.getLogger(AircraftRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    AircraftRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Method to get all the active aircraft - both LAA and LUS.
     *
     * @return {@code List} of aircraft details
     */
    @Cacheable(AircraftConstants.AIRCRAFT_CACHE)
    public List<AircraftEntity> getAllAircraftDetails() {
        LOG.debug("getAllAircraftDetails() - Retrieving aircraft details from the database");
        LOG.debug("getAllAircraftDetails() - Query to fetch the Active aircraft - {}",
                  AircraftSqlQuery.GET_ACTIVE_AIRCRAFT_QUERY);

        List<AircraftEntity> aircraftEntities = namedJdbcTemplate.query(AircraftSqlQuery.GET_ACTIVE_AIRCRAFT_QUERY,
                                                                        new AircraftRowMapper());

        LOG.debug("getAllAircraftDetails() - Got {} records from the DB.", aircraftEntities.size());

        return aircraftEntities;
    }
}
