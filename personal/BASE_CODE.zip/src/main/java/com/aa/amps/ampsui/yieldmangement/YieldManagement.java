package com.aa.amps.ampsui.yieldmangement;

import lombok.Data;
import org.springframework.stereotype.Repository;

/**
 * Entity class for YieldManagement.
 *
 * @author Thanuja
 * @since 05/13/2019.
 */

@Repository
@Data
public class YieldManagement {
    private String yieldManagementId;
    private String redVal;
    private String greenVal;
    private String blueVal;
    private String desc;
    private String rowCreateTms;
    private String lastUpdtTms;
    private String rowDelInd;
    private String yieldFrom;
    private String yieldTo;
    private String userId;
    private String fleetCode;
    private String subFleetCode;
    private String aircftTypeEqpCode;
}
