package com.aa.amps.base.task;

import com.aa.amps.base.util.TaskUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link TaskEntity}.
 *
 * @author Paul Verner (650196)
 * @since 6/08/2018.
 */
public class WorkPackageTaskRowMapper implements RowMapper {
    private static final String T_STRING = "T";
    private static final String U_STRING = "U";
    private static final String BLANK_STRING = "";

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        TaskEntity taskEntity = new TaskEntity();

        taskEntity.setTaskId(rs.getString("AIRCFT_MNTNC_TASK_ID"));
        taskEntity.setWorkPkgId(rs.getLong("DRAFT_WORK_PKG_ID"));
        taskEntity.setDescription(rs.getString("AIRCFT_MNTNC_TASK_DESC"));
        taskEntity.setAircraftNbr(rs.getString("AIRCFT_NBR"));
        taskEntity.setForecastDateAsString(rs.getString("MNTNC_TASK_DUE_DT"));
        taskEntity.setPlannedDateAsString(rs.getString("MNTNC_WORK_PKG_SCHD_DT"));
        taskEntity.setTtgHours(rs.getInt("MNTNC_REMAIN_HR_QTY"));
        taskEntity.setTtgCycles(rs.getInt("MNTNC_REMAIN_CYCLE_QTY"));
        taskEntity.setTtgDays(rs.getInt("MNTNC_REMAIN_DAY_QTY"));
        taskEntity.setPlannedStation(rs.getString("PLAN_MNTNC_STN_CD"));
        // for ME8 subtypes, set taskType based on first 3 characters of description
        taskEntity.setTaskTypeCode(TaskUtil.determineTaskType(rs.getString("AIRCFT_MNTNC_TASK_TYPE_CD"), taskEntity.getDescription()));
        taskEntity.setManHours(rs.getInt("MNTNC_REQUIR_MECH_HR_QTY"));

        if (U_STRING.equals(rs.getString("ROUTE_CNTRL_TYPE_CD"))) {
            taskEntity.setRouteControlCode(BLANK_STRING);
        } else {
            taskEntity.setRouteControlCode(rs.getString("ROUTE_CNTRL_TYPE_CD"));
        }
        taskEntity.setDni(setBooleanFromTF(rs, "MNTNC_TASK_DO_NOT_ISSUE_IND"));
        taskEntity.setDeferralLockInd(setBooleanFromTF(rs, "MNTNC_DFRL_LOCK_IND"));
        taskEntity.setStatus(rs.getString("MNTNC_TASK_STATUS_TYPE_CD"));

        taskEntity.setForecastDtgCategory(TaskUtil.determineForecastDaysToGoCategory(taskEntity.getForecastDateAsString()));

        String trackTypeCode = rs.getString("WORK_PKG_TRACK_TYPE_CD");
        taskEntity.setBowType(TaskUtil.determineBowType(trackTypeCode));

        return taskEntity;
    }

    private boolean setBooleanFromTF(ResultSet rs, String columnName) throws SQLException {
        return T_STRING.equals(rs.getString(columnName));
    }


}