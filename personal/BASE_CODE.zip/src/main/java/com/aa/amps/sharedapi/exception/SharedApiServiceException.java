package com.aa.amps.sharedapi.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * The wrapper exception class for the all the services in SharedApi package. All service classes <b>must</b> wrap
 * any checked exceptions into this class and then throw an object of this class.
 *
 * @author Neelabh Tripathi
 * @since 12/11/2018
 */
@Getter
@Setter
public class SharedApiServiceException extends Exception {

    private final String statusCode;

    public SharedApiServiceException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
