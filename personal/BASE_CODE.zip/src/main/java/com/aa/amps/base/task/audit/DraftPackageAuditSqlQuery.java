package com.aa.amps.base.task.audit;

class DraftPackageAuditSqlQuery {
    /**
     * Audit: Query to save all the base drafts in database table: DRAFT_WORK_PKG
     */
    static final String INSERT_BASE_BOW_DRAFT_AUDIT =
            "INSERT  INTO DRAFT_WORK_PKG_AUDIT " +
                    "(DRAFT_WORK_PKG_AUDIT_ID, DRAFT_WORK_PKG_ID, " +
                    "DRAFT_SPAN, WORK_ORDER_JOB_CD, DRAFT_DOCK_CD, DRAFT_WORK_PKG_TXT, " +
                    "DRAFT_WORK_PKG_STATUS_CD, UPDATE_USER_ID, COMMENTS, LAST_UPDATE_TIME) " +
                    "(Select DRAFT_WORK_PKG_AUDIT_SEQ.NEXTVAL, :workPkgId, :span, " +
                    ":workOrderJobCd, :dockCd, NVL(:workPkgTxt,'DRAFT'), :workPkgStatusCd, " +
                    ":userId, " +
                    ":comments, " +
                    "SYSDATE from dual)";

    /**
     * Audit: Query to save all the task details in database table: DRAFT_WORK_PKG_TASK
     */
    static final String INSERT_BASE_BOW_TASKS_AUDIT =
            "INSERT  INTO DRAFT_WORK_PKG_TASK_AUDIT " +
                    "(DRAFT_WORK_PKG_TASK_AUDIT_ID, DRAFT_WORK_PKG_ID, AIRCFT_NBR, AIRCFT_MNTNC_TASK_ID, " +
                    " DRAFT_WORK_PKG_TASK_STATUS, UPDATE_USER_ID, LAST_UPDATE_TIME) " +
                    "(SELECT DRAFT_WORK_PKG_TASK_AUDIT_SEQ.NEXTVAL, :workPkgId, :aircraftNbr, :taskId," +
                    ":wrkPkgTaskStatus, " +
                    ":userId, SYSDATE from dual)";
    /**
     * Audit: Query to insert delete audit of the base draft in database table: DRAFT_WORK_PKG
     */
    static final String INSERT_BASE_BOW_DRAFT_AUDIT_FOR_DELETE =
            "INSERT INTO DRAFT_WORK_PKG_AUDIT" +
                    " (DRAFT_WORK_PKG_AUDIT_ID, DRAFT_WORK_PKG_ID, DRAFT_SPAN, WORK_ORDER_JOB_CD," +
                    "  DRAFT_DOCK_CD, DRAFT_WORK_PKG_TXT, DRAFT_WORK_PKG_STATUS_CD, UPDATE_USER_ID," +
                    "  COMMENTS, LAST_UPDATE_TIME )" +
                    " (SELECT DRAFT_WORK_PKG_AUDIT_SEQ.NEXTVAL, DRAFT_WORK_PKG_ID, DRAFT_SPAN," +
                    "   WORK_ORDER_JOB_CD, DRAFT_DOCK_CD, DRAFT_WORK_PKG_TXT, :wrkPkgTaskStatus, " +
                    "   :userId, COMMENTS, SYSDATE" +
                    "  FROM DRAFT_WORK_PKG WHERE DRAFT_WORK_PKG_ID = :workPkgId )";
    /**
     * Audit: Query to insert delete audit for tasks of the base draft in database table: DRAFT_WORK_PKG_TASK
     */
    static final String INSERT_BASE_BOW_TASKS_AUDIT_FOR_DELETE =
            "INSERT INTO DRAFT_WORK_PKG_TASK_AUDIT" +
                    " ( DRAFT_WORK_PKG_TASK_AUDIT_ID, DRAFT_WORK_PKG_ID, AIRCFT_NBR, AIRCFT_MNTNC_TASK_ID," +
                    "    DRAFT_WORK_PKG_TASK_STATUS, UPDATE_USER_ID, LAST_UPDATE_TIME )" +
                    "  (SELECT DRAFT_WORK_PKG_TASK_AUDIT_SEQ.NEXTVAL, DRAFT_WORK_PKG_ID," +
                    "      AIRCFT_NBR, AIRCFT_MNTNC_TASK_ID, :wrkPkgTaskStatus, " +
                    "      :userId, SYSDATE" +
                    "   FROM DRAFT_WORK_PKG_TASK WHERE DRAFT_WORK_PKG_ID = :workPkgId" +
                    "  )";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private DraftPackageAuditSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
