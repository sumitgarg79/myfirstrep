package com.aa.amps.cwlv.exception;

/**
 * Class handles all the exceptions for the TaskRepository for LUS/LAA.
 * @author Naseer Mohammed (842018)
 * @since 04/24/2018
 */
public class TaskRepositoryException extends RuntimeException {

    public static final String NULL_NAMEDJDBCTEMPLATE ="NamedParameterJDBCTemplate is NULL";
    public static final String EMPTY_SEARCH_CRITERIA ="Empty Search Criteria.";
    public static final String NULL_SEARCH_CRITERIA ="NULL Search Criteria.";
    public static final String PLANNED_DATE_MISSING ="Planned From Date and Planned To Date are required.";

    public TaskRepositoryException(String exceptionMsg){
        super(exceptionMsg);
    }
}
