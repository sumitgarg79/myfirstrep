package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.WorkPackageEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * This class contains the REST endpoint for the functionality related to Bill Of Work Status search
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@CrossOrigin
@RestController
@RequestMapping({"/base/bow/search"})
public class BOWStatusSearchController {
    private static final Logger LOG = LoggerFactory.getLogger(BOWStatusSearchController.class);

    private BOWStatusSearchService bowStatusSearchService;

    public BOWStatusSearchController(BOWStatusSearchService bowStatusSearchService) {
        this.bowStatusSearchService = bowStatusSearchService;
    }

    /**
     * Method to get bill of work package using searchCriteria StatusSearchFilterRequest.
     *
     * @param searchCriteria User searchCriteria input.
     * @return List<WorkPackageEntity> List of bill of work package.
     */
    @PostMapping("/getWorkPackages")
    public List<WorkPackageEntity> getWorkPackages(
            @RequestBody StatusSearchFilterRequest searchCriteria) throws BaseServiceException {
        LOG.info("received request for search BOW for searchCriteria: {} ", searchCriteria);

        return searchCriteria != null ? bowStatusSearchService
                .getWorkPackages(searchCriteria.getSearchCriteriaAsMap()) : null;
    }
}
