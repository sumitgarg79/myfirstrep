package com.aa.amps.ampsui.taskassociation;

import com.aa.amps.ampsui.exception.AmpsuiServiceException;
import com.aa.amps.ampsui.util.AmpsApiRestClientUtils;
import com.aa.amps.ampsui.util.Constants;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

/**
 * Service class for Maintenance Associations
 * Maintenance Associations related APIs are hosted on AMPS Line application which will be called
 * from the methods in this class.
 *
 * @author HCL
 * @since 9/03/2019.
 */
@Component
public class TaskAssociationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskAssociationService.class);

    private static final String INTERNAL_AMPSWEB_TASK_ASSOC_SAVE_ERROR = "Exception while saving task associations data through amps-web rest api";
    private static final String INTERNAL_AMPSWEB_TASK_ASSOC_RETRIEVE_ERROR = "Exception while fetching task associations data through amps-web rest api";


    @Value("${ampsui.taskassociation.api}")
    private String taskAssociationRetrieveAPI;

    @Value("${ampsui.taskassociation.api.save}")
    private String taskAssociationSaveAPI;

    private AmpsApiRestClientUtils apiRestClient;

    private RestTemplate restTemplate;

    public TaskAssociationService(AmpsApiRestClientUtils apiRestClient) {
        this.apiRestClient = apiRestClient;
        this.restTemplate = new RestTemplate();
    }

    /**
     * Getter method for restTemplate
     *
     * @return restTemplate
     */
    public RestTemplate getRestTemplate() {
        return restTemplate;
    }

    /**
     * This method retrieves list of task associations by calling AMPS-WEB REST API.
     *
     * @param taskAssociationRequest contains task id for which associations needs to be retrieved
     * @return list of task associations
     * @throws AmpsuiServiceException in case of exception while fetching task associations
     */
    List<TaskAssociations> getTaskAssociations(TaskAssociationRequest taskAssociationRequest)
            throws AmpsuiServiceException {

        LOGGER.info("Request for task association retrieve AMPS-WEB service for task id : {}",
                taskAssociationRequest.getTaskId());

        HttpHeaders httpHeaders = apiRestClient.getHeaderWithSession(taskAssociationRequest.getSmSession());
        ResponseEntity<List<TaskAssociations>> taskAssociationList;
        try {
            HttpEntity<String> requestEntity = new HttpEntity<>(httpHeaders);
            String taskAssociationRetriveAPIURL = taskAssociationRetrieveAPI + Constants.MNTNC_ID +
                    taskAssociationRequest.getTaskId();

            taskAssociationList = restTemplate.
                    exchange(taskAssociationRetriveAPIURL, HttpMethod.GET,
                            requestEntity, new ParameterizedTypeReference<List<TaskAssociations>>() {
                            });
        } catch (Exception e) {
            LOGGER.error("Exception while fetching task associations data ", e);
            throw new AmpsuiServiceException(INTERNAL_AMPSWEB_TASK_ASSOC_RETRIEVE_ERROR, null);
        }
        return taskAssociationList.getBody();
    }

    /**
     * This method calls amps-web Interface using RestTemplate Call to save list of task associations data.
     *
     * @param taskAssociationRequest contains session object and task associations to be saved
     * @return {@code 'SUCCESS'} if save api call is successful else {@code 'FAILED'}
     * @throws AmpsuiServiceException in case of exception while saving task associations
     */
    Map<String, String> saveTaskAssociations(TaskAssociationRequest taskAssociationRequest)
            throws AmpsuiServiceException {

        LOGGER.info("Request for save task association data to AMPS-WEB");
        HttpHeaders httpHeaders = apiRestClient.getHeaderWithSession(taskAssociationRequest.getSmSession());
        ResponseEntity<Map<String, String>> ampsMsg;
        try {
            final ObjectMapper mapper = new ObjectMapper();
            HttpEntity<String> requestEntity = new HttpEntity<>(mapper.writeValueAsString(
                    taskAssociationRequest), httpHeaders);

            ampsMsg = restTemplate.
                    exchange(taskAssociationSaveAPI, HttpMethod.POST, requestEntity,
                            new ParameterizedTypeReference<Map<String, String>>() {
                            });
        } catch (Exception e) {
            LOGGER.error("Exception while saving task associations data ", e);
            throw new AmpsuiServiceException(INTERNAL_AMPSWEB_TASK_ASSOC_SAVE_ERROR, null);
        }

        return ampsMsg.getBody();
    }

}
