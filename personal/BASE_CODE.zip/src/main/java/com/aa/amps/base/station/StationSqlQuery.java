package com.aa.amps.base.station;

/**
 * Query constant for the {@link StationRepository} class.
 *
 * @author HCL(922166)
 * Created on 5/21/2018.
 */
public class StationSqlQuery {

    /**
     * Query to get all the active station from database
     * DE70710 Query Changed to get the mntnc_stn_alias_cd as mntnc_stn_cd if its heavy Station.
     */
    public static final String SELECT_All_MAINTENANCE_STATIONS =
            "SELECT DECODE(MNTNC_STN_TYPE_CD, 'H', mntnc_stn_alias_cd, mntnc_stn_cd) as mntnc_stn_cd , " +
                    "MNTNC_STN_TYPE_CD , " +
                    "mntnc_stn_alias_cd " +
                    "FROM AMPSFCST_MNTNC_STN " +
                    "ORDER BY mntnc_stn_cd, " +
                    "MNTNC_STN_TYPE_CD";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private StationSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }
}
