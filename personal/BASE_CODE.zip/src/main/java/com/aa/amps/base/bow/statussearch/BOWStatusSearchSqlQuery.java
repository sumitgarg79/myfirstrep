package com.aa.amps.base.bow.statussearch;

/**
 * This is the query declaration class to search the work package.
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
class BOWStatusSearchSqlQuery {
    /**
     * Query to get Draft Base Bow details.
     */
    static final String SELECT_DRAFT_BASE_BOW =
            "SELECT DRAFT_WORK_PKG_ID, DRAFT_WORK_PKG_TXT, TO_CHAR(DRAFT_PKG_SCHD_DT, 'MM/DD/YYYY') DRAFT_PKG_SCHD_DT, DRAFT_PLAN_STN_CD, " +
                    " (NVL(EMP_LAST_NM, ' ') || ', ' || NVL(EMP_FIRST_NM, ' ')) as UPDATE_USER_ID, DRAFT_WORK_PKG_STATUS_CD, " +
                    " COMMENTS, TO_CHAR(LAST_UPDATE_TIME, 'MM/DD/YYYY HH24:MI:SS') LAST_UPDATE_TIME " +
                    " FROM DRAFT_WORK_PKG pkg, AMPS_USER au  where au.amps_user_id = pkg.update_user_id ";

    static final String SELECT_DRAFT_BASE_BOW_DEFAULT_ORDER_BY =
            " ORDER BY DRAFT_PKG_SCHD_DT ";

    /**
     * Private default constructor to prevent any instantiation.
     */
    private BOWStatusSearchSqlQuery() {
        throw new IllegalStateException("BOW Status Search Query constants class");
    }
}
