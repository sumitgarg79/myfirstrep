package com.aa.amps.cwlv.crossutil;

import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link CrossUtilEntity}.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/23/2018.
 */
public class CrossUtilRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        CrossUtilEntity crossUtilEntity = new CrossUtilEntity();

        crossUtilEntity.setMntncStnCode(rs.getString("MNTNC_STN_CD"));
        crossUtilEntity.setCrossUtilFlag(rs.getString("CROSS_UTILIZED_FLG").charAt(0));

        crossUtilEntity.setRonCapacity(rs.getLong("RON_CAPACITY"));
        crossUtilEntity.setRodCapacity(rs.getLong("ROD_CAPACITY"));
        crossUtilEntity.setActiveFlag(rs.getString("ACTIVE_FLG").charAt(0));

        return crossUtilEntity;
    }
}
