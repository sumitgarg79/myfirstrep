package com.aa.amps.base.tracktype;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link TrackTypeEntity}.
 *
 * @author HCL(292147)
 * @since 5/24/2018.
 */

public class TrackTypeRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        TrackTypeEntity trackTypeEntity = new TrackTypeEntity();

        trackTypeEntity.setWorkPkgTrackTypCd(rs.getString("WORK_PKG_TRACK_TYPE_CD"));
        trackTypeEntity.setWorkPkgTrackTypDesc(rs.getString("WORK_PKG_TRACK_TYPE_DESC"));
        trackTypeEntity.setMenuDispInd(rs.getString("MENU_DISPLY_IND"));
        trackTypeEntity.setBaseWPTrackTypDesc(rs.getString("BASE_WP_TRACK_TYPE_DESC"));

        return trackTypeEntity;
    }
}
