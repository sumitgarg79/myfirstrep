package com.aa.amps.cwlv.crossutil;

import com.aa.amps.cwlv.crossutil.audit.CrossUtilAuditService;
import com.aa.amps.cwlv.exception.StationNotFoundException;
import com.aa.amps.cwlv.util.ServiceResponseMessage;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseDescription.*;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatus.*;
import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatusCode.*;

/**
 * This is the <i>Business Logic</i> class for Cross Utilization screen. <b>All</b> the functionalities associated with
 * that screen <b><i>must</i></b> be defined here.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/22/2018.
 */
@Service
@Transactional
public class CrossUtilService {
    public static final String MNTNC_STN_CD_NULL_INVALID = "Maintenance station code is either null or invalid";
    public static final String RON_CAPACITY_INVALID = "RON capacity cannot be 0 or less than 0";
    public static final String ROD_CAPACITY_INVALID = "ROD capacity cannot be less than 0";
    public static final String CROSS_UTIL_FLAG_INVALID = "Cross Util flag should be eiter Y or N";
    public static final String CROSS_UTIL_STATION_DEL = "Deleted Successfully";

    private static final Logger LOG = LoggerFactory.getLogger(CrossUtilService.class);

    private CrossUtilRepository crossUtilRepository;
    private CrossUtilAuditService crossUtilAuditService;

    public CrossUtilService(CrossUtilRepository crossUtilRepository, CrossUtilAuditService crossUtilAuditService) {
        this.crossUtilRepository = crossUtilRepository;
        this.crossUtilAuditService = crossUtilAuditService;
    }

    /**
     * Fetches cross utilized data for all the active stations(i.e., stations <i>not</i> deleted by the user).
     *
     * @return {@code List} of cross utilized station list
     */
    @Transactional(readOnly = true)
    public List<CrossUtilEntity> getCrossUtililzionDetails() {
        return crossUtilRepository.getAllActiveStations();
    }

    /**
     * Fetches list of all active cross utilized stations(i.e., stations with cross util flag as {@code Y} and not
     * deleted by the user).
     *
     * @return {@code List} of cross utilized stations
     */
    @Transactional(readOnly = true)
    public List<String> getCrossUtilizationStation() {
        List<CrossUtilEntity> allStations = getCrossUtililzionDetails();
        List<String> crossUtilStations = new ArrayList<>();

        if (!CollectionUtils.isEmpty(allStations)) {
            allStations.forEach(s -> {
                if (s.getCrossUtilFlag().toString().equalsIgnoreCase("Y")) {
                    crossUtilStations.add(s.getMntncStnCode());
                }
            });
        }

        return crossUtilStations;
    }

    /**
     * Updates the existing cross utilization record.<br>
     *
     * @param recordToUpdate the record data to update
     * @return {@code true} if record is updated, {@code false} otherwise
     */
    public Optional<ServiceResponseMessage> updateCrossUtilRecord(CrossUtilEntity recordToUpdate) {
        ServiceResponseMessage result = null;

        if (recordToUpdate != null) {
            recordToUpdate.setActiveFlag('Y');
        }

        if (isValidCrossEntityRecord(recordToUpdate)) {
            LOG.debug("Updating cross util record: {}", recordToUpdate);

            //Convert cross util flag to uppercase
            Character upperCaseCrossUtilFlag = Character.toUpperCase(recordToUpdate.getCrossUtilFlag());

            recordToUpdate.setCrossUtilFlag(upperCaseCrossUtilFlag);
            recordToUpdate.setMntncStnCode(recordToUpdate.getMntncStnCode().toUpperCase());

            int rowsUpdated = crossUtilRepository.updateStation(recordToUpdate);

            if (rowsUpdated == 1) {
                result = new ServiceResponseMessage(SUCCESS, RECORD_UPDATED_SUCCESSSFULLY.toString(),
                                                    SUCCESSFULLY_UPDATED.toString());

                crossUtilAuditService.audit(recordToUpdate);//auditing update
                LOG.debug("Record updated successfully for: {}", recordToUpdate.getMntncStnCode());
            } else {
                result = new ServiceResponseMessage(EXCEPTION, RECORD_NOT_FOUND_DESC.toString());
            }
        } else {
            result = setResponseForFailure(recordToUpdate);
        }

        LOG.debug("Result of the cross util update is {}", result);

        LOG.info("Update completed with status : {}", result.getStatus());

        return Optional.ofNullable(result);
    }

    /**
     * Method for setting the {@code ServiceResponseMessage} with appropriate response data.
     *
     * @param recordToUpdate the request object with xtuil record to update
     * @return the {@code ServiceResponseMessage} with appropriate status and message
     */
    protected ServiceResponseMessage setResponseForFailure(CrossUtilEntity recordToUpdate) {
        ServiceResponseMessage result = null;

        if (recordToUpdate == null) {
            result = new ServiceResponseMessage(NULL_REQUEST, NULL_REQUEST_DATA.toString());
        } else if (!isValidStationFormat(recordToUpdate.getMntncStnCode())) {
            result = new ServiceResponseMessage(EXCEPTION, MNTNC_STN_CD_NULL_INVALID);
        } else if (!isValidRonCapacity(recordToUpdate.getRonCapacity())) {
            result = new ServiceResponseMessage(EXCEPTION, RON_CAPACITY_INVALID);
        } else if (!isValidCrossUtilFlag(recordToUpdate.getCrossUtilFlag())) {
            result = new ServiceResponseMessage(EXCEPTION, CROSS_UTIL_FLAG_INVALID);
        } else if (!isValidRodCapacity(recordToUpdate.getRodCapacity())) {
            result = new ServiceResponseMessage(EXCEPTION, ROD_CAPACITY_INVALID);
        }

        return result;
    }


    /**
     * Adds new cross utilization station data.
     *
     * @param recordToAdd the record data to update
     * @return the {@code ServiceResponseMessage} with appropriate status and message
     */
    public Optional<ServiceResponseMessage> addStation(CrossUtilEntity recordToAdd) {
        ServiceResponseMessage result;
        recordToAdd.setActiveFlag('Y'); //For auditing purpose. Otherwise this flag is taken care at the query level.

        if (isValidCrossEntityRecord(recordToAdd)) {
            LOG.debug("Updating cross util record: {}", recordToAdd);

            CrossUtilEntity value = crossUtilRepository.getStation(recordToAdd.getMntncStnCode().toUpperCase());
            LOG.info(value.getMntncStnCode());

            if (StringUtils.equalsIgnoreCase(value.getMntncStnCode(), recordToAdd.getMntncStnCode().toUpperCase())
                && value.getActiveFlag() == 'Y') {
                result = new ServiceResponseMessage(EXCEPTION, STATION_ALREADY_EXSIST.toString());

            } else if (StringUtils.equals(value.getMntncStnCode(), recordToAdd.getMntncStnCode().toUpperCase())
                && value.getActiveFlag() == 'N') {
                int rowsUpdated = crossUtilRepository.updateStationToActive(recordToAdd);

                crossUtilAuditService.audit(recordToAdd);//audit

                if (rowsUpdated == 1) {
                    result = new ServiceResponseMessage(SUCCESS, RECORD_ADDED_SUCCESSSFULLY.toString());

                    LOG.debug("Record updated successfully for: {}", recordToAdd.getMntncStnCode());
                } else {
                    result = new ServiceResponseMessage(EXCEPTION, RECORD_NOT_ADDED_DESC.toString());
                }
            } else {
                int rowsUpdated = crossUtilRepository.addStation(recordToAdd);
                crossUtilAuditService.audit(recordToAdd);//audit

                if (rowsUpdated == 1) {
                    result = new ServiceResponseMessage(SUCCESS, RECORD_ADDED_SUCCESSSFULLY.toString());
                    LOG.debug("Record added successfully for: {}", recordToAdd.getMntncStnCode());
                } else {
                    result = new ServiceResponseMessage(EXCEPTION, RECORD_NOT_FOUND_DESC.toString());
                }
            }
        } else {
            result = setResponseForFailure(recordToAdd);
        }

        LOG.debug("Result of the cross util add station is {}", result);

        LOG.info("Adding record completed with status : {}", result.getStatus());

        return Optional.ofNullable(result);
    }

    /**
     * Fetches selected station cross utilized data which is active stations(i.e., stations <i>not</i> deleted by
     * the user).
     * @param stationCode
     * @return {@code crossutilEntity} of cross utilized station data
     */
    public CrossUtilEntity getStation(String stationCode) {
        CrossUtilEntity crossUtilEntity = crossUtilRepository.getStation(stationCode);

        if (crossUtilEntity.getMntncStnCode() == null) {
            throw new StationNotFoundException("Station- " + stationCode + " notFound");
        }

        return crossUtilEntity;
    }

    /**
     * Updates  selected cross utilized data to active
     * stations Flag to N(i.e., stations <i>not</i> deleted by the user).
     * @param stationCode
     * @return {@code ServiceResponseMessage} with appropriate status and message
     */
    public Optional<ServiceResponseMessage> deleteStation(String stationCode, String userId) {
        ServiceResponseMessage result = null;
        int count = crossUtilRepository.deleteStation(stationCode);

        CrossUtilEntity recordToDelete = new CrossUtilEntity();
        recordToDelete.setMntncStnCode(stationCode);
        recordToDelete.setUserId(userId);
        recordToDelete.setActiveFlag('N');

        crossUtilAuditService.audit(recordToDelete);

        if (count == 1) {
            result = new ServiceResponseMessage(SUCCESS, CROSS_UTIL_STATION_DEL);

            LOG.info("Station {} deleted by user {}", stationCode,
                      userId);
        } else {
            result = ServiceResponseMessage.getExceptionStatusOnly();

            result.setMessage(ServiceResponseMessage
                                  .ServiceResponseDescription.RECORD_NOT_FOUND_DESC.toString());
        }

        return Optional.ofNullable(result);
    }


    /**
     * Checks if provided {@code CrossUtilEntity} record is valid for update and insert operation
     *
     * @param recordToUpdate the {@code CrossUtilEntity} record to validate
     * @return {@code true} if the record is valid, {@code false} otherwise
     */
    public boolean isValidCrossEntityRecord(CrossUtilEntity recordToUpdate) {
        boolean result = false;

        if (recordToUpdate != null && isValidStationFormat(recordToUpdate.getMntncStnCode()) && isValidRonCapacity(
            recordToUpdate.getRonCapacity()) && isValidCrossUtilFlag(recordToUpdate.getCrossUtilFlag()) &&
            isValidRodCapacity(
                recordToUpdate.getRodCapacity())) {

            result = true;
        }

        return result;
    }

    /**
     * Verifies if provided station code is valid or not. Following checks are performed - <br>
     * <ul>
     *      <li>Station Code is not null or empty</li>
     *      <li>Station code contains only alphabets</li>
     *      <li>Station code's length is exactly 3 chars</li>
     * </ul>
     * @param station the station code to verify
     * @return {@code true} if station code format is valid, {@code false} otherwise
     */
    public boolean isValidStationFormat(String station) {
        boolean result = false;

        if (StringUtils.isNotBlank(station) && StringUtils.isAlpha(station) && station.length() == 3) {
            result = true;
        }

        return result;
    }

    /**
     * Verifies if provided RON Capacity has valid value - <br>
     * <ul>
     *      <li>RON Capcaity is not null</li>
     *      <li>RON Capacity is greater than 0</li>
     * </ul>
     *
     * @param ronCapacity the ron capacity to check
     * @return {@code true} if RON Capacity is valid, {@code false} otherwise
     */
    public boolean isValidRonCapacity(Long ronCapacity) {
        boolean result = false;

        if (ronCapacity != null && ronCapacity >= 0L) {
            result = true;
        }

        return result;
    }

    /**
     * Validates if ROD Capacity is valid or not i.e., it should be greater than or equal to zero.
     *
     * @param rodCapacity the ROD capacity to validate
     * @return {@code true} if valid, {@code false} otherwise
     */
    public boolean isValidRodCapacity(Long rodCapacity) {
        boolean result = false;

        if (rodCapacity != null && rodCapacity >= 0) {
            result = true;
        }

        return result;
    }

    /**
     * Verifies if provided Cross Utilization flag has valid values - {@code Y} or {@code N}.
     *
     * @param crossUtilFlag the cross utilization flag to validate
     * @return {@code true} if flag is valid, {@code false} otherwise
     */
    public boolean isValidCrossUtilFlag(Character crossUtilFlag) {
        boolean result = false;

        if (crossUtilFlag != null && StringUtils.isNotBlank(crossUtilFlag.toString())) {
            Character crossUtilToUpperCase = Character.toUpperCase(crossUtilFlag);
            result = crossUtilToUpperCase.equals('Y') || crossUtilToUpperCase.equals('N');
        }

        return result;
    }
}
