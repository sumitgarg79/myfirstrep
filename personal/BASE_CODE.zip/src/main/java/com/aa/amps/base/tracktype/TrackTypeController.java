package com.aa.amps.base.tracktype;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST controller class that contains all the endpoints related to work package track type functionality.
 *
 * @author HCL(292147)
 * Created on 5/24/2018.
 */

@CrossOrigin
@RestController
@RequestMapping("/base/trackType")
public class TrackTypeController {

    private TrackTypeService trackTypeService;

    public TrackTypeController(TrackTypeService trackTypeService) {
        this.trackTypeService = trackTypeService;
    }

    /**
     * GET request implementation to retrieve base work package track type.
     *
     * @return base work package track type
     */
    @GetMapping("/getBaseTrack")
    public List<TrackTypeEntity> getBaseTrackTypes() {
        return trackTypeService.getBaseTrackTypes();
    }
}


