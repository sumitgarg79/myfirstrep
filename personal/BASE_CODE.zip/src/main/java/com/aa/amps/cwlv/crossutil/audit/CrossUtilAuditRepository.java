package com.aa.amps.cwlv.crossutil.audit;

import com.aa.amps.cwlv.crossutil.CrossUtilEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

import static com.aa.amps.cwlv.crossutil.audit.CrossUtilAuditSqlQuery.INSERT_CROSS_UTIL_AUDIT;

/**
 * Repository class for Cross Util audit.
 *
 * @author Neelabh Tripathi(847697)
 * @since 6/12/2018.
 */
@Repository
public class CrossUtilAuditRepository {
    private static final Logger LOG = LoggerFactory.getLogger(CrossUtilAuditRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    /**
     * Parameterized constructor.
     *
     * @param namedJdbcTemplate DB connection object
     */
    public CrossUtilAuditRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Method to add the cross util record in the audit table.
     *
     * @param auditRecord cross util record to be audited
     * @return number or rows affected(inserted or updated) in DB
     */
    public int addAuditRecord(CrossUtilEntity auditRecord) {
        Map<String, Object> param = new HashMap<>();

        param.put("mntncStnCode", auditRecord.getMntncStnCode().toUpperCase());

        if (auditRecord.getCrossUtilFlag() != null) {
            param.put("crossUtilFlag", auditRecord.getCrossUtilFlag().toString().toUpperCase());
        } else {
            param.put("crossUtilFlag", null);
        }

        param.put("rodCapacity", auditRecord.getRodCapacity());

        param.put("ronCapacity", auditRecord.getRonCapacity());

        if (auditRecord.getActiveFlag() != null) {
            param.put("activeFlag", auditRecord.getActiveFlag().toString().toUpperCase());
        } else {
            param.put("activeFlag", null);
        }

        param.put("userId", auditRecord.getUserId());

        int rowsUpdated = namedJdbcTemplate.update(INSERT_CROSS_UTIL_AUDIT, param);

        LOG.debug("Audited record for station {}", auditRecord.getMntncStnCode());
        LOG.debug("Number of row affected is {}", rowsUpdated);

        return rowsUpdated;
    }
}
