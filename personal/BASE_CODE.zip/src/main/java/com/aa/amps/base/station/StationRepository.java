package com.aa.amps.base.station;


import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository class for {@link StationEntity}.
 * It provides the interfaces for CRUD operations on the entity.
 *
 * @author HCL(922166)
 * @since 5/18/2018.
 */
@Repository
class StationRepository {

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    StationRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Get list of all active stations
     * <b> Note: </b>Fetches data for active stations.
     *
     * @return {@code List} of all active stations records
     */
    List<StationEntity> getAllActiveStations() {
        List<StationEntity> result;

        result = namedJdbcTemplate.query(StationSqlQuery.SELECT_All_MAINTENANCE_STATIONS, new StationRowMapper());

        return result;
    }
}
