package com.aa.amps.cwlv.util;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * A Date utility class to do different date operations.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */
public class DateUtil {

    public static final String Basic_Date_Format = "yyyy-MM-dd";
    public static final String JMOCA_Date_Format = "ddMMMyyyy";
    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

    private DateUtil() {
        throw new IllegalStateException("Utility class");
    }

    public static java.sql.Date getDateFromString(String inputDate, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            return new java.sql.Date(sdf.parse(inputDate).getTime());
        } catch (ParseException e) {
            LOGGER.error("Error in date conversion: ", e);
            return null;
        }
    }

    public static String convertMinutesToHHMM(Long minutes) {
        if (minutes != null && minutes > 0) {
            int hrs = (int) (minutes / 60L);
            int mins = minutes.intValue() - (hrs * 60); // hrs = 4, then add "0" , then add hrs("04")

            return (hrs < 10 ? "0" : "") + hrs + ":" + (mins < 10 ? "0" : "") + mins;
        } else return null;
    }

    public static Calendar getCalendarDate(String date, String timeAsHHMM) {
        return getCalendarDate(date, timeAsHHMM, null);
    }

    public static String getFormattedDate(Date date, String requiredFormat, boolean upperCase) {
        java.util.Date someDate = new Date(date.getTime());
        SimpleDateFormat formatter = new SimpleDateFormat(requiredFormat);
        if (upperCase)
            return formatter.format(someDate).toUpperCase();
        else
            return formatter.format(someDate);
    }

    private static Calendar getCalendarDate(String date, String timeAsHHMM, java.util.TimeZone tz) {
        date = ("0" + date);
        date = date.substring(date.length() - 9);
        int day = Integer.valueOf(date.substring(0, 2)).intValue();
        int month = getMonth(date.substring(2, 5));
        int year = Integer.valueOf(date.substring(5)).intValue();

        int hour = 0;
        int minute = 0;
        int second = 0;
        if (timeAsHHMM != null) {
            timeAsHHMM = "0000" + timeAsHHMM;
            timeAsHHMM = timeAsHHMM.substring(timeAsHHMM.length() - 4);
            hour = Integer.valueOf(timeAsHHMM.substring(0, 2)).intValue();
            minute = Integer.valueOf(timeAsHHMM.substring(2)).intValue();
        }

        Calendar calDate = Calendar.getInstance();
        if (tz != null)
            calDate.setTimeZone(tz);
        calDate.set(year, month, day, hour, minute, second);    // MAP-1771: Setting seconds
        calDate.set(Calendar.MILLISECOND, 0);    // MAP-1771: Also setting miliiseconds

        return calDate;
    }

    private static int getMonth(String strMonth) {
        if (strMonth.equalsIgnoreCase("JAN"))
            return Calendar.JANUARY;
        if (strMonth.equalsIgnoreCase("FEB"))
            return Calendar.FEBRUARY;
        if (strMonth.equalsIgnoreCase("MAR"))
            return Calendar.MARCH;
        if (strMonth.equalsIgnoreCase("APR"))
            return Calendar.APRIL;
        if (strMonth.equalsIgnoreCase("MAY"))
            return Calendar.MAY;
        if (strMonth.equalsIgnoreCase("JUN"))
            return Calendar.JUNE;
        if (strMonth.equalsIgnoreCase("JUL"))
            return Calendar.JULY;
        if (strMonth.equalsIgnoreCase("AUG"))
            return Calendar.AUGUST;
        if (strMonth.equalsIgnoreCase("SEP"))
            return Calendar.SEPTEMBER;
        if (strMonth.equalsIgnoreCase("OCT"))
            return Calendar.OCTOBER;
        if (strMonth.equalsIgnoreCase("NOV"))
            return Calendar.NOVEMBER;
        if (strMonth.equalsIgnoreCase("DEC"))
            return Calendar.DECEMBER;
        else
            return 0;
    }

    /**
     * To determine the terminating date in some edge scenario's such as when the flight arrives before 3:00AM, is
     * considered as the previous date.
     *
     * @param arrivalDate - Flight arrival date.
     * @param arrivalTime - Flight arrival time.
     * @return terminating date string
     */
    public static String getTerminationDate(String arrivalDate, String arrivalTime) {
        SimpleDateFormat sdf = new SimpleDateFormat(BeanConstants.JMOCA_TimeStamp_Format);
        String dateAndTime = arrivalDate + " " + arrivalTime;
        Calendar cal = Calendar.getInstance();
        cal.setTime(sdf.parse(dateAndTime, new ParsePosition(0)));
        cal.add(Calendar.HOUR_OF_DAY, -BeanConstants.TERMINATION_ARRIVAL_TIME_THRESHOLD_HOURS);
        DateFormat df = new SimpleDateFormat(BeanConstants.JMOCA_Date_Format);
        return df.format(cal.getTime());
    }

    /**
     * It Eliminates the time from Date and convert the date into BASIC_DATE_FORMAT and return as string.
     *
     * @param inputDateStr - this input string contain Date and Time.
     * @return date in string with BASIC_DATE_FORMAT.
     */
    public static String getFormattedDateStr(String inputDateStr) {
        String outputDateStr = null;
        if (null != inputDateStr) {
            outputDateStr = getFormattedDate(getDateFromString(inputDateStr, Basic_Date_Format), Basic_Date_Format,
                    false);
        }

        return outputDateStr;
    }

    /**
     * Utility method to convert the date from the input format (MM/dd/yyyy) to man hour acceptable format(yyyy-MM-dd).
     *
     * @param date input date in MM/dd/yyyy format
     * @return date in yyyy-mm-dd format
     */
    public static String getDateInManHrFormat(String date) {
        String manHrDate = null;

        if (StringUtils.isNotEmpty(date)) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
            LocalDate dateTime = LocalDate.parse(date, formatter);

            DateTimeFormatter manHrFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            manHrDate = dateTime.format(manHrFormatter);
        }

        return manHrDate;
    }

    /**
     * Gets today's date in format yyyy-MM-dd.
     *
     * @return today's date in format yyyy-MM-dd
     */
    public static String getTodaysDate() {
        DateTimeFormatter manHrFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        return LocalDate.now().format(manHrFormatter);
    }
}
