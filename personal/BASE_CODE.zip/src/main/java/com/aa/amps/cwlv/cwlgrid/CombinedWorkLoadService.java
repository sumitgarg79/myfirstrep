package com.aa.amps.cwlv.cwlgrid;

import com.aa.amps.cwlv.crossutil.CrossUtilService;
import com.aa.amps.cwlv.cwlgrid.laa.LAATaskService;
import com.aa.amps.cwlv.cwlgrid.lus.LUSTaskService;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.util.Constants;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Business class to get both LAA/LUS Combined Task details.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Service
public class CombinedWorkLoadService {

    private static final Logger LOG = LoggerFactory.getLogger(CombinedWorkLoadService.class);

    private LUSTaskService lusTaskService;
    private LAATaskService laaTaskService;
    private CrossUtilService crossUtilService;

    public CombinedWorkLoadService(LUSTaskService lusTaskService,
                                   LAATaskService laaTaskService,
                                   CrossUtilService crossUtilService) {
        this.lusTaskService = lusTaskService;
        this.laaTaskService = laaTaskService;
        this.crossUtilService = crossUtilService;
    }

    /**
     * Method to fetch from {@code LAATaskService} and {@code LUSTaskSerive} the {@code List}
     * {@code combinedTaskDetails} for the given SearchCriteria.
     *
     * @param searchCriteria - Input Parameter map to get the data for.
     * @return initialized {@code List} of {@code CombinedTaskDetail}
     */
    public List<CombinedTaskDetail> getCombinedWorkLoadTasksDetails(Map<String, Object> searchCriteria) {

        if (!searchCriteria.containsKey(Constants.STATION_PLANNED)) {
            List<String> crossUtilizedstations = crossUtilService.getCrossUtilizationStation();

            if (!CollectionUtils.isEmpty(crossUtilizedstations)) {
                searchCriteria.put(Constants.STATION_PLANNED, crossUtilizedstations);
            }
        }

        List<CombinedTaskDetail> response = new ArrayList<>();

        //LUS TaskDetails
        List<CombinedTaskDetail> responseLUS = lusTaskService.getCombinedTasksDetails(searchCriteria);

        //LAA TaskDetails
        List<CombinedTaskDetail> responseLAA = laaTaskService.getCombinedTasksDetails(searchCriteria);

        // Merging the LUS and LAA response to one list such that LAA comes first in the resultant response.
        if (!CollectionUtils.isEmpty(responseLAA)) {
            LOG.debug("Got response from LAA service {}", responseLAA.size());
            response.addAll(responseLAA);
        }

        if (!CollectionUtils.isEmpty(responseLUS)) {
            LOG.debug("Got response from LUS service {}", responseLUS.size());
            response.addAll(responseLUS);
        }

        /**
         * ROD - Remove the element if flight information is not available, this is invalid record.
         * RON - Mark it InvalidRecord = true if flight information is not available and this need to show on UI as
         * Yellow, this is invalid record.
         */
        response.removeIf(c -> c.getRodRon().equalsIgnoreCase(Constants.ROD) && StringUtils.isEmpty(c.getFlightNbr()));

        return response;
    }

}
