package com.aa.amps.ampsui.restclients;

import lombok.Data;

/**
 * Data class for Station.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/9/2019
 */
@Data
public class StationEntity {
    /**
     * The active maintenance station code for line
     */
    private String mntncStnCd;

    /**
     * The active maintenance station type code which tell if its a heavy(base) station or line station
     */
    private String mntncStnTypCd;

    /**
     * The active maintenance station code for Base
     */
    private String mntncStnAliasCd;
}
