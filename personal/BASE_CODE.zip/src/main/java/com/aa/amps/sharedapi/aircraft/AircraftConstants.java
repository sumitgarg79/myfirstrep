package com.aa.amps.sharedapi.aircraft;

/**
 * Constants class for the Aircraft API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019.
 */
public class AircraftConstants {
    /**
     * Name for the aircraft cache.
     */
    public static final String AIRCRAFT_CACHE = "aircraft";

    /**
     * Private constructor to prevent class instantiation.
     */
    private AircraftConstants() {
        //Nothing goes here.
    }
}
