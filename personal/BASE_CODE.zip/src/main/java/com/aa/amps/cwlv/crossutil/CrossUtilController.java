package com.aa.amps.cwlv.crossutil;

import com.aa.amps.cwlv.util.ServiceResponseMessage;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.aa.amps.cwlv.util.ServiceResponseMessage.ServiceResponseStatus.SUCCESS;

/**
 * REST Controller class for Cross Utilization screen related functionality.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/22/2018.
 */
@RestController
@RequestMapping("/xutil")
@CrossOrigin
public class CrossUtilController {
    private static final Logger LOG = LoggerFactory.getLogger(CrossUtilController.class);

    private CrossUtilService crossUtilService;
    private SessionTimeOutUtil sessionTimeOutUtil;

    @Value("${cwlv.session.flag}")
    private boolean isSessionCheckRequired;

    public CrossUtilController(CrossUtilService crossUtilService, SessionTimeOutUtil sessionTimeOutUtil) {
        this.crossUtilService = crossUtilService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }

    /**
     * GET endpoint for BIGIP health check monitoring.
     *
     * @return string {@code ALL UP} if healthy, {@code ALL DOWN} if sick
     */
    @GetMapping("/health")
    public String healthCheck() {
        String response = "ALL UP";
        try {
            crossUtilService.getCrossUtililzionDetails();
        } catch (Exception ex) {
            LOG.error("Exception while doing health check", ex);
            response = "ALL DOWN";
        }

        return response;
    }

    /**
     * GET request implementation to retrieve all the XUtil records.
     *
     * @return all XUtil records
     */
    @GetMapping("/getAll")
    public List<CrossUtilEntity> getCrossUtilDetails() {
        LOG.debug("Got request to fetch cross utilization data.");

        return crossUtilService.getCrossUtililzionDetails();
    }

    /**
     * PUT request implementation to update an existing XUtil record.
     * <b>Note:</b> If request body is {@code null} then <i>Spring</i> sends back the {@code 400(BAD REQUEST)} status
     * so that scenario need not be handled here.
     *
     * @param request the {@code CrossUtilEntity} record to update
     * @return the {@code ResponseEntity} with status 200 (OK) if successfully updated
     * or with status 404 (NOT_FOUND) no record is updated
     */
    @PutMapping("/update")
    public ResponseEntity<ServiceResponseMessage> updateCrossUtilRecord(@RequestBody CrossUtilEntity request) {
        LOG.info("Got request to update Cross Util record.");

        //validating session
        if (request != null && isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(request.getSmSession());
        }

        ResponseEntity response = null;
        Optional<ServiceResponseMessage> updateResult = crossUtilService.updateCrossUtilRecord(request);

        String resultStatus = updateResult.orElse(ServiceResponseMessage.getGenericExceptionStatus())
            .getStatus().toString();

        if (resultStatus.equalsIgnoreCase(SUCCESS.toString())) {
            response = ResponseEntity.ok().body(updateResult);
        } else {
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(updateResult);
        }

        return response;
    }

    /**
     * POST request implementation to create new crossUtil Station record.
     * <b>Note:</b> If request body is {@code null} then <i>Spring</i> sends back the {@code 400(BAD REQUEST)} status
     * so that scenario need not be handled here.
     *
     * @param request the {@code CrossUtilEntity} record to add
     * @return the {@code ResponseEntity} with status 202 (Accepted) if successfully added
     */
    @PostMapping("/add")
    public ResponseEntity<ServiceResponseMessage> createStation(@RequestBody CrossUtilEntity request) {
        LOG.info("Got request to add CrossUtil record: {}", request);

        if (request != null && isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(request.getSmSession());
        }

        ResponseEntity response = null;
        Optional<ServiceResponseMessage> addResult = crossUtilService.addStation(request);

        String resultStatus = addResult.orElse(ServiceResponseMessage.getGenericExceptionStatus())
            .getStatus().toString();

        if (resultStatus.equalsIgnoreCase(SUCCESS.toString())) {
            response = ResponseEntity.accepted().body(addResult);
        } else {
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(addResult);
        }

        return response;
    }


    /**
     * Delete request implementation to delete an existing crossUtil Station record.
     * <b>Note:</b> If request body is {@code null} then <i>Spring</i> sends back the {@code 400(BAD REQUEST)} status
     * so that scenario need not be handled here.
     *
     * @param stationCode the {@code CrossUtilEntity} record to delete
     * @return the {@code ResponseEntity} with status 202 (Accepted) if successfully deleted
     */
    @DeleteMapping("/delete/{id}/{userId}")
    public ResponseEntity<ServiceResponseMessage> deleteStation(@PathVariable("id") String stationCode, @PathVariable
        ("userId") String userId) {
        LOG.info("Got request to delete cross utilization station data: stn - {}, userId - {}", stationCode, userId);

        ResponseEntity response;

        Optional<ServiceResponseMessage> addResult = crossUtilService.deleteStation(stationCode, userId);
        String resultStatus = addResult.orElse(ServiceResponseMessage.getGenericExceptionStatus())
            .getStatus().toString();

        if (resultStatus.equalsIgnoreCase(SUCCESS.toString())) {
            response = ResponseEntity.ok().body(addResult);
        } else {
            response = ResponseEntity.status(HttpStatus.NO_CONTENT).body(addResult);
        }

        return response;
    }

    /**
     * GET request implementation to retrieve all the XUtil Station records.
     *
     * @return all Station records
     */
    @GetMapping("/getAllStations")
    public List<String> getCrossUtilStation() {
        LOG.info("Got request to fetch cross utilized stations.");

        return crossUtilService.getCrossUtilizationStation();
    }

    /**
     * GET request implementation to retrieve all the XUtil Station records in the format that CWV screen expects for
     * its dropdown list. Eg.,
     * <code>
     * [{"text":"DFW","checked":false},
     * {"text":"ATL","checked":false}]
     * </code>
     *
     * @return all Station records
     */
    @GetMapping("/getAllStationsCwv")
    public List<StationResponse> getCrossUtilStationsForCwv() {
        LOG.info("Got request to fetch cross utilization stations for Cwv");

        List<String> stations = crossUtilService.getCrossUtilizationStation();
        List<StationResponse> response = new ArrayList<>();

        stations.forEach(s -> response.add(new StationResponse(s, false)));

        LOG.debug("Returning a list of {} stations.", stations.size());

        return response;
    }
}
