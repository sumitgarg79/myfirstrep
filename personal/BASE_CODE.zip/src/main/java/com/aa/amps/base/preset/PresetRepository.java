package com.aa.amps.base.preset;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Repository interface which extends CrudRepository. It uses ATSQueryTranslator to generate query at runtime.
 *
 * @author Naseer Mohammed (842018):American Airlines
 * @since 08/06/2018
 */
interface PresetRepository extends CrudRepository<PresetEntity, Integer> {


    /**
     * This Spring Data JPA method to find PresetEntity by UserId, SearchCriteriaId & SearchCriteriaTypeCd.
     *
     * @param userId             User Id
     * @param searchCriterId     search Criteria Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return {@link PresetEntity} object if found else return null.
     */
    PresetEntity findByUserIdAndSearchCriterIdAndSearchCriterTypeCd(String userId, int searchCriterId, String
            searchCriterTypeCd);

    /**
     * This Spring Data JPA method to find all PresetEntities by UserId, SearchCriteriaId order by RowUpdtTime
     *
     * @param userId             User Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return list of {@link PresetEntity}
     */
    List<PresetEntity> findByUserIdAndSearchCriterTypeCdOrderByRowUpdtTmsDesc(String userId, String searchCriterTypeCd);

    /**
     * This Spring Data JPA method uses customized query to get MAX of searchCriteriaId for given UserId &
     * searchCriterTypeCd
     *
     * @param userId             User Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return MAX of searchCriteriaId
     */
    @Query("SELECT coalesce(max(p.searchCriterId), 0) FROM PresetEntity p where p.userId=:userId and" +
            " p.searchCriterTypeCd=:searchCriterTypeCd")
    Long getMaxOfSearchCriterId(@Param("userId") String userId, @Param("searchCriterTypeCd") String searchCriterTypeCd);


    /**
     * This Spring Data JPA method to delete PresetEntity by UserId, SearchCriteriaId & SearchCriteriaTypeCd.
     *
     * @param userId             User Id
     * @param searhCriterId      search Criteria Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return delete status (1 for success, 0 for failed)
     */
    int deleteByUserIdAndSearchCriterIdAndSearchCriterTypeCd(String userId, int searhCriterId, String searchCriterTypeCd);

    /**
     * This Spring Data JPA method to return list of PresetEntity by UserId, SearchCriteriaCd for find if any
     * duplicates exits.
     *
     * @param userId             User Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return {@link PresetEntity} List if found else return empty List
     */
    List<PresetEntity> findByUserIdAndSearchCriterTypeCd(String userId, String searchCriterTypeCd);

    /**
     * This Spring Data JPA method to get the count of Presets for user by userId, SearchCriterTypeCd.
     *
     * @param userId             User Id
     * @param searchCriterTypeCd search Criteria Type Cd
     * @return count of preset entities for userId and SearchCriterTypeCd
     */
    Long countByUserIdAndSearchCriterTypeCd(String userId, String searchCriterTypeCd);
}
