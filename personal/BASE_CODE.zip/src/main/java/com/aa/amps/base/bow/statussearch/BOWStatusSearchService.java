package com.aa.amps.base.bow.statussearch;

import com.aa.amps.base.exception.BaseServiceException;
import com.aa.amps.base.task.WorkPackageEntity;
import com.aa.amps.base.util.DateUtil;
import com.aa.amps.base.util.sysparam.SysParamService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.util.*;

import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.PKG_SCHD_FROM;
import static com.aa.amps.base.bow.statussearch.BOWStatusSearchConstants.PKG_SCHD_TO;
import static com.aa.amps.base.util.BaseConstants.DRAFT_STATUS_FINALIZE_ROLE;

/**
 * Service class for all functionality related to work package search.
 *
 * @author HCL(296319)
 * @since 8/15/2018.
 */
@Service
@Transactional
public class BOWStatusSearchService {
    private static final Logger LOG = LoggerFactory.getLogger(BOWStatusSearchService.class);

    private SysParamService sysParamService;
    private BOWStatusSearchRepository bowStatusSearchRepository;

    public BOWStatusSearchService(BOWStatusSearchRepository bowStatusSearchRepository, SysParamService sysParamService) {
        this.bowStatusSearchRepository = bowStatusSearchRepository;
        this.sysParamService = sysParamService;
    }

    /**
     * Method to get bill of work package using searchCriteria.
     *
     * @param searchCriteria User searchCriteria input.
     * @return List<WorkPackageEntity> List of bill of work package.
     */
    @Transactional(readOnly = true)
    public List<WorkPackageEntity> getWorkPackages(final Map<String, Object> searchCriteria) throws BaseServiceException {
        List<WorkPackageEntity> workPackageEntities = null;

        if (!CollectionUtils.isEmpty(searchCriteria)) {
            try {
                Optional<Date> fromDate = DateUtil.getDateFromString((String) searchCriteria.get(PKG_SCHD_FROM));
                Optional<Date> toDate = DateUtil.getDateFromString((String) searchCriteria.get(PKG_SCHD_TO));

                String finalizeRole = sysParamService.getParamValue(DRAFT_STATUS_FINALIZE_ROLE);

                fromDate.ifPresent(date -> searchCriteria.put(PKG_SCHD_FROM, date));

                toDate.ifPresent(date -> searchCriteria.put(PKG_SCHD_TO, date));

                workPackageEntities = bowStatusSearchRepository.getWorkPackages(searchCriteria, finalizeRole);

            } catch (ParseException e) {
                LOG.error("Exception while parsing FROM or TO date", e);
                throw new BaseServiceException("Exception while parsing package scheduled FROM or TO date.", null);
            }
        }

        return workPackageEntities != null ? workPackageEntities : new ArrayList<>();
    }
}