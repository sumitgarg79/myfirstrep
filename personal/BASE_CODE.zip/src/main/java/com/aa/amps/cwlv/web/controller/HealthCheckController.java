package com.aa.amps.cwlv.web.controller;

import com.aa.amps.cwlv.crossutil.CrossUtilService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


/**
 * Rest Controller for Checking healthStatus of service
 *
 * @author Ramesh Rudra(842020)
 * @since 6/15/2018.
 */
@RestController
@CrossOrigin
@RequestMapping("/health")
public class HealthCheckController {

    private CrossUtilService crossUtilService;


    public HealthCheckController(CrossUtilService crossUtilService) {
        this.crossUtilService = crossUtilService;
    }

    /**
     * This is a test method. It returns a message to confirm if service is working or not.
     *
     * @return json response with sucess message or failure message
     */
    @GetMapping("/serviceStatus")
    public String serviceMessage() {
        List<String> result = crossUtilService.getCrossUtilizationStation();
        if (result != null)
            return "Service is Up";
        else
            return "service failure";
    }
}
