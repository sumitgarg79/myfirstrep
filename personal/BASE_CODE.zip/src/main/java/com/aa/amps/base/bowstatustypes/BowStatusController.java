package com.aa.amps.base.bowstatustypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * REST Controller class for BOW Status drop-down List functionality.
 *
 * @author Paul Verner(650196):American Airlines
 * @since 05/31/2018
 */
@RestController
@RequestMapping("/base/bowStatus")
@CrossOrigin
public class BowStatusController {

    private static final Logger LOG = LoggerFactory.getLogger(BowStatusController.class);
    private BowStatusService bowStatusService;

    public BowStatusController(@Autowired BowStatusService bowStatusService) {
        this.bowStatusService = bowStatusService;
    }

    /**
     * GET request implementation to retrieve all the BOW Status Types.
     *
     * @return all BOW Status Types
     */
    @GetMapping("/getAllBowStatusTypes")
    public List<String> getBowStatusList() {
        LOG.debug("Start getBowStatusList()");

        return bowStatusService.getBowStatusTypes();
    }
}
