package com.aa.amps.cwlv.cwlgrid.laa;

import com.aa.amps.cwlv.exception.TaskRepositoryException;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetail;
import com.aa.amps.cwlv.cwlgrid.util.CombinedTaskDetailMapper;
import com.aa.amps.cwlv.cwlgrid.util.RepositoryConstants;
import com.aa.amps.cwlv.util.Constants;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * Repository class which executes a parameterized query to get the TaskDetails from LAA tables.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */

@Repository
public class LAATaskRepository {

    private static final Logger LOG = LoggerFactory.getLogger(LAATaskRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    LAATaskRepository(@Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {

        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Builds and execute the SQL Query to retrieves the TaskDetails for LAA based on the searchCriteria.
     *
     * @param searchCriteria - holds all the input values to the query.
     * @return {@code List} of CombinedTaskDetails for LAA
     */
    public List<CombinedTaskDetail> getCombinedTasksDetails(Map<String, Object> searchCriteria) {

        if (CollectionUtils.isEmpty(searchCriteria)) {
            throw new TaskRepositoryException(TaskRepositoryException.EMPTY_SEARCH_CRITERIA);
        }

        Map<String, Object> parameterMap = new HashMap<>();
        StringBuilder sql = new StringBuilder();

        sql.append(LAAQueryBuilder.LAA_QUERY);

        appendQueryCondition(searchCriteria, parameterMap, sql);

        appendQueryConditionsForType(searchCriteria, parameterMap, sql);

        appendQueryConditionsForRodRon(searchCriteria, parameterMap, sql);

        sql.append(LAAQueryBuilder.ORDER_BY_AIRCRAFT);
        LOG.debug("LAA CombinedTask SQL Query - {}", sql);

        List<String> parameterMapList = new ArrayList<>();
        parameterMap.forEach((k,v) -> parameterMapList.add(k + "=" + v));
        LOG.debug("LAA CombinedTask SQL Query parameter map values - {} ", parameterMapList);

        return (List<CombinedTaskDetail>) namedJdbcTemplate.query(sql.toString(), parameterMap, new
                CombinedTaskDetailMapper());
    }

    /**
     * To append the query parameters to the sql query builder for the following conditions -
     * schdDt, acftNumber, mntncId, fleetCd, stnCd
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryCondition(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        if (searchCriteria.containsKey(Constants.PLANNED_DATE_FROM) && searchCriteria.containsKey(Constants.PLANNED_DATE_TO)) {
            sql.append(" AND mss.MNTNC_SCHD_DT BETWEEN TO_DATE(:fromDate , 'MM/DD/YYYY') AND TO_DATE(:toDate , 'MM/DD/YYYY')");
            parameterMap.put("fromDate", searchCriteria.get(Constants.PLANNED_DATE_FROM));
            parameterMap.put("toDate", searchCriteria.get(Constants.PLANNED_DATE_TO));
        } else {
            throw new TaskRepositoryException(TaskRepositoryException.PLANNED_DATE_MISSING);
        }

        if (searchCriteria.containsKey(Constants.AIRCRAFT_NO)) {
            sql.append(" AND mss.AIRCFT_NBR in (:acftNumber) ");
            parameterMap.put("acftNumber", searchCriteria.get(Constants.AIRCRAFT_NO));
        }

        if (searchCriteria.containsKey(Constants.FLEET_CODE)) {
            sql.append(" AND subfleet.FOS_FLEET_CD in (:fleetCode) ");
            parameterMap.put("fleetCode", searchCriteria.get(Constants.FLEET_CODE));
        }

        if (searchCriteria.containsKey(Constants.STATION_PLANNED)) {
            sql.append(" AND mss.STATION_CD in (:stationPlanned)");
            parameterMap.put("stationPlanned", searchCriteria.get(Constants.STATION_PLANNED));
        }

        if (searchCriteria.containsKey(Constants.MNTNC_ID)) {
            sql.append(" AND mm.MNTNC_NM like (:mntncId) ");
            parameterMap.put("mntncId", "%" + searchCriteria.get(Constants.MNTNC_ID) + "%");
        }
    }


    /**
     * To append the query parameters to the sql query builder for the following conditions -
     * Type - CHK
     * Type - MTC (SIC & FMR(MEL/NEF/PML/PTF/TAC/TFI/TII))
     * Type - ECO
     * Type - ALL ( query return resultset for all above types)
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryConditionsForType(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        if (searchCriteria.containsKey(Constants.MNTNC_TYPE)) {
            List<String> typeCds = (List<String>) searchCriteria.get(Constants.MNTNC_TYPE);

            sql.append(" AND ( ");
            for (String typeCD : typeCds) {
                if (StringUtils.equalsIgnoreCase(typeCD, Constants.ALL)) {
                    sql.append(" mm.MNTNC_TYPE_CD in (:typeALL)");
                    parameterMap.put("typeALL", Arrays.asList(RepositoryConstants.LAA_TYPE_ALL));

                } else if (StringUtils.equalsIgnoreCase(typeCD, Constants.CHK)) {
                    sql.append("mm.MNTNC_TYPE_CD in (:typeCHK)");
                    parameterMap.put("typeCHK", Arrays.asList(RepositoryConstants.CHK));

                } else if (StringUtils.equalsIgnoreCase(typeCD, Constants.MTC)) {
                    sql.append("mm.MNTNC_TYPE_CD in (:typeMTC)");
                    parameterMap.put("typeMTC", Arrays.asList(RepositoryConstants.LAA_MTC_ITEMS));

                } else if (StringUtils.equalsIgnoreCase(typeCD, Constants.ECO)) {
                    sql.append("mm.MNTNC_TYPE_CD in (:typeECO)");
                    parameterMap.put("typeECO", Arrays.asList(RepositoryConstants.ECO));

                }
                if (typeCds.size() > 1 && typeCds.indexOf(typeCD) + 1 != typeCds.size()) {
                    sql.append(" OR ");
                }
            }
            sql.append(" ) ");

        } else {
            /* This means None is selected for Type - query will return everything same as ALL.*/
            sql.append(" AND mm.MNTNC_TYPE_CD in (:typeALL)");
            parameterMap.put("typeALL", Arrays.asList(RepositoryConstants.LAA_TYPE_ALL));
        }
    }

    /**
     * To append the query parameters to the sql query builder for the following conditions -
     * Rod/Ron/All. If nothing selected by default it will be queried with 'All' option.
     *
     * @param searchCriteria - holds all the input values to the query.
     * @param parameterMap   - holds the parameter values for the sql query
     * @param sql            - query string
     */
    private void appendQueryConditionsForRodRon(Map<String, Object> searchCriteria, Map<String, Object> parameterMap, StringBuilder sql) {
        if (searchCriteria.containsKey(Constants.ROD_RON)) {
            sql.append(" AND mss.BILL_OF_WORK_TYPE_CD in (:ronRodStr)");
            parameterMap.put("ronRodStr", getRonRodList((String) searchCriteria.get(Constants.ROD_RON)));
        } else {
            /* This means None is selected for RonRod - query will return everything.
                So intentionally ignoring this block.
             */
        }
    }

    /**
     * Utility method to return the List of RON or ROD or ALL.
     *
     * @param rodRonStr - holds the value ROD, RON or ALL
     * @return - A list of String with 'O' or 'T' or ['O','T']
     */
    private List<String> getRonRodList(String rodRonStr) {
        List<String> ronRodList;
        if (StringUtils.equalsIgnoreCase(rodRonStr, Constants.ROD)) {
            ronRodList = Arrays.asList(RepositoryConstants.LAA_ROD);

        } else if (StringUtils.equalsIgnoreCase(rodRonStr, Constants.RON)) {
            ronRodList = Arrays.asList(RepositoryConstants.LAA_RON);
        } else {
            ronRodList = Arrays.asList(RepositoryConstants.LAA_RON_ROD);
        }

        return ronRodList;
    }
}
