package com.aa.amps.cwlv.timetogo;

import lombok.Data;

import java.util.Date;

/**
 * This Bean holds TimeToGo Criteria needed for calculating TWD.
 *
 * @author Naseer Mohammed (842018)
 * @since 05/23/2018
 */

@Data
public class TtgCriteria {

    private Long dueTime;
    private Long dueCycles;
    private Date dueDate;
    private Long shipTime;
    private Long shipCycles;
    private Date schdDate;
    private Double avgHoursPerDay;
    private Double avgCyclesPerDay;
}
