package com.aa.amps.cwlv.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;

/**
 * This is the configuration class for database connection. It defines single datasource.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/20/2018.
 */
@Configuration
public class CwlvDataSourceConfig {

    /**
     * Creating datasource from the properties defined in the application.properties.
     * @return {@link DataSource} object.
     */
    @Bean(name = "ampsDS")
    @Primary
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource masterDataSource() {
        return DataSourceBuilder.create().build();
    }

    /**
     * @param dataSource
     * @return {@link JdbcTemplate} object from the underlined datasource object.
     */
    @Bean(name = "jdbcTemplate")
    @Autowired
    public JdbcTemplate jdbcTemplate(@Qualifier("ampsDS") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    /**
     * @param dataSource
     * @return {@link NamedParameterJdbcTemplate} object from the underlined datasource object.
     */
    @Bean(name = "namedJdbcTemplate")
    @Autowired
    public NamedParameterJdbcTemplate namedJdbcTemplate(@Qualifier("ampsDS") DataSource dataSource) {
        return new NamedParameterJdbcTemplate(dataSource);
    }
}
