package com.aa.amps.cwlv.cwlgrid.util;

import com.aa.amps.cwlv.util.DateUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * This class maps LUS/LAA query result set to the {@link CombinedTaskDetail}.
 *
 * @author Naseer Mohammed (842018)
 * @since 03/23/2018
 */
public class CombinedTaskDetailMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        CombinedTaskDetail combinedTaskDetail = new CombinedTaskDetail();
        combinedTaskDetail.setAircftNbr(rs.getString("aircftNbr"));
        combinedTaskDetail.setLogo(rs.getString("logo"));
        combinedTaskDetail.setFleetCd(rs.getString("fleetCd"));
        combinedTaskDetail.setStnCd(rs.getString("stnCd"));
        combinedTaskDetail.setTaskId(rs.getString("taskId"));
        combinedTaskDetail.setTaskDesc(rs.getString("taskDesc"));
        combinedTaskDetail.setSchdDt(DateUtil.getFormattedDateStr(rs.getString("schdDt")));
        combinedTaskDetail.setForecastDt(DateUtil.getFormattedDateStr(rs.getString("forecastDt")));
        combinedTaskDetail.setTaskTypeCd(rs.getString("taskTypeCd"));
        combinedTaskDetail.setRodRon(rs.getString("rodRon"));
        combinedTaskDetail.setMechHour(rs.getString("mechHour"));
        combinedTaskDetail.setFlightNbr(rs.getString("flightNbr"));
        if (combinedTaskDetail.getLogo().equalsIgnoreCase("SCPT")) {
            combinedTaskDetail.setTimeCycle(getCycleDayHrValue(rs));
            combinedTaskDetail.setEtd(rs.getString("etd"));
            combinedTaskDetail.setEta(rs.getString("eta"));
            combinedTaskDetail.setGroundTime(rs.getString("groundTime"));
            if (StringUtils.isEmpty(combinedTaskDetail.getFlightNbr())) {
                combinedTaskDetail.setInvalidRecord(true);
            }
        }
        if (combinedTaskDetail.getLogo().equalsIgnoreCase("DECS")) {
            combinedTaskDetail.setAircftMntncCycle(rs.getString("aircftMntncCycle"));
            combinedTaskDetail.setAircftMntncHours(rs.getString("aircftMntncHours"));
            combinedTaskDetail.setAircftMntncDays(DateUtil.getFormattedDateStr(rs.getString("aircftMntncDays")));
            combinedTaskDetail.setAircftShipCycles(rs.getString("aircftShipCycles"));
            combinedTaskDetail.setAircftShipTime(rs.getString("aircftShipTime"));
            combinedTaskDetail.setAvgCyclesPerDay(rs.getString("avgCyclesPerDay"));
            combinedTaskDetail.setAvgHoursPerDay(rs.getString("avgHoursPerDay"));
        }
        combinedTaskDetail.setPriority(rs.getString("priority"));

        return combinedTaskDetail;
    }

    /**
     * Helper method to determine if timeCycle value to be empty if all are not null or any two are not null.
     * otherwise if any one value , then display that value.
     *
     * @param resultSet to fetch the values of remianCycle, remainDay, remainHr.
     * @return either Cycle/Day/Hour value or null.
     * @throws SQLException
     */
    private String getCycleDayHrValue(ResultSet resultSet) throws SQLException {
        String cycleDayHourStr = null;
        if (StringUtils.isNotEmpty(resultSet.getString("remainCycle")) &&
                StringUtils.isEmpty(resultSet.getString("remainDay")) &&
                StringUtils.isEmpty(resultSet.getString("remainHr"))) {
            cycleDayHourStr = resultSet.getString("remainCycle") + " C";

        } else if (StringUtils.isNotEmpty(resultSet.getString("remainDay")) &&
                StringUtils.isEmpty(resultSet.getString("remainCycle")) &&
                StringUtils.isEmpty(resultSet.getString("remainHr"))) {
            cycleDayHourStr = resultSet.getString("remainDay") + " D";

        } else if (StringUtils.isNotEmpty(resultSet.getString("remainHr")) &&
                StringUtils.isEmpty(resultSet.getString("remainCycle")) &&
                StringUtils.isEmpty(resultSet.getString("remainDay"))) {
            cycleDayHourStr = resultSet.getString("remainHr") + " H";
        } else {
            /**
             * either all are empty or all has value, in both case we need to display the timeCycle value on UI as
             * empty. so this will return null.
             */
        }

        return cycleDayHourStr;
    }
}
