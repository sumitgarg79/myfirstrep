package com.aa.amps.cwlv.crossutil;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.aa.amps.cwlv.crossutil.CrossUtilSqlQuery.*;

/**
 * Repository class for {@link CrossUtilEntity}. It provides the interfaces for CRUD operations
 * on the entity.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/22/2018.
 */
@Repository
public class CrossUtilRepository {
    private static final Logger LOG = LoggerFactory.getLogger(CrossUtilRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    public CrossUtilRepository(
        @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Gets list of all cross utilized stations
     * <b> Note: </b>Fetches data for active stations, i.e., stations
     * that are not deleted by the users.
     *
     * @return {@code List} of cross utilized stations records
     */
    public List<CrossUtilEntity> getAllActiveStations() {
        List<CrossUtilEntity> result = null;

        result = namedJdbcTemplate.query(SELECT_CROSS_UTIL_ALL, new CrossUtilRowMapper());
        if (CollectionUtils.isEmpty(result)) {
            LOG.error("Got null/empty response from repository. Something is VERY wrong. This should not be ignored!");
        }

        LOG.debug("Row count for cross utilized stations from db: {}", result.size());

        return result;
    }

    /**
     * Gets all the data of Cross Utilized stations List.
     *
     * @return {@code List} of cross utilized stations List
     */
    public List<String> getAllStations() {
        List<String> result = null;

        result = namedJdbcTemplate.query(SELECT_CROSS_UTIL_STATION, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                return (rs.getString("MNTNC_STN_CD"));
            }
        });
        if (CollectionUtils.isEmpty(result)) {
            LOG.info("Got null/empty response from repository");
        }

        LOG.debug("Row count for cross utilized stations from db: {}", result.size());

        return result;
    }

    /**
     * Method to retrieve cross utilization details about a specific station. Only <b><i>one</i></b> record will be
     * returned.
     *
     * @param stationCode three letter station code(line stations only)
     * @return cross utilization record
     */
    public Optional<CrossUtilEntity> getStationDetail(String stationCode) {
        List<CrossUtilEntity> queryResult = null;

        CrossUtilEntity response = null;

        Map<String, String> param = new HashMap<>();
        param.put("mntncStnCd", stationCode);

        queryResult = namedJdbcTemplate.query(SELECT_CROSS_UTIL_SINGLE_STN, param, new CrossUtilRowMapper());

        if (CollectionUtils.isEmpty(queryResult)) {
            LOG.info("No data found for station {}", stationCode);
        } else {
            response = queryResult.get(0);
        }

        return Optional.ofNullable(response);
    }

    /**
     * Updates the cross utilization data for the provided record.
     *
     * @param stationDetail the record to be update
     * @return the count of the rows updated
     */
    public int updateStation(CrossUtilEntity stationDetail) {
        int rowsUpdated = 0;

        /*
            Check for following:
                - Input object is not null.
                - Station code is present.
         */
        if (stationDetail != null && StringUtils.isNotBlank(stationDetail.getMntncStnCode())) {
            Map<String, Object> param = new HashMap<>();

            param.put("crossUtliFlg", stationDetail.getCrossUtilFlag().toString().toUpperCase());
            param.put("rodCapacity", stationDetail.getRodCapacity());
            param.put("ronCapacity", stationDetail.getRonCapacity());
            param.put("mntncStnCd", stationDetail.getMntncStnCode());

            rowsUpdated = namedJdbcTemplate.update(UPDATE_CROSS_UTIL, param);
        }

        String mntncStnCode = stationDetail != null ? stationDetail.getMntncStnCode() : null;
        LOG.info("Rows updated for station {} is {}", mntncStnCode, rowsUpdated);

        return rowsUpdated;
    }

    /**
     * Adds New cross utilization station data.
     *
     * @param crossUtilEntity the record to be added
     * @return the count of the rows updated
     */
    public int addStation(CrossUtilEntity crossUtilEntity) {
        int rowsUpdated = 0;

        /*
            Check for following:
                - Input object is not null.
                - Station code is present.
         */
        if (crossUtilEntity != null && StringUtils.isNotBlank(crossUtilEntity.getMntncStnCode())) {
            Map<String, Object> param = new HashMap<String, Object>();

            param.put("crossUtilFlag", crossUtilEntity.getCrossUtilFlag().toString().toUpperCase());
            param.put("rodCapacity", crossUtilEntity.getRodCapacity());
            param.put("ronCapacity", crossUtilEntity.getRonCapacity());
            param.put("mntncStnCode", crossUtilEntity.getMntncStnCode().toString().toUpperCase());

            rowsUpdated = namedJdbcTemplate.update(INSERT_CROSS_UTIL_STATION, param);

        }
        String mntncStnCode = crossUtilEntity != null ? crossUtilEntity.getMntncStnCode() : null;
        LOG.info("Rows updated for station {} is {}", mntncStnCode, rowsUpdated);

        return rowsUpdated;
    }

    /**
     * updates cross utilization station  to be Active.
     *
     * @param crossUtilEntity the record to be added
     * @return the count of the rows updated
     */
    public int updateStationToActive(CrossUtilEntity crossUtilEntity) {
        int rowsUpdated = 0;

        /*
            Check for following:
                - Input object is not null.
                - Station code is present.
         */
        if (crossUtilEntity != null && StringUtils.isNotBlank(crossUtilEntity.getMntncStnCode())) {
            Map<String, Object> param = new HashMap<String, Object>();

            param.put("crossUtilFlg", crossUtilEntity.getCrossUtilFlag().toString().toUpperCase());
            param.put("rodCapacity", crossUtilEntity.getRodCapacity());
            param.put("ronCapacity", crossUtilEntity.getRonCapacity());
            param.put("mntncStnCd", crossUtilEntity.getMntncStnCode().toString().toUpperCase());


            rowsUpdated = namedJdbcTemplate.update(UPDATE_ADDSTATION_CROSS_UTIL, param);
        }

        String mntncStnCode = crossUtilEntity != null ? crossUtilEntity.getMntncStnCode() : null;
        LOG.info("Rows updated for station {} is {}", mntncStnCode, rowsUpdated);

        return rowsUpdated;
    }

    /**
     * Gets cross utilization station data.
     *
     * @param stationCode the record to be added
     * @return the count of the rows
     */
    public CrossUtilEntity getStation(String stationCode) {

        LOG.info("Get Request CrossUtilisation Station {}", stationCode);
        CrossUtilEntity crossUtilEntity = null;

        Map<String, Object> param = new HashMap<>();
        SqlParameterSource namedParameters = new MapSqlParameterSource("mntncStnCd", String.valueOf(stationCode));
        try {
            crossUtilEntity = (CrossUtilEntity) namedJdbcTemplate.queryForObject
                (SELECT_FOR_STATION,
                 namedParameters, new CrossUtilRowMapper());
        } catch (EmptyResultDataAccessException e) {
            LOG.debug("No Data Found for input station {}", stationCode);

            crossUtilEntity = new CrossUtilEntity();
        }

        return crossUtilEntity;
    }

    /**
     * Deletes requested cross utilization station data.
     *
     * @param stationCode the record to be added
     * @return the count of the rows updated
     */
    public int deleteStation(String stationCode) {

        LOG.info("Request to delete Station" + stationCode);

        Map<String, Object> param = new HashMap<>();
        param.put("mntncStnCode", String.valueOf(stationCode));

        int count = namedJdbcTemplate.update(DELETE_CROSS_UTIL_SELECTED_STATION, param);
        LOG.info("deleted selected station " + stationCode + ", count :" + count);

        return count;
    }
}
