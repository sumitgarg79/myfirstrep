package com.aa.amps.cwlv.model;

import com.aa.amps.cwlv.util.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.text.DecimalFormat;
import java.util.Calendar;

public class Flight implements Serializable {
	/**
	 *
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(Flight.class);

	private static final long serialVersionUID = -2895475272036162509L;
	private AircraftRoutingInfo routingInfo;
	private String flightNumber;
	private String stationClassCode;
	private Long totalShipTime;
	private Long totalShipCycles;
	private boolean maintenanceOppurtunity;

	// Flight Arrival Information
	private String arrivalCity;
	private String arrivalDate;
	private String scheduledArrivalTime;
	private String arrivalTime;
	private String arrivalGateNumber;
	private String arrivalStatus;
	private String arrivalDeviation;
	private String arrivalDuplicateIndicator;

	// Flight Departure Information
	private String departureCity;
	private String departureDate;
	private String departureTime;
	private String scheduledDepartureTime;
	private String departureGateNumber;
	private String departureStatus;
	private String departureDeviation;
	private String departureDuplicateIndicator;

	private String type;
	private boolean isTerminator;
	private boolean isRedEye;

	private String inAir;
	private String totalInAir;
	private String groundTime;

	private transient boolean selected;
	private transient Boolean readOnly;

	//added for MAPSServices
	private String scheduledEquipment, actualEquipment;
	private Long minGroundTimeObjective;
	private String DEFAULT_LOCATIONTYPE_FOR_MODELALLOCATEDONES = "XX";
	private Long jmocaGroundTime;


	public Long getJmocaGroundTime() {
		return jmocaGroundTime;
	}

	public void setJmocaGroundTime(Long jmocaGroundTime) {
		this.jmocaGroundTime = jmocaGroundTime;
	}

	private Long flightTime;

	public Long getFlightTime() {
		return flightTime;
	}

	public void setFlightTime(Long flightTime) {
		this.flightTime = flightTime;
	}


	public Flight() {}

	public Flight(AircraftRoutingInfo rtgInfo)
	{
		this.routingInfo = rtgInfo;

		flightNumber = "";
		stationClassCode = "";
		maintenanceOppurtunity = false;

		arrivalCity = "";
		arrivalTime = "";
		arrivalGateNumber = "";
		arrivalDeviation = "";
		arrivalDuplicateIndicator = "";

		departureCity = "";
		departureTime = "";
		departureGateNumber = "";
		departureDeviation = "";
		departureDuplicateIndicator = "";

		type = "";
		isTerminator = false;
	}

	/**
	 * @return Aircraft
	 */
	public String getNoseId()
	{
		return routingInfo.getNoseId();
	}

	public String getEquipmentType()
	{
		return routingInfo.getEquipmentType();
	}

	/**
	 * @return flightNumber
	 */
	public String getFlightNumber()
	{
		return flightNumber;
	}

	/**
	 * @param flightNumber
	 */
	public void setFlightNumber(String flightNumber)
	{
		this.flightNumber = flightNumber;
	}

	/**
	 * @return stationClassCode
	 */
	public String getStationClassCode()
	{
		return stationClassCode;
	}

	public void setStationClassCode(String string)
	{
		stationClassCode = string;
	}

	/**
	 * @return
	 */
	public Long getTotalShipCycles()
	{
		return totalShipCycles;
	}


	public Long getTotalShipTime()
	{
		return totalShipTime;
	}

	/**
	 * 06/12/07 QI - added to show time in hours MAP-472
	 * @return
	 */
	public String getTotalShipTimeHour()
	{
		// convert minutes to hours
		int hour = new Long(totalShipTime.longValue()).intValue() / 60;
		int min = Math.abs(new Long(totalShipTime.longValue()).intValue() % 60);
		DecimalFormat hourFormat = new DecimalFormat("#####0");
		DecimalFormat minFormat = new DecimalFormat("00");

		return hourFormat.format(hour) + ":" + minFormat.format(min);

	}

	public void setTotalShipCycles(Long shipCycles)
	{
		totalShipCycles = shipCycles;
	}

	public void setTotalShipTime(Long shipTime)
	{
		totalShipTime = shipTime;
	}

	public String getArrivalCity()
	{
		return arrivalCity;
	}

	public void setArrivalCity(String arrivalCity)
	{
		this.arrivalCity = arrivalCity;
	}

	public String getArrivalDate()
	{
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate)
	{
		this.arrivalDate = arrivalDate;
	}

	public String getArrivalTime()
	{
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime)
	{
		this.arrivalTime = arrivalTime;
	}

	public String getArrivalGateNumber()
	{
		return arrivalGateNumber;
	}

	public void setArrivalGateNumber(String arrivalGateNumber)
	{
		this.arrivalGateNumber = arrivalGateNumber;
	}

	public String getArrivalStatus()
	{
		return arrivalStatus;
	}

	public void setArrivalStatus(String arrivalStatus)
	{
		this.arrivalStatus = arrivalStatus;
	}

	public String getDepartureCity()
	{
		return departureCity;
	}

	public void setDepartureCity(String departureCity)
	{
		this.departureCity = departureCity;
	}

	public String getDepartureDate()
	{
		return departureDate;
	}

	public void setDepartureDate(String departureDate)
	{
		this.departureDate = departureDate;
	}

	public String getDepartureTime()
	{
		return departureTime;
	}

	public void setDepartureTime(String departureTime)
	{
		this.departureTime = departureTime;
	}

	public String getDepartureGateNumber()
	{
		return departureGateNumber;
	}

	public void setDepartureGateNumber(String departureGateNumber)
	{
		this.departureGateNumber = departureGateNumber;
	}

	public String getDepartureStatus()
	{
		return departureStatus;
	}

	public void setDepartureStatus(String departureStatus)
	{
		this.departureStatus = departureStatus;
	}

	/**
	 * @return
	 */
	public boolean isSelected()
	{
		return selected;
	}

	/**
	 * @param b
	 */
	public void setSelected(boolean b)
	{
		selected = b;
	}

	public boolean isMaintenanceOppurtunity()
	{
		return maintenanceOppurtunity;
	}

	public void setMaintenanceOppurtunity(boolean maintenanceOppurtunity)
	{
		this.maintenanceOppurtunity = maintenanceOppurtunity;
	}

	public String getMtcOpp()
	{
		if (isMaintenanceOppurtunity())
			return DEFAULT_LOCATIONTYPE_FOR_MODELALLOCATEDONES;
		else
			return " ";

	}

	public Boolean getReadOnly()
	{
		return readOnly;
	}

	public void setReadOnly(Boolean boolean1)
	{
		readOnly = boolean1;
	}

	public boolean equals(Object obj)
	{
		if (obj == null)
			return false;
		if (!(obj instanceof Flight))
			return false;
		//if(null != obj){
			// Comparision make sures the departure and arrival times do not overlap
			Flight obj2 = (Flight) obj;
			return this.getNoseId().equals(obj2.getNoseId())
					&& this.getDepartureDate().equals(obj2.getDepartureDate())
					&& ((this.getDepartureTime().equals(obj2.getDepartureTime()) || this.getArrivalTime().equals(
							obj2.getArrivalTime())) || (this.getDepartureTime().compareTo(obj2.getArrivalTime()) > 0 || obj2
							.getDepartureTime().compareTo(this.getArrivalTime()) > 0));
		//}
		//return false;
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}

	public boolean equalsByFlightNumber(Flight obj)
	{
		if(obj==null)
			return false;
		return this.getNoseId().equals(obj.getNoseId())
					&& this.getFlightNumber().equals(obj.getFlightNumber());

	}


	public String toString()
	{
		StringBuffer sb = new StringBuffer();
		sb.append(getNoseId()).append(",").append(flightNumber).append(",");
		sb.append(departureDate).append(",").append(departureCity).append(",").append(departureTime).append(",")
				.append(departureGateNumber).append(",").append(departureStatus).append(",");
		sb.append(arrivalDate).append(",").append(arrivalCity).append(",").append(arrivalTime).append(",").append(
				arrivalGateNumber).append(",").append(arrivalStatus);

		return sb.toString();
	}

	public String getArrivalDeviation()
	{
		return arrivalDeviation;
	}

	public void setArrivalDeviation(String arrivalDeviation)
	{
		this.arrivalDeviation = arrivalDeviation;
	}

	public String getDepartureDeviation()
	{
		return departureDeviation;
	}

	public void setDepartureDeviation(String departureDeviation)
	{
		this.departureDeviation = departureDeviation;
	}

	public boolean isTerminator()
	{
		return isTerminator;
	}

	public void setTerminator(boolean isTerminator)
	{
		this.isTerminator = isTerminator;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getArrivalDuplicateIndicator()
	{
		return arrivalDuplicateIndicator;
	}

	public void setArrivalDuplicateIndicator(String arrivalDuplicateIndicator)
	{
		this.arrivalDuplicateIndicator = arrivalDuplicateIndicator;
	}

	public String getDepartureDuplicateIndicator()
	{
		return departureDuplicateIndicator;
	}

	public void setDepartureDuplicateIndicator(String departureDuplicateIndicator)
	{
		this.departureDuplicateIndicator = departureDuplicateIndicator;
	}

	public AircraftRoutingInfo getRoutingInfo()
	{
		return routingInfo;
	}

	public void setRoutingInfo(AircraftRoutingInfo routingInfo) {
		this.routingInfo = routingInfo;
	}

	public String getScheduledDepartureTime()
	{
		return scheduledDepartureTime;
	}

	public void setScheduledDepartureTime(String scheduledDepartureTime)
	{
		this.scheduledDepartureTime = scheduledDepartureTime;
	}

	public String getScheduledArrivalTime()
	{
		return scheduledArrivalTime;
	}

	public void setScheduledArrivalTime(String scheduledArrivalTime)
	{
		this.scheduledArrivalTime = scheduledArrivalTime;
	}

	public Calendar calculateActualDepartureDateTime()
	{
		Calendar depDate = null;
		if (scheduledDepartureTime != null && !scheduledDepartureTime.trim().equals("")
				&& !scheduledDepartureTime.equalsIgnoreCase("null"))
		{
			depDate = DateUtil.getCalendarDate(departureDate, scheduledDepartureTime);
			if (departureDeviation!=null && !departureDeviation.equals("") && !departureDeviation.equalsIgnoreCase("null"))
				depDate.add(Calendar.MINUTE,  new Integer(departureDeviation.trim()).intValue());
		}	else
		{
			LOGGER.info("scheduled departure time null for noseId:" + routingInfo==null?null:routingInfo.getNoseId() + "-" + flightNumber);
			depDate = DateUtil.getCalendarDate(departureDate, departureTime);
		}
		return depDate;
	}

	/**
	 * @return Returns the actualEquipment.
	 */
	public String getActualEquipment()
	{
		return actualEquipment;
	}

	/**
	 * @param actualEquipment The actualEquipment to set.
	 */
	public void setActualEquipment(String actualEquipment)
	{
		this.actualEquipment = actualEquipment;
	}

	/**
	 * @return Returns the minGroundTimeObjective.
	 */
	public Long getMinGroundTimeObjective()
	{
		return minGroundTimeObjective;
	}

	/**
	 * @param minGroundTimeObjective The minGroundTimeObjective to set.
	 */
	public void setMinGroundTimeObjective(Long minGroundTimeObjective)
	{
		this.minGroundTimeObjective = minGroundTimeObjective;
	}

	/**
	 * @return Returns the scheduledEquipment.
	 */
	public String getScheduledEquipment()
	{
		return scheduledEquipment;
	}

	/**
	 * @param scheduledEquipment The scheduledEquipment to set.
	 */
	public void setScheduledEquipment(String scheduledEquipment)
	{
		this.scheduledEquipment = scheduledEquipment;
	}

	public boolean isRedEye() {
		return isRedEye;
	}

	public void setRedEye(boolean isRedEye) {
		this.isRedEye = isRedEye;
	}

	/**
	 * @return the inAir
	 */
	public String getInAir() {
		return inAir;
	}

	/**
	 * @param inAir the inAir to set
	 */
	public void setInAir(String inAir) {
		this.inAir = inAir;
	}

	/**
	 * @return the totalInAir
	 */
	public String getTotalInAir() {
		return totalInAir;
	}

	/**
	 * @param totalInAir the totalInAir to set
	 */
	public void setTotalInAir(String totalInAir) {
		this.totalInAir = totalInAir;
	}

	/**
	 * @return the groundTime
	 */
	public String getGroundTime() {
		return groundTime;
	}

	/**
	 * @param groundTime the groundTime to set
	 */
	public void setGroundTime(String groundTime) {
		this.groundTime = groundTime;
	}

	//US227587
	public Calendar calculateActualArrivalDateTime()
	{
		Calendar arrDate = null;
		if (scheduledArrivalTime != null && !scheduledArrivalTime.trim().equals("")
				&& !scheduledArrivalTime.equalsIgnoreCase("null"))
		{
			arrDate = DateUtil.getCalendarDate(arrivalDate, scheduledArrivalTime);
			if (arrivalDeviation!=null && !arrivalDeviation.equals("") && !arrivalDeviation.equalsIgnoreCase("null"))
				arrDate.add(Calendar.MINUTE,  new Integer(arrivalDeviation.trim()).intValue());
		}	else
		{
			LOGGER.info("scheduled arrival time null for noseId:" + routingInfo==null?null:routingInfo.getNoseId() + "-" + flightNumber);
			arrDate = DateUtil.getCalendarDate(arrivalDate, arrivalTime);
		}
		return arrDate;
	}

}
