package com.aa.amps.base.mntnctasktypes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Rest Controller for getting List of AircraftMaintenance Task Types.
 *
 * @author Sudeep (842019)
 * @since 05/21/2018
 */

@CrossOrigin
@RestController
@RequestMapping("/base/acftMntncTaskTypes")
public class MntncTaskTypesController {

    private static final Logger LOG = LoggerFactory.getLogger(MntncTaskTypesController.class);
    private MntncTaskTypesService mntncTaskTypesService;

    public MntncTaskTypesController(MntncTaskTypesService mntncTaskTypesService) {
        this.mntncTaskTypesService = mntncTaskTypesService;
    }

    /**
     * This method is used to retrieve All the aircraft maintenance types either 'B' (Base) , 'LB'(LineBase) and ALL (B,LB).
     *
     * @param appType ,values can be either 'B' ,'LB',when appType is null ALL (B,LB) .
     * @return List of MaintenanceTypes based on the app type.
     **/
    @GetMapping("/getAll")
    public List<MntncTaskTypeEntity> getAircraftMaintenanceTaskTypes(@RequestParam(value = "appType", required = false) String appType) {
        LOG.debug("Request to fetch AircraftMaintenanceTypes of appType.{}", appType);
        return mntncTaskTypesService.getMaintenanceTaskTypes(appType);
    }

}
