package com.aa.amps.base.bow.actions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * This class contains the REST endpoint for  the functionality related to Bill Of Work Actions
 *
 * @author HCL(296319)
 * @since 7/27/2018.
 */
@CrossOrigin
@RestController
@RequestMapping({"/base/bow/actions"})
public class BOWStatusActionController {
    private static final Logger LOG = LoggerFactory.getLogger(BOWStatusActionController.class);

    private BOWStatusActionService bowStatusActionService;

    public BOWStatusActionController(BOWStatusActionService bowStatusActionService) {
        this.bowStatusActionService = bowStatusActionService;
    }

    /**
     * Fetches all the active bow status actions.
     *
     * @return List<String>
     */
    @GetMapping("/getAllActions")
    public List<String> getAllActions() {
        LOG.info("received request for search bow status actions ");
        return bowStatusActionService.getAllActions();
    }
}
