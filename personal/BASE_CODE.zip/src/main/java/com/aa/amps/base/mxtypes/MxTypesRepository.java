package com.aa.amps.base.mxtypes;


import org.springframework.jdbc.core.SingleColumnRowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

/**
 * MxType Repository to perform all the CRUD Operations.
 *
 * @author Shyam Sundar Ashok(202571):American Airlines
 * @since 06/01/2018.
 */

@Repository
class MxTypesRepository {

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    MxTypesRepository(NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }

    /**
     * Get list of all Mx(maintenance) Types
     * <b> Note: </b>Fetches data for mx types.
     * Currently defined mx(maintenance) types by Business are : " ", RON and Base
     *
     * @return {@code List} of mx(maintenance) types
     */
    List<String> getAllMxTypes() {
        List<String> result = namedJdbcTemplate.query(MxTypesSqlQuery.SELECT_MX__TYPES, new SingleColumnRowMapper<>());
        if (!CollectionUtils.isEmpty(result))
            result = Arrays.asList(result.get(0).split("\\s*,\\s*"));
        return result;
    }
}