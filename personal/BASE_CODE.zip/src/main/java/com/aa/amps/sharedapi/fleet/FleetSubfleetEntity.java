package com.aa.amps.sharedapi.fleet;

import lombok.Data;

import java.util.List;

/**
 * Entity class for Fleet. It contains all the fields needed for Fleet API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 12/11/2018.
 */
@Data
public class FleetSubfleetEntity {
    private String fleet;
    private List<String> subfleet;
    private String airlineCode;
    private boolean validFleetCode = false;
}
