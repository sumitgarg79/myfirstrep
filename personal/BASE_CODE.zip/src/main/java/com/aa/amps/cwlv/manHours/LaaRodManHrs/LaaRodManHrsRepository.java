package com.aa.amps.cwlv.manHours.LaaRodManHrs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.aa.amps.cwlv.manHours.LaaRodManHrs.LaaRodManHrsSqlQuery.ROD_MANHRS_LAA_QUERY;

/**
 * Repository class for {@link LaaTerminationEntity}. It provides the interfaces for CRUD operations
 * on the entity.
 *
 * @author RAMESH RUDRA(842020)
 * @since 5/06/2018.
 */
@Repository
public class LaaRodManHrsRepository {

    private static final Logger LOG = LoggerFactory.getLogger(LaaRodManHrsRepository.class);

    private NamedParameterJdbcTemplate namedJdbcTemplate;

    LaaRodManHrsRepository(
            @Autowired @Qualifier("namedJdbcTemplate") NamedParameterJdbcTemplate namedJdbcTemplate) {
        this.namedJdbcTemplate = namedJdbcTemplate;
    }


    /**
     * This Method provides {@link LaaTerminationEntity} of LaaRodManHrs
     *
     * @param date is passed as string date which is planned date
     * @return LaaTerminationEntity list of LAA ROD MAN Hours.
     */
    public List<LaaTerminationEntity> getLaaRodManHrs(String date) {
        List<LaaTerminationEntity> result = null;

        Map<String, String> param = new HashMap<>();
        param.put("date", date);

        LOG.debug("ROD Manhour LAA query - {}", ROD_MANHRS_LAA_QUERY);
        LOG.debug("Querying LAA man hours for date {}", date);

        result = namedJdbcTemplate.query(ROD_MANHRS_LAA_QUERY, param, new LaaTerminationMapper());

        if (CollectionUtils.isEmpty(result)) {
            LOG.debug("Got null/empty response for LUS_ROD ManHrs repository ");

        }
        return result;
    }
}
