package com.aa.amps.cwlv.web.controller;


import com.aa.amps.cwlv.util.FeatureSwitchUtil;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Rest Controller for Refreshing Sys_Paramtr
 *
 * @author Ramesh Rudra(842020)
 * @since 6/19/2018.
 */
@RestController
@CrossOrigin
@RequestMapping("/feature")
public class FeatureSwitchController {

    private FeatureSwitchUtil featureSwitchUtil;

    public FeatureSwitchController(FeatureSwitchUtil featureSwitchUtil) {
        this.featureSwitchUtil = featureSwitchUtil;
    }


    /**
     * This Method is to refresh the data in paramMap which contains Sys_Param Values where it is used to apply Switch case
     * for Priority0
     */
    @GetMapping("/switch")
    public void refreshMessage() {
        featureSwitchUtil.refreshMap();
    }


    /**
     * GET endpoint to fetch switch flag value.
     *
     * @return value for priority0 switch.
     */
    @GetMapping("/pri0Switch")
    public String getPri0SwitchFlag() {
        String value = featureSwitchUtil.getParamValue("PRIORITY_0_REQ");
        return value;
    }
}
