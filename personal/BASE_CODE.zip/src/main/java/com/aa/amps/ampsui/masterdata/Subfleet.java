package com.aa.amps.ampsui.masterdata;

import lombok.Data;

import java.util.List;

/**
 * Data class for Subfleet.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/7/2019
 */
@Data
public class Subfleet {
    private String subfleetCode;
    private String subfleetName;

    private List<Aircraft> aircraft;
}
