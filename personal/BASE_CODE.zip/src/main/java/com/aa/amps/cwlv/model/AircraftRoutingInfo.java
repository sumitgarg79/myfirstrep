package com.aa.amps.cwlv.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AircraftRoutingInfo implements Serializable, Cloneable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3432301710464420462L;
	private String noseId;
	private String equipmentType;
	private String jmocaStatus;
	private String otsStation;
	private String returnDate;
	private String returnTime;
	private boolean retired;
	private Flight[] flightArray;
	private List<Flight> flights = new ArrayList<Flight>();

	public AircraftRoutingInfo()
	{

	}

	public AircraftRoutingInfo(String noseId)
	{
		this.noseId = noseId;
	}

	public Object clone() {
        try {
            return super.clone();
        }
        catch (CloneNotSupportedException e) {
            throw new InternalError(e.toString());
        }
    }

	public String getEquipmentType()
	{
		return equipmentType;
	}
	public void setEquipmentType(String equipmentType)
	{
		this.equipmentType = equipmentType;
	}
	public List<Flight> getFlights()
	{
		return flights;
	}

	public String getJmocaStatus()
	{
		return jmocaStatus;
	}
	public void setJmocaStatus(String jmocaStatus)
	{
		this.jmocaStatus = jmocaStatus;
	}
	public String getNoseId()
	{
		return noseId;
	}
	public void setNoseId(String noseId)
	{
		this.noseId = noseId;
	}
	public String getOtsStation()
	{
		return otsStation;
	}
	public void setOtsStation(String otsStation)
	{
		this.otsStation = otsStation;
	}
	public String getReturnDate()
	{
		return returnDate;
	}
	public void setReturnDate(String returnDate)
	{
		this.returnDate = returnDate;
	}
	public String getReturnTime()
	{
		return returnTime;
	}
	public void setReturnTime(String returnTime)
	{
		this.returnTime = returnTime;
	}
	public void setRetired(boolean retired)
	{
		this.retired = retired;
	}
	public boolean getRetired()
	{
		return retired;
	}

	public Flight[] getFlightArray()
	{
		return flightArray;
	}

	public void setFlightArray(Flight[] flightArray)
	{
		this.flightArray = flightArray;
	}
}
