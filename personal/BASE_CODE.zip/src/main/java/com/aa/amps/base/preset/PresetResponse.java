package com.aa.amps.base.preset;

import lombok.Data;

/**
 * Entity that holds data to be returned from Preset query.
 *
 * @author Naseer Mohammed(842018)
 * @since 08/06/2018.
 */
@Data
public class PresetResponse {

    // SNO is taken from AMPS, as per logic its hold the index number in the preset list.
    private String sno;
    private String presetDesc;
    private String presetData;
    private String presetCreatedDt;
    private String presetUpdatedDt;
    private String presetId;
    private String presetTypeCd;
}
