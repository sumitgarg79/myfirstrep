package com.aa.amps.ampsui.taskassociation;

import lombok.Data;


/**
 * Entity class for Task Associations.
 *
 * @author HCL
 * @since 09/03/2019.
 */
@Data
public class TaskAssociations {

    private String assocTaskId;
    private String asoMntncCode;
    private String lusAsoMntncId;
    private String inclusionsInd;
    private String exclusionsInd;
    private String blockedJobsInd;
}
