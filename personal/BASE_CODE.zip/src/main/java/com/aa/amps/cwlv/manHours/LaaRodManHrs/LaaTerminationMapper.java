package com.aa.amps.cwlv.manHours.LaaRodManHrs;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LaaTerminationMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {

        LaaTerminationEntity laaTerminationEntity = new LaaTerminationEntity();

        laaTerminationEntity.setStation(rs.getString("STATION_CD"));
        laaTerminationEntity.setPriorityCode(rs.getLong("MNTNC_SCHD_IMPACT_CD"));
        laaTerminationEntity.setAircraftNbr(rs.getString("AIRCFT_NBR"));
        laaTerminationEntity.setSchdFlightNbr(rs.getString("SCHD_FLIGHT_NBR"));
        laaTerminationEntity.setSchdDate(rs.getDate("Mntnc_Schd_Dt"));
        laaTerminationEntity.setManHrsOfpriorityCode(rs.getFloat("TotalManHrs"));

        return laaTerminationEntity;
    }
}
