package com.aa.amps.sharedapi.aircraft;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service class for Aircraft API. It provides methods for various operations for Aircraft API.
 *
 * @author Neelabh Tripathi(847697)
 * @since 1/2/2019.
 */
@Service
public class AircraftService {
    private static final Logger LOG = LoggerFactory.getLogger(AircraftService.class);

    private AircraftRepository aircraftRepository;

    public AircraftService(AircraftRepository aircraftRepository) {
        this.aircraftRepository = aircraftRepository;
    }

    /**
     * Method to get all the active aircraft with details(fleet, subfleet, airline code etc). This includes both LAA and
     * LUS aircraft.
     *
     * @return {@code List} of aircraft with details
     */
    public List<AircraftEntity> getAllAircraft() {
        LOG.debug("getAllAircraft() - Fetching all the active aircraft.");

        List<AircraftEntity> aircraftResponse = aircraftRepository.getAllAircraftDetails();
        LOG.debug("getAllAircraft() - Returning a total of {} aircraft.", aircraftResponse.size());

        return aircraftResponse;
    }

    /**
     * Method to get all aircraft with specific airline code(LAA or LUS).
     *
     * @param airlineCode LAA or LUS
     * @return {@code List} of aircraft with details
     */
    public List<AircraftEntity> getAllAircraft(String airlineCode) {
        LOG.debug("getAllAircraft() - Fetching all aircraft for airline code {}.", airlineCode);
        List<AircraftEntity> aircraft = null;

        if (StringUtils.isNotEmpty(airlineCode)) {
            List<AircraftEntity> allAircraft = aircraftRepository.getAllAircraftDetails();

            aircraft = allAircraft.stream()
                .filter(a -> a.getAirlineCode().equalsIgnoreCase(airlineCode))
                .collect(Collectors.toList());

        }

        if (aircraft == null) {
            aircraft = new ArrayList<>();
        }

        LOG.debug("getAllAircraft() - Returning {} aircraft.", aircraft.size());

        return aircraft;
    }

    /**
     * Method to get details of specific aircraft.
     *
     * @param aircraftNumber aircraft number(e.g., 3AB)
     * @return aircraft details if aircraft number is valid, a {@code empty} object otherwise
     */
    public AircraftEntity getAircraft(String aircraftNumber) {
        LOG.debug("getAircraft() - Getting aircraft details for input {}", aircraftNumber);

        AircraftEntity matchingAircraft = null;

        if (StringUtils.isNotEmpty(aircraftNumber)) {
            List<AircraftEntity> allAircraft = aircraftRepository.getAllAircraftDetails();

            matchingAircraft = allAircraft.stream()
                .filter(a -> a.getAircraftNumber().equalsIgnoreCase(aircraftNumber))
                .findAny()
                .orElse(new AircraftEntity());
        } else {
            matchingAircraft = new AircraftEntity(); // to avoid NPE at calling method
        }

        if (StringUtils.isNotBlank(matchingAircraft.getAirlineCode())) {
            LOG.debug("getAircraft() - Got matching aircraft details {}.", matchingAircraft);

        } else {
            LOG.debug("getAircraft() - Did not find any matching aircraft for {}.", aircraftNumber);
        }

        return matchingAircraft;
    }

    /**
     * Method to clear the aircraft cache.
     */
    @CacheEvict(value = AircraftConstants.AIRCRAFT_CACHE, allEntries = true)
    public void clearAircraftCache() {
        LOG.info("Aircraft cache cleared up.");
    }
}
