package com.aa.amps.cwlv.manHours;


import com.aa.amps.cwlv.manHours.LaaRodManHrs.LaaRodManHrsService;
import com.aa.amps.cwlv.util.SessionTimeOutUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * REST Controller class for RodAndRonManHrs screen related functionality.
 *
 * @author RAMESH RUDRA(842020)
 * Created on 4/17/2018.
 */
@RestController
@RequestMapping("/stationManHour")
@CrossOrigin
public class RodAndRonManHrsController {

    private static final Logger LOG = LoggerFactory.getLogger(RodAndRonManHrsController.class);

    private RodAndRonManHrsService rodAndRonManHrsService;
    private SessionTimeOutUtil sessionTimeOutUtil;

    private LaaRodManHrsService laaRodManHrsService;

    @Value("${cwlv.session.flag}")
    private boolean isSessionCheckRequired;

    public RodAndRonManHrsController(RodAndRonManHrsService rodAndRonManHrsService, LaaRodManHrsService
        laaRodManHrsService, SessionTimeOutUtil sessionTimeOutUtil) {
        this.rodAndRonManHrsService = rodAndRonManHrsService;
        this.laaRodManHrsService = laaRodManHrsService;
        this.sessionTimeOutUtil = sessionTimeOutUtil;
    }

    /**
     * GET request implementation to retrieve all the RodAndRon ManHrs records for Both LAA and LUS.
     *
     * @return all RodAndRonManHours records
     */
    @PostMapping("/getAll")
    public List<RodAndRonManHours> getRodAndRonManHrs(@RequestBody ManHrsFilterRequest request) {
        LOG.info("Got request to fetch ManHours data for date {}", request);

        //validating session
        if (request != null && isSessionCheckRequired) {
            sessionTimeOutUtil.validateSession(request.getSmSession());
        }

        Map<String, Object> requestMap = request.getSearchCriteriaAsMap();
        List<RodAndRonManHours> totalManHrs = rodAndRonManHrsService.getTotalManHrs(requestMap);

        return totalManHrs;
    }

    /**
     * GET request implementation to retrieve all the RodAndRon ManHrs records for Both LAA and LUS.
     *
     * @return all RodAndRonManHours records
     */
    @PostMapping("/getAllRodManHour")
    public List<RodAndRonManHrsEntity> getRodManHrs(@RequestBody ManHrsFilterRequest request) {
        LOG.info("Got request to fetch ManHours data for date {}", request);

        Map<String, Object> requestMap = request.getSearchCriteriaAsMap();
        List<RodAndRonManHrsEntity> rodManHrs = laaRodManHrsService.getLaaRodManHrs(requestMap);

        return rodManHrs;
    }
}
