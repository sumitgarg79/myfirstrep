package com.aa.amps.cwlv.manHours;

/**
 * Query constant for the {@link RodAndRonManHrsRepository} class.
 *
 * @author Ramesh Rudra(842020)
 * Created on 3/24/2018.
 */
public class ManHoursSqlQuery {

    /**
     * Private default constructor to prevent any instantiation.
     */
    private ManHoursSqlQuery() {
        throw new IllegalStateException("Utility Constant class. This should not be instantiated.");
    }

    public static final String RON_MANHRS_LUS_QUERY =
            "SELECT wp.PLAN_MNTNC_STN_CD," +
                    "NVL(task.MNTNC_TASK_PRIOR_TYPE_CD,3) as MNTNC_TASK_PRIOR_TYPE_CD, " +
                    "sum(task.MNTNC_REQUIR_MECH_HR_QTY) as TotalManHrs" +
                    " FROM MNTNC_WORK_PKG wp, AIRCFT_MNTNC_TASK_PLAN task" +
                    " WHERE wp.MNTNC_WORK_PKG_ID   =task.MNTNC_WORK_PKG_ID" +
                    " AND wp.AIRCFT_NBR= task.AIRCFT_NBR" +
                    " AND wp.MNTNC_WORK_PKG_SCHD_DT=to_date(:date,'YYYY-MM-DD')" +
                    " AND wp.WORK_PKG_TRACK_TYPE_CD in ('01','04','05','06')" +
                    " GROUP BY wp.PLAN_MNTNC_STN_CD," +
                    " NVL(task.MNTNC_TASK_PRIOR_TYPE_CD,3)," +
                    " wp.FLIGHT_NBR ORDER BY PLAN_MNTNC_STN_CD";


    public static final String ROD_MANHRS_LUS_QUERY =
            "   SELECT wp.PLAN_MNTNC_STN_CD," +
                    "NVL(task.MNTNC_TASK_PRIOR_TYPE_CD,3) as MNTNC_TASK_PRIOR_TYPE_CD,sum(task.MNTNC_REQUIR_MECH_HR_QTY) as TotalManHrs" +
                    " FROM MNTNC_WORK_PKG wp," +
                    " AIRCFT_MNTNC_TASK_PLAN task," +
                    " AIRCFT_ROUTE_SCHD ars" +
                    " WHERE wp.MNTNC_WORK_PKG_ID=task.MNTNC_WORK_PKG_ID" +
                    " AND wp.AIRCFT_NBR= task.AIRCFT_NBR" +
                    " AND wp.MNTNC_WORK_PKG_SCHD_DT=to_date(:date,'YYYY-MM-DD')" +
                    " AND wp.WORK_PKG_TRACK_TYPE_CD in ('07','08','09')" +
                    " AND ars.AIRCFT_NBR = wp.AIRCFT_NBR" +
                    " AND (case when ars.flight_arvl_tm_txt < 0300 then trunc(ars.FLIGHT_ARVL_DT-1) else trunc(ars" +
                    ".FLIGHT_ARVL_DT) end) = TO_Date(:date,'YYYY-MM-DD')" +
                    " AND ars.FLIGHT_DESTNTN_STN_CD = wp.PLAN_MNTNC_STN_CD" +
                    " and ars.SCHD_FLIGHT_NBR = wp.FLIGHT_NBR" +
                    " and ars.FLIGHT_CATG_TYPE_CD = 'D'" +
                    " GROUP BY wp.PLAN_MNTNC_STN_CD," +
                    " NVL(task.MNTNC_TASK_PRIOR_TYPE_CD,3)," +
                    " wp.FLIGHT_NBR";

    public static final String RON_MANHRS_LAA_QUERY =
            "SELECT mnt.STATION_CD," +
                    "NVL(mnt.MNTNC_SCHD_IMPACT_CD,3) as MNTNC_SCHD_IMPACT_CD," +
                    "SUM(DECODE(amt.MNTNC_TM,NULL,0,amt.MNTNC_TM)" +
                    " + DECODE(amt.AVIONICS_MANHR_QTY,NULL,0,amt.AVIONICS_MANHR_QTY))/(60) as TotalManHrs" +
                    " FROM aircraft_maint amt," +
                    " MNTNC_SCHD_STATE mnt" +
                    " WHERE TRUNC(mnt.Mntnc_Schd_Dt) = to_date(:date,'YYYY-MM-DD')" +
                    " AND mnt.Mntnc_Schd_Dt > CURRENT_TIMESTAMP - 30" +
                    " AND mnt.Mntnc_Status_Cd = 'G'" +
                    " AND mnt.BILL_OF_WORK_TYPE_CD = 'O'" +
                    " AND mnt.mntnc_id =amt.mntnc_id" +
                    " AND mnt.AIRCFT_NBR=amt.AIRCFT_NBR" +
                    " GROUP BY mnt.STATION_CD," +
                    " NVL(mnt.MNTNC_SCHD_IMPACT_CD,3) ORDER BY mnt.STATION_CD";
}
