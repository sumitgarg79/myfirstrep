package com.aa.amps.base.preset;

import com.aa.amps.base.util.DateUtil;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

/**
 * Mapper class to map Entity to Preset Response.
 *
 * @author Naseer Mohammed (842018)
 * @since 08/09/2018
 */
@Component
public class ResponseMapper {

    /**
     * Method to transfer the Entity object to Preset Response object.
     *
     * @param presetEntityList from DB
     * @return list of presetResponse
     */
    public static List<PresetResponse> mapToPresetResponse(List<PresetEntity>
                                                                   presetEntityList) {

        List<PresetResponse> presetResponseList = new ArrayList<>();

        if (!CollectionUtils.isEmpty(presetEntityList)) {
            IntStream.range(0, presetEntityList.size())
                    .forEach(idx -> {
                        PresetResponse response = new PresetResponse();
                        response.setSno(String.valueOf(idx + 1));
                        response.setPresetDesc(presetEntityList.get(idx).getSearchCriterTxt());
                        response.setPresetData(presetEntityList.get(idx).getActlSelectTxt());

                        response.setPresetCreatedDt(DateUtil.getFormattedDate(presetEntityList.get(idx).getRowCreateTms()
                                , DateUtil.DATE_FORMAT_MMDDYYYY, false));
                        response.setPresetUpdatedDt(DateUtil.getFormattedDate(presetEntityList.get(idx).getRowUpdtTms(),
                                DateUtil.DATE_FORMAT_MMDDYYYY, false));
                        response.setPresetId(String.valueOf(presetEntityList.get(idx).getSearchCriterId()));
                        response.setPresetTypeCd(presetEntityList.get(idx).getSearchCriterTypeCd());

                        presetResponseList.add(response);
                    });
        }

        return presetResponseList;
    }
}
