package com.aa.amps.base.user;

import com.aa.amps.base.util.UserIdUtil;
import lombok.Data;

/**
 * User Login Request object.
 *
 * @author Paul Verner (650196)
 * @since 9/13/2018
 */
@Data
public class UserRequest {

    private String userId;
    private String firstName;
    private String lastName;

    /**
     * Trim the first 2 characters from the userId.
     * eg. 00842018 to 842018.
     *
     * @return userId - last 6 characters only
     */
    public String getUserId() {

        return UserIdUtil.shortenUserIdTo6Characters(userId);
    }
}
