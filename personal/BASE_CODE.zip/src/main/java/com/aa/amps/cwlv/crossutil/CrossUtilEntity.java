package com.aa.amps.cwlv.crossutil;

import lombok.*;
import org.springframework.stereotype.Repository;

/**
 * Entity that represents the CRSS_UTLZD_STN_CAP table in the DB.
 *
 * @author Neelabh Tripathi(847697)
 * @since 3/22/2018.
 */
@Repository
@Data
public class CrossUtilEntity {

    /** The maintenance station code for which the data is stored in this Class. Its also a primary key in the DB */
    private String mntncStnCode;

    /** Denotes if the station is cross utilized, i.e., can support both LAA and LUS a/c for maintenance */
    private Character crossUtilFlag;

    /** Capacity for ROD(Remain OverNight) flight maintenances */
    private Long rodCapacity;

    /** Capacity for ROD(Remain OverNight) flight maintenances */
    private Long ronCapacity;

    /** Indicates if the station is active or deleted */
    private Character activeFlag;

    /** User id for auditing purpose */
    private String userId;

    /** SiteMinder session cookie holder. For the purpose of checking session timeouts */
    private String smSession;
}
