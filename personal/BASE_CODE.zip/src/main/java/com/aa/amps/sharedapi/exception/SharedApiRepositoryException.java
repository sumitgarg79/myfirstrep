package com.aa.amps.sharedapi.exception;

import lombok.Getter;
import lombok.Setter;

/**
 * The wrapper exception class for all the repository classes in SharedApi package. All repositories <b>must</b> wrap
 * the checked exceptions into this exception class and then throw an object of this exception class.
 *
 * @author Neelabh Tripathi
 * @since 12/11/2018
 */
@Getter
@Setter
public class SharedApiRepositoryException extends Exception {

    public static final String RECORD_ADD_FAILED = "Failed to Add Record. Please see logs for details";
    public static final String RECORD_UPDATE_FAILED = "Failed to Update Record. Please see logs for details";
    public static final String RECORD_DELETE_FAILED = "Failed to Delete Record. Please see logs for details";
    public static final String RECORD_EXIST = "Description you entered already exists please rename and try again.";
    public static final String RECORD_NOT_FOUND_DESC = "No matching record found.";
    public static final String DATA_ACCESS_EXCEPTION = "Records could not be fetched from DB.";

    private final String statusCode;

    public SharedApiRepositoryException(String message, String statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
