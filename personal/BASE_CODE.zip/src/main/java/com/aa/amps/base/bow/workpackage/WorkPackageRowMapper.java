package com.aa.amps.base.bow.workpackage;

import com.aa.amps.base.task.WorkPackageEntity;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Rowmapper for {@link WorkPackageEntity}.
 *
 * @author
 * @since 8/15/2018.
 */
public class WorkPackageRowMapper implements RowMapper {

    @Override
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
        WorkPackageEntity draftDetailsEntity = new WorkPackageEntity();

        draftDetailsEntity.setWorkPkgId((rs.getLong("DRAFT_WORK_PKG_ID")));
        draftDetailsEntity.setAircraftNbr((rs.getString("AIRCFT_NBR")));
        draftDetailsEntity.setPkgSchdDt(rs.getString("DRAFT_PKG_SCHD_DT"));
        draftDetailsEntity.setPlanStationCd(rs.getString("DRAFT_PLAN_STN_CD"));
        draftDetailsEntity.setTrackTypeCd(rs.getString("DRAFT_TRACK_TYPE_CD"));
        draftDetailsEntity.setSpan(rs.getLong("DRAFT_SPAN"));
        draftDetailsEntity.setWorkOrderJobCd(rs.getString("WORK_ORDER_JOB_CD"));
        draftDetailsEntity.setSceptreMntncWorkPkgId(rs.getString("SCEPTRE_MNTNC_WORK_PKG_ID"));
        draftDetailsEntity.setDockCd(rs.getString("DRAFT_DOCK_CD"));
        draftDetailsEntity.setWorkPkgTxt(rs.getString("DRAFT_WORK_PKG_TXT"));
        draftDetailsEntity.setWorkPkgStatusCd(rs.getString("DRAFT_WORK_PKG_STATUS_CD"));
        draftDetailsEntity.setUserId(rs.getString("UPDATE_USER_ID"));
        draftDetailsEntity.setUpdatedTime(rs.getString("LAST_UPDATE_TIME"));
        draftDetailsEntity.setComments(rs.getString("COMMENTS"));
        return draftDetailsEntity;
    }

}
