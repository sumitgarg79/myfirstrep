/******************************************************************************
 **
 **  Database        : gpldb
 **  Procedure Name  : wbedb_FE_insert 
 **  Author          : Saurabh Gupta (Keane Inc.)	
 **  Date            : 09/15/2006
 **  Company         : UBS
 **  Project         : ETL
 **  System          : GPL Workbench
 **
 *******************************************************************************
 ** Description: This stored procedure will insert record to the wb_fund_earnings table.
 **
 ** Modified:  
 ******************************************************************************/
use gpldb
go

IF OBJECT_ID('dbo.wbedb_FE_insert') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.wbedb_FE_insert
    IF OBJECT_ID('dbo.wbedb_FE_insert') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.wbedb_FE_insert >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.wbedb_FE_insert >>>'
END
go
/*
    Author: Saurabh Gupta (Keane Inc.)
    Date: 09/15/2006
    Description: This stored procedure will insert record to the wb_fund_earnings table.

*/
CREATE PROCEDURE wbedb_FE_insert 
	 		@bgnrefno			VARCHAR(12),
	 		@fund_code			VARCHAR(6),
	 		@accrual_date		DATETIME,
	 		@eff_date			DATETIME,
	 		@activity_date		DATETIME,
	 		@act_qty			INT,
	 		@lnvalue			NUMERIC(38,2),
	 		@invest_yield		NUMERIC(9,6),
	 		@rebate_rate		NUMERIC(9,6),
	 		@mgmt_pct			NUMERIC(5,2),
	 		@fund_rep_cat		CHAR(18),
	 		@spread				NUMERIC(9,6),
	 		@gr_earnings		NUMERIC(17,6),
	 		@rebate				NUMERIC(17,6),
	 		@gpl_fee			NUMERIC(17,6),
	 		@third_party_fee	NUMERIC(17,6),
	 		@net_fund_earnings	NUMERIC(17,6),
	 		@run_ctrl_cd		CHAR(10),
	 		@user_id 			VARCHAR(15),
	        @mod_user			VARCHAR(15),
    		@mod_module     	VARCHAR(50),
	 		@rec_type  			CHAR(3),
	 		@load_date    		DATETIME,
	 		@finder_fee			NUMERIC(17,6)
AS
   BEGIN
     DECLARE @fundEariningsCount INTEGER
     SELECT @fundEariningsCount = COUNT(*)  
       FROM dbo.wb_fund_earnings
      WHERE bgnrefno = @bgnrefno
      AND	fund_code = @fund_code
      AND	accrual_date = @accrual_date
      AND	eff_date = @eff_date
      AND	run_ctrl_cd = @run_ctrl_cd
    
    IF (@fundEariningsCount < 1)
        INSERT INTO dbo.wb_fund_earnings (
			bgnrefno,
			fund_code,
			accrual_date,
			eff_date,
			activity_date,
			act_qty,
			lnvalue,
			invest_yield,
			rebate_rate,
			mgmt_pct,
			fund_rep_cat,
			spread,
			gr_earnings,
			rebate,
			gpl_FEE,
	        third_party_fee,
	        net_fund_earnings,
	        run_ctrl_cd ,
	        create_user,
	        mod_user,
	        mod_module,
	        rec_type,
	        load_date,
	        third_pty_findfee) 
        VALUES (
	 		@bgnrefno,
	 		@fund_code,
	 		@accrual_date,
	 		@eff_date,
	 		@activity_date,
	 		@act_qty,
	 		@lnvalue,
	 		@invest_yield,
	 		@rebate_rate,
	 		@mgmt_pct,
	 		@fund_rep_cat,
	 		@spread,
	 		@gr_earnings,
	 		@rebate,
	 		@gpl_fee,
	 		@third_party_fee,
	 		@net_fund_earnings,
	 		@run_ctrl_cd ,
	 		@user_id ,
	        @mod_user,
	 		@mod_module,
	 		upper(@rec_type),
	 		@load_date,
	 		@finder_fee)  
	END
go

IF OBJECT_ID('dbo.wbedb_FE_insert') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.wbedb_FE_insert >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.wbedb_FE_insert >>>'
go

EXEC sp_procxmode 'dbo.wbedb_FE_insert','anyMode'
go

GRANT ALL ON dbo.wbedb_FE_insert TO public
go
