
/******************************************************************************
 **  Database        : gpldb
 **  Procedure Name  : wbedb_FA_load
 **  Author          : Nikhil Jain (keane Inc.)
 **  Date            : 8/25/2006
 **  Company         : UBS
 **  Project         : EDB/ETL
 **  System          : GPL Workbench
 *******************************************************************************
 ** Description:       This procedure will insert/update the data in fund_accrual table.
 
 ** Modified:  		   	11/17/2006
 *					   	Three new fields identified and added during
 * 						Month End Balancing construction to provide 
 * 						Summarized Cash Earnings for every fund.
 * 						1.	ttl_gr_earn_cash: this field will contain the 
 * 						summarized Cash Income Accrued for each fund and currency.
 * 						2.	as_of_adj_not_accrued: this field will contain
 *						the summarized adjustment cash earnings accrued for 
 *						each fund and currency.
 *						3.	ttl_lnvalue_cash: this field will contain the loan value
 *						summarized by day for each fund and currency.
 ******************************************************************************/

use gpldb
GO

IF OBJECT_ID('dbo.wbedb_FA_load') IS NOT NULL

BEGIN
    DROP PROCEDURE dbo.wbedb_FA_load
    IF OBJECT_ID('dbo.wbedb_FA_load') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.wbedb_FA_load>>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.wbedb_FA_load>>>'
END
GO

use gpldb
go 

setuser 'dbo'
go 

/******************************************************************************
			Author          : Nikhil Jain (Keane Inc.)
 			Date            : 8/25/2006
 			Description		: This procedure will insert/update the data in fund_accrual table.
 ******************************************************************************/
 
CREATE PROCEDURE dbo.wbedb_FA_load
    @fund_code                      VARCHAR(6),
    @accrual_date                   DATETIME ,
    @ln_currency                    CHAR(3)        	=   'USD' , 
    @accrual_grp                    CHAR(1)        	=   NULL  ,
    @alt_fund_id                    VARCHAR(15)    	=   NULL  ,
    @ttl_gr_earn                    NUMERIC(17,6)  	=   NULL  ,
    @ttl_rebates                    NUMERIC(17,6)  	=   NULL  ,
    @ttl_gpl_fee                    NUMERIC(17,6)  	=   NULL  ,
    @ttl_third_party_fee            NUMERIC(17,6)  	=   NULL  ,
    @ttl_fund_earn                  NUMERIC(17,6)  	=   NULL  ,
    @user_id                        VARCHAR(15)    	=   NULL  ,
    @mod_module                     VARCHAR(50)    	=   NULL  ,
    @run_ctrl_cd                    CHAR(10)       	=   NULL  ,
    @tolerance_flg_exceed           CHAR(1)        	=   'N' , 
	@ttl_gr_earn_cash				NUMERIC(17,6)	=	NULL  ,	
	@as_of_adj_not_accrued			NUMERIC(17,6)	=	NULL  ,
	@ttl_lnvalue_cash				NUMERIC(38,4)	=	NULL  ,
	@load_date    					DATETIME        =     '1900/01/01' 
AS
    DECLARE @fundCodeCount INTEGER
     SELECT @fundCodeCount = COUNT(*)  
       FROM wb_fund_accrual
      WHERE fund_code = @fund_code
        AND	Accrual_date = @accrual_date
        AND ln_currency =  @ln_currency
      
       IF (@fundCodeCount > 0)
    	   UPDATE 	dbo.wb_fund_accrual
	          SET	accrual_grp 	= @accrual_grp,
	       			alt_fund_id 	= alt_fund_id,
			        ttl_gr_earn 	= @ttl_gr_earn,
	    		    ttl_rebates 	= @ttl_rebates,
			        ttl_gpl_fee 	= @ttl_gpl_fee,
			        ttl_third_pty_fee = @ttl_third_party_fee,
			        ttl_fund_earn 	= @ttl_fund_earn, 
			        mod_user 		= @user_id,
			        mod_module 		= @mod_module,
			        run_ctrl_cd 	= @run_ctrl_cd,
			        tolerance_flg_exceed =  @tolerance_flg_exceed,
			        ttl_gr_earn_cash = @ttl_gr_earn_cash,
			        as_of_adj_not_accrued = @as_of_adj_not_accrued,
					ttl_lnvalue_cash = @ttl_lnvalue_cash
	        WHERE   fund_code = @fund_code
		      AND	Accrual_date = @accrual_date
	          AND	ln_currency =  @ln_currency
    	ELSE   
		BEGIN
            INSERT INTO
            			dbo.wb_fund_accrual(
            			fund_code,Accrual_date,accrual_grp,alt_fund_id,
            			ln_currency,ttl_gr_earn,ttl_rebates,ttl_gpl_fee,
            			ttl_third_pty_fee,ttl_fund_earn,create_user,                  
        	            mod_user,mod_module,run_ctrl_cd,tolerance_flg_exceed,
        	            ttl_gr_earn_cash,as_of_adj_not_accrued,ttl_lnvalue_cash,load_date)   
             VALUES (
             			@fund_code,@accrual_date,@accrual_grp,@alt_fund_id,
             			@ln_currency,@ttl_gr_earn,@ttl_rebates,@ttl_gpl_fee,
        			    @ttl_third_party_fee,@ttl_fund_earn,@user_id,
        			    NULL,@mod_module,@run_ctrl_cd,@tolerance_flg_exceed,
       			        @ttl_gr_earn_cash,@as_of_adj_not_accrued,@ttl_lnvalue_cash,@load_date)                    
		END        
go 
 
IF OBJECT_ID('dbo.wbedb_FA_load') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.wbedb_FA_load>>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.wbedb_FA_load>>>'
go 

sp_procxmode 'wbedb_FA_load', 'anymode'
go 

Grant Execute on dbo.wbedb_FA_load to public
go
