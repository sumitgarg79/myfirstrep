/******************************************************************************
 **  Database        : gpldb
 **  Procedure Name  : dbo.wbedb_ALL_rollback_earnings
 **  Author          : Saurabh Gupta (Keane Inc.)
 **  Date            : 08/22/2006
 **  Company         : UBS
 **  Project         : EDB/ETL
 **  System          : GPL Workbench
 *******************************************************************************
 ** Description:       This Stored Proceddure delete the data from dbo.wb_fund_earnings table 
 **					   on the basis of entered Run Control Code.It will perform the following steps.
 **					   	 1.	Declare a cursor to fetch the records from dbo.wb_fund_earnings for the given 
 **				 			run control code and record type where record type is master.
 **		 				 2. Retrieve bargain refrence number, fund code and effective date for every record.
 **		 				 3. Store the number of adjustments per record that exists for the current value in cursor.
 **						 4.	If number of adjustments are more than 1
 **						 	a)	Get the previous latest run control code
 **		 				 	b)	Get the values from previous adjustments
 **						 	c)	Store the values from the adjustment record to be deleted 
 **						 	d)	Retrieve the values from Master record
 **		 				 	e)	Update the master record WHERE New master=(Old Master - Adjustments) 
 **						 	f)	Finally the adjustment record is deleted from the wb_fund_earnings table 
 **						 5. If number of adjustments is less than 1 then Delete the master record.
 **		 				 6. If number of adjustments equals 1, then Delete Master, Adjustment record and Update 
 **							Original Record ito master record.
 **						 7.	Commit the delete operation.
 **						 8. Close Cursor.     
 ** Modified:  		 : 	
 ******************************************************************************/

use gpldb
GO

IF OBJECT_ID('dbo.wbedb_ALL_rollback_earnings') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.wbedb_ALL_rollback_earnings
    IF OBJECT_ID('dbo.wbedb_ALL_rollback_earnings') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.wbedb_ALL_rollback_earnings>>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.wbedb_ALL_rollback_earnings>>>'
END
GO

/*
    Author: Saurabh Gupta
    Date: 08/22/2006
    Description:       This Stored Proceddure delete the data from dbo.wb_fund_earnings table 
 					   on the basis of entered Run Control Code.It will perform the following steps.
 					   	 1.	Declare a cursor to fetch the records from dbo.wb_fund_earnings for the given 
 				 			run control code and record type where record type is master.
 		 				 2. Retrieve bargain refrence number, fund code and effective date for every record.
 		 				 3. Store the number of adjustments per record that exists for the current value in cursor.
 						 4.	If number of adjustments are more than 1
 						 	a)	Get the previous latest run control code
 		 				 	b)	Get the values from previous adjustments
 						 	c)	Store the values from the adjustment record to be deleted 
 						 	d)	Retrieve the values from Master record
 		 				 	e)	Update the master record WHERE New master=(Old Master - Adjustments) 
 						 	f)	Finally the adjustment record is deleted from the wb_fund_earnings table 
 						 5. If number of adjustments is less than 1 then Delete the master record.
 		 				 6. If number of adjustments equals 1, then Delete Master, Adjustment record and Update 
 							Original Record ito master record.
 						 7.	Commit the delete operation.
 						 8. Close Cursor.       
*/

CREATE PROCEDURE dbo.wbedb_ALL_rollback_earnings
@run_ctrl_cd CHAR(10)
AS  
BEGIN
	DECLARE @bgnrefno VARCHAR(12),
       		@fund_code VARCHAR(6),
       		@eff_date DATETIME,
       		@previous_run_ctrl_cd CHAR(10),
       		@gr_earnings_Master NUMERIC(17,6),
       		@rebate_Master NUMERIC(17,6),
       		@gpl_FEE_Master NUMERIC(17,6),
       		@third_party_fee_Master NUMERIC(17,6),
       		@net_fund_earnings_Master NUMERIC(17,6),
       		@gr_earnings NUMERIC(17,6),
       		@rebate NUMERIC(17,6),
       		@gpl_FEE NUMERIC(17,6),
       		@third_party_fee NUMERIC(17,6),
       		@net_fund_earnings NUMERIC(17,6),
       		@total_adj_counter integer
	DECLARE @REC_TYPE_MASTER CHAR(3)
		SET @REC_TYPE_MASTER = 'MST'
	DECLARE @REC_TYPE_ADJ	CHAR(3)
    	SET @REC_TYPE_ADJ = 'ADJ'
	DECLARE @REC_TYPE_ORIGINAL	CHAR(3)
    	SET @REC_TYPE_ORIGINAL = 'ORG'

 	
 	DECLARE	distinct_bgnrefno_fund_code CURSOR FOR 
 	SELECT DISTINCT bgnrefno,
                	fund_code,
                	eff_date 
			   FROM dbo.wb_fund_earnings 
              WHERE run_ctrl_cd=@run_ctrl_cd 
                AND	rec_type=@REC_TYPE_MASTER
               			
	OPEN  distinct_bgnrefno_fund_code
    FETCH distinct_bgnrefno_fund_code 
    INTO  @bgnrefno,@fund_code,@eff_date

	WHILE (@@sqlstatus = 0) 
    	BEGIN
			SELECT  @total_adj_counter=COUNT(*)
			  FROM 	dbo.wb_fund_earnings 
			 WHERE 	bgnrefno=@bgnrefno 
			   AND  fund_code=@fund_code 
			   AND 	eff_date=@eff_date 
			   AND 	rec_type=@REC_TYPE_ADJ
		                 
                IF  (@total_adj_counter > 1)
			    BEGIN
-->a)	Get the previous latest run control code
	            	SELECT @previous_run_ctrl_cd=max(run_ctrl_cd) 
		              FROM dbo.wb_fund_earnings
			         WHERE bgnrefno=@bgnrefno
			           AND fund_code=@fund_code 
			           AND eff_date=@eff_date
			           AND run_ctrl_cd<>@run_ctrl_cd
			           AND rec_type=@REC_TYPE_ADJ
			           

					DECLARE	@previous_activity_date DATETIME,
	               			@previous_act_qty INT,
	               			@previous_lnvalue NUMERIC(38,2),
		                    @previous_invest_yield NUMERIC(9,6),
		                    @previous_rebate_rate NUMERIC(9,6),
		                    @previous_mgmt_pct NUMERIC(5,2),
		                    @previous_fund_rep_cat CHAR(18),
		                    @previous_spread NUMERIC(9,6),
							@previous_mod_module VARCHAR(50),
							@previous_create_date DATETIME,
							@previous_create_user VARCHAR(15)
		                   
-->b)	Get the values from previous adjustments
               		SELECT	@previous_activity_date=activity_date,
            				@previous_act_qty=act_qty,
            				@previous_lnvalue=lnvalue,
            				@previous_invest_yield=invest_yield,
            				@previous_rebate_rate=rebate_rate,
            				@previous_mgmt_pct=mgmt_pct,
            				@previous_fund_rep_cat=fund_rep_cat,
            				@previous_spread=spread,
            				@previous_mod_module=mod_module,
            				@previous_create_date=create_date,
            				@previous_create_user=create_user 		                   
		             FROM	dbo.wb_fund_earnings
		            WHERE	bgnrefno=@bgnrefno
					  AND 	fund_code=@fund_code 
			          AND 	eff_date=@eff_date
			          AND 	run_ctrl_cd=@previous_run_ctrl_cd
			          AND 	rec_type=@REC_TYPE_ADJ		                   
			                		
               		IF 	@previous_act_qty= NULL 
	               		SET @previous_act_qty=0   
			        IF 	@previous_lnvalue= NULL 
			        	SET @previous_lnvalue=0   
			        IF  @previous_invest_yield= NULL 
			            SET @previous_invest_yield=0   
			        IF  @previous_rebate_rate= NULL 
			            SET @previous_rebate_rate=0   
			        IF  @previous_mgmt_pct= NULL 
			            SET @previous_mgmt_pct=0
			        IF  @previous_run_ctrl_cd=NULL   
						SET @previous_run_ctrl_cd=@run_ctrl_cd

					
-->c)	Store the values from the adjustment record to be deleted 
					SELECT  @gr_earnings=gr_earnings,
					        @rebate=rebate,
					        @gpl_FEE=gpl_FEE,
					        @third_party_fee=third_party_fee,
					        @net_fund_earnings=net_fund_earnings
					  FROM  dbo.wb_fund_earnings 
					 WHERE  bgnrefno=@bgnrefno 
					   AND 	fund_code=@fund_code 
					   AND  eff_date=@eff_date
					   AND 	run_ctrl_cd=@run_ctrl_cd    
					   AND 	rec_type=@REC_TYPE_ADJ     
					                
					IF @gr_earnings= NULL
						SET @gr_earnings=0   
					IF @rebate= NULL
					    SET @rebate=0   
					IF @gpl_FEE= NULL
					    SET @gpl_FEE=0   
					IF @third_party_fee= NULL
						SET @third_party_fee=0   
					IF @net_fund_earnings= NULL
						SET @net_fund_earnings=0 
					                          

-->d)	Retrieve the values from Master record
					SELECT 	@gr_earnings_Master =gr_earnings,
					        @rebate_Master =rebate,
					        @gpl_FEE_Master =gpl_FEE,
					        @third_party_fee_Master= third_party_fee,
					        @net_fund_earnings_Master = net_fund_earnings 
					 FROM	dbo.wb_fund_earnings 
					WHERE 	bgnrefno=@bgnrefno 
					  AND 	fund_code=@fund_code 
					  AND  	eff_date=@eff_date
					  AND   rec_type=@REC_TYPE_MASTER
					               
	               
-->e)	Update the master record WHERE New master=(old Master - Adjustments) 
	               UPDATE 	dbo.wb_fund_earnings 
					  SET   gr_earnings =(@gr_earnings_Master-@gr_earnings),
					        rebate =(@rebate_Master-@rebate),
					        gpl_FEE =(@gpl_FEE_Master-@gpl_FEE),
					        third_party_fee=(@third_party_fee_Master-@third_party_fee),
					        net_fund_earnings = (@net_fund_earnings_Master-@net_fund_earnings), 
					        activity_date=@previous_activity_date,
					        act_qty=@previous_act_qty,
					        lnvalue=@previous_lnvalue,
		                    invest_yield=@previous_invest_yield ,
		                    rebate_rate=@previous_rebate_rate,
							mgmt_pct=@previous_mgmt_pct,
							fund_rep_cat=@previous_fund_rep_cat,
							spread=@previous_spread,
					        run_ctrl_cd=@previous_run_ctrl_cd, 
		                    mod_module=@previous_mod_module,
		                    mod_date=@previous_create_date ,
	  						mod_user=@previous_create_user
					WHERE 	bgnrefno=@bgnrefno 
					  AND   fund_code=@fund_code 
					  AND  	eff_date=@eff_date
					  AND   accrual_date is NULL
					  AND 	run_ctrl_cd=@run_ctrl_cd
					  AND   rec_type=@REC_TYPE_MASTER
					  
					               
-->f) Finally the adjustment record is deleted from the wb_fund_earnings table                                              
					DELETE   
					  FROM	dbo.wb_fund_earnings 
					 WHERE  bgnrefno=@bgnrefno 
					   AND 	fund_code=@fund_code
					   AND  eff_date=@eff_date
					   AND 	run_ctrl_cd=@run_ctrl_cd 
					   AND 	rec_type=@REC_TYPE_ADJ 
					                   
			    END           
-->5. If number of adjustments less than 1 then Deletion of both the master and adjustment record takes place	   
	            ELSE
				BEGIN
			    	DELETE
			          FROM	dbo.wb_fund_earnings
		             WHERE  bgnrefno=@bgnrefno 
		               AND  fund_code=@fund_code
		               AND  eff_date=@eff_date
		               AND  run_ctrl_cd=@run_ctrl_cd 
		               AND 	(rec_type=@REC_TYPE_MASTER OR  rec_type=@REC_TYPE_ADJ)
	            END    
-->6. If number of adjustments equals 1, then Original Record is updated to master   
	            IF  (@total_adj_counter = 1)
				BEGIN
	                UPDATE 	dbo.wb_fund_earnings 
				       SET  rec_type=@REC_TYPE_MASTER
				     WHERE  rec_type=@REC_TYPE_ORIGINAL
				       AND 	bgnrefno=@bgnrefno 
				       AND 	fund_code=@fund_code 
				       AND  eff_date=@eff_date
				END

-->7. Commit the rollback
				COMMIT
			     
                FETCH  distinct_bgnrefno_fund_code 
                 INTO  @bgnrefno,@fund_code,@eff_date  
            END

-->8. Close Cursor            
    CLOSE distinct_bgnrefno_fund_code
    DEALLOCATE CURSOR distinct_bgnrefno_fund_code                 
END                                              
go
  
IF OBJECT_ID('dbo.wbedb_ALL_rollback_earnings') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.wbedb_ALL_rollback_earnings>>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.wbedb_ALL_rollback_earnings>>>'
go 

sp_procxmode 'dbo.wbedb_ALL_rollback_earnings', 'anymode'
go 

Grant Execute on dbo.wbedb_ALL_rollback_earnings to public
go
	