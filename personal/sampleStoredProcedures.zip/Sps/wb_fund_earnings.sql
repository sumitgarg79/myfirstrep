/**
 * This file is a script to create database tables, TRIGGERs, defaults 
 * and rules pertaining to the wb_fund_earnings table
  * this table is the major table in the EDB system
  * It captures all the funds that participates in a loan and their daily earnings 
 * @author      Pinaki Patra
 * @version     %I%, %G%
 * <p>Date: 09/20/2006
 *
 * <p>Modification
 *           <p>By: Modifier
 *           <p>Date: mm/dd/yyyy
 *           <p>Desc: description of change
 */

/* Script modified on 01/22/2007 to include alter script */

IF OBJECT_ID('fund_earnings_rec_type') IS NOT NULL
BEGIN
    exec sp_unbindrule 'wb_fund_earnings.rec_type'
    DROP RULE fund_earnings_rec_type
END
GO

CREATE RULE fund_earnings_rec_type
	AS @limit IN ('MST','ORG','ADJ')
go

IF OBJECT_ID('wb_fund_earnings') IS NOT NULL
BEGIN
    DROP TABLE wb_fund_earnings
END
GO

CREATE TABLE wb_fund_earnings (
       fund_earning_id      numeric(18,0) IDENTITY,
       bgnrefno             varchar(12) NOT NULL,
       fund_code            varchar(6) NOT NULL,
       accrual_date         datetime NULL,
       eff_date             datetime NOT NULL,
       activity_date        datetime NULL,
       act_qty              integer NOT NULL,
       lnvalue              numeric(38,2) NOT NULL,
       invest_yield         numeric(9,6) NOT NULL,
       rebate_rate          numeric(9,6) NOT NULL,
       mgmt_pct             numeric(5,2) NOT NULL,
       fund_rep_cat         char(18) NULL,
       spread               numeric(9,6) NULL,
       gr_earnings          numeric(17,6) NOT NULL,
       rebate               numeric(17,6) NOT NULL,
       gpl_FEE              numeric(17,6) NOT NULL,
       third_party_fee      numeric(17,6) NOT NULL,
       net_fund_earnings    numeric(17,6) NOT NULL,
       rec_type             char(3) NOT NULL,
       run_ctrl_cd          char(10) NOT NULL,
       create_user          varchar(15) NULL,
       create_date          datetime NULL,
       mod_user             varchar(15) NULL,
       mod_date             datetime NULL,
       mod_module           varchar(50) NULL,
       load_date            datetime NULL,
       third_pty_findfee    numeric (17,6) NULL,
       fund_days_open_num   numeric NULL,
       CONSTRAINT XPKwb_fund_earnings 
              PRIMARY KEY CLUSTERED (fund_earning_id ASC), 
       CONSTRAINT fk_wb_fund_earnings_wb_g1_loan
              FOREIGN KEY (bgnrefno)
                             REFERENCES wb_edb_loan  (bgnrefno), 
       CONSTRAINT fk_wb_fund_earning_wb_run_ctrl
              FOREIGN KEY (run_ctrl_cd)
                             REFERENCES wb_run_control  (run_ctrl_cd),
       CONSTRAINT XAK1wb_fund_earnings
       UNIQUE (
              bgnrefno ASC,
              fund_code ASC,
              accrual_date ASC,
              eff_date ASC,
              run_ctrl_cd ASC
       )
)

GO

CREATE INDEX idx_fund_earnings_rec_type ON wb_fund_earnings
(
       rec_type                       ASC
)
go

CREATE INDEX idx_fund_earnings_run_ctrl_cd ON wb_fund_earnings
(
       run_ctrl_cd                    ASC
)
go

/*exec sp_bindrule fund_earnings_rec_type, 'wb_fund_earnings.rec_type'
go*/

IF OBJECT_ID('fund_earnings_rec_type') IS NOT NULL
	    BEGIN
	        exec sp_unbindrule 'wb_fund_earnings.rec_type'
	        DROP RULE fund_earnings_rec_type
	    END
GO
	    
	    CREATE RULE fund_earnings_rec_type
	    	AS @limit IN ('MST','ORG','ADJ')
go

    exec sp_bindrule fund_earnings_rec_type, 'wb_fund_earnings.rec_type'
go

GRANT ALL on wb_fund_earnings to public

GO


IF OBJECT_ID('wb_fund_earnings_instrg') IS NOT NULL
BEGIN
    DROP TRIGGER wb_fund_earnings_instrg
END
GO

CREATE TRIGGER wb_fund_earnings_instrg ON wb_fund_earnings
 For INSERT AS

      BEGIN
           UPDATE wb_fund_earnings
            SET create_date = getdate(), 
                mod_date = getdate() 
            FROM  wb_fund_earnings, inserted 
            WHERE wb_fund_earnings.fund_earning_id = inserted.fund_earning_id
      END
      
GO
  
  IF OBJECT_ID('wb_fund_earnings_updtrg') IS NOT NULL
  BEGIN
      DROP TRIGGER wb_fund_earnings_updtrg
  END

GO
      
      
      CREATE TRIGGER wb_fund_earnings_updtrg ON wb_fund_earnings 
       For UPDATE AS 
       
            	BEGIN 
                	UPDATE	wb_fund_earnings 
           		   SET  mod_date=getdate()  
           		  FROM  wb_fund_earnings,inserted 
           		 WHERE  wb_fund_earnings.fund_earning_id = inserted.fund_earning_id   
     	END
     	
GO