/******************************************************************************
 **  Database        : gpldb
 **  Procedure Name  : wbedb_FE_earnings_load
 **  Author          : Saurabh Gupta (Keane Inc.)
 **  Date            : 8/17/2006
 **  Company         : UBS
 **  Project         : EDB/ETL
 **  System          : GPL Workbench
 *******************************************************************************
    Description: This Stored Procedure is having responsibility to load the data in 
    			 wb_edb_loan and dbo.wb_fund_earnings table for fund earnings extract data.
    			 1.	Declare the variables for default values, master data and 
   				 	difference between master & adjustment records data.
				 2. Check if the record already exists in wb_edb_loan table, if record 
					does not exist it will insert the data in wb_edb_loan table otherwise 
					it will update the data provided init_sett_date is different from 
					init_sett_date of the existing record.
    			 3. It will load fund earnings data and perform following steps
    			 	a. Check If bargain reference, earnings date, fund code and rec_type 
    			 		master does not exists.
    			 	b. If master record does not exists, It will insert the record.
    			 	c. Else retrieve earnings values from existing Master Record.	
    			 	d. Calculte the difference between master record present in the database & 
    			 	   the new extracted record.
    			 	e. If there is differnec between the available earnings and inserted earnings 
    			 		then only update the data else ignore the record.
					f. Check if the Rec Type Original exists in wb_fubd_earning table to create adjustments    			 	
					g. If Rec Type Original not available then update Master to Original, Insert new Master and Insert New 
					   Adjustment record in wb_fund_earnings table.
				    h. Else Update master record and Insert New Adjustment record in wb_fund_earnings table.
 ** Modified:     
 **	Date               31/08/2006
 **	Comments	       Adding the record to wb_edb_loan_history before updating the 
 **				       record in wb_edb_loan
 **				       09/14/2006: Where condition added in wb_edb_loan update
 ** 
 ** Modified	:      06/27/2007
 ** Modified by	:      Sumit Garg
 **	Comments	       Changes to load third party earnings in wb_third_party_earnings table. 
 ******************************************************************************/

use gpldb
GO

IF OBJECT_ID('dbo.wbedb_FE_earnings_load') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.wbedb_FE_earnings_load
    IF OBJECT_ID('dbo.wbedb_FE_earnings_load') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.wbedb_FE_earnings_load>>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.wbedb_FE_earnings_load>>>'
END
GO
/************************************************************************************
    Author: Saurabh Gupta (Keane Inc.)
    Date: 8/17/2006
    Description: This Stored Procedure is having responsibility to load the data in 
    			 wb_edb_loan and dbo.wb_fund_earnings table for fund earnings extract data.
    			 1.	Declare the variables for default values, master data and 
   				 	difference between master & adjustment records data.
				 2. Check if the record already exists in wb_edb_loan table, if record 
					doesn't exist it will insert the data in wb_edb_loan table 
					otherwise it will update the data provided init_sett_date is different from 
					init_sett_date of the existing record.
    			 3. It will load fund earnings data and perform following steps
    			 	a. Check If bargain reference, earnings date, fund code and rec_type 
    			 		master doesn't exists.
    			 	b. If master record does not exists, It will insert the record.
    			 	c. Else retrieve earnings values from existing Master Record.	
    			 	d. Calculte the difference between master record present in the database & 
    			 	   the new extracted record.
    			 	e. If there is differnec between the available earnings and inserted earnings 
    			 		then only update the data else ignore the record.
					f. Check if the Rec Type Original exists in wb_fubd_earning table to create adjustments    			 	
					g. If Rec Type Original not available then update Master to Original, Insert new Master and Insert New 
					   Adjustment record in wb_fund_earnings table.
				    h. Else Update master record and Insert New Adjustment record in wb_fund_earnings table.
************************************************************************************/


CREATE PROCEDURE dbo.wbedb_FE_earnings_load 
@bgnrefno               VARCHAR(12)     =     NULL, 
@fund_code              VARCHAR(6)      =     NULL, 
@eff_date               DATETIME        =     '1900/01/01',
@cpty                   CHAR(6)         =     NULL, 
@cpty_major             CHAR(6)         =     NULL, 
@coll_type_cd           CHAR(1)         =     '0', 
@BL                     CHAR(5)         =     NULL, 
@security_code          VARCHAR(12)     =     NULL,
@init_sett_date         DATETIME        =     '1900/01/01', 
@act_qty                INT             =     0, 
@lnvalue                NUMERIC(38,2)   =     0.00, 
@ln_currency            CHAR(3)         =     NULL, 
@rebate_rate            NUMERIC(9,6)    =     0.00, 
@trade_category         VARCHAR(30)     =     NULL, 
@FUND_XREF              VARCHAR(10)     =     NULL,
@FUND_MAJOR             CHAR(6)         =     NULL,
@fund_rep_cat           CHAR(18)        =     NULL,
@mgmt_pct               NUMERIC(5,2)    =     0.00, 
@invest_yield           NUMERIC(9,6)    =     0.00, 
@spread                 NUMERIC(9,6)    =     0.00, 
@dealer                 VARCHAR(8)      =     NULL, 
@activity_date          DATETIME        =     '1900/01/01', 
@gr_earnings            NUMERIC(17,6)   =     0.00, 
@rebate     	        NUMERIC(17,6)   =     0.00, 
@gpl_fee                NUMERIC(17,6)   =     0.00, 
@third_party_fee        NUMERIC(17,6)   =     0.00, 
@net_fund_earnings      NUMERIC(17,6)   =     0.00, 
@rec_type               CHAR(3)         =     NULL, 
@run_ctrl_cd            CHAR(10)        =     NULL, 
@accrual_date           DATETIME        =     '1900/01/01', 
@mod_module             VARCHAR(50)     =     NULL, 
@user_id                VARCHAR(15)     =     NULL,
@load_date    			DATETIME        =     '1900/01/01',
@returned_earnings		CHAR(1),
@party1_earnings        NUMERIC(17,6),
@party1_desc            VARCHAR(50),
@party2_earnings        NUMERIC(17,6),
@party2_desc            VARCHAR(50),
@party3_earnings        NUMERIC(17,6),
@party3_desc            VARCHAR(50),
@party4_earnings        NUMERIC(17,6),
@party4_desc            VARCHAR(50),
@finder_fee             NUMERIC(17,6)   =     0.00

 


AS 
	BEGIN 
         DECLARE    @net_fund_earnings_Master  	NUMERIC(17,6), 
                    @third_party_fee_Master     NUMERIC(17,6), 
                    @gpl_fee_Master     		NUMERIC(17,6), 
                    @rebate_Master     			NUMERIC(17,6), 
                    @gr_earnings_Master     	NUMERIC(17,6), 
		    		@net_fund_earnings_Diff  	NUMERIC(17,6), 
                    @third_party_fee_Diff     	NUMERIC(17,6) , 
                    @gpl_fee_Diff     			NUMERIC(17,6) , 
                    @rebate_diff     			NUMERIC(17,6), 
                    @gr_earnings_diff     		NUMERIC(17,6), 
		    		@total_diff      			NUMERIC(17,6), 
		    		@bgnrefnovalue   			VARCHAR(12),
					@finder_cd       			VARCHAR(20),                              
			     	@rec_type_MASTER 			CHAR(3),
        		    @rec_type_ADJ				CHAR(3),
				    @rec_type_ORIGINAL			CHAR(3),
        		 	@zero_fee_rate 				NUMERIC(4,2),
		         	@currentDate 				DATETIME,
         			@finder_rate 				NUMERIC(9,6),
         			@fund_earnings_id			NUMERIC(18,0),
         			@min_fee                    NUMERIC(10,4)
         			SET @zero_fee_rate = 0.00
                    SET @rec_type_MASTER = 'MST'
                    SET @rec_type_ORIGINAL = 'ORG'
                    SET @rec_type_ADJ = 'ADJ'
                    SET @currentDate = getdate()	
                    SET @finder_cd  = 'NR'

-->2. 	Check if the record already exists in wb_edb_loan table, if record 
-->		doesn't exist in wb_edb_loan table it will insert the data in wb_edb_loan table 
-->     otherwise it will update the data provided init_sett_date is different from init_sett_date 
-->		of the existing record.

		IF (@returned_earnings <> 'Y')
		BEGIN

		 	DECLARE @bgnrefnoCount INTEGER
	     	SELECT 	@bgnrefnoCount = COUNT(*)  
	       	  FROM 	dbo.wb_edb_loan
	         WHERE 	bgnrefno = @bgnrefno
	    
		    IF (@bgnrefnoCount > 0)
			BEGIN
				DECLARE @bgnrefnoUpdateCount INTEGER
		     	 SELECT @bgnrefnoUpdateCount = COUNT(*)  
		       	   FROM dbo.wb_edb_loan
		          WHERE bgnrefno = @bgnrefno
		      	    AND	finder_rate=@finder_rate 
					AND SUBSTRING(CONVERT( DATETIME,init_sett_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@init_sett_date, 101),1,11)      	
	
		    	IF (@bgnrefnoUpdateCount < 1)     
		    		UPDATE 	dbo.wb_edb_loan 
		       	   	   SET	security_code=@security_code,
							coll_type_cd=@coll_type_cd, 
							dealer=@dealer,
							ln_currency=@ln_currency, 
							init_sett_date=@init_sett_date,
			   				trade_category=@trade_category, 
							mod_user=@user_id,
							mod_module=@mod_module,
							run_ctrl_cd=@run_ctrl_cd
					 WHERE 	bgnrefno=@bgnrefno    
			END
		    ELSE
	    	BEGIN
	    		EXEC dbo.wbedb_FF_Insert	@security_code,@bgnrefno,@cpty,@finder_rate,  
								        	@min_fee,@finder_cd,@run_ctrl_cd,@user_id,@load_date,  
											@mod_module,@cpty_major,@coll_type_cd,@ln_currency,  
											@init_sett_date,@trade_category,@dealer,@user_id    
	   		END
   		END


-->3. Load data in dbo.wb_fund_earnings
-->a. Check If bargain reference, earnings date, fund code and rec_type master does not exists.

	 	DECLARE @bgnrefnoEarningsCount INTEGER
     	SELECT 	@bgnrefnoEarningsCount = COUNT(*)  
       	  FROM 	dbo.wb_fund_earnings
         WHERE 	bgnrefno = @bgnrefno
		   AND  fund_code=@fund_code 
		   AND  SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11) 
		   AND  rec_type=@rec_type_MASTER

		IF (@bgnrefnoEarningsCount < 1)
		BEGIN
-->b. If bargain reference, earnings date, fund code and rec_type master not exists insert the record
             EXEC wbedb_FE_insert
             			 @bgnrefno,@fund_code,@accrual_date,@eff_date,@activity_date,
             			 @act_qty,@lnvalue,@invest_yield,@rebate_rate,@mgmt_pct,@fund_rep_cat,
             			 @spread,@gr_earnings,@rebate,@gpl_fee,@third_party_fee,@net_fund_earnings, 
                         @run_ctrl_cd ,@user_id ,NULL,@mod_module,@rec_type_MASTER,@load_date,@finder_fee
		END
-->c. Else retrieve earnings values from existing Master Record
	    ELSE
     	BEGIN  

			EXEC 	wbedb_FE_earnings_update
					@bgnrefno,@fund_code,@eff_date,@load_date
        	
        	SELECT  @net_fund_earnings_Master= net_fund_earnings,
            		@third_party_fee_Master=third_party_fee,
                 	@gpl_fee_Master=gpl_FEE,
                 	@rebate_Master=rebate,
                 	@gr_earnings_Master=gr_earnings 
          	  FROM 	dbo.wb_fund_earnings 
          	 WHERE 	bgnrefno=@bgnrefno 
          	   AND 	fund_code=@fund_code 
          	   AND 	SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11)  
          	   AND 	rec_type=upper(@rec_type_MASTER)                       

			IF @net_fund_earnings_Master IS NULL
				SET @net_fund_earnings_Master=0.00
			IF @third_party_fee_Master   IS NULL
				SET @third_party_fee_Master=0.00
			IF @gpl_fee_Master IS NULL
				SET @gpl_fee_Master=0.00
			IF @rebate_Master IS NULL
				SET @rebate_Master =0.00
			IF @gr_earnings_Master IS NULL
				SET @gr_earnings_Master=0.00

-->d. Calculte the difference between Master Record Present in the database and new extracted record 
			SET @net_fund_earnings_Diff	 = @net_fund_earnings- @net_fund_earnings_Master
	        SET @third_party_fee_Diff	 = @third_party_fee-@third_party_fee_Master  
			SET @gpl_fee_Diff 		 	 = @gpl_fee-@gpl_fee_Master
	        SET @rebate_diff			 = @rebate-@rebate_Master 
	        SET @gr_earnings_diff      	 = @gr_earnings-@gr_earnings_Master

-->e. If there is differnec between the available earnings and inserted earnings only then update the data else ignore the record.
			SET @total_diff      		 = abs(@net_fund_earnings_Diff) +  abs(@third_party_fee_Diff) + abs(@gpl_fee_Diff) + abs(@rebate_diff) + abs(@gr_earnings_diff) 
			
								--> REMOVE 
					DECLARE @test  VARCHAR(24)
					SET @test=CONVERT(VARCHAR(24),@total_diff)
					PRINT 'Total'
					PRINT   @test 
			
   		    IF (@total_diff > 0.000001)
-->f. Check if the Rec type Original exists to create adjustments
			BEGIN 
	 			DECLARE @originalEarningsCount INTEGER
     			SELECT 	@originalEarningsCount = COUNT(*)  
				FROM  	dbo.wb_fund_earnings 
				WHERE 	bgnrefno=@bgnrefno 
				AND 	fund_code=@fund_code 
				AND 	SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11)  
				AND 	rec_type=@rec_type_ORIGINAL

				IF (@originalEarningsCount < 1) 
-->g. If record type 'Original Not Available' then update master to Original, Insert New master and Insert New Adjustment record.
			    BEGIN 
		            UPDATE 	dbo.wb_fund_earnings 
		            SET	   	rec_type=@rec_type_ORIGINAL,
		                   	mod_user=@user_id 
		            WHERE  	fund_code=@fund_code 
		            AND		bgnrefno=@bgnrefno 
		            AND 	SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11) 
					AND 	accrual_date IS NOT NULL
					AND		run_ctrl_cd<>@run_ctrl_cd
					AND 	rec_type=@rec_type_MASTER 
											
					IF @@rowcount = 1 
					BEGIN
		                EXEC wbedb_FE_insert
		                	@bgnrefno,@fund_code,NULL,@eff_date,@activity_date,@act_qty,@lnvalue,
		                    @invest_yield,@rebate_rate,@mgmt_pct,@fund_rep_cat,@spread,@gr_earnings,
		                    @rebate,@gpl_fee,@third_party_fee,@net_fund_earnings,@run_ctrl_cd ,
		                    @user_id ,NULL,@mod_module,@rec_type_MASTER,@load_date,@finder_fee

		                EXEC wbedb_FE_insert
		                    @bgnrefno,@fund_code,@accrual_date,@eff_date,@activity_date,@act_qty,
		                    @lnvalue,@invest_yield,@rebate_rate,@mgmt_pct,@fund_rep_cat,@spread,
		                    @gr_earnings_diff,@rebate_diff,@gpl_fee_Diff,@third_party_fee_Diff,
		                    @net_fund_earnings_Diff,@run_ctrl_cd ,@user_id ,
		                    NULL,@mod_module,@rec_type_ADJ,@load_date,@finder_fee
		            END
			    END 
-->h. Else Update master and Insert New Adjustment record.
				ELSE
				BEGIN 
		            UPDATE  	dbo.wb_fund_earnings 
		                SET		invest_yield=@invest_yield,
		                        gr_earnings=@gr_earnings,
		                        rebate=@rebate,
		                        gpl_FEE=@gpl_fee,
		                        third_party_fee=@third_party_fee, 
		                        net_fund_earnings=@net_fund_earnings,
		                        mod_user=@user_id ,mod_date=getdate(),
		                        run_ctrl_cd=@run_ctrl_cd,
		                        activity_date=@activity_date,
								act_qty=@act_qty,
								lnvalue=@lnvalue,
								rebate_rate=@rebate_rate,
								mgmt_pct=@mgmt_pct,
								fund_rep_cat=@fund_rep_cat,
								spread=@spread,
	        					mod_module=@mod_module
		                WHERE 	fund_code=@fund_code  
		                AND 	bgnrefno=@bgnrefno 
		                AND 	SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11) 
		                AND 	accrual_date IS NULL
		                AND		rec_type=@rec_type_MASTER 

		            EXEC wbedb_FE_insert
		                @bgnrefno,@fund_code,@accrual_date,@eff_date,@activity_date,@act_qty,
		                @lnvalue,@invest_yield,@rebate_rate,@mgmt_pct,@fund_rep_cat,@spread,
		                @gr_earnings_diff,@rebate_diff,@gpl_fee_Diff,@third_party_fee_Diff,
		                @net_fund_earnings_Diff,@run_ctrl_cd ,@user_id ,
		                NULL,@mod_module,@rec_type_ADJ,@load_date,@finder_fee
-->End h.
		        END 
-->End f.
			END
-->End 3.
		END  
			
		--> added to insert third party earnings 
		--> get fund earnings id 
			SELECT @fund_earnings_id=fund_earning_id
			FROM   wb_fund_earnings
			WHERE 	bgnrefno = @bgnrefno
		    AND  fund_code=@fund_code 
		    AND  SUBSTRING(CONVERT( DATETIME,eff_date,101),1,11)=SUBSTRING(CONVERT( DATETIME,@eff_date, 101),1,11) 
		    AND  rec_type=@rec_type_MASTER
			
			--> call third party earnings load procedure
			EXEC wbedb_third_party_insert @fund_earnings_id, @party1_earnings,@party1_desc,
				 @party2_earnings,@party2_desc,@party3_earnings,@party3_desc,@party4_earnings,@party4_desc,
				 @user_id ,@user_id,@mod_module
	END 
go
  
IF OBJECT_ID('dbo.wbedb_FE_earnings_load') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.wbedb_FE_earnings_load>>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.wbedb_FE_earnings_load>>>'
go 

sp_procxmode 'wbedb_FE_earnings_load', 'anymode'
go 

Grant Execute on dbo.wbedb_FE_earnings_load to public
go