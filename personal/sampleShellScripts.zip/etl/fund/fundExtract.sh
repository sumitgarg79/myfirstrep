#!/usr/bin/ksh -x 
set -x
set -v
#-------------------------------------------------------------

/global1/scripts/ktek.keane.batch FUNDGEN
  
cp /usr/ud/GLOBAL1.GPL.KEANE/iofiles/FUNDFILE.DAT /home/choudhsu/loads/fund/FUNDFILE.DAT
cd /home/choudhsu/loads/fund
chmod 777 *

