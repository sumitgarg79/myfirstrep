#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loadBusCalInfo.sh
#  Author         : Kumar Subramaniam
#  Date Created   : Aug 9, 2006
#
#  Last Revised   : Sumit Garg (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#-------------------------------------------------------------
#-------------------------------------------------------------
#
#  Description    : This script loads Business Calendar info
#                   into the GPL Workbench database with data 
#                   retrieved from the UBS Dating Server system.
#
#-------------------------------------------------------------

echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Started... =====

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=loadBusCalInfo.sh
ACTION_CLASS_NAME=com.ubs.gplw.action.buscal.LoadBusCalInfoAction
BUSINESS_ENTITY=buscal

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Load process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
     
#-----------------------------------------------------------------------
#  Capture exit code from invoking the common batchRunner.sh script
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the process did not complete successfully.
    #--------------------------------------------------------------------------- 
    
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The Process Failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/buscal/Batch.log"
		    
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Ended... =====
exit $exitCode
