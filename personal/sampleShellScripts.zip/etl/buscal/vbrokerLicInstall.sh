#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : vbrokerLicInstall.sh
#  Author         : Kumar Subramaniam
#  Date Created   : Nov 14, 2006
#  Last Revised   :
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script installs the Visibroker License
#                   file needed by the UBS EDP Dating Server 
#                   instance for GPL Workbench.
#
#                   This is a ONE-TIME script that needs to be
#                   run whenever the Dating Server is being
#                   instantiated on a new host. When this script
#                   executes on a given host, it creates a specific
#                   directory structure under dyn data and installs
#                   the host specific Visibroker License file for 
#                   the Dating Server to use.
#
#                   This script basically takes in one parameter
#                   which is the environment such as dev / dev2 /
#                   uat / prod. Invokation examples are:
#                   ./vbrokerLicInstall.sh dev - for DEV
#                   .vbrokerLicInstall.sh uat - for UAT
#
#-------------------------------------------------------------

echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Started... =====

#-------------------------------------------------------------
#  Validate input parameters
#-------------------------------------------------------------
if [ $# -gt 0 ]; then
  printf "%s\n" "Environment parameter passed in is $1."
  ENV=$1
else
  printf "%s\n" "Error at line $LINENO: A required environment parameter is missing. Aborting..."
  printf "%s\n" "For example, the script must be invoked as ./vbrokerLicInstall.sh dev for the DEV environment" 
  exit 1
fi 

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Validate the Environment Parameter passed in
#-------------------------------------------------------------
if [ $1 != 'dev' -a $1 != 'dev2' -a $1 != 'uat' -a $1 != 'prod' ]; then
  printf "%s\n" "Error at line $LINENO: Incorrect environment passed. Valid values are dev, dev2, uat, prod. Cannot continue processing. Aborting..."
  exit 1
fi

#-------------------------------------------------------------
#   Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=vbrokerLicInstall.sh

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#----------------------------------------------------------
#  Copy the Borland Enterprise (BES) Visibroker License INI file from HUFS
#  to the Dyn Data path for GPL Workbench's Dating Server
#----------------------------------------------------------
cp -v $CFG_VAR_BES_VBROKER_LIC_INI_FILE $CFG_VAR_GPL_DS_VBROKER_LIC_DIR
     
#-----------------------------------------------------------------------
#  Capture exitcode from copying of Visibroker License INI file
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the copy of the license file was not successful.
    #---------------------------------------------------------------------------
    
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            -m"Unable to copy Visibroker License INI file needed for running the GPL Workbench Dating Server instance. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME."

    exit $exitCode
fi

#----------------------------------------------------------
#  Invoke the Borland Enterprise License Manager Administration
#  Module to install the Visibroker License in the desired 
#  Dyn Data directory for GPL Workbench the DEV environment.
#
#  Since the License Manager Administration Module is invoked
#  in the interactive (-i) and console mode, when this step in
#  the script is executed, you will see the following menu on
#  the screen.
#
#  License Administration Tool 
#  ---------------------------
#  [0] Direct register (requires internet connection) 
#  [1] Register using Web, and receive activation file via email 
#  [2] List all licenses 
#  [3] Disable a license 
#  [4] Enable a license 
#  [5] Save 
#  [6] Quit
#
#  When you see this menu, enter 6 and hit Enter-key to come out
#  of the menu
#
#  The successful installation of the VisiBroker License via the
#  Borland Enterprise License Administration Tool will result in
#  the following files being installed in the dyn data area for
#  for buscal (/sbcimp/dyn/data/ALG/ALGWB/<env>/etl/buscal/):
#
#  1) borland.pkg
#  2) borland.lic
#
#----------------------------------------------------------
$CFG_VAR_BES_LIC_MGR_ADM_SCRIPT \
	-Dborland.enterprise.licenseDir=$CFG_VAR_GPL_DS_VBROKER_LIC_DIR \
	-Dborland.enterprise.licenseDefaultDir=$CFG_VAR_BES_VBROKER_DEFAULT_LIC_DIR \
	-i console
     
#-----------------------------------------------------------------------
#  Capture exitcode from executing the Borland Enterprise License Manager
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the license installation was not successful.
    #---------------------------------------------------------------------------
    
    
      $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
          -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
          -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
          -e$ENV \
          -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_ACCESS" \
          -k$SHELL_SCRIPT_NAME \
          -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
          -m"Unable to install Visibroker License needed for running the GPL Workbench Dating Server instance. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
          -t"$CFG_VAR_MMNETCOOL_FAILTYPE_AUTHENTICATE" \
          -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME."

    exit $exitCode
    
fi

#---------------------------------------------------------------------------
#  Visibroker License file installed successfully on host
#---------------------------------------------------------------------------
echo ===== Visibroker License file needed for GPL Workbench Dating Server installed successfully on `hostname` =====

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Ended... =====
exit $exitCode
