#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : startGplDatingServer.sh
#  Author         : Kumar Subramaniam
#  Date Created   : Nov 14, 2006
#
#  Last Revised   : Kumar Subramaniam (Keane Inc.)
#  Date Revised   : Mar 11, 2007
#  Why Revised    : Changed log file referenced in UserData field
#                   from etl/buscal/DatingServer.log to 
#                   autosys/startGplDtng*.`date +%y%m%d`.loglog
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 11, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Kumar Subramaniam (Keane Inc.)
#  Date Revised   : Dec 14, 2006
#  Why Revised    : The startDS.ksh script sends a mail message
#                   by default whenever the server is stopped.
#                   This is an informational message and new
#                   guidelines from GSD suggest that we NOT
#                   send mail messages for system event notifications.
#                   Since we have our own instance of the Dating
#                   Server for GPL Workbench, we are going to 
#                   pass a SEND_MAIL_FLAG parameter from the config
#                   file (whose value will be set to N) to the 
#                   startDS.ksh script. The startDS.ksh script will
#                   send a mail only if the SEND_MAIL_FLAG is Y.
#                   This way we can have a more flexible design. 
#
#-------------------------------------------------------------
#
#  Description    : This script will create an instance of the
#                   UBS Equity Data Programme (EDP) Dating Server
#                   running on host/port for the GPL Workbench
#                   application. By design, the GPL Workbench
#                   application will have an instance of the Dating
#                   Server per environment (i.e. dev, dev2, uat, prod).
#                   
#                   The Dating Server instance created through this
#                   script will be used by the Business Calendar
#                   Load process to retrieve business calendar information
#                   from the DATES database and then load it into the
#                   GPL Workbench database.
#
#                   The Dating Server is a CORBA server running on
#                   Linux and listening for client requests on a 
#                   specific port (which is set up in gplwb_xxx.cfg)
#                   configured for the target environment.
#
#                   This script basically takes in one parameter
#                   which is the environment such as dev / dev2 /
#                   uat / prod. Invokation examples are:
#                   ./startGplDatingServer.sh dev - for DEV
#                   ./startGplDatingServer.sh uat - for UAT
#
#-------------------------------------------------------------

echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Started... =====

#-------------------------------------------------------------
#  Validate input parameters
#-------------------------------------------------------------
if [ $# -gt 0 ]; then
  printf "%s\n" "Environment parameter passed in is $1."
  ENV=$1
else
  printf "%s\n" "Error at line $LINENO: A required environment parameter is missing. Aborting..."
  printf "%s\n" "For example, the script must be invoked as ./startGplDatingServer.sh dev for the DEV environment"
  exit 1
fi

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Validate the Environment Parameter passed in
#-------------------------------------------------------------
if [ $1 != 'dev' -a $1 != 'dev2' -a $1 != 'uat' -a $1 != 'prod' ]; then
  printf "%s\n" "Error at line $LINENO: Incorrect environment passed. Valid values are dev, dev2, uat, prod. Cannot continue processing. Aborting..."
  exit 1
fi

#-------------------------------------------------------------
#   Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=startGplDatingServer.sh

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#----------------------------------------------------------
#  Invoke the script provided by the UBS EDP Dating Server
#  Group to instantiate the Dating Server. This script is
#  basically a wrapper script that invokes the script provided
#  by the UBS EDP Dating Server group, with parameters.
#----------------------------------------------------------

#
#  Setup and export the input parameters to be sent to the
#  UBS EDP Dating Server start-up script
#
export LOG_DIR=$CFG_VAR_HUFS_LOG_BUSCAL_DIR
export DATA_DIR=$CFG_VAR_HUFS_DATA_BUSCAL_DIR
export CACHE_FILE_NAME=$CFG_VAR_GPL_DS_CACHE_FILE_NAME
export IOR_FILE_NAME=$CFG_VAR_GPL_DS_IOR_FILE_NAME
export LOG_FILE_CONFIG=$CFG_VAR_HUFS_DATA_GPL_DATING_SERVER_LOGXML
export LOG_FILE_NAME=$CFG_VAR_GPL_DS_LOG_FILE_NAME
export MAIL_LIST=$CFG_VAR_GPL_DS_MAIL_LIST
export PORT_NUMBER=$CFG_VAR_GPL_DS_PORT_NUMBER
export DEBUG_LEVEL=$CFG_VAR_GPL_DS_DEBUG_LEVEL
export NUM_OF_RETRIES=$CFG_VAR_GPL_DS_NUM_OF_RETRIES
export VBROKER_LICENSE_DIR=$CFG_VAR_GPL_DS_VBROKER_LIC_DIR
export LOCK_FILE_NAME=$CFG_VAR_GPL_DS_LOCK_FILE
export SEND_MAIL_FLAG=$CFG_VAR_GPL_SEND_MAIL_ON_DS_STOP

#
#  Invoke UBS EDP Dating Server Script
#  NOTE: The parameters are passed to the UBS EDP Dating Server
#        script by exporting the variables and not by passing them
#        as command line parameters to the script.
#
$CFG_VAR_UBS_EDP_START_DS_SCRIPT &
     
#-----------------------------------------------------------------------
#  Capture exitcode from invoking the UBS EDp Dating Server script
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the instantiation of the Dating Server was not successful
    #---------------------------------------------------------------------------
    
         $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_AVAILABILITY" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            -m"Unable to instantiate GPL Workbench Dating Server instance. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATING_SERVER_CONN" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/startGplDtng*.`date +%y%m%d`.log"
        
      exit $exitCode
fi

#---------------------------------------------------------------------------
#  GPL Workbench Dating Server instantiated successfully
#---------------------------------------------------------------------------
echo ===== GPL Workbench Dating Server instantiated successfully on `hostname`: $CFG_VAR_GPL_DS_PORT_NUMBER  =====

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Ended... =====
exit $exitCode
