#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : buscalTester.sh
#  Author         : Rohit Jain (Keane Inc.)
#  Date Created   : Sep 11, 2006
#
#  Last Revised   : Kumar Subramaniam (Keane Inc.)
#  Date Revised   : Sep 22, 2006
#  Why Revised    : Removed $HOME/buscal prefix for the config file
#                   to unit test script from Rohits home directory
#                   on linux.
#
#-------------------------------------------------------------
#
#  Description    : This script is used to invoke the business calendar
#                   tester java program which will execute all of the
#                   business calendar processing functions (i.e excluding
#                   load) which will be used within the GPL
#                   Workbench application.
#
#                   The tester program uses properties that can be set
#                   within the gplworkbench_xxx.properties file to be
#                   able to execute various test scenarios based on 
#                   test different test input to the functions. 
#
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Setup Local Configuration Variables
#-------------------------------------------------------------
BUS_CAL_TEST_RUNNER=com.ubs.gplw.frameworks.buscal.BusCalFunctionTester

#-------------------------------------------------------------
#  Setup the CLASSPATH for launching the JVM
#-------------------------------------------------------------
CLASSPATH=$CFG_VAR_SYBASE_JDBC_DRIVER_PATH:$CFG_VAR_MAIL_JAR:$CFG_VAR_J2EE_JAR:$CFG_VAR_CHATENGINE_JAR:$CFG_VAR_CORE_JAR:$CFG_VAR_JAXB_API_JAR:$CFG_VAR_JAXB_IMPL_JAR:$CFG_VAR_JAXB_LIBS_JAR:$CFG_VAR_JAXP_JAR:$CFG_VAR_JAXP_API_JAR:$CFG_VAR_JAX_QNAME_JAR:$CFG_VAR_LOG4J_JAR:$CFG_VAR_NAMESPACE_JAR:$CFG_VAR_XSDLIB_JAR:$CFG_VAR_ACTIVATION_JAR:$CFG_VAR_JTDS_JAR:$CFG_VAR_GPLWB_COMMON_JAR:$CFG_VAR_GPLWB_BATCH_CLIENT_JAR:$CFG_VAR_XERCES_API_JAR:$CFG_VAR_XERCES_IMPL_JAR:$CFG_VAR_JCERT_JAR:$CFG_VAR_JNET_JAR:$CFG_VAR_PWDRSTUTILS_JAR:$CFG_VAR_JSSE_JAR:$CFG_VAR_IWSORB_JAR:$CFG_VAR_SECURITYIMPL_JAR

#-------------------------------------------------------------
#  Invoke the BusCalFunctionTester.java program.
#-------------------------------------------------------------
$CFG_VAR_JAVA_HOME/java -cp $CLASSPATH -Dgplwb.propertieshome=$CFG_VAR_HUFS_DATA_PROP_DIR/gplworkbench_$CFG_VAR_HUFS_ENV.properties -Dgplwb.loghome=$CFG_VAR_HUFS_LOG_HOME_DIR/etl/buscal/ -Dlog4j.configuration=$CFG_VAR_HUFS_DATA_BATCHCLIENT_LOGXML -Dgplwb.chat.servername=$CFG_VAR_CHAT_SERVER_NAME -Dgplwb.chat.port=$CFG_VAR_CHAT_SERVER_PORT $BUS_CAL_TEST_RUNNER

#---------------------------------------------------------------------
# Capture and exit with the exit code returned by the java program
#---------------------------------------------------------------------
exitCode=$?
exit $exitCode
