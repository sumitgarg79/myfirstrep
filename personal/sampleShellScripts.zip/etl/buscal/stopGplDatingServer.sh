#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : stopGplDatingServer.sh
#  Author         : Kumar Subramaniam (Keane Inc.)
#  Date Created   : Nov 16, 2006
#
#  Last Revised   : Kumar Subramaniam (Keane Inc.)
#  Date Revised   : Mar 16, 2007
#  Why Revised    : Change from running netstat command to get PID
#                   for Dating Server Process to stop, to using the
#                   PID from the DatingServerLockFile. Using the 
#                   netstat command was resulting in unpredictable
#                   results in DEV/UAT versus PROD.
#
#                   Also changed the micromuse notification to say
#                   "Unable to stop..." instead of "Unable to instantiate..."
#                   when there is a valid PID > 0. Added an additional check
#                   to alert micromuse if the PID from the LockFile was not 
#                   a valid value greater than 0. Changed the Logs in the UserData
#                   file to reference autosys/stopGplDtng*.`date +%y%m%d`.log instead of
#                   etl/buscal/DatingServer.log  
#                   
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 11, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Kumar Subramaniam (Keane Inc.)
#  Date Revised   : Nov 22, 2006
#  Why Revised    : There was a $ sign in front of the line
#                   where we setup the GPL Workbench Config
#                   variables. This was causing an incorrect
#                   path resulting in an error when trying
#                   to stop the GPL Dating Server. Removed the
#                   extraneous $ sign
#-------------------------------------------------------------
#
#  Description    : This script will locate the GPL Workbench instance
#                   of the Dating Server and stop the instance 
#
#                   This script basically takes in one parameter
#                   which is the environment such as dev / dev2 /
#                   uat / prod. Invokation examples are:
#                   ./stopGplDatingServer.sh dev - for DEV
#                   ./stoptGplDatingServer.sh uat - for UAT
#
#-------------------------------------------------------------

echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Started... =====

#-------------------------------------------------------------
#  Validate input parameters
#-------------------------------------------------------------
if [ $# -gt 0 ]; then
  printf "%s\n" "Environment parameter passed in is $1."
  ENV=$1
else
  printf "%s\n" "Error at line $LINENO: A required environment parameter is missing. Aborting..."
  printf "%s\n" "For example, the script must be invoked as ./stopGplDatingServer.sh dev for the DEV environment"
  exit 1
fi

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Validate the Environment Parameter passed in
#-------------------------------------------------------------
if [ $1 != 'dev' -a $1 != 'dev2' -a $1 != 'uat' -a $1 != 'prod' ]; then
  printf "%s\n" "Error at line $LINENO: Incorrect environment passed. Valid values are dev, dev2, uat, prod. Cannot continue processing. Aborting..."
  exit 1
fi

#-------------------------------------------------------------
#   Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=stopGplDatingServer.sh
DATING_SERVER_PID=-1

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#----------------------------------------------------------
#  Get the process ID of the GPL Workbench Dating Server
#  for the requested environment
#----------------------------------------------------------

printf "%s\n" "Info: Process Id for GPL Workbench Dating Server BEFORE look-up = ${DATING_SERVER_PID}"
#
# IMPORTANT: The startGplDtngSvr.sh script calls startDS.ksh which creates the Dating Server and puts
#            the PID in /sbcimp/dyn/data/ALG/ALGWB/<env>/etl/buscal/DatingServerLockFile. Get the PID
#            from this lock file and use that to determine the process to kill to stop the GPL Dating Server
#
DATING_SERVER_PID=`cat $CFG_VAR_GPL_DS_LOCK_FILE`
printf "%s\n" "Info: Process Id for GPL Workbench Dating Server AFTER look-up = ${DATING_SERVER_PID}"
     
#-----------------------------------------------------------------------
#  If the Dating Server PID is valid (i.e. a value greater than 0), then
#  stop the Dating Server process
#-----------------------------------------------------------------------
if [ $DATING_SERVER_PID -gt 0 ] 
then

    #---------------------------------------------------------------------------
    #  Stop the GPL Workbench Dating Server process
    #  IMPORTANT: DO NOT use the kill -9 command because the Dating Server needs
    #             to do some housekeeping before stopping. This is a recommendation
    #             from the UBS EDP Dating Server group
    #---------------------------------------------------------------------------
    kill $DATING_SERVER_PID

    exitCode=$?
    #---------------------------------------------------------------------------------
    #  Notify MicroMuse that stopping the GPL Dating Server process was not successful
    #---------------------------------------------------------------------------------
    if [ $exitCode -ne 0 ]
    then
    
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_AVAILABILITY" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            -m"Unable to stop GPL Workbench Dating Server PID $DATING_SERVER_PID. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATING_SERVER_CONN" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/stopGplDtng*.`date +%y%m%d`.log"
            
        exit $exitCode
    fi
else
    
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that there is no valid GPL Dating Server process to stop
    #---------------------------------------------------------------------------
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
        -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
        -e$ENV \
        -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_AVAILABILITY" \
        -k$SHELL_SCRIPT_NAME \
        -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        -m"GPL Workbench Dating Server PID $DATING_SERVER_PID is not a valid process or could not be found. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
        -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATING_SERVER_CONN" \
        -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/buscal/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/stopGplDtng*.`date +%y%m%d`.log"
        
    exit 1
fi

#---------------------------------------------------------------------------
#  GPL Workbench Dating Server stopped successfully
#---------------------------------------------------------------------------
echo ===== GPL Workbench Dating Server stopped successfully on `hostname`: $CFG_VAR_GPL_DS_PORT_NUMBER  =====

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
echo ===== `date '+%Y-%m-%d %H:%M:%S %Z'` Script $0 Ended... =====
exit $exitCode
