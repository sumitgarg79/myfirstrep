#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : ratePurge.sh
#  Author         : Subhankar Choudhury
#  Date Created   : Feb 15, 2005
#  Last Revised   :
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 11, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                    script for de-duplication feature.
# 
#-------------------------------------------------------------
#
#  Description    : This script purges the data from the following
#                   wb_daily_rate_history table .
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=ratePurge.sh
PURGE_DAILY_RATE_CLASS_NAME=com.ubs.gplw.action.rate.PurgeDailyRateAction
BUSINESS_ENTITY=rate

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
export SYBASE=/sbcimp/run/tp/sybase/OpenClientServer/v12.5.1ebf11776
export SYBASE_ASE=ASE-12_5
export LANG=C

#----------------------------------------------------------
#  Call the BCP utility to unload the wb_daily_rate_history Table
#----------------------------------------------------------
$CFG_VAR_BCP_EXECPATH/bcp \
    gpldb..wb_daily_rate_history \
    out \
    $CFG_VAR_BCP_DATA_DIR/wb_daily_rate_history.dat \
    -c \
    -S$CFG_VAR_BCP_SYBSERVER \
    -U$CFG_VAR_BCP_SYBUSERID \
    -P$CFG_VAR_BCP_SYBPASSWD \
    -t ';'

exitCode=$?

#-------------------------------------------------------------
#  If the process has not completed successfully, send a error 
#  message to Micromuse. 
#-------------------------------------------------------------
if [ $exitCode -ne 0 ]
then
  
  $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
          -a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
          -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
          -e$ENV \
          -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
          -k$SHELL_SCRIPT_NAME \
          -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
          -m"The backup of rate table failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
          -t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
          -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/rate/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/ratePurge*.`date +%y%m%d`.log"
    
    exit $exitCode
fi

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Purge of the wb_daily_rate_history table 
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $PURGE_DAILY_RATE_CLASS_NAME \
    $BUSINESS_ENTITY

exitCode=$?

#-------------------------------------------------------------
#  If the process has not completed successfully, send a error 
#  message to Micromuse. Otherwise send a completion message
#-------------------------------------------------------------
if [ $exitCode -ne 0 ]
then
  
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            -m"Completed with error.$CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"Purge" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/rate/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/rate/Batch.log"
  fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
