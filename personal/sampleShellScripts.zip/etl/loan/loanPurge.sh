#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loanPurge.sh
#  Author         : Subhankar Choudhury
#  Date Created   : Feb 15, 2005
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script purges the data from the following
#                   tables in the order given:
#                   1. wb_loan_allocation table
#                   2. wb_loan table
#                   3. wb_borrower_request table 
#                   4. wb_loan_history 
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=loanPurge.sh
PURGE_LOAN_ALLOC_CLASS_NAME=com.ubs.gplw.action.loan.PurgeLoanAllocationTableAction
PURGE_LNT_LOAN_ATTRIBS_CLASS_NAME=com.ubs.gplw.action.loan.PurgeLntLoanAttribsAction
PURGE_EQL_LOAN_ATTRIBS_CLASS_NAME=com.ubs.gplw.action.loan.PurgeEqlLoanAttribsAction
PURGE_LOAN_CLASS_NAME=com.ubs.gplw.action.loan.PurgeLoanTableAction
PURGE_LOAN_HISTORY_CLASS_NAME=com.ubs.gplw.action.loan.PurgeLoanHistoryTableAction
PURGE_BORROWER_REQ_CLASS_NAME=com.ubs.gplw.action.borrower.PurgeBorrowerTableAction
BUSINESS_ENTITY=loan

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
export SYBASE=/sbcimp/run/tp/sybase/OpenClientServer/v12.5.1ebf11776
export SYBASE_ASE=ASE-12_5
export LANG=C

#----------------------------------------------------------
#  Call the BCP utility to unload the wb_loan_allocation Table
#----------------------------------------------------------
$CFG_VAR_BCP_EXECPATH/bcp \
    gpldb..wb_loan_allocation \
    out \
    $CFG_VAR_BCP_DATA_DIR/wb_loan_allocation.dat \
    -c \
    -S$CFG_VAR_BCP_SYBSERVER \
    -U$CFG_VAR_BCP_SYBUSERID \
    -P$CFG_VAR_BCP_SYBPASSWD \
    -t ';'

exitCode=$?

if [ $exitCode -eq 0 ]
then 
        
    #----------------------------------------------------------
    #  Call the BCP utility to unload the wb_loan Table
    #----------------------------------------------------------
    $CFG_VAR_BCP_EXECPATH/bcp \
        gpldb..wb_loan \
        out \
        $CFG_VAR_BCP_DATA_DIR/wb_loan.dat \
        -c \
        -S$CFG_VAR_BCP_SYBSERVER \
        -U$CFG_VAR_BCP_SYBUSERID \
        -P$CFG_VAR_BCP_SYBPASSWD \
        -t ';'

    exitCode=$?

    if [ $exitCode -eq 0 ]
    then 
        #----------------------------------------------------------
        #  Call the BCP utility to unload the wb_borrower_request Table
        #----------------------------------------------------------
        $CFG_VAR_BCP_EXECPATH/bcp \
            gpldb..wb_borrower_request \
            out \
            $CFG_VAR_BCP_DATA_DIR/wb_borrower_request.dat \
            -c \
            -S$CFG_VAR_BCP_SYBSERVER \
            -U$CFG_VAR_BCP_SYBUSERID \
            -P$CFG_VAR_BCP_SYBPASSWD \
            -t ';'

        exitCode=$?

        if [ $exitCode -eq 0 ]
        then 
            #----------------------------------------------------------
            #  Call the BCP utility to unload the wb_loan_history Table
            #----------------------------------------------------------
            $CFG_VAR_BCP_EXECPATH/bcp \
                gpldb..wb_loan_history \
                out \
                $CFG_VAR_BCP_DATA_DIR/wb_loan_history.dat \
                -c \
                -S$CFG_VAR_BCP_SYBSERVER \
                -U$CFG_VAR_BCP_SYBUSERID \
                -P$CFG_VAR_BCP_SYBPASSWD \
                -t ';'

            exitCode=$?

            if [ $exitCode -eq 0 ]
            then 
                #--------------------------------------------------------------
                #  Call the BCP utility to unload the wb_lnt_loan_attribs Table
                #--------------------------------------------------------------
                $CFG_VAR_BCP_EXECPATH/bcp \
                    gpldb..wb_lnt_loan_attribs \
                    out \
                    $CFG_VAR_BCP_DATA_DIR/wb_lnt_loan_attribs.dat \
                    -c \
                    -S$CFG_VAR_BCP_SYBSERVER \
                    -U$CFG_VAR_BCP_SYBUSERID \
                    -P$CFG_VAR_BCP_SYBPASSWD \
                    -t ';'
                exitCode=$?

                if [ $exitCode -eq 0 ]
                then 
                    #--------------------------------------------------------------
                    #  Call the BCP utility to unload the wb_eql_loan_attribs Table
                    #--------------------------------------------------------------
                    $CFG_VAR_BCP_EXECPATH/bcp \
                        gpldb..wb_eql_loan_attribs \
                        out \
                        $CFG_VAR_BCP_DATA_DIR/wb_eql_loan_attribs.dat \
                        -c \
                        -S$CFG_VAR_BCP_SYBSERVER \
                        -U$CFG_VAR_BCP_SYBUSERID \
                        -P$CFG_VAR_BCP_SYBPASSWD \
                        -t ';'
                    exitCode=$?

                fi
            fi
        fi
    fi
fi

#-------------------------------------------------------------
#  If the process has not completed successfully, send a error 
#  message to Micromuse and exit the script.
#-------------------------------------------------------------
if [ $exitCode -ne 0 ]
then
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		-m"Backup of the tables has an error. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-q"Unload" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/loan/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/loanPurge*.`date +%y%m%d`.log"
   
    exit $exitCode

fi

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Purge of the loan allocation table 
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $PURGE_LOAN_ALLOC_CLASS_NAME \
    $BUSINESS_ENTITY

exitCode=$?

if [ $exitCode -eq 0 ]
then 
    #---------------------------------------------------------------------------
    #  Call the generic Batch Runner script with the appropriate
    #  parameters to start the Purge of the loanet loan attribs table
    #---------------------------------------------------------------------------
    $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
        $ENV \
        $PURGE_LNT_LOAN_ATTRIBS_CLASS_NAME \
        $BUSINESS_ENTITY
        
    exitCode=$?

    if [ $exitCode -eq 0 ]
    then 
        #---------------------------------------------------------------------------
        #  Call the generic Batch Runner script with the appropriate
        #  parameters to start the Purge of the Equilend loan attribs table
        #---------------------------------------------------------------------------
        $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
            $ENV \
            $PURGE_EQL_LOAN_ATTRIBS_CLASS_NAME \
            $BUSINESS_ENTITY
         
        exitCode=$?

        if [ $exitCode -eq 0 ]
        then 
            #---------------------------------------------------------------------------
            #  Call the generic Batch Runner script with the appropriate
            #  parameters to start the Purge of the loan history table
            #---------------------------------------------------------------------------
            $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
                $ENV \
                $PURGE_LOAN_HISTORY_CLASS_NAME \
                $BUSINESS_ENTITY
        
            exitCode=$?

            if [ $exitCode -eq 0 ]
            then 
                #---------------------------------------------------------------------------
                #  Call the generic Batch Runner script with the appropriate
                #  parameters to start the Purge of the loan table
                #---------------------------------------------------------------------------
                $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
                    $ENV \
                    $PURGE_LOAN_CLASS_NAME \
                    $BUSINESS_ENTITY
                 
                exitCode=$?

                if [ $exitCode -eq 0 ]
                then 
                    #---------------------------------------------------------------------------
                    #  Call the generic Batch Runner script with the appropriate
                    #  parameters to start the Purge of the borrower request table
                    #---------------------------------------------------------------------------
                    $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
                        $ENV \
                        $PURGE_BORROWER_REQ_CLASS_NAME \
                        $BUSINESS_ENTITY
                
                    exitCode=$?
                fi
            fi
        fi
    fi
fi


#-------------------------------------------------------------
#  If the process has not completed successfully, send a error 
#  message to Micromuse. Otherwise send a completion message
#-------------------------------------------------------------
if [ $exitCode -ne 0 ]
then
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                -m"Completed with error. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-q"Purge" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/loan/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/loan/Batch.log"
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
