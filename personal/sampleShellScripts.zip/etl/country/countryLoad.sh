#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : countryLoad.sh
#  Author         : Subhankar Choudhury
#  Date Created   : Feb 15, 2005
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script loads the Country data 
#                   from the GOSOS Extract file into the 
#                   in the GPL Workbench Database
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=countryLoad.sh
DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ETL_DIR/country
DATA_FILE_NAME=LATECURRENCY.DAT
DATA_ARCHIVE_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_ETL_DIR/country
ACTION_CLASS_NAME=com.ubs.gplw.action.country.LoadCountryAction
BUSINESS_ENTITY=country

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
#  Check to see if the file created by the
#  GOSOS extract is present
#-------------------------------------------------------------
cp $CFG_VAR_GLOBAL1_DATA_DIR/$DATA_FILE_NAME $DATA_FOLDER_NAME/$DATA_FILE_NAME

inputFileExists=`ls -alt $DATA_FOLDER_NAME/$DATA_FILE_NAME|wc|awk '{print($1)}'`

#-------------------------------------------------------------
#  If the file is missing, restore previous days file from 
#  archive and continue processing
#-------------------------------------------------------------
if [ $inputFileExists -ne 1 ] 
then 
    #---------------------------------------------------------------------------
    #  Uncompress the precious days file for processing
    #---------------------------------------------------------------------------
    mv $DATA_ARCHIVE_FOLDER_NAME/$DATA_FILE_NAME.Z \
        $DATA_FOLDER_NAME/
        uncompress -f $DATA_FOLDER_NAME/$DATA_FILE_NAME.Z
fi
        	
#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Load process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
     
#-----------------------------------------------------------------------
#  Capture exit code from invoking the common batchRunner.sh script
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the process did not complete successfully.
    #---------------------------------------------------------------------------
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The Process Failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/country/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/country/Batch.log"

else
    #---------------------------------------------------------------------------
    #  Backup the file to the archive folder
    #---------------------------------------------------------------------------
    mv $DATA_FOLDER_NAME/$DATA_FILE_NAME \
        $DATA_ARCHIVE_FOLDER_NAME/
        compress -f $DATA_ARCHIVE_FOLDER_NAME/$DATA_FILE_NAME

    exitCode=$?
        
    if [ $exitCode -ne 0 ]
    then 
        #---------------------------------------------------------------------------
        #  Notify MicroMuse that the backup of the file failed.
        #---------------------------------------------------------------------------
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The backup of the file failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/country/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/countryLoad*.`date +%y%m%d`.log"
    fi
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
