#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#   Shell name     :    unitOfQuotationExtract.sh
#   Author         :    Priti Goyal
#   Date           :    Dec 19, 2006
#
#  	Last Revised   : 	Abhishek Sharma (Keane Inc.)
#  	Date Revised   : 	Mar 11, 2007
#  	Why Revised    : 	Added new parameters to the micromuse notification
#                   	 	script for de-duplication feature.
#
#-------------------------------------------------------------
#
#       Description: This script downloads the unit of quotation field
#					 from Global1 to the HUFS dir
#
#-------------------------------------------------------------
#       Run Global Configuration Script
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
BATCH_JOB_NAME=UNQUOT
SHELL_SCRIPT_NAME=unitOfQuotationExtract.sh
EXTRACTED_FILE_NAME=UnitOfQuotation.DAT

export LANG=C

#-------------------------------------------------------------
#  Run the Global One extract script to extract the report
#-------------------------------------------------------------
$CFG_VAR_GLOBAL1_SCRIPTPATH/$CFG_VAR_GLOBAL1_SCRIPTNAME $BATCH_JOB_NAME

#-------------------------------------------------------------
#  Check the name of the file that got extracted
#-------------------------------------------------------------
outputFileName=`ls $CFG_VAR_GLOBAL1_DATA_DIR/$EXTRACTED_FILE_NAME -t1r |tail -1`

#-------------------------------------------------------------
#  Copy the extracted file to the HUFS directory structure
#-------------------------------------------------------------
cp $outputFileName $CFG_VAR_HUFS_DATA_ETL_DIR/security/UnitOfQuotation.DAT
returnCode=$?

#-------------------------------------------------------------
#  If the copy of the file has been successfull, delete the 
#  file created by the extract
#------------------------------------------------------------
if [ $returnCode -eq 0 ]
then
    chmod 777 $CFG_VAR_HUFS_DATA_ETL_DIR/security/UnitOfQuotation.DAT
    rm $outputFileName
else
    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the file generation 
    #-------------------------------------------------------------
    
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
        -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
        -e$ENV \
        -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        -k$SHELL_SCRIPT_NAME \
        -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        -m"The file has not been generated successfully. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
        -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
        -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/security/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/prod/autosys/unitQuotExtr*.`date +%y%m%d`.log"
       
fi

exit $returnCode