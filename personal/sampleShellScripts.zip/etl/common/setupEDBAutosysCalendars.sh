#!/bin/csh

#-------------------------------------------------------------
#  File Name      : setupEDBAutosysCalendars.sh
#  Author         : Kumar Subramaniam (Keane Inc.)
#  Date Created   : Feb 13, 2007
#
#  Last Revised   : 
#  Revised By     : 
#  Why Revised    : 
#
#-------------------------------------------------------------
#  Description    : This script creates the following autosys
#                   calendars which will be used by the Earnings
#                   module within GPL Workbench application
#                   a) gplwb_etl_firstBusDay
#                   b) gplwb_etl_secondBusDay
#
#                   Pass dev/dev2/uat/prod as the parameter to
#                   this script to setup the calendars with the
#                   environment specific autosys subsystem.
#-------------------------------------------------------------
#
# Setup Autosys Environment variables for dev/dev2/uat/prod
#
if (($1 == "dev") || ($1 == "dev2")) then
    source /sbcimp/shared/config/CA/Autosys/v4.0/devl/autouser/cshellDLN
else if ($1 == "uat") then
    source /sbcimp/shared/config/CA/Autosys/v4.0/uat/autouser/cshellUAT
else if ($1 == "prod") then
    source /sbcimp/shared/config/CA/Autosys/v4.0/prod/autouser/cshellPSM
else
    echo Error: Invalid environment parameter passed. Valid values are dev, dev2, uat or prod.
    exit(1)  
endif


#
# Setup gplwb_etl_firstBusDay
# Note: Leave the blank line before END_OF_LIST1 and the last date
#       which is the equivalent of the Enter Key and that is how the
#       autocal_csc command terminates.
#
autocal_asc << END_OF_LIST1
gplwb_etl_firstBusDay
A
01/02/2007
02/01/2007
03/01/2007
04/02/2007
05/01/2007
06/01/2007
07/02/2007
08/01/2007
09/04/2007
10/01/2007
11/01/2007
12/03/2007

END_OF_LIST1

#
# Setup gplwb_etl_secondBusDay
# Note: Leave the blank line before END_OF_LIST2 and the last date
#       which is the equivalent of the Enter Key and that is how the
#       autocal_csc command terminates.
#
autocal_asc << END_OF_LIST2
gplwb_etl_secondBusDay
A
01/03/2007
02/02/2007
03/02/2007
04/03/2007
05/02/2007
06/04/2007
07/03/2007
08/02/2007
09/05/2007
10/02/2007
11/02/2007
12/04/2007

END_OF_LIST2
