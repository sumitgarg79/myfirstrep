#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : indexBuild.sh
#  Author         : Subhankar Choudhury
#  Date Created   : Feb 15, 2005
#
#  Last Revised   : Kumar Subramniam
#  Date Revised   : Aug 04, 2006
#  Why Revised    : Changed path from DataDefinition/ to
#                   DatabaseDefinition/Tables/ to account for
#                   changes in the ClearCase folder proposed
#                   by Pinaki
#-------------------------------------------------------------
#
#  Description    : This script rebuilds the indexes in the tables
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
#  Setups Configuration Variables
#
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=indexBuild.sh
exitCode=0
export SYBASE=/sbcimp/run/tp/sybase/OpenClientServer/v12.5.1ebf11776
export SYBASE_ASE=ASE-12_5
export LANG=C

#-------------------------------------------------------------
#  Recreate indexes in the tables
#-------------------------------------------------------------
$CFG_VAR_BCP_EXECPATH/isql \
    -S$CFG_VAR_BCP_SYBSERVER \
    -U$CFG_VAR_BCP_SYBUSERID \
    -P$CFG_VAR_BCP_SYBPASSWD \
    -i$CFG_VAR_HUFS_PKG_SCRIPTS_DB_DIR/DataDefinition/Tables/wb_index_build.sql

exit $exitCode

#-------------------------------------------------------------
#  Exit the script with the exitCode
#-------------------------------------------------------------
exit $exitCode
