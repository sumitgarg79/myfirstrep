#!/bin/bash
set -x
set -v
#-----------------------------------------------------------------------
#
#	Shell Script Name : gnu_decrypt.sh
#
#	Coded By 	  : Arun Sundar
#	Dated   	  : September 2005
#
#	Description: This shell script will decrypt files
#
#Input Arguments Options :
#	-d : decrypt
#	-o : output file name
#	-h : Help option
#	-H : Help option
#	-u : Userid option
#
#------------------------------------------------------------------------
# Modification History:
# _____________________
#
# Changed On Changed By		Description	
# ---------- ----------		-----------
#
#------------------------------------------------------------------------

PROG_NAME=$(basename $0)

function echoHelp {
	echo "Usage: ${PROG_NAME} [-o output_file_name ] [-i input_file_to_be_decrypted ] [-u userid]"
	echo "General Information:"
	echo "Option -h or -H providesthe help for the script $PROG_NAME.  This option cannot be used along with any other optionsas it will make the script exit after showing the help"
	echo 'Option -o is name of the decrypted output file'
	echo 'Option -i is name of the file to be decrypted'
	echo 'Option -u is userid'
  	echo "Copyright c 2005 UBS All rights reserved. Developed by Arun Sundar on September 2005"
	exit 1
}

function echoError {
	echo "Error : Please check Option : $1"
	echoHelp
}

if [ $# -le 0 ]
then
	echoHelp
	exit 1
fi

while getopts hH:i:o:u: OPTION
do
	case ${OPTION} in
		h) echoHelp
			exit 2;;
		H) echoHelp
			exit 2;;
		i) INPUT_FILE=`echo ${OPTARG}`;;
		o) OUTPUT_FILE=`echo ${OPTARG}`;;
		u) USERID=`echo ${OPTARG}`;;
		\?) echoHelp
		exit 2;;
	esac
done

echo " output file is ${OUTPUT_FILE} "
echo " input  file is ${INPUT_FILE} "
echo " user id is ${USERID} "

echo "Command Line:$0 $*"

if [ `echo $OUTPUT_FILE | wc -c | awk '{print($1)}'` -lt 2 ]
then
	echoError -o
fi

if [ `echo $INPUT_FILE | wc -c | awk '{print($1)}'` -lt 3 ]
then
	echoError -d
fi

if [ `echo $USERID | wc -c | awk '{print($1)}'` -lt 3 ]
then
	echoError -u
fi

echo "Message : Decrypting $INPUT_FILE to $OUTPUT_FILE started at `date`"
 
/usr/bin/gpg --verbose --yes --batch --local-user "${USERID}" --output ${OUTPUT_FILE} --decrypt ${INPUT_FILE} 

RETURN_CODE=$?

if [ $RETURN_CODE -ne 0 ]
then
  echo "Decryption Not successful"
  exit $RETURN_CODE
fi

echo "Message : Decryption Processing complete at `date`"
exit 0
