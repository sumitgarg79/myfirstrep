#!/bin/ksh
set -x
set -v
#-----------------------------------------------------------------------
#
#	Shell Script Name : ftpFile.sh
#
#	Coded By 	  : Arun Sundar
#	Dated   	  : September 2005
#
#	Description: This shell script make the ftp connection and
#		process the neccessary command.
#
#Input Arguments Options :
#	-c : Command To Process Like get or put
#	-d : Directory
#	-e : Option to use proxy FTP logic to send file outside the firm.
#	-h : Help option
#	-H : Help option
#	-u : Ftp User Id
#	-p : Ftp Password
#	-s : Ftp Server
#	-t : File Transfer Type
#	-r : Renaming Command if it is there
#	-v : If the mode is passive
#	-z : type of Mode
#
#------------------------------------------------------------------------
# Modification History:
# _____________________
#
# Changed On Changed By		Description	
# ---------- ----------		-----------
#
#------------------------------------------------------------------------


PROG_NAME=$(basename $0)

function printHelp {
	echo  "Usage: ${PROG_NAME} [ -cCommand_To_Process -dClient_Directory -uClient_UserId -pClient_Password -sServer -rRenaming_File_Command -tFile_Transfer_Type [-e] -zEnvironment ]"
	echo  "General Information:"
	echo  "Option -h or -H providesthe help for the script $PROG_NAME. This option cannot be used along with any other optionsas it will make the script exit after showing the help"
	echo  "Option -e is optional,this option identifies that the FTP server provided is for an external clienthence uses proxy ftp method to ftp file to external clients"
	echo  'Option -c is option which can be used to process commands on the FTP serverthe commands can be separated by a newline character.e.g. get xyz.txt abc.txt\pwd\cd SomeDirectory'
	echo  'Option -d is option corresponds to the directory where the ftp command is to be issued'
	echo  'Option -u is option is the FTP user id'
	echo  'Option -p is option is the FTP password'
	echo  'Option -s is option is the FTP server alias or the IP address'
	echo  'Option -r is option is used to rename a file under the directory specifiedoption -c can also be used for renaming files'
	echo  'Option -t is option is file Transfer type 'asc' or 'bin'option -c can also be used for renaming files'
	echo  'Option -v is option is passive command'
	echo  'Option -z is option  for environment'
	echo  "NOTE: This ftp script does a 'dir' in the ftp immediatelyafter the 'cd' command so there is no need to put an additional 'dir'to check the status if the file in the directory"
  	echo  "Copyright c 2004-2005 UBS All rights reserved.Developed by Arun Sundar on September 2005"
	exit 1
}

function printError {
	echo  "Error : Please check Option : $1"
	printHelp
}

if [ $# -le 0 ]
then
	printHelp
	exit 1
fi
E_FLAG=FALSE
while getopts c:d:ehHvp:r:s:u:t:z: OPTION
do
	case ${OPTION} in
		c) COMMANDTOPROCESS=`echo ${OPTARG}`;;
		d) CLIENT_CD=${OPTARG}
			CLIENT_CD_FLAG=TRUE;;
		e) E_FLAG=TRUE;;
		h) printHelp
			exit 2;;
		H) printHelp
			exit 2;;
		v) PASSIVE_FLAG=TRUE;;
		p) CLIENT_PASSWORD=${OPTARG};;
		r) RENAMECOMMAND=${OPTARG};;
		s) CLIENT_ADDRESS=${OPTARG};;
		u) CLIENT_USERID=${OPTARG};;
		t) FILETRANSFERTYPE=${OPTARG};;
		z) ENV=${OPTARG};;
		\?) printHelp
		exit 2;;
	esac
done

. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

echo "Script $0 processing the arguments: $*"

if [ `echo $ENV | wc -c | awk '{print($1)}'` -lt 2 ]
then
	printError -z
fi


if [ `echo $CLIENT_ADDRESS | wc -c | awk '{print($1)}'` -lt 8 ]
then
	printError -s
fi

if [ `echo $CLIENT_USERID | wc -c | awk '{print($1)}'` -lt 2 ]
then
	printError -u
fi

if [ `echo $CLIENT_PASSWORD | wc -c | awk '{print($1)}'` -lt 2 ]
then
	printError -p
fi

if [ `echo $FILETRANSFERTYPE | wc -c | awk '{print($1)}'` -gt 6 ]
then
	printError -t
fi

if [ "$CLIENT_CD_FLAG" == "TRUE" ]
then
	CDCOMMAND="cd $CLIENT_CD"
fi

if [ "$PASSIVE_FLAG" == "TRUE" ]
then
	PASSIVE="passive"
fi


if [[ "$FILETRANSFERTYPE" != "ASC" && "$FILETRANSFERTYPE" != "asc" && "$FILETRANSFERTYPE" != "ascii" && "$FILETRANSFERTYPE" != "ASCII" && "$FILETRANSFERTYPE" != "bin" && "$FILETRANSFERTYPE" != "BIN" && "$FILETRANSFERTYPE" != "binary" && "$FILETRANSFERTYPE" != "BINARY" ]]
then
	printError -t
fi

echo "FTP PARAMETERS"
echo "CLIENT_ADDRESS IS $CLIENT_ADDRESS"
echo "CDCOMMAND IS $CDCOMMAND"
echo "CLIENT_USERID IS $CLIENT_USERID"
echo "CLIENT_PASSWORD IS $CLIENT_PASSWORD"
echo "PASSIVE IS $PASSIVE"
echo "FILETRANSFERTYPE IS $FILETRANSFERTYPE"
echo "COMMANDTOPROCESS IS $COMMANDTOPROCESS"
echo "RENAMECOMMAND IS $RENAMECOMMAND"

echo "Message : Processing the FTP to server $CLIENT_ADDRESS started at `date`"

if [ "$E_FLAG" == "FALSE" ]
then
ftp -nv ${CLIENT_ADDRESS} <<EOF 
user ${CLIENT_USERID} ${CLIENT_PASSWORD}
$PASSIVE
${CDCOMMAND}
dir
${FILETRANSFERTYPE}
${COMMANDTOPROCESS}
${RENAMECOMMAND}
dir
quit
EOF
else
ftp -nv $CFG_VAR_UBSPROXYSRV <<EOT
user $CFG_VAR_UBSPROXYUID $CFG_VAR_UBSPROXYPWD
user ${CLIENT_USERID}@${CLIENT_ADDRESS} ${CLIENT_PASSWORD}
$PASSIVE
${CDCOMMAND}
dir
${FILETRANSFERTYPE}
${COMMANDTOPROCESS}
${RENAMECOMMAND}
dir
quit
EOT
fi
echo "Message : Processing the FTP to server $CLIENT_ADDRESS ended at `date`"
#--------------------- end of Ftp_File_Generic.sh ---------------------------
