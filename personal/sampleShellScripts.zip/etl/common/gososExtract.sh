#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : gososExtract.sh
#  Author         : Saurabh Gupta (Keane Inc.)
#  Date Created   : July 15, 2006
#  Last Revised   : November 28, 2006
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script is  a common script used to
#					extracts the data from GLOBAL1 instance 
#					for given Parameters
#	Param 1		  : Environment
#	Param 2		  : Batch Record Name
#	Param 3		  : From Date
#	Param 4		  : To Date
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/common/$SHELL_SCRIPT_NAME. Please Refer to std_out and std_err file associated with AutoSys JIL"
    else
       # Call batchLogger WITH the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/common/$SHELL_SCRIPT_NAME. Please Refer to std_out and std_err associated with AutoSys JIL"
    fi    

}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/common/Comm.log" \
    -c$3
}
#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=gososExtract.sh
TERM=vt100
UDTHOME=/usr/ud
UDTBIN=/usr/ud/bin
TROJANBIN="/global1/scripts/trojan"	

#------------------------------------------------------------------
#	Name and Location of Log file 
#------------------------------------------------------------------
#TODO: Path to be verified from onsite		
CONFIG_VAR_LOGPATH=/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/gosos/
KTLOGFILE=$CONFIG_VAR_LOGPATH/$2.log                                            
rm -f $KTLOGFILE

#------------------------------------------------------------------
# check if all the arguments has been passed to the script
#------------------------------------------------------------------
if [ "$#" -ne 4 ]
then
	echo "Usage: gososExtract.sh <environment> <batch record name> <from date> <to date>"
	
	 notifyMicromuse "The GOSOS extract can not be performed. Incorrect Parameters passed to the script." \
	      $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	      "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
	      "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
          ""
 
	exit 1
fi

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
#  Change the date format to required Gosos Instance format
#-------------------------------------------------------------
fromDate=$3
toDate=$4
mm=`expr ${fromDate:0:2}`
dd=`expr ${fromDate:2:2}`
yyyy=`expr ${fromDate:4:4}`
fromDate=$mm"/"$dd"/"$yyyy
mm=`expr ${toDate:0:2}`
dd=`expr ${toDate:2:2}`
yyyy=`expr ${toDate:4:4}`
toDate=$mm"/"$dd"/"$yyyy

#------------------------------------------------------------------
#	Internal job name
#	Begin Date for extract
#	End Date for extract
#------------------------------------------------------------------
KTEXTERN=$2                                                                     
KTVARFMDT=$fromDate                                                                    
KTVARTODT=$toDate                                                                    
LANG=C
PATH=$TROJANBIN:$PATH:$UDTBIN

#------------------------------------------------------------------
#Global one internal name for batch
#------------------------------------------------------------------
KTLOGNAME=BATCH                                                                 

#------------------------------------------------------------------
#	Export commnad 
#------------------------------------------------------------------
export KTLOGNAME KTLOGFILE KTEXTERN UDTHOME UDTBIN TERM KTVARFMDT KTVARTODT PATH

#------------------------------------------------------------------
#	Goto Global1 instance directory
#	Excecute the unisys application
#------------------------------------------------------------------
cd $CFG_VAR_GLOBAL1_ACCT                                                           
udt                                                                             

#-----------------------------------------------------------------------
#  Capture exit code from invoking the extract process
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
	errorMessage=" EDB: ERROR IN GOSOS EXTRACT PROCESS. ETL ABORTED."
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

     notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""
	    
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
