#!/bin/bash
set -x
set -v
#-----------------------------------------------------------------------
#
#	Shell Script Name : gnu_encrypt.sh
#
#	Coded By 	  : Arun Sundar
#	Dated   	  : September 2005
#
#	Description: This shell script make encrypts files
#
#Input Arguments Options :
#	-i : input file name
#	-o : output file name
#       -r : recipient name 
#       -u : userid
#	-h : Help option
#	-H : Help option
#
#------------------------------------------------------------------------
# Modification History:
# _____________________
#
# Changed On Changed By		Description	
# ---------- ----------		-----------
#
#------------------------------------------------------------------------

PROG_NAME=$(basename $0)

function echoHelp {
	echo  "Usage: ${PROG_NAME} [-o output_file_name ] [-i input_file_to_be_encrypted ] [-r recipient_user_id] [-u senders_user_id]" 
	echo  "General Information:"
	echo  "Option -h or -H providesthe help for the script $PROG_NAME. This option cannot be used along with any other options, as it will make the script exit after showing the help"
	echo  'Option -o is name of the encrypted output file'
	echo  'Option -i is name of the input file to encrypted'
	echo  'Option -r is name of the recipient whose public key will be used to encrypt'
	echo  'Option -u is name of the userid used for encryption'
  	echo  "Copyright c 2005 UBS All rights reserved. Developed by Arun Sundar on September 2005"
	exit 1
}

function echoError {
	echo  "Error : Please check Option : $1"
	echoHelp
}

if [ $# -le 0 ]
then
	echoHelp
	exit 1
fi

while getopts hH:i:o:r:u: OPTION
do
	case ${OPTION} in
		h) echoHelp
			exit 2;;
		H) echoHelp
			exit 2;;
		i) INPUT_FILE=`echo ${OPTARG}`;;
		o) OUTPUT_FILE=`echo ${OPTARG}`;;
		r) RECIPIENT=`echo ${OPTARG}`;;
		u) SENDER=`echo ${OPTARG}`;;
		\?) echoHelp
		exit 2;;
	esac
done

echo " output file is ${OUTPUT_FILE} "
echo " input  file is ${INPUT_FILE} "
echo " recipient is ${RECIPIENT} "
echo " userid is ${SENDER} "

echo "Command Line:$0 $*"

if [ `echo $OUTPUT_FILE | wc -c | awk '{print($1)}'` -lt 2 ]
then
	echoError -o
fi

if [ `echo $INPUT_FILE | wc -c | awk '{print($1)}'` -lt 3 ]
then
	echoError -d
fi

if [ `echo $RECIPIENT | wc -c | awk '{print($1)}'` -lt 3 ]
then
	echoError -r
fi

if [ `echo $SENDER | wc -c | awk '{print($1)}'` -lt 3 ]
then
	echoError -u
fi

echo "Message : encrypting $INPUT_FILE to $OUTPUT_FILE started at `date`"
 
/usr/bin/gpg --verbose --yes --batch --local-user ${SENDER} --recipient ${RECIPIENT} --output ${OUTPUT_FILE} --encrypt ${INPUT_FILE} 

RETURN_CODE=$?

if [ $RETURN_CODE -ne 0 ]
then
  echo "Encryption Not successful"
  exit $RETURN_CODE
fi

echo "Message : encryption Processing complete at `date`"

exit 0
