#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#       Shell name     : fundAllocExtract.sh
#       Author         : Subhankar Choudhury 
#       Date           :  March 08, 2005
#
#       Last Revised   : Abhishek Sharma (Keane Inc.)
#       Date Revised   : Mar 9, 2007
#       Why Revised    : Added new parameters to the micromuse 
#                        notification script for the 
#                        de-duplication feature.
#
#       Last Revised   : March 08, 2005
#-------------------------------------------------------------
#
#       Description: This script downloads the Fund Allocation
#                    Credit Report from Global1 to the HUFS dir
#
#-------------------------------------------------------------
#       Run Global Configuration Script
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
BATCH_JOB_NAME=FUNDALLOCRPT
SHELL_SCRIPT_NAME=fundAllocExtract.sh
EXTRACTED_FILE_NAME=*R*CREDITS*R2*

export LANG=C

#-------------------------------------------------------------
#  Run the Global One extract script to extract the report
#-------------------------------------------------------------
$CFG_VAR_GLOBAL1_SCRIPTPATH/$CFG_VAR_GLOBAL1_SCRIPTNAME $BATCH_JOB_NAME

#-------------------------------------------------------------
#  Check the name of the file that got extracted
#-------------------------------------------------------------
outputFileName=`ls $CFG_VAR_GLOBAL1_REPORT_DIR/$EXTRACTED_FILE_NAME -t1r |tail -1`

#-------------------------------------------------------------
#  Copy the extracted file to the HUFS directory structure
#-------------------------------------------------------------
cp $outputFileName $CFG_VAR_HUFS_DATA_ETL_DIR/queue/FundCreditReport.dat
returnCode=$?

#-------------------------------------------------------------
#  If the copy of the file has been successfull, delete the 
#  file created by the extract
#------------------------------------------------------------
if [ $returnCode -eq 0 ]
then
    chmod 777 $CFG_VAR_HUFS_DATA_ETL_DIR/queue/FundCreditReport.dat
    rm $outputFileName
else
    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the file generation 
    #-------------------------------------------------------------
    
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
        -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
        -e$ENV \
        -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        -k$SHELL_SCRIPT_NAME \
        -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        -m"The file has not been generated successfully. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
        -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
        -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/queue/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/fundAlcExtr*.`date +%y%m%d`.log"
fi

exit $returnCode