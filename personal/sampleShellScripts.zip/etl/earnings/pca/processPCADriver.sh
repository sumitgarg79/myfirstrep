#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : processPCADriver.sh
#  Author         : Nitish Shoree  (Keane Inc.)
#  Date Created   : Jul 03, 2007
#-------------------------------------------------------------
#
#  Description    : This script is responsible for following tasks
#					1.	Calls the gosos extracts for PCA 
#                   data from the Global1 instance
#					2.	Once the extract file is recieved, calls the
#					validate script to validate the extract file
#					3.	Invokes the batch Runner script to load the 
#					data to GPLW Database
#					4.	Performs cleanup to archive the loaded data 
#                   
#	Param 1		  : Environment
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=processPCADriver.sh
VALIDATE_PCA_SCRIPT=validatePCA.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/pca
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/pca
VAR_CONTROL_DATA_PCA_DIR=$CFG_VAR_CONTROL_DATA_DIR/pca
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.pca.LoadPostCloseActivityAction
BUSINESS_ENTITY=earnings/pca

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
year=0
extractName=PCA

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/pca/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/PCAOut.log"
    else
       # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/pca/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/PCAOut.log" 
    fi
}
#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
    -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/pca/Comm.log" \
    -c$3 
} 


#-------------------------------------------------------------
# Function Name : extractPCAData
# Description   : This function extracts Post Close Activity data from 
#				  Global1,where Global1 is set to 'Incremental' and copy into destination folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
extractPCAData(){ 	
	
	#-------------------------------------------------------------
	#  Check to see if the file created by the
	#  GOSOS extract is present in the destination location
	#-------------------------------------------------------------
	extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME|wc|awk '{print($1)}'`
	#-------------------------------------------------------------
	#  	If the PCA extract from Global1 does not already 
	#	exist, extract the data  
	#-------------------------------------------------------------
	if [ $extractFileExists -ne 1 ] 
	then 
		$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_GOSOS_EXTRACT_SCRIPT \
			$ENV \
	    	$extractName \
	    	"" \
	    	""
	    	
	#-----------------------------------------------------------------------
	#  Capture exit code from running the extract
	#-----------------------------------------------------------------------
	exitCode=$?    
	if [ $exitCode -ne 0 ] 
	then
        errorMessage=" EDB - the Gosos Extract Process failed."

		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
	   	exit 1
	fi
	    	
		#-----------------------------------------------------------------------
		#  Copy the extract folder from iofiles to destination folder
		#-----------------------------------------------------------------------
		cp $CFG_VAR_GLOBAL1_DATA_DIR/$CFG_VAR_ETL_PCA_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME
	    	
		#-----------------------------------------------------------------------
		#  Capture exit code from Gosos extract
		#-----------------------------------------------------------------------
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - the Gosos Extract Process failed. Error in copying the extract folder from iofiles to destination folder."
	
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
					 
        	notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
		   	exit 1
		fi
	
	fi
	
}

#-------------------------------------------------------------
# Function Name : validatePCADataFile
# Description   : This function calls the  script to validate 
#				  PCA data File , if  Data File 
#				  is not valid it exits  with  exit code		
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validatePCADataFile( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_PCA_DIR/$VALIDATE_PCA_SCRIPT \
	$ENV \
	
	exitCode=$?

	
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - Validate PCA Data Failed." 
		
        notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
       	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""
		exit 1
	fi	
}

#-------------------------------------------------------------
# Function Name : loadPCAData
# Description   : This function calls the  script to load 
#				  PCA Data from Global1 extract File
#				  into earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadPCAData( )
{
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
   	$ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
    
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then 
        #---------------------------------------------------------------------------------
    	#  Notify Micromuse that the there is some problem with the PCA Load 
	    #----------------------------------------------------------------------------------
  		errorMessage=" EDB - Error in PCA Load Process. Check the Batch log to determine cause of the problem.." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
     	$CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        	-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/pca/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/pca/Batch.log"

	    exit 1
	fi
}

#-------------------------------------------------------------
# Function Name : performCleanUp
# Description   : This function will archive PCA 
#				  data file and move it to archive folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
performCleanUp( )
{
	rm $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME.`date +%Y%m%d`
	mv $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME.`date +%Y%m%d`
	

   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB - Error occured while archiving $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_PCA_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        "Archive PCA Data"
	    exit 1
	fi	
}

#-------------------------------------------------------------
#  Main function
#-------------------------------------------------------------


#-------------------------------------------------------------
#  Extract PCA data 
#-------------------------------------------------------------
	extractPCAData
#---------------------------------------------------------------------------
# Call validate script to check the extracted PCA data
#---------------------------------------------------------------------------
	validatePCADataFile
#---------------------------------------------------------------------------
#  load PCA data 
#---------------------------------------------------------------------------
  	loadPCAData
#---------------------------------------------------------------------------
#  perform Clean up process 
#---------------------------------------------------------------------------
  	performCleanUp
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
	
	
	