#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : processDailyEarningsRC.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : November30, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 13, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#-------------------------------------------------------------
#
#  Description    : This script is used to Compare month to date
#					accruals to month to date daily income and
#					identify variances 
#	Param 1		  : Environment
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg					

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=processDailyEarningsRC.sh
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.recon.ReconcileDailyEarningsAction
BUSINESS_ENTITY=earnings/recon

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/recon/Comm.log" \
    -c$3
}
#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Month End Balancing  process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY 
    
exitCode=$?
         
if [ $exitCode -ne 0 ]
then
 	errorMessage=" EDB - Error in the Month to Date balancing process." 
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID

     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
         -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
         -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
         -e$ENV \
         -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
         -k$SHELL_SCRIPT_NAME \
         -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
         -m"The Process Failed - usage error. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
         -t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
         -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/recon/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/recon/Batch.log"

fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode