#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : reconcileTriLedgerBalances.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : November 03, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 11, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                    script for de-duplication feature.
# 
#-------------------------------------------------------------
#
#  Description    : This script is used to facilitate the month end 
#					review by performing the tri ledger balancing 
#					by reconcilition of Actual Fund Earnings and 
#					Accrued Fund Earnings data
#	Param 1		  : Environment
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg					

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=reconcileTriLedgerBalances.sh
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.recon.ReconcileTriLedgerBalancesAction
BUSINESS_ENTITY=earnings/recon

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){

if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/recon/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/recon/Batch.log"
    else
       # Call batchLogger WITH the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -q"$5" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/recon/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/recon/Batch.log"
    fi 
    
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/recon/Comm.log" \
    -c$3
}
#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Month End Balancing  process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY \
    
exitCode=$?
         
if [ $exitCode -ne 0 ]
then  
 	errorMessage=" EDB - Error in Month End Balancing process." 
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID

	notifyMicromuse "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
	"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        ""			 	
fi

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Borrower Recon Data Load process.
#  This process has been added to TriLedgerBalances job
#  simply because this job runs after FullRun is complete.
#  Otherwise Borrower Recon process does not depend upon
#  Monthly Recon process and not related with it.
#----------------------------------------------------------
LOAD_ACTION_CLASS_NAME_BR=com.ubs.gplw.action.borrower.recon.LoadBorrowerReconciliationAction
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME_BR \
    $BUSINESS_ENTITY \
    
exitCode=$?
         
if [ $exitCode -ne 0 ]
then  
 	errorMessage=" EDB - Error in Borrower Recon Data Load process." 
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID

	notifyMicromuse "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
	"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""			 	
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode