#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : initialLoadOCBLoans.sh
#  Author         : Sumit Garg  (Keane Inc.)
#  Date Created   : July 18, 2007
#-------------------------------------------------------------
#
#  Description    : This script is responsible for following tasks
#					1.	check existence of NEWPOSmmdd.DAT
#						(mm - month, dd - date), if file does not exist
#						log error to chat channel 
#					2.	Invokes the batch Runner script for initial load 
#						of On Close billing indicator and repaid date
#					3.Performs cleanup to archive
#                   
#	Param 1		  : Environment
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=initialLoadOCBLoans.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/ocb
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/ocb
VAR_CONTROL_DATA_OCB_DIR=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.ocb.InitialLoadOCBloansAction
BUSINESS_ENTITY=earnings/ocb
OCB_INITLOAD_FILE_NAME=NEWPOS`date +%m%d`.DAT
OCB_INIT_FILE_NAME=NEWPOS.DAT


#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
extractFileExists=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/OCBOut.log" 
    else
       # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/OCBOut.log" 
    fi
}

#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
    -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/ocb/Comm.log" \
    -c$3 
} 


#-------------------------------------------------------------
# Function Name : loadInitialOCBData
# Description   : This function calls the  script for initial load 
#				  of On Close billing indicator and repaid date
#				  into earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadInitialOCBData( )
{
    extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$OCB_INITLOAD_FILE_NAME|wc|awk '{print($1)}'`
    
    cp $DATA_EXTRACT_FOLDER_NAME/$OCB_INITLOAD_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$OCB_INIT_FILE_NAME
    
	if [ $extractFileExists -ne 1 ] 
	then 
        #---------------------------------------------------------------------------------------------
    	#  Notify Chat Channel and Micromuse that the there is some problem with the copying data file
	    #---------------------------------------------------------------------------------------------
		errorMessage=" EDB - Error occured while copying file from $OCB_INITLOAD_FILE_NAME to $OCB_INIT_FILE_NAME." 
		
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
     	$CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        	-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/ocb/Batch.log"

	    exit 1
	fi
	 
	 
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
   	$ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
    
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then 
        #---------------------------------------------------------------------------------
    	#  Notify Micromuse that the there is some problem with the Broker rebates Load 
	    #----------------------------------------------------------------------------------
  		errorMessage=" EDB - Error in OCB Load Process. Check the Batch log to determine cause of the problem.." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
     	$CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        	-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/ocb/Batch.log"

	    exit 1
	fi
}

#-------------------------------------------------------------
# Function Name : performCleanUp
# Description   : This function will remove/archive  
#				  data file 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
performCleanUp( )
{
	rm -f $DATA_EXTRACT_FOLDER_NAME/$OCB_INIT_FILE_NAME
	mv $DATA_EXTRACT_FOLDER_NAME/$OCB_INITLOAD_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$OCB_INITLOAD_FILE_NAME.`date +%m%d%Y`

   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB - Error occured while copying $DATA_EXTRACT_FOLDER_NAME/$OCB_INITLOAD_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        "Archive Rebates Data"
	    exit 1
	fi	
}

#-------------------------------------------------------------
#  Main function
#-------------------------------------------------------------
#---------------------------------------------------------------------------
#  load OCB data 
#---------------------------------------------------------------------------
  	loadInitialOCBData
#---------------------------------------------------------------------------
#  perform Clean up process 
#---------------------------------------------------------------------------
  	performCleanUp
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode