#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : processOCBLoansDriver.sh
#  Author         : Bikram Singh  (Keane Inc.)
#  Date Created   : May 21, 2007
#-------------------------------------------------------------
#
#  Description    : This script is responsible for following tasks
#					1.	Calls the gosos extracts for OCB 
#                   data from the Global1 instance
#					2.	Once the extract file is recieved, calls the
#					validate script to validate the extract file
#					3.	Invokes the batch Runner script to load the 
#					data to GPLW Database
#					4.	Performs cleanup to archive the loaded data 
#                   
#	Param 1		  : Environment
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=processOCBLoansDriver.sh
VALIDATE_OCB_SCRIPT=validateOCBLoans.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/ocb
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/ocb
VAR_CONTROL_DATA_OCB_DIR=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.ocb.LoadOCBLoansAction
TRIGGER_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.ocb.GenerateOCBLoansTriggerFileAction
BUSINESS_ENTITY=earnings/ocb
OCB_TRIGGER_FILE_NAME=OCBLoan_`date +%m%d%Y`.trg


#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
year=0
date=0
extractName=OCB

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/OCBOut.log" 
    else
       # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/ocb/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/OCBOut.log" 
    fi
}
#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
    -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/ocb/Comm.log" \
    -c$3 
} 

#-------------------------------------------------------------
# Function Name : generateTriggerFile
# Description   : This function calls the  script to  
#				  generate Trigger File
#				  
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
generateTriggerFile( )
{
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
   	$ENV \
    $TRIGGER_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
    
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then 
        #---------------------------------------------------------------------------------
    	#  Notify Micromuse error occured while generating trigger file for OCB load 
	    #----------------------------------------------------------------------------------
  		errorMessage=" EDB - Error in OCB Trigger File Generation. Check the Batch log to determine cause of the problem.." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	  	
	  	notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "Trigger File"
	    
	    exit 1
	fi
}

#-------------------------------------------------------------
# Function Name : extractOCBLoansData
# Description   : This function calculates from date,to date and 
#				  extracts On Close Billing data from 
#				  Global1 and copy into destination folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
extractOCBData(){ 
	
	prior_business_date=`head -1 $VAR_CONTROL_DATA_OCB_DIR/$OCB_TRIGGER_FILE_NAME  | cut -c1-8` 
	
	#-------------------------------------------------------------
	#  Check to see if the file created by the
	#  GOSOS extract is present in the destination location
	#-------------------------------------------------------------
	extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME|wc|awk '{print($1)}'`
	#-------------------------------------------------------------
	#  	If the OCB extract from Global1 does not already 
	#	exist, extract the data  
	#-------------------------------------------------------------
	if [ $extractFileExists -ne 1 ] 
	then 
		$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_GOSOS_EXTRACT_SCRIPT \
			$ENV \
	    	$extractName \
	    	$prior_business_date \
	    	$prior_business_date

		#-----------------------------------------------------------------------
		#  Copy the extract folder from iofiles to destination folder
		#-----------------------------------------------------------------------
		cp $CFG_VAR_GLOBAL1_DATA_DIR/$CFG_VAR_ETL_OCB_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME		
	    	
		#-----------------------------------------------------------------------
		#  Capture exit code from Gosos extract
		#-----------------------------------------------------------------------
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - the Gosos Extract Process failed. Check the Autosys log to determine the cause of the problem."
	
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
					 
        	notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
		   	exit 1
		fi
	
	fi
	#-----------------------------------------------------------------------
	#Sort the Extracted Data on the basis of Activity Transaction Number
	#-----------------------------------------------------------------------
	sort $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME -o $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME
}

#-------------------------------------------------------------
# Function Name : validateOCBDataFile
# Description   : This function calls the  script to validate 
#				  OCB data File , if  Data File 
#				  is not valid it exits  with  exit code		
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateOCBDataFile( )
{

	date=`head -1 $VAR_CONTROL_DATA_OCB_DIR/$OCB_TRIGGER_FILE_NAME  | cut -c1-4` 
	year=`head -1 $VAR_CONTROL_DATA_OCB_DIR/$OCB_TRIGGER_FILE_NAME  | cut -c5-8` 

	$CFG_VAR_HUFS_PKG_SCRIPTS_OCB_DIR/$VALIDATE_OCB_SCRIPT \
	$ENV \
	$year$date \
	$year$date

	exitCode=$?

	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - Validate OCB Data Failed." 
		
        notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
       	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""
		exit 1
	fi	
}

#-------------------------------------------------------------
# Function Name : loadOCBData
# Description   : This function calls the  script to load 
#				  OCB Data from Global1 extract File
#				  into earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadOCBData( )
{
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
   	$ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
    
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then 
        #---------------------------------------------------------------------------------
    	#  Notify Micromuse that the there is some problem with the Broker rebates Load 
	    #----------------------------------------------------------------------------------
  		errorMessage=" EDB - Error in OCB Load Process. Check the Batch log to determine cause of the problem.." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
     	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        ""

	    exit 1
	fi
}

#-------------------------------------------------------------
# Function Name : performCleanUp
# Description   : This function will archive OCB 
#				  data file and move it to archive folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
performCleanUp( )
{
	rm $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME.`date +%m%d%Y`
	mv $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME.`date +%m%d%Y`
	mv $VAR_CONTROL_DATA_OCB_DIR/$OCB_TRIGGER_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/

   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB - Error occured while copying $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_OCB_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        "Archive Data"
	    exit 1
	fi	
}

#-------------------------------------------------------------
#  Main function
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Trigger File Generation
#-------------------------------------------------------------
	generateTriggerFile
#-------------------------------------------------------------
#  Extract OCB data 
#-------------------------------------------------------------
	extractOCBData
#---------------------------------------------------------------------------
# Call validate script to check the extracted OCB data
#---------------------------------------------------------------------------
	validateOCBDataFile
#---------------------------------------------------------------------------
#  load OCB data 
#---------------------------------------------------------------------------
  	loadOCBData
#---------------------------------------------------------------------------
#  perform Clean up process 
#---------------------------------------------------------------------------
  	performCleanUp
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
	
	
	