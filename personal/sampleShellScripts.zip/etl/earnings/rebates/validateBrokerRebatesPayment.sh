#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : validateBrokerRebatesPayment.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : Mar 23, 2007
#-------------------------------------------------------------
#
#  Description    : This script validates Broker rebates payment 
#					Data file.Its perform following operations
#
#					a) Check, If Broker rebates payment Data File Exists.
#					b) Check, If Broker rebates payment Data File has 
#					   detail records.
#					c) Check, If Broker rebates payment Data File has valid date .
#					d) It also validate All Records for following fields
#						1) Effective date 
#						2) Activity value
#	Param 1		  : Environment
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg			

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=validateBrokerRebatesPayment.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/rebates

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
fromDate=$2
toDate=$3
maxLine=`expr $CFG_VAR_ETL_BROKER_REBATE_PAYMENT_VALIDATE_RECORD_COUNT + 1`
# This variable will not treat blank space as a field separator
# during validation of  records 
IFS=$'\t\n'

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
lineCount=0

#------------------------------------------------------------- 
# Function Name : notifyMicromuse 
# Description   : Notify MicroMuse that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/rebates/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/BrokerRebatesPaymentOut.log" 
    else
       # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/rebates/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/BrokerRebatesPaymentOut.log" 
    fi
}


#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
    -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/rebates/Comm.log" \
    -c$3 
} 

#-------------------------------------------------------------
# Function Name : isValidInt
# Description   : Validate integer input and doesn't allow any 
#				  negative integer. 
# Parameters    : String with integer value e.g. "1".
# Return        :  0 for success, 1 for failure.
#-------------------------------------------------------------
isValidInt()
{   
  	number="$1"      
  	nodigits="$(echo $number | sed 's/[[:digit:]]//g')" 
  	if [ ! -z $nodigits ] 
	then
  		echo "Invalid number format! Only digits, no commas, spaces, etc."
    	return 1
  	fi
 	return 0 
}  

#-------------------------------------------------------------
# Function Name : isValidNumeric
# Description   : Validate whether a number is a valid floating 
#				  point value. Note that this cannot accept 
#				  scientific (1.304e5)notation.To test whether 
#				  an entered value is a valid floating point 
#				  number, we need to split the value at the 
#				  decimal point,then test the first part to see
#				  if it's a valid integer, then the second part
#				  to see if it's a  valid >=0 integer, doesn't 
#				  allow any negative  values  
# Parameters    : String with integer value e.g. "1".
# Return        : 0 for success, 1 for failure.
#-------------------------------------------------------------
isValidNumeric()
{
	fvalue="$1" 
    decimalPart="$(echo $fvalue | cut -d. -f1)"
    fractionalPart="$(echo $fvalue | cut -d. -f2)"  
    
    if [ ! -z $decimalPart ]  
    then  
        isValidInt $decimalPart        
        if  [ $? -eq 1 ]
        then
          	return 1
       	fi 
    fi 
    
    if [ "$fractionalPart" != "" ] 
    then    
        isValidInt $fractionalPart             
        if  [ $? -eq 1 ]
        then 
        	return 1
        fi       
    fi    
	return 0
}

#------------------------------------------------------------------------
# Function Name : hasDetailRecords
# Description   : This function check if the Broker rebates payment Extract 
#				  has at least 1 detail record to upload the data.
#				  a) The number of row in the extract are more than "2"
#				  b) Checks if any of the row starts with "1" 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------------------
hasDetailRecords(){ 
	if [ `cat $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME | wc -l` -gt 2 ]
	then
    	if [ `head -2 $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME | tail -1 | cut -c1`  -ne  1 ]
	    then
        	errorMessage=" EDB - Error in Validate Borrower rebates payment Extract Data. Borrower rebates payment Extract file doesn't have any detail records." 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
	    	notifyMicromuse "$errorMessage" \
    	    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
	        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
	        "Detail Record < 1"
			exit 1
	   	fi 
	else 
        errorMessage=" EDB - Error in Validate Borrower rebates payment Extract Data. Borrower rebates payment Extract file doesn't have any detail records." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        "Total Record < 2"
		exit 1
	fi 
}

#-----------------------------------------------------------------------------
# Function Name : validDateRange
# Description   : Validate the date range of the Broker rebates payment Extract
#				  data. 
# Parameters    : none
# Return        : none
#-----------------------------------------------------------------------------
validDateRange(){ 
	extract_fromDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME  | cut -c104-111` 
	extract_toDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME    | cut -c112-119`   

	if [   $fromDate  -ne $extract_fromDate ]  ||  [ $toDate  -ne $extract_toDate  ]
	then 
		errorMessage=" EDB - Error in Validate Borrower rebates payment Extract Data. Date Range is invalid." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        "Date Range"
		exit 1
	fi  
}

#-------------------------------------------------------------
# Function Name : validateRecords
# Description   : Validate loan value,effective date,
#				  input date,activity value among top 10 
#				  detail records from Broker rebates payment 
#				  Extract file.Calls isValidNumeric function . 
#				  Skip the first record as 1st record is having 
#				  header data.			
# Parameters    : none
# Return        : none
#-------------------------------------------------------------

validateRecords (){ 
exec 3<$DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME
while read  EXTRACTFILERECORD <&3
do
let "lineCount+=1"          
	 if [ $lineCount  -gt 1 ] &&  [ $lineCount  -le $maxLine ]
	 then
	 	
 	 	br_Extract_EFFDATE=`echo $EXTRACTFILERECORD | cut  -c2-9`
   	    br_Extract_ACTVALUE=`echo $EXTRACTFILERECORD | cut  -c10-24`

		# Remove -ve sign from the value if available before validation. -ve values/earnings are acceptable
		br_Extract_ACTVALUE="$(echo $br_Extract_ACTVALUE | sed 's/-//g')"
		
		isValidNumeric $br_Extract_EFFDATE
		exitCode=$?
		if  [ $exitCode -ne 0 ]
		then 
			errorMessage=" EDB - Error in Validate Borrower rebates payment Extract Data. effective date is invalid."
		
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
	    	notifyMicromuse "$errorMessage" \
	        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
	        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
	        "Effective date"
		   	exit 1
		fi  
		
		isValidNumeric $br_Extract_ACTVALUE
		exitCode=$?
		if  [ $exitCode -ne 0 ]
		then 
			errorMessage=" EDB - Error in Validate Borrower rebates payment Extract Data. activity value is invalid."
		
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
	    	notifyMicromuse "$errorMessage" \
	        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
	        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
	        "Activity value"
		   	exit 1
		fi  
	 
	else
	if [ $lineCount  -gt $maxLine ]
	then
	  	break 
	fi 
fi	 
done    
}
 
#-------------------------------------------------------------
#  Main function to validate the Data file for all records
#-------------------------------------------------------------
#---------------------------------------------------------------------------
#  Check If Extract File has detail records
#---------------------------------------------------------------------------
	hasDetailRecords    

#---------------------------------------------------------------------------
#  Check If Extract File has valid date range
#---------------------------------------------------------------------------
	validDateRange 

#---------------------------------------------------------------------------
#  Validate Top 10 Records for various fields
#---------------------------------------------------------------------------
	validateRecords 
    
exit $exitCode
