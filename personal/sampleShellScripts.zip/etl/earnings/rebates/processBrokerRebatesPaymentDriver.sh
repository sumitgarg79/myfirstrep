#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : processBrokerRebatesPaymentDriver.sh
#  Author         : Sumit Garg  (Keane Inc.)
#  Date Created   : March 21, 2007
#-------------------------------------------------------------
#
#  Description    : This script is responsible for following tasks
#					1.	Calls the gosos extracts for broker rebates payment 
#                   data from the Global1 instance
#					2.	Once the extract file is recieved, calls the
#					validate script to validate the extract file
#					3.	Invokes the batch Runner script to load the 
#					data to GPLW Database
#					4.	Performs cleanup to archive the loaded data 
#                   
#	Param 1		  : Environment
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=processBrokerRebatesPaymentDriver.sh
VALIDATE_BROKER_REBATES_SCRIPT=validateBrokerRebatesPayment.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/rebates
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/rebates
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.rebates.LoadBrokerRebatesPaymentAction
BUSINESS_ENTITY=earnings/rebates

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
year=0
extractName=BROKERREBATE

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/rebates/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/BrokerRebatesPaymentOut.log" 
    else
       # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/rebates/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/BrokerRebatesPaymentOut.log" 
    fi
}
#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
    -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/rebates/Comm.log" \
    -c$3 
} 

#-------------------------------------------------------------
# Function Name : extractBrokerRebatesData
# Description   : This function calculates from date,to date and 
#				  extracts Broker rebates payment data from 
#				  Global1 and copy into destination folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
extractBrokerRebatesData(){ 
	
	currentDate=`date +%Y%m%d`
	currentMonth=`echo $currentDate | cut -c5-6`
	currentYear=`echo $currentDate | cut -c1-4`

	if [ $currentMonth  -ne 01 ]
	then
		year=$currentYear
		previousMonth=`expr $currentMonth - 1`
		previousMonth=0`+`$previousMonth

	elif [ $currentMonth  -eq 01 ]
	then
		year=`expr $currentYear - 1`
		previousMonth=12
	fi
	
	fromDate=$previousMonth`+`01
	
	#-------------------------------------------------------------
	#  calculation to date
	#-------------------------------------------------------------
	
	if [[ $previousMonth -eq 01 || $previousMonth -eq 03 || $previousMonth -eq 05 || $previousMonth -eq 07 || $previousMonth -eq 08 || $previousMonth -eq 10 || $previousMonth -eq 12 ]]
	then
		toDate=$previousMonth`+`31
	elif [[ $previousMonth -eq 04  || $previousMonth -eq 06  || $previousMonth -eq 09  || $previousMonth -eq 11  ]]
	then
		toDate=$previousMonth`+`30
	elif [ $previousMonth -eq 02  ]  && [ $((year % 4)) -ne 0 ]
	then
		toDate=$previousMonth`+`28
	elif [ $previousMonth -eq 02 ]   && [ $((year % 4)) -eq 0  ]
	then
		toDate=$previousMonth`+`29
	fi
	
	#-------------------------------------------------------------
	#  Check to see if the file created by the
	#  GOSOS extract is present in the destination location
	#-------------------------------------------------------------
	extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME|wc|awk '{print($1)}'`
	#-------------------------------------------------------------
	#  	If the Broker rebates payment extract from Global1 does not already 
	#	exist, extract the data  
	#-------------------------------------------------------------
	if [ $extractFileExists -ne 1 ] 
	then 
		$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_GOSOS_EXTRACT_SCRIPT \
			$ENV \
	    	$extractName \
	    	$fromDate$year \
	    	$toDate$year
	
		#-----------------------------------------------------------------------
		#  Capture exit code from running the extract
		#-----------------------------------------------------------------------
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - the Gosos Extract Process failed. Check the Autosys log to determine the cause of the problem."
	
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
					 
        	notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
		   	exit 1
		fi
	
		#-----------------------------------------------------------------------
		#  Copy the extract folder from iofiles to destination folder
		#-----------------------------------------------------------------------
		
		cp $CFG_VAR_GLOBAL1_DATA_DIR/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME		
		
		#-----------------------------------------------------------------------
		#  Capture exit code from copy command execution
		#-----------------------------------------------------------------------
		
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - the Gosos Extract Process failed. Error in copying the extract file from iofiles to destination folder."
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
					 
        	notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            "Copy Data"
		   	exit 1
		fi
	fi
}

#-------------------------------------------------------------
# Function Name : validateBrokerRebatesDataFile
# Description   : This function calls the  script to validate 
#				  Broker rebates payment data File , if  Data File 
#				  is not valid it exits  with  exit code		
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateBrokerRebatesDataFile( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_REBATES_DIR/$VALIDATE_BROKER_REBATES_SCRIPT \
	$ENV \
	$year$fromDate \
	$year$toDate
	exitCode=$?
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - Validate Borrower Rebates Data Failed." 
		
        notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
       	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""
		exit 1
		
	fi	
}

#-------------------------------------------------------------
# Function Name : loadBrokerRebateData
# Description   : This function calls the  script to load 
#				  Broker rebates Data from Global1
#				  System into earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadBrokerRebateData( )
{
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
   	 $ENV \
     $LOAD_ACTION_CLASS_NAME \
     $BUSINESS_ENTITY
    
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then 
        #---------------------------------------------------------------------------------
    	#  Notify Micromuse that the there is some problem with the Broker rebates Load 
	    #----------------------------------------------------------------------------------
		
  		errorMessage=" EDB - Error in Borrower rebates Load Process. Check the Batch log to determine cause of the problem.." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
     	$CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        	-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            -k$SHELL_SCRIPT_NAME \
            -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/rebates/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/rebates/Batch.log"

	    exit 1

	fi
}

#-------------------------------------------------------------
# Function Name : performCleanUp
# Description   : This function will archive broker rebates 
#				  data file and move it to archive folder 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
performCleanUp( )
{
	mv $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME.`date +%Y%m%d`
   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		
		errorMessage=" EDB - Error occured while copying $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_BROKER_REBATES_PAYMENT_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
    	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        "Archive Data"
	    exit 1
	 
	fi	
}



#-------------------------------------------------------------
#  Main function 
#  Extract Broker rebates data 
#-------------------------------------------------------------
	extractBrokerRebatesData
   
#---------------------------------------------------------------------------
# Call validate script to check the extracted Broker Rebate data
#---------------------------------------------------------------------------
	validateBrokerRebatesDataFile
  
#---------------------------------------------------------------------------
#  load Broker rebates data 
#---------------------------------------------------------------------------
  	loadBrokerRebateData
  
#---------------------------------------------------------------------------
#  perform Clean up process 
#---------------------------------------------------------------------------
  	performCleanUp
  
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
	
	
	