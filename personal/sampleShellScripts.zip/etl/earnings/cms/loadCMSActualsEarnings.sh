#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loadCMSActualsEarnings.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : October 16, 2006
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script is responsible for following tasks
#					1.	loads CMS Actuals Earnings data   
#                   extracted from Collateral Manangement System
#					into earnings database
#					2. On Successful Load, moves the data and control files
#					to archive folder
#	Param 1		  : Environment
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg					

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------

CMS_ACTUAL_DATA_FILE_NAME=$CFG_VAR_ETL_CMS_MONTHLY_ACTUALS_FILE_NAME
ACTUAL_EARNINGS_TOKEN_FILE_NAME=AM_`date +%m`.DAT 
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/cms
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl    
ARCHIVE_ACTUAL_EARNINGS_TOKEN_FILE_NAME=AMTOKEN_`date +%y%m%d`.DAT
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/cms
ARCHIVE_CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/controletl
SHELL_SCRIPT_NAME=loadCMSActualsEarnings.sh
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.cms.LoadCMSActualsAction
BUSINESS_ENTITY=earnings/cms
RUNTYPE=AM

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Contact Name
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/prod/autosys/ActualsMonthly*.`date +%y%m%d`.log"
    else
       # Call batchLogger WITH the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -q"$5" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/prod/autosys/ActualsMonthly*.`date +%y%m%d`.log"
    fi
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/cms/Comm.log" \
    -c$3
}

#----------------------------------------------------------
#  Call the generic Batch Runner script with the following
#  parameters to start the Load process.
#  Environment, Java Action Class Name, Business folder, AM
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY \
    $RUNTYPE
    
exitCode=$?
if [ $exitCode -ne 0 ]
then 
	errorMessage=" EDB - the CMS Actual Earnings Load Process did not complete successfully."

	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		-m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/cms/Batch.log"

	exit 1
fi

#-------------------------------------------------------------
#  					CleanUp process 
#-------------------------------------------------------------
#-------------------------------------------------------------
#  	Move the CMS Actual data files to respective ARCHIVE Folders
#-------------------------------------------------------------

fileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$CMS_ACTUAL_DATA_FILE_NAME|wc|awk '{print($1)}'`
if [ $fileExists -eq 1 ]
then
   	mv $DATA_EXTRACT_FOLDER_NAME/$CMS_ACTUAL_DATA_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_CMS_MONTHLY_ACTUALS_FILE_NAME.`date +%y%m%d`
   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB - Error occured while copying $DATA_EXTRACT_FOLDER_NAME/$CMS_ACTUAL_DATA_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_WARN \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            "Data File"
	fi	
fi

#--------------------------------------------------------------------------
#  	Move the CMS Actual Token file(if Present )to respective ARCHIVE Folder
#--------------------------------------------------------------------------

fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ACTUAL_EARNINGS_TOKEN_FILE_NAME|wc|awk '{print($1)}'`
if [ $fileExists -eq 1 ]
then
   	mv $CONTROL_DATA_FOLDER_NAME/$ACTUAL_EARNINGS_TOKEN_FILE_NAME $ARCHIVE_CONTROL_DATA_FOLDER_NAME/$ARCHIVE_ACTUAL_EARNINGS_TOKEN_FILE_NAME
   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB - Error occured while copying $CONTROL_DATA_FOLDER_NAME/$ACTUAL_EARNINGS_TOKEN_FILE_NAME to $ARCHIVE_CONTROL_DATA_FOLDER_NAME folder." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_WARN \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			 
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            "Token File"
	fi	
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode