#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : processCMSCalculatedEarningsDriver.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : October 12, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                    script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    :	This script is responsible for following tasks on
#					first business day
#					1. It will check presence of CMS calculated
#				   	data flat File 
#					2. If the file is not available then rechecks for 
#					its presence every Ten minutes and  sends a message to
#				   	Business Support every Hour.
#					3. If  Flat file is still not present until 1900 
#					Eastern Time, then aborts the process and creates a
#					token file for next day.
#					4. If the flat file  is present then script  will  call
#				   	validateCMSCalculatedEarnings.sh script to validate
#				   	flat file and load the earnings to database after 
#					validation
#					5. On next business day the process will check for availability
#					of token file from previous day, if the token file is found then
#					repeat above 4 steps or exit 0
#
#	Param 1		  : Environment
#   Param 2 	  : Bussiness Day 	
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=processCMSCalculatedEarningsDriver.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/cms
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl   
DATA_EXTRACT_FILE_NAME=$CFG_VAR_ETL_CMS_DAILY_CALCULATED_FILE_NAME
VALIDATE_CMSCALCULATED_SCRIPT=validateCMSCalculatedEarnings.sh       
LOAD_CMSCALCULATED_SCRIPT=loadCMSCalculatedEarnings.sh  
CALCULATED_EARNINGS_TOKEN_FILE_NAME=DD_`date +%m`.DAT  
        
#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
SLEEP_TIME_INTERVAL=600
WARNING_SECONDS_INTERVAL=3600
SLEEP_COUNT_NOS=`expr $WARNING_SECONDS_INTERVAL / $SLEEP_TIME_INTERVAL + 1`

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
tokenFileExist=0
sleepCounter=0
bussinessDay=$2

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successfull
#-------------------------------------------------------------
notifyMicromuse(){

    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/CalcDaily*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/CalcDaily*.`date +%y%m%d`.log"
    fi 
    
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/cms/Comm.log" \
    -c$3
}

#-------------------------------------------------------------
# Function Name : loadCMSCalculatedData
# Description   : This function calls the  script to load 
#				  CMS Calculated Data from CMS into 
#				  earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadCMSCalculatedData( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_CMS_DIR/$LOAD_CMSCALCULATED_SCRIPT $ENV 
	exitCode=$?
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - the CMS Calculated Earnings Load Process failed." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
		notifyMicromuse "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
		"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		""
		
    	exit 1
	fi
}	

#-------------------------------------------------------------
# Function Name : validateCMSCalculatedDataFile
# Description   : This function calls the  script to validate 
#				  CMS Calculated Data File , if  Data is not
#				  valid it notify micromuse and exits with error code		
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateCMSCalculatedDataFile( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_CMS_DIR/$VALIDATE_CMSCALCULATED_SCRIPT $ENV 
	exitCode=$?
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - CMS Calculated Earnings failed Validate Process. The CMS Calculated data file is not in valid format." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			 
	 	notifyMicromuse "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		"$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
		"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		""
    	exit 1
	fi	
}


#-------------------------------------------------------------
# Function Name : isFilePresent
# Description   : This function checks if the CMS Calculated Earnings Data File  exist in global1 
#				  directory,if exist it copies into destination folder to load the data.
#				  Otherwise this script send  message to GPL Workbench support every hour 
#				  for CMS Calculated Earnings file not recieved till 1900 Eastern Time.
#				  If the file is not recieved till 1900 hrs, then the script will create a 		
#				  token file to resume the CMS Calculated earnings process on next business day   
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
isFilePresent( )
{   
#-------------------------------------------------------------
#  Check to see if the CMS Calculated Data file is present in 
#  work  folder of global1 
#-------------------------------------------------------------
	while true
	do
		if [ `date +%H` -lt 19 ] 
		then
			extractFileExists=`ls -alt $CFG_VAR_CMS_DATA_FILE_DIR/$DATA_EXTRACT_FILE_NAME|wc|awk '{print($1)}'`
			if [ $extractFileExists -ne 1 ] 
			then 
				let "sleepCounter+=1"
				if [ $sleepCounter -eq $SLEEP_COUNT_NOS ]
				then
					sleepCounter=1
					#TODO MESSAGE TO GPLWORKBENCH SUPPORT to remind for file
					echo  "MESSAGE TO GPLWORKBENCH SUPPORT"  `date`
				fi
				errorMessage=" EDB - WAITING FOR CALCULATED EARNINGS FILE: " `date` 
				
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 

				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

				sleep  $SLEEP_TIME_INTERVAL
			else
				#--------------------------------------------------------------
				# If File found then exit the search
				#--------------------------------------------------------------
				break
    	    fi  
 		#----------------------------------------------------------------------
	 	# If the file is not recieved till 1900 Eastern Time a empty file as 
	 	token needs to be created to  continue  execution  on next  bussiness day 
		#----------------------------------------------------------------------    	    		
		elif [ `date +%H`  -ge 19 ]
		then
			if [ $bussinessDay -eq 1 ]
			then
				touch $CONTROL_DATA_FOLDER_NAME/$CALCULATED_EARNINGS_TOKEN_FILE_NAME
				exitCode=$?    
				if [ $exitCode -ne 0 ] 
				then
					errorMessage=" EDB - The CMS Calculated Earnings Extract Process failed. Error in creating token file." 
					notifyChatChannel "$errorMessage" \
					$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
					$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
						 
					notifyMicromuse "$errorMessage" \
                        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                        "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                        "Token File"   	
			    	
			    	exit 1
				fi
				errorMessage=" EDB - The CMS Calculated Earnings Extract Process did not start. CMS Calculated Data file not recieved." 
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 
			
		    	notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "Data File"
		    			    	
			else
				errorMessage=" EDB - CMS Calculated Earnings Extract Process Failed. CMS Actual Data file not recieved on 2nd day by 19:00 Hrs." 
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 
				
				notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    ""
				
				exit 1 	
			fi
		fi
	done 

	#-----------------------------------------------------------------------
	# Extract File Recieved
	#-----------------------------------------------------------------------
	if [ $extractFileExists -eq 1 ] 
	then
		#-----------------------------------------------------------------------
		#  Copy the Data file from work to destination folder
		#-----------------------------------------------------------------------
		cp $CFG_VAR_CMS_DATA_FILE_DIR/$DATA_EXTRACT_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME
	
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - the Extract CMS Calculated Earnings Extract Process failed. Error in copying the extract folder from work to destination folder." 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				  
			notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                ""
			            	
	    	exit 1
		fi
	fi		                               
}

#-------------------------------------------------------------
# Function Name : checkBussinessDay
# Description   : This function notify micromuse and  exit with 0 
#				  if token File is not present on second  bussiness
#				  day of the month 			  	 	    
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
checkBussinessDay( )
{ 
	if [ $bussinessDay -eq 2 ]
	then
		tokenFileExist=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CALCULATED_EARNINGS_TOKEN_FILE_NAME|wc|awk '{print($1)}'`
		if [ $tokenFileExist -ne 1 ] 
		then  
		
				 
		
							
		
#			notifyMicromuse " EDB - CMS Calculated Earnings Process completed successfully. Process is not required on 2nd Business Day." \
#			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR
			
			exit 0 	
		fi
	fi
}

#-------------------------------------------------------------
#  Main function 
#-------------------------------------------------------------
# Check If Extract File Exists
	checkBussinessDay  
# Check If Extract File Exists
	isFilePresent  
# Call validate script to check the extracted CMS Calculated data
	validateCMSCalculatedDataFile
# Call script to load CMS Calculated data
	loadCMSCalculatedData
# Exit the script with the proper exitcode.
	exit $exitCode


