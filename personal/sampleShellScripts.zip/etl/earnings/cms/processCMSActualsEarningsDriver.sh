#!/bin/bash
set -x
set -v
#------------------------------------------------------------------------------
#  File Name      : processCMSActualsEarningsDriver.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : October 12, 2006
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#------------------------------------------------------------------------------
#
#  Description    :	processCMSActualsEarningsDriver script is responsible for 
#					following tasks on first business day
#					1.	This script will check presence of CMS Actual data 
#						flat file at desired location
#					2.	If the Flat file is not available, Rechecks for its 
#						presence every Ten minutes and sends a message to
#				   		Business Support every Hour that the file is not found
#					3.	If the File is not recieved until 1900 Eastern Time,  
#						writes a token file for next day and exit.
#					4.	If data file  is present  this  script  will  call
#				   		validateCMSActualsEarnings.sh script to validate
#				   		the data file 
#					5.  On next business day the process will check for availability
#						of token file from previous day, if the token file is found 
#						then repeat above 4 steps or exit 0
#	Param 1		  : Environment
#   Param 2 	  : Bussiness Day 	
#------------------------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#------------------------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#------------------------------------------------------------------------------
#  Local configuration variables to be used in this script
#------------------------------------------------------------------------------
SHELL_SCRIPT_NAME=processCMSActualsEarningsDriver.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/cms
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl   
ACTUAL_DATA_EXTRACT_FILE_NAME=$CFG_VAR_ETL_CMS_MONTHLY_ACTUALS_FILE_NAME
VALIDATE_CMSACTUAL_SCRIPT=validateCMSActualsEarnings.sh       
LOAD_CMSACTUAL_SCRIPT=loadCMSActualsEarnings.sh  
ACTUAL_EARNINGS_TOKEN_FILE_NAME=AM_`date +%m`.DAT  
             
#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
SLEEP_TIME_INTERVAL=600
WARNING_SECONDS_INTERVAL=3600
SLEEP_COUNT_NOS=`expr $WARNING_SECONDS_INTERVAL / $SLEEP_TIME_INTERVAL + 1`

#TODO Remove the echo statement
echo "SLEEP_COUNT_NOS = $SLEEP_COUNT_NOS"

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
tokenFileExist=0
sleepCounter=0
bussinessDay=$2

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/prod/autosys/ActualsMonthly*.`date +%y%m%d`.log"
    else
       # Call batchLogger WITH the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -q"$5" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/prod/autosys/ActualsMonthly*.`date +%y%m%d`.log"
    fi
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/cms/Comm.log" \
    -c$3
}

#-------------------------------------------------------------
# Function Name : loadCMSData
# Description   : This function calls the  script to load 
#				  CMS Actual Data from Collateral Management
#				  System into earnings database 
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadCMSActualsData( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_CMS_DIR/$LOAD_CMSACTUAL_SCRIPT $ENV 
	exitCode=$?
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - CMS Actuals Earnings Load Process failed." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			 
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
    	exit 1
	fi
	exit $exitCode
}	

#-------------------------------------------------------------
# Function Name : validateCMSActualsDataFile
# Description   : This function calls the  script to validate 
#				  CMS Actual Data File , if  Data File is not
#				  valid it exits  with  exit code		
#				  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateCMSActualsDataFile( )
{
	$CFG_VAR_HUFS_PKG_SCRIPTS_CMS_DIR/$VALIDATE_CMSACTUAL_SCRIPT $ENV 
	exitCode=$?
	if [ $exitCode -ne 0 ] 
	then 
		errorMessage=" EDB - CMS Actuals Earnings Process failed Validation. The CMS Actual data file is not in valid format." 
		
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			 
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
    	exit 1
	fi	
}


#-------------------------------------------------------------
# Function Name : isFilePresent
# Description   : This function checks if the CMS Actuals Earnings Data File  exist in global1 
#				  directory,if exist it copies into destination folder to load the data.
#				  Otherwise this script send  message to GPL Workbench support every hour 
#				  for CMS Actuals Earnings file not recieved till 1900 Eastern Time.
#				  If the file is not recieved till 1900 hrs, then the script will create a 		
#				  token file to resume the CMS Calculated earnings process on next business day   
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
isFilePresent( )
{   
#-------------------------------------------------------------
#  Check to see if the CMS Actual Data file is present in 
#  work folder of global1 
#-------------------------------------------------------------
	while true
	do
		if [  `date +%H`  -lt 19 ] 
		then
			extractFileExists=`ls -alt $CFG_VAR_CMS_DATA_FILE_DIR/$ACTUAL_DATA_EXTRACT_FILE_NAME|wc|awk '{print($1)}'`
			if [ $extractFileExists -ne 1 ] 
			then 
				let "sleepCounter+=1"
				if [ $sleepCounter -eq $SLEEP_COUNT_NOS ]
				then
					sleepCounter=1
					#TODO MESSAGE TO GPLWORKBENCH SUPPORT to remind for file
				fi
				errorMessage=" EDB - WAITING FOR ACTUALS EARNINGS FILE " `date` 
				
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 
				
				sleep  $SLEEP_TIME_INTERVAL
			else
				#--------------------------------------------------------------
				# If File found then exit the search
				#--------------------------------------------------------------
				break
    	    fi  
 		#----------------------------------------------------------------------
	 	# If the file is not recieved till 1900 Eastern Time a empty file as 
	 	token needs to be created to  continue  execution  on next  bussiness day 
		#----------------------------------------------------------------------    	    		
		elif [ `date +%H` -ge 19 ]
		then
			if [ $bussinessDay -eq 1 ]
			then
				touch $CONTROL_DATA_FOLDER_NAME/$ACTUAL_EARNINGS_TOKEN_FILE_NAME
				exitCode=$?    
				if [ $exitCode -ne 0 ] 
				then
					errorMessage=" EDB - CMS Actuals Earnings Extract Process failed. Error in creating token file." 
					
					notifyChatChannel "$errorMessage" \
					$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
					$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
						 
					notifyMicromuse "$errorMessage" \
						$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
						"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
						"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            			"Token File"
			    	exit 1
				fi
				errorMessage=" EDB - CMS Actuals Earnings Extract Process did not start. CMS Actual Data file not recieved by 19:00 Hrs." 
				
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 
									 
				notifyMicromuse "$errorMessage" \
					$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
					"$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
					"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
					"Data File"

			else
				errorMessage=" EDB - CMS Actuals Earnings Extract Process Failed. CMS Actual Data file not recieved on 2nd day by 19:00 Hrs." 
				
				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

				notifyChatChannel "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
				$CFG_VAR_BATCH_LOGGER_ALERT_CHAT_CHANNEL_USER_ID 
									 
				notifyMicromuse "$errorMessage" \
					$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
					"$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
					"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
					""
		    	exit 1
			fi
		fi
	done 
	#-----------------------------------------------------------------------
	# Extract File Recieved
	#-----------------------------------------------------------------------
	if [ $extractFileExists -eq 1 ] 
	then
		#-----------------------------------------------------------------------
		#  Copy the Data file to required destination folder to load data
		#-----------------------------------------------------------------------
		cp $CFG_VAR_CMS_DATA_FILE_DIR/$ACTUAL_DATA_EXTRACT_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$ACTUAL_DATA_EXTRACT_FILE_NAME
		
		exitCode=$?    
		if [ $exitCode -ne 0 ] 
		then
			errorMessage=" EDB - CMS Actuals Earnings Extract Process failed. Error in copying the data file from $CFG_VAR_CMS_DATA_FILE_DIR folder to $DATA_EXTRACT_FOLDER_NAME folder." 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
			notifyMicromuse "$errorMessage" \
				$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
				"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
				"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
				""
	    	exit 1
		fi
	fi		                               
}

#-------------------------------------------------------------
# Function Name : checkBussinessDay
# Description   : If token File is not present on second  bussiness
#				  day of the month, the function will made the script 
#				  discontinue the execution and exits with 0 after 
#				  notifying micromuse	 			  	 	    
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
checkBussinessDay( )
{ 
	if [ $bussinessDay -eq 2 ]
	then
		tokenFileExist=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ACTUAL_EARNINGS_TOKEN_FILE_NAME|wc|awk '{print($1)}'`
		if [ $tokenFileExist -ne 1 ] 
		then  
#			notifyMicromuse " EDB - CMS Actuals Earnings Process completed successfully. Process is not required on 2nd Business Day." \
#			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR 
			exit 0	
		fi
	fi
}

#-------------------------------------------------------------
#  Main function 
#-------------------------------------------------------------
# Check If Extract File Exists
	checkBussinessDay  
# Check If Extract File Exists
	isFilePresent  
# Call validate script to check the extracted CMS Actual data
	validateCMSActualsDataFile
# Call script to load CMS Actual data
	loadCMSActualsData
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------	
	exit $exitCode


