#!/bin/bash
set -x
set -v
#------------------------------------------------------------------------------
#  File Name      : validateCMSCalculatedEarnings.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : October 17, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : John DSouza (Keane Inc.)
#  Date Revised   : Mar 8, 2007
#  Why Revised    : Modified error message in method hasDetailRecords(),
#                   and removed erroneous call to Micromuse
#
#  Last Revised   : Saurabh Gupta, Sumit Garg (Keane Inc.)
#  Date Revised   : Mar 30, 2007
#  Why Revised    : Flat file validation - enhancement to Header/Trailer 
#					validation logic modify it to case insensitive
#					Modify the date range logic - CMS flat file always 
#					contains 31 days for any month. Validation fails on months < 31. 
#
#
#------------------------------------------------------------------------------
#
#  Description    : This script validates CMS Calculated Flat  file
#                   recieved from Global one. It performs following operations
#
#                   b) Check, If CMS Calculated Data File has detail records.
#                   d) It also validates all Records for following fields
#                        1) Outstanding Loan
#                        2) Repo earnings
#                        3) Mutual fund earnings
#                        4) Durated Earnings
#                        5) Earnings Date
#
#    Param 1      : Environment
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#------------------------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=validateCMSCalculatedEarnings.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/cms
DATA_EXTRACT_FILE_NAME=$CFG_VAR_ETL_CMS_DAILY_CALCULATED_FILE_NAME

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
HEADER=Header
TRAILER=Trailer
currentMonth=`date +%m`
currentYear=`date +%Y`
# This variable will not treat blank space as a field separator
# during validation of  records
IFS=$'\t\n'

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
cms_Calculated_OUTSTANDING_LOANS=0
cms_Calculated_REPO_EARNINGS=0
cms_Calculated_MUTUAL_FUND_EARNINGS=0
cms_Calculated_DURATED_EARNINGS=0
cms_Calculated_EarningsDate=0
earningsYearMonth=0
earningsMonth=0
earningsYear=0
calculatedEarningsYear=0
calculatedEarningsMonth=0
noDigits=0
number=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){

    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/CalcDaily*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/cms/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/CalcDaily*.`date +%y%m%d`.log"
    fi
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
       -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
       -m"$1" \
       -l$2 \
       -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/cms/Comm.log" \
       -c$3
}

#-------------------------------------------------------------
# Function Name : isValidInt
# Description   : Validate integer input and doesn't allow any
#                  negative integer.
# Parameters    : String with integer value e.g. "1".
# Return        :  0 for success, 1 for failure.
#-------------------------------------------------------------
isValidInt(){
    number=$1;
    noDigits="$(echo $number | sed 's/[[:digit:]]//g')"

    if [ ! -z $noDigits ]
    then
        echo "Invalid number format! Only digits, no commas, spaces, etc."
        return 1
    fi
return 0
}

#-------------------------------------------------------------
# Function Name : isNumeric
# Description   : Validate whether a number is a valid floating
#                  point value. Note that this cannot accept
#                  scientific (1.304e5)notation.To test whether
#                  an entered value is a valid floating point
#                  number, we need to split the value at the
#                  decimal point,then test the first part to see
#                  if it's a valid integer, then the second part
#                  to see if it's a  valid >=0 integer, doesn't
#                  allow any negative  values
# Parameters    : String with integer value e.g. "1".
# Return        : 0 for success, 1 for failure.
#-------------------------------------------------------------
isNumeric(){
      fvalue="$1"
    decimalPart="$(echo $fvalue | cut -d. -f1)"
    fractionalPart="$(echo $fvalue | cut -d. -f2)"

    if [ ! -z $decimalPart ]
    then
        isValidInt $decimalPart
        if  [ $? -eq 1 ]
        then
              return 1
        fi
    fi

    if [ "$fractionalPart" != "" ]
    then
        isValidInt $fractionalPart
        if  [ $? -eq 1 ]
        then
              return 1
        fi
    fi
return 0
}

#-------------------------------------------------------------
# Function Name : isDateRangeValid
# Description   : Valid date range will check if the date
#                  in the CMS Calculated data file is valid or not.
#                  Parameter will be in CCyymm format  representing
#                  year and month , this method will  check whether
#                  parameter is representing  previous month or
#                  not for e.x it will check  if parameter is
#                   200602 (feb. 2006) if current month is march
#                  2006, it will check  if parameter is 200512( Dec. 2005 )
#                  if current month is january 2006
#
# Parameters    : String with integer value e.g. "200608"
# Return        :0 for success, 1 for failure.
#-------------------------------------------------------------

isDateRangeValid(){
    earningsYearMonth="$1"
    earningsMonth=`echo $earningsYearMonth | cut -c5-6`
    earningsYear=`echo $earningsYearMonth | cut -c1-4`

    if [ $currentMonth  -ne 01 ]
    then
        calculatedEarningsYear=$currentYear
        calculatedEarningsMonth=`expr $currentMonth - 1`

    elif [ $currentMonth  -eq 01 ]
    then
        calculatedEarningsYear=`expr $currentYear - 1`
        calculatedEarningsMonth=12
    fi
    if [ $earningsMonth -lt $calculatedEarningsMonth ] || [ $earningsYear -lt $calculatedEarningsYear ]
    then
        return 1
    fi
return 0
}

#-------------------------------------------------------------
# Function Name : validateRecords
# Description   : Validate various fields among all detail
#                  records from CMS Calculated Data file,checks
#                  whether CMS Calculated Data file  contains
#                  Header and Footer.Skip the first record as
#                  1st record is having header data.
#                  Various tested Fields are
#                        1) Repo earnings
#                        2) Mutual fund earnings
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateRecords ()
{
    if [ "$HEADER"  != $"`head -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME`" ]   || [  "$TRAILER"  != $"`tail -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME`" ]
    then
            errorMessage=" EDB - Invalid CMS Calculated Data file. Header or Footer missing from the required File Format."
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

             notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                "Header/Footer"

            exit 1
    fi
    exec 3<$DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME
    while read  CMSCALCULATEDDATA <&3
    do
    if [ "$CMSCALCULATEDDATA" != "$HEADER" ] &&  [ "$CMSCALCULATEDDATA"  != $TRAILER  ] && [ ! -z "$CMSCALCULATEDDATA"  ]
        then
            cms_Calculated_OUTSTANDING_LOANS=`echo $CMSCALCULATEDDATA | cut -c28-51`
            cms_Calculated_REPO_EARNINGS=`echo $CMSCALCULATEDDATA | cut -c52-75`
            cms_Calculated_MUTUAL_FUND_EARNINGS=`echo $CMSCALCULATEDDATA | cut -c76-99`
            cms_Calculated_DURATED_EARNINGS=`echo $CMSCALCULATEDDATA | cut -c100-123`
            cms_Calculated_EarningsDate=`echo $CMSCALCULATEDDATA | cut -c20-27`

            # remove leading white spaces and  trailing white spaces
            cms_Calculated_OUTSTANDING_LOANS="$(echo $cms_Calculated_OUTSTANDING_LOANS | sed 's/^[     ]*//' | sed 's/[     ]*$//')"
            cms_Calculated_REPO_EARNINGS="$(echo $cms_Calculated_REPO_EARNINGS | sed 's/^[     ]*//' | sed 's/[     ]*$//')"
            cms_Calculated_MUTUAL_FUND_EARNINGS="$(echo $cms_Calculated_MUTUAL_FUND_EARNINGS | sed 's/^[     ]*//' | sed 's/[     ]*$//')"
            cms_Calculated_DURATED_EARNINGS="$(echo $cms_Calculated_DURATED_EARNINGS | sed 's/^[     ]*//' | sed 's/[     ]*$//')"
            cms_Calculated_EarningsDate="$(echo $cms_Calculated_EarningsDate | sed 's/^[     ]*//' | sed 's/[     ]*$//')"

			# Remove -ve sign from the value if available before validation. -ve values/earnings are acceptable
			cms_Calculated_OUTSTANDING_LOANS="$(echo $cms_Calculated_OUTSTANDING_LOANS | sed 's/-//g')"
			cms_Calculated_REPO_EARNINGS="$(echo $cms_Calculated_REPO_EARNINGS | sed 's/-//g')"
			cms_Calculated_MUTUAL_FUND_EARNINGS="$(echo $cms_Calculated_MUTUAL_FUND_EARNINGS | sed 's/-//g')"
			cms_Calculated_DURATED_EARNINGS="$(echo $cms_Calculated_DURATED_EARNINGS | sed 's/-//g')"


            #-------------------------------------------------------------------------
            #    Check outstanding Loans  for Numeric Value
            #-------------------------------------------------------------------------
            isNumeric $cms_Calculated_OUTSTANDING_LOANS
            exitCode=$?
            if [ $exitCode != 0 ]
            then
                echo "RECORD NO. $i -- INVALID OUTSTANDING LOANS FIELD : " $cms_Calculated_OUTSTANDING_LOANS
                errorMessage=" EDB - CMS Calculated Data Failed validation. Outstanding Loans field is not numeric."
                notifyChatChannel "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

                notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "Outstanding Loans"

              exit 1
            fi

            #-------------------------------------------------------------------------
            #    Check Repo earnings  for Numeric Value
            #-------------------------------------------------------------------------
            isNumeric $cms_Calculated_REPO_EARNINGS
            exitCode=$?
            if [ $exitCode != 0 ]
            then
                echo "RECORD NO. $i -- INVALID REPO EARNINGS FIELD : " $cms_Calculated_REPO_EARNINGS
                errorMessage=" EDB - CMS Calculated Data Failed validation. Repo Earnings field is not numeric."
                notifyChatChannel "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

                notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "Repo Earnings"

                exit 1
            fi

            #-------------------------------------------------------------------------
            #    Check Mutual fund earnings  for Numeric Value
            #-------------------------------------------------------------------------
            isNumeric $cms_Calculated_MUTUAL_FUND_EARNINGS
            exitCode=$?
            if  [ $exitCode != 0 ]
            then
                echo "RECORD NO. $i -- INVALID MUTUAL FUND EARNINGS FIELD."
                errorMessage=" EDB - CMS Calculated Data Failed validation. Mutual Fund Earnings field is not numeric."
                notifyChatChannel "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

                notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "MF Earnings"

                exit 1
            fi

            #-------------------------------------------------------------------------
            #    Check Durated earnings  for Numeric Value
            #-------------------------------------------------------------------------
            isNumeric $cms_Calculated_DURATED_EARNINGS
            exitCode=$?
            if  [ $exitCode != 0 ]
            then
                echo "RECORD NO. $i -- INVALID DURATED EARNINGS FIELD."
                errorMessage=" EDB - CMS Calculated Data Failed validation. Durated Earnings field is not numeric."
                notifyChatChannel "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

                notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "Durated Earnings"

                exit 1
            fi

            #-------------------------------------------------------------------------
            #    validate Earnings Date
            #-------------------------------------------------------------------------
            isDateRangeValid $cms_Calculated_EarningsDate
            exitCode=$?
            if  [ $exitCode != 0 ]
            then
                echo "RECORD NO. $i -- INVALID EARNINGS DATE ."
                errorMessage=" EDB - CMS Calculated Data Failed validation. Earnings Date field is not numeric."
                notifyChatChannel "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

                notifyMicromuse "$errorMessage" \
                    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                    "Earnings Date"

                exit 1
            fi
        fi
    done
}

#-------------------------------------------------------------
# Function Name : hasDetailRecords
# Description   : This function check if the CMS Calculated data
#                  has at least 1 detail record to upload the data.
#                 a) The number of row in the extract are more than "2"
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
hasDetailRecords () {

    if [ `cat $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | wc -l` -le 2 ]
    then
        errorMessage=" EDB - CMS Calculated Data Failed validation. CMS Calculated Extract file does not have any detail records."

        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""

        exit 1
    fi
}

#-------------------------------------------------------------
# Main function to validate the CMS Calculated data file for all records
#-------------------------------------------------------------
# Check If CMS Calculated data file has detail records
hasDetailRecords

# Validate all  Records for various fields
validateRecords

# Exit the script with the proper exitcode.
exit $exitCode

