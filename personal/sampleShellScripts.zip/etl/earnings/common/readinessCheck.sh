#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : readinesscheck.sh
#  Author         : Geetika Nim
#  Date Created   : July 15, 2006
#
#  Last Revised   : Sumit Garg (Keane Inc.)
#  Date Revised   : Mar 09, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Saurabh Gupta (Keane Inc.)
#  Date Revised   : Mar 30, 2007
#  Why Revised    : Added new code for graceful exit when ME 
#					job is not required.
#-------------------------------------------------------------
#-------------------------------------------------------------
#
#  Description    : This script checks the approval with
#		    		the help of Java class for Full Run 
#					& Month End Run. Once the approval is
#					available and there is no holiday for
#					current date following files are generated.
#					Full Run 	: Finder Fee Control File
#								: Fund Earnings Control File
#								: Month End Trigger File
#					Month End	: Finder Fee Control File
#								: Fund Earnings Control File
#					No approval / holiday check required 
#					for Non Cash Run
#					Non Cash 	: Fund Earnings Control File
#
#                   Some common abbreviations used is in this
#                   script are as follows:
#                   FR = Full Run
#                   ME = Month-End Run
#					NC = Non Cash Run
#	Param 1		  : Environment
#	Param 2		  : Run Type
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg 		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=readinesscheck.sh
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
runDate=`date '+%y%m%d'`                  
CONTROL_FILE_FR_FF=FR_FF_$runDate.DAT
CONTROL_FILE_FR_FE=FR_FE_$runDate.DAT
CONTROL_FILE_ME_FF=ME_FF_$runDate.DAT
CONTROL_FILE_ME_FE=ME_FE_$runDate.DAT
#added  by  sumit 
CONTROL_FILE_NC_FE=NC_FE_$runDate.DAT 
ME_TRIGGER_FILE_NAME=ME_FLAG_$runDate.DAT

LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.common.ReadinessCheckAction
BUSINESS_ENTITY=earnings/readinesscheck

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
RUNTYPE=$2	
batchContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Batch.log"
autosysContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_ReadyCh*"

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Comm.log" \
    -c$3
}
	
#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
FFcontrolFileExists=0
FEcontrolFileExists=0
MEtriggerFileExists=0 

#---------------------------------------------------------------------------------
#	Checking if the control file already exists in the destination folder then 
#	Readiness check is already done for Full Run else run the BatchRunner to 
#	execute the ReadinessCheck process.
#---------------------------------------------------------------------------------
if [ $RUNTYPE = FR ]
then
	FFcontrolFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CONTROL_FILE_FR_FF|wc|awk '{print($1)}'`
	FEcontrolFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CONTROL_FILE_FR_FE|wc|awk '{print($1)}'`
	
	if [[ "$FFcontrolFileExists" -ne "1" || "$FEcontrolFileExists" -ne "1" ]]
	then
		$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
		$ENV \
		$LOAD_ACTION_CLASS_NAME \
		$BUSINESS_ENTITY \
		$RUNTYPE		

		exitCode=$?
		if [ $exitCode -ne 0 ]
		then 
		    errorMessage=" EDB - Full Run Readiness Check process failed."
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

		    #-------------------------------------------------------------
		    #  Notify Micromuse that the there is some problem with the Full Run Readiness Check 
		    #-------------------------------------------------------------
		   $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
			-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
			-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
			-e$ENV \
			-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
			-k$SHELL_SCRIPT_NAME \
			-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			-m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
			-q"Full Run" \
			-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
			-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/common/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Batch.log"
		   

		fi		    
		exit $exitCode
	#---------------------------------------------------------------------------
	#	If Control files are already available, exit successfully	
	#---------------------------------------------------------------------------
	else
		exit $exitCode
	fi
#---------------------------------------------------------------------------------
#	Checking if the control file already exists in the destination folder then 
#	Readiness check is already done for Non Cash else run the BatchRunner to 
#	execute the ReadinessCheck process.
#---------------------------------------------------------------------------------
elif [ $RUNTYPE = NC ]
	then 
	FEcontrolFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CONTROL_FILE_NC_FE|wc|awk '{print($1)}'` 
	if [ $FEcontrolFileExists -ne 1 ]
    then 
        $CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
		$ENV \
		$LOAD_ACTION_CLASS_NAME \
		$BUSINESS_ENTITY  \
		$RUNTYPE
			
		exitCode=$?
		if [ $exitCode -ne 0 ]
		then 
		    errorMessage=" EDB - Non Cash Readiness Check process failed."
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

		    #-------------------------------------------------------------
		    #  Notify Micromuse that the there is some problem with the Non Cash ReadinessCheck 
		    #-------------------------------------------------------------
		    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
				-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
				-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
				-e$ENV \
				-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
				-k$SHELL_SCRIPT_NAME \
				-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
				-m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
				-q"Non Cash" \
				-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
				-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/common/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Batch.log"
			

		fi
		exit $exitCode
	#---------------------------------------------------------------------------
	#	If Control files are already available, exit successfully	
	#---------------------------------------------------------------------------
	else
		exit $exitCode
	fi
#---------------------------------------------------------------------------------
#	Checking if the control file already exists in the destination folder then 
#	Readiness check is already done for Month End else run the BatchRunner to 
#	execute the ReadinessCheck process.
#---------------------------------------------------------------------------------	
elif [ $RUNTYPE = ME ]
then
	FFcontrolFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CONTROL_FILE_ME_FF|wc|awk '{print($1)}'`
	FEcontrolFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$CONTROL_FILE_ME_FE|wc|awk '{print($1)}'`
	MEtriggerFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_TRIGGER_FILE_NAME|wc|awk '{print($1)}'`
	
	#------------------------------------------------------------------------------
	#	If Trigger file is not available then ME run is not required. Exit with 0
	#------------------------------------------------------------------------------
	if [ $MEtriggerFileExists -ne 1 ]
	then
	    exit 0
	elif [ $FFcontrolFileExists -ne 1 ] || [ $FEcontrolFileExists -ne 1 ]
	then
		$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
		$ENV \
		$LOAD_ACTION_CLASS_NAME \
		$BUSINESS_ENTITY  \
		$RUNTYPE
			
		exitCode=$?
		if [ $exitCode -ne 0 ]
		then 
		    errorMessage=" EDB - Error in Month End Readiness Check process."
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

		    #-------------------------------------------------------------
		    #  Notify Micromuse that the there is some problem with the Month End ReadinessCheck 
		    #-------------------------------------------------------------
		   $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		   	-a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
		   	-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		   	-e$ENV \
		   	-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		   	-k$SHELL_SCRIPT_NAME \
		   	-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		   	-m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		   	-q"Month End" \
		   	-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		   	-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/common/$SHELL_SCRIPT_NAME.  Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Batch.log"

		fi
		exit $exitCode		
	#---------------------------------------------------------------------------
	#	If Control files are already available, exit successfully	
	#---------------------------------------------------------------------------
	else
		exit $exitCode
	fi
fi
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode


