#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#    File Name     : CleanupExtract.sh
#    Author        : Saurabh Gupta (Keane Inc.)
#    Date Created  :    September 05, 2006
#    Last Revised  : September 25, 2006     
#
#   Last Revised   : Abhishek Sharma (Keane Inc.)
#   Date Revised   : Mar 9, 2007
#   Why Revised    : Added new parameters to the micromuse notification
#                    script for de-duplication feature.
#    
#-------------------------------------------------------------
#   Description    : This scriptis for the cleanup of the data
#                    files and control files after successful 
#                    load of the box and move them to respective
#                    Archive Folders.
#                    Some common abbreviations used is in this
#                    script are as follows:
#                    FR = Full Run
#                    ME = Month-End Run
#                    NC = Non Cash
#   Param 1          : Environment
#   Param 2          : Run Type
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg                    

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
runType=$2

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=CleanupExtract.sh
DATA_FOLDER_NAME_FF=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/findersfee
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
DATA_FOLDER_NAME_FE=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/fundearnings
DATA_FILE_NAME_FF=FINDERFEE.DAT
DATA_FILE_NAME_FE=FUNDEARNINGS.DAT
FR_FF_CONTROL_FILE_NAME=FR_FF_`date +%y%m%d`.DAT
ME_FF_CONTROL_FILE_NAME=ME_FF_`date +%y%m%d`.DAT
ME_FE_CONTROL_FILE_NAME=ME_FE_`date +%y%m%d`.DAT
FR_FE_CONTROL_FILE_NAME=FR_FE_`date +%y%m%d`.DAT
NC_FE_CONTROL_FILE_NAME=NC_FE_`date +%y%m%d`.DAT
ME_FLAG_TRIGGER_FILE=ME_FLAG_`date +%y%m%d`.DAT
ARCHIVE_FE_DATA_FILE_NAME=FE_`date +%y%m%d`_$runType.DAT
ARCHIVE_FF_DATA_FILE_NAME=FF_`date +%y%m%d`_$runType.DAT
DATA_ARCHIVE_FOLDER_NAME_FF=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/findersfee
DATA_ARCHIVE_FOLDER_NAME_FE=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/fundearnings
DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/controletl

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.The function does not 
#                  abort the code and continues to copy all files
# Parameters    : Error Message, Severity
# Return        : None
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
       # Call batchLogger WITHOUT the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/common/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$runType"_Cleanup*.`date +%y%m%d`.log"
    else
       # Call batchLogger WITH the -q flag
       $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
           -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
           -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
           -e$ENV \
           -g"$4" \
           -k$SHELL_SCRIPT_NAME \
           -l$2 \
           -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
           -q"$5" \
           -t"$3" \
           -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/common/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$runType"_Cleanup*.`date +%y%m%d`.log"
    fi
} 


#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
       -e$ENV \
       -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
       -m"$1" \
       -l$2 \
       -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/common/Comm.log" \
       -c$3
}

#-------------------------------------------------------------
#      Move the Finder Fee & Fund Earnings data files to respective ARCHIVE Folders
#-------------------------------------------------------------

fileExists=`ls -alt $DATA_FOLDER_NAME_FF/$DATA_FILE_NAME_FF|wc|awk '{print($1)}'`
if [ $fileExists -eq 1 ]
then
    mv $DATA_FOLDER_NAME_FF/$DATA_FILE_NAME_FF $DATA_ARCHIVE_FOLDER_NAME_FF/$ARCHIVE_FF_DATA_FILE_NAME
    exitCode=$?
    if [ $exitCode -ne 0 ]
    then        
    
        errorMessage=" EDB - Error occured while archiving $DATA_FOLDER_NAME_FF/$DATA_FILE_NAME_FF to $DATA_ARCHIVE_FOLDER_NAME_FF/$ARCHIVE_FF_DATA_FILE_NAME."
    
        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
             
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            "Archive FF Data"
    fi    
fi    

fileExists=`ls -alt $DATA_FOLDER_NAME_FE/$DATA_FILE_NAME_FE|wc|awk '{print($1)}'`
if [ $fileExists -eq 1 ]
then
       mv $DATA_FOLDER_NAME_FE/$DATA_FILE_NAME_FE $DATA_ARCHIVE_FOLDER_NAME_FE/$ARCHIVE_FE_DATA_FILE_NAME
       exitCode=$?
    if [ $exitCode -ne 0 ]
    then        
        errorMessage=" EDB - Error occured while archiving $DATA_FOLDER_NAME_FE/$DATA_FILE_NAME_FE to $DATA_ARCHIVE_FOLDER_NAME_FE/$ARCHIVE_FE_DATA_FILE_NAME." 
        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
             
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            "Archive FE Data"
    fi    
fi

#-------------------------------------------------------------
#      Move the Full Run Control Files to respective ARCHIVE Folders
#-------------------------------------------------------------
if [ $runType = "FR" ]
then
      fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$FR_FF_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
      if [ $fileExists -eq 1 ]
      then  
          mv $CONTROL_DATA_FOLDER_NAME/$FR_FF_CONTROL_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$FR_FF_CONTROL_FILE_NAME
        exitCode=$?
        if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$FR_FF_CONTROL_FILE_NAME to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$FR_FF_CONTROL_FILE_NAME." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive FR Data"
        fi    
    fi
    
     fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$FR_FE_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
      if [ $fileExists -eq 1 ]
      then 
          mv $CONTROL_DATA_FOLDER_NAME/$FR_FE_CONTROL_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$FR_FE_CONTROL_FILE_NAME
        exitCode=$?
        if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$FR_FE_CONTROL_FILE_NAME to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$FR_FE_CONTROL_FILE_NAME." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
            
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive FR FE Control File"
        fi    
    fi
 
#-------------------------------------------------------------
#      Move the Month End Run Control Files to respective ARCHIVE Folders
#-------------------------------------------------------------
elif [ $runType = "ME" ]
then
       fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_FF_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
    if [ $fileExists -eq 1 ]
      then 
         mv $CONTROL_DATA_FOLDER_NAME/$ME_FF_CONTROL_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FF_CONTROL_FILE_NAME
          exitCode=$?
        if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$ME_FF_CONTROL_FILE_NAME to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FF_CONTROL_FILE_NAME." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
            
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive ME FF Control File"
        fi    
      fi
    
    fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_FE_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
    if [ $fileExists -eq 1 ]
    then 
        mv $CONTROL_DATA_FOLDER_NAME/$ME_FE_CONTROL_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FE_CONTROL_FILE_NAME
          exitCode=$?
        if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$ME_FE_CONTROL_FILE_NAME to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FE_CONTROL_FILE_NAME." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
            
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive ME FE Control File"
        fi    
    fi

     fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_FLAG_TRIGGER_FILE|wc|awk '{print($1)}'`
      if [ $fileExists -eq 1 ]
      then 
          mv $CONTROL_DATA_FOLDER_NAME/$ME_FLAG_TRIGGER_FILE $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FLAG_TRIGGER_FILE
        exitCode=$?
        if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$ME_FLAG_TRIGGER_FILE to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$ME_FLAG_TRIGGER_FILE." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
            
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive ME Flag Control File"
        fi    
    fi

#-------------------------------------------------------------
#  Move the Non Cash Run Control File to respective ARCHIVE Folders
#-------------------------------------------------------------
elif [ $runType = "NC" ]
then
      fileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$NC_FE_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
     if [ $fileExists -eq 1 ]
      then
        mv $CONTROL_DATA_FOLDER_NAME/$NC_FE_CONTROL_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$NC_FE_CONTROL_FILE_NAME
          exitCode=$?
          if [ $exitCode -ne 0 ]
        then        
            errorMessage=" EDB - Error occured while archiving $CONTROL_DATA_FOLDER_NAME/$NC_FE_CONTROL_FILE_NAME to $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$NC_FE_CONTROL_FILE_NAME." 
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
            
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "Archive NC FE Control File"
        fi    
    fi
fi

exitCode=$?
if [ $exitCode -eq 0 ]
then
    successMessage=" EDB - $runType: Cleanup completed successfully."

    notifyChatChannel "$successMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_WARN \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode


