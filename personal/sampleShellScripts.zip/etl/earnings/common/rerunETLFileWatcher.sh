#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : 	rerunETLFileWatcher.sh
#  Author         : 	Saurabh Gupta
#  Date Created   : 	January 16, 2007
#  Last Revised   :		
#-------------------------------------------------------------
#
#  Description    : This script invoked by autosys job
#					every 10 minutes and checks for the availability 
#					of respective trigger file in case of any rerun 
#					is required. This will invoke all the required shell 
#					script one by one in the desired order.
#                   Some common abbreviations used is in this
#                   script are as follows:
#                   FR = Full Run
#                   ME = Month-End Run
#	Param 1		  : Environment
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg 		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=rerunETLFileWatcher.sh
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/controletl
ETL_CLEANUP_SCRIPT=cleanupExtract.sh
ETL_ROLLBACK_SCRIPT=rollbackLoad.sh
ETL_READINESSCHECK_SCRIPT=readinessCheck.sh
ETL_FF_EXTRACT_SCRIPT=extractFinderFeeDriver.sh
ETL_FF_LOAD_SCRIPT=loadFinderFee.sh
ETL_FE_EXTRACT_SCRIPT=extractFundEarningsDriver.sh
ETL_FE_LOAD_SCRIPT=loadFundEarnings.sh
ETL_FA_LOAD_SCRIPT=loadFundAccrual.sh
runDate=`date '+%Y%m%d'`                  
TRIGGER_FILE_FR=FR_RR_$runDate.trg
TRIGGER_FILE_ME=ME_RR_$runDate.trg
ME_TRIGGER_FILE_NAME=ME_FLAG_`date '+%y%m%d'`.DAT

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
RUNTYPE=0	
	
#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
FR_RerunFileExists=0
ME_RerunFileExists=0 

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){
	errorMessage=$1
    $CFG_VAR_HUFS_PKG_SCRIPTS_LOGGING_DIR/$CFG_VAR_MICROMUSE_SCRIPT \
   	-p$SHELL_SCRIPT_NAME \
   	-s$2 \
   	-m$SHELL_SCRIPT_NAME"$errorMessage" \
	-c"Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_rerunETLWatchOut"\
    $ENV
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/readinesscheck/Comm.log" \
    -c$3
}

#---------------------------------------------------------------------------------
#	Checking if the control file already exists in the destination folder then 
#	Readiness check is already done for Full Run else run the BatchRunner to 
#	execute the ReadinessCheck process.
#---------------------------------------------------------------------------------
FR_RerunFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_FR|wc|awk '{print($1)}'`
ME_RerunFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_ME|wc|awk '{print($1)}'`

echo ' Invoked by ETL Rerun File Watcher '

if [ "$FR_RerunFileExists" -eq "1" ]
then
	RUNTYPE=FR

	notifyChatChannel " EDB: Rerun Started for Full Run " \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_INFO \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
	mv $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_FR $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$TRIGGER_FILE_FR
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		notifyMicromuse  " EDB: Error occured while moving trigger file $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_FR to archive folder." \
		$CFG_VAR_MM_SEVERITY_AMBER 
		
		exitCode=0
	fi	

	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the cleanup script to remove all data files and control files
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_CLEANUP_SCRIPT \
		$ENV \
		$RUNTYPE 
	
		exitCode=$?
	fi
			
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the rollback script to remove all recently loaded data from the database
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_ROLLBACK_SCRIPT \
		$ENV \
		$RUNTYPE 
	
		exitCode=$?
		if [ $exitCode -ne 0 ]
		then	    
			notifyMicromuse  "- ROLLBACK NOT REQUIRED for $RUNTYPE." \
			$CFG_VAR_MM_SEVERITY_AMBER 
		fi
		exitCode=0
	fi	

	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the ReadinessCheck script to check for the approval of rates
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_READINESSCHECK_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
			
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Finder Fee Extract from Gosos
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FINDERFEE_DIR/$ETL_FF_EXTRACT_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
			
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Finder Fee Load script to load the data extracted from gosos interface
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FINDERFEE_DIR/$ETL_FF_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
		
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Earnings Extract from Gosos
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDEARNINGS_DIR/$ETL_FE_EXTRACT_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
		
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Earnings Load script to load the data extracted from gosos interface
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDEARNINGS_DIR/$ETL_FE_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
		
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Accruals Load script to summarize and load fund earnings
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDACCRUAL_DIR/$ETL_FA_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the cleanup script to remove all data files and control files
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_CLEANUP_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
	
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB: Error occured during Rerun - Full Run. Please check the appropriate logs."

		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
		notifyMicromuse  "$errorMessage" \
		$CFG_VAR_MM_SEVERITY_RED 

		exit1
	fi	
	
fi

#---------------------------------------------------------------------------------
#	Checking if the control file already exists in the destination folder then 
#	Readiness check is already done for Non Cash else run the BatchRunner to 
#	execute the ReadinessCheck process.
#---------------------------------------------------------------------------------
if [ "$ME_RerunFileExists" -eq "1" ]
then
	RUNTYPE=ME
	
	notifyChatChannel " EDB: Rerun Started for Month End Run " \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_INFO \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
	mv $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_FR $DATA_ARCHIVE_FOLDER_NAME_CONTROLFILE/$TRIGGER_FILE_ME
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		notifyMicromuse  " EDB: Error occured while moving trigger file $CONTROL_DATA_FOLDER_NAME/$TRIGGER_FILE_ME to archive folder." \
		$CFG_VAR_MM_SEVERITY_AMBER 
	fi	

	#--------------------------------------------------------------------------
	# Run the cleanup script to remove all data files and control files
	#--------------------------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_CLEANUP_SCRIPT \
	$ENV \
	$RUNTYPE 
	
	exitCode=$?
	
	#--------------------------------------------------------------------------
	# Run the rollback script to remove all recently loaded data from the database
	#--------------------------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_ROLLBACK_SCRIPT \
	$ENV \
	$RUNTYPE 
	
	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		notifyMicromuse  "- ROLLBACK NOT REQUIRED for $RUNTYPE." \
		$CFG_VAR_MM_SEVERITY_AMBER 
		
		exitCode=0
	fi
	
	#--------------------------------------------------------------------------
	# Create the month end trigger file to proceed with readiness check
	#--------------------------------------------------------------------------
	touch $CONTROL_DATA_FOLDER_NAME/$ME_TRIGGER_FILE_NAME
	exitCode=$?
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the ReadinessCheck script to check for the approval of rates
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_READINESSCHECK_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Finder Fee Extract from Gosos
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FINDERFEE_DIR/$ETL_FF_EXTRACT_SCRIPT \
		$ENV \
		$RUNTYPE 
			
		exitCode=$?
	fi
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Finder Fee Load script to load the data extracted from gosos interface
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FINDERFEE_DIR/$ETL_FF_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Earnings Extract from Gosos
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDEARNINGS_DIR/$ETL_FE_EXTRACT_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
		
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Earnings Load script to load the data extracted from gosos interface
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDEARNINGS_DIR/$ETL_FE_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the Fund Accruals Load script to summarize and load fund earnings
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDACCRUAL_DIR/$ETL_FA_LOAD_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi	
	
	if [ $exitCode -eq 0 ]
	then	
		#--------------------------------------------------------------------------
		# Run the cleanup script to remove all data files and control files
		#--------------------------------------------------------------------------
		$CFG_VAR_HUFS_PKG_SCRIPTS_EARNINGS_COMMON_DIR/$ETL_CLEANUP_SCRIPT \
		$ENV \
		$RUNTYPE 
		
		exitCode=$?
	fi
	
	if [ $exitCode -ne 0 ]
	then	    
		errorMessage=" EDB: Error occured during Rerun - Month End Run. Please check the appropriate logs."

		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
		notifyMicromuse  "$errorMessage" \
		$CFG_VAR_MM_SEVERITY_RED 
		
		exit1
	fi	
	
fi
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode


