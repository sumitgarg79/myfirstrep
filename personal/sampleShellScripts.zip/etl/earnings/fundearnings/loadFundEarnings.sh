#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loadFundEarnings.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : July 17, 2006
#  Last Revised   : October 03, 2006    
#
#  Last Revised   : Kunal Aggarwal (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Saurabh Gupta (Keane Inc.)
#  Date Revised   : Mar 30, 2007
#  Why Revised    : Added new code for graceful exit when ME 
#					job is not required.
#
#  Last Revised   : Saurabh Gupta (Keane Inc.)
#  Date Revised   : May 30, 2007
#  Why Revised    : Added new code for load of Returned Fund 
#					Earnings when FR in progress 
#-------------------------------------------------------------
#-------------------------------------------------------------
#
#  Description    : This script loads the FundEarnings data 
#                   from the GOSOS Extract file into the 
#                   in the GPL Workbench Database
#   Param 1       : Environment
#   Param 2       : Run Type
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg                 

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=loadFundEarnings.sh
DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/fundearnings
DATA_FILE_NAME=FUNDEARNINGS.DAT
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.fundearnings.LoadFundEarningsAction
LOAD_RETURNED_EARNINGS_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.fundearnings.ProcessReturnedFundEarningsAction
BUSINESS_ENTITY=earnings/fundearnings
RUNTYPE=$2 
batchContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Batch.log"
autosysContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnLoad"
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
ME_TRIGGER_FILE_NAME=ME_FLAG_`date +%y%m%d`.DAT

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
        -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
        -m"$1" \
        -l$2 \
        -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Comm.log" \
        -c$3
}

if [ $RUNTYPE = "ME" ]
then
#------------------------------------------------------------------------------
#	If Trigger file is not available then ME run is not required. Exit with 0
#------------------------------------------------------------------------------
	triggerFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_TRIGGER_FILE_NAME|wc|awk '{print($1)}'`
	if [ $triggerFileExists -ne 1 ] 
	then
    	exit 0
	fi
fi

#-------------------------------------------------------------
#   Check to see if the Fund Earnings Extract from GOSOS 
#   interface is available for load
#-------------------------------------------------------------
extractFileExists=`ls -alt $DATA_FOLDER_NAME/$DATA_FILE_NAME |wc|awk '{print($1)}'`
if [ $extractFileExists -ne 1 ] 
then  
    errorMessage=" EDB - Error in the Load Fund Earnings Process. Extract File not available for Upload."

    notifyChatChannel "$errorMessage" \
    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the extract 
    #-------------------------------------------------------------
     
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
         -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
         -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
         -e$ENV \
         -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
         -k$SHELL_SCRIPT_NAME \
         -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
         -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
         -t"$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
         -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnLoad*.`date +%y%m%d`.log"
     
    exit 1
fi


#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Fund Earnings Load process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY \
    $RUNTYPE
    
exitCode=$?
         
if [ $exitCode -ne 0 ]
then
    errorMessage=" EDB - Error in the Load Fund Earnings Process."


    notifyChatChannel "$errorMessage" \
    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the load 
    #-------------------------------------------------------------
    
    
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
                -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
                -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
                -e$ENV \
                -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                -k$SHELL_SCRIPT_NAME \
                -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
                -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
                -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Batch.log"
  
    exit 1
fi

if [ $RUNTYPE = "FR" ]
then
	#----------------------------------------------------------
	#  Call the generic Batch Runner script with the appropriate
	#  parameters to start the Load of Returned Fund Earnings 
	#  during Full Run Load process.
	#----------------------------------------------------------
	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
	    $ENV \
	    $LOAD_RETURNED_EARNINGS_ACTION_CLASS_NAME \
	    $BUSINESS_ENTITY \
	    $RUNTYPE
	    
	exitCode=$?
	         
	if [ $exitCode -ne 0 ]
	then
	    errorMessage=" EDB - Error in the Load Process for Returned Fund Earnings."
	
	
	    notifyChatChannel "$errorMessage" \
	    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	    $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
	    #-------------------------------------------------------------
	    #  Notify Micromuse that the there is some problem with the load 
	    #-------------------------------------------------------------
	    
	    
	     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
	                -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
	                -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
	                -e$ENV \
	                -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
	                -k$SHELL_SCRIPT_NAME \
	                -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	                -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
	                -t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
	                -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Batch.log"
	  
	    exit 1
	fi
fi


#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode