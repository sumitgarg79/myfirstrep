#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : extractFundEarningsDriver.sh
#  Author         : Geetika Nim (Keane Inc.)
#  Date Created   : July 17, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Saurabh Gupta (Keane Inc.)
#  Date Revised   : Mar 30, 2007
#  Why Revised    : Added new code for graceful exit when ME 
#					job is not required.
#-------------------------------------------------------------
#
#  Description    : This script extracts Fund Earnings data   
#                   used from Global One to be further used in
#                   processing Fund Earnings and Distributions,
#                   within GPL Workbench. If the extract is 
#                   successful, this script additionally invokes
#                   another script to validate the extracted data
#                   for data sufficiency.
#
#                   Some common abbreviations used is in this
#                   script are as follows:
#                   FR = Full Run
#                   ME = Month-End Run
#					NC = Non Cash Run
#	Param 1		  : Environment
#	Param 2		  : Run Type
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------

SHELL_SCRIPT_NAME=extractFundEarningsDriver.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/fundearnings
IOFILES_DATA_FILE_NAME=FUNDEARNINGS.DAT
#IOFILES_DATA_FILE_NAME=FE`date +%m%d`*
DATA_EXTRACT_FILE_NAME=FUNDEARNINGS.DAT

CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
FR_CONTROL_FILE_NAME=FR_FE_`date +%y%m%d`.DAT
ME_CONTROL_FILE_NAME=ME_FE_`date +%y%m%d`.DAT
ME_TRIGGER_FILE_NAME=ME_FLAG_`date +%y%m%d`.DAT
NC_CONTROL_FILE_NAME=NC_FE_`date +%y%m%d`.DAT
VALIDATE_FUNDEARNINGS_EXTRACT_SCRIPT=validateFundEarningsExtract.sh

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
RUNTYPE=$2						
currdate=`date +%y%m%d`						
extractName=FUNDEARNFEX

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
controlFileExists=0
triggerFileExists=0
extractFileExists=0
runFlag=0
fromDate=`date %m%d`
fromYear=`date %Y`
toDate=`date %m%d`
toYear=`date %Y`
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code
#-------------------------------------------------------------
notifyMicromuse(){
    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnExtr*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnExtr*.`date +%y%m%d`.log"
    fi
} 

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Comm.log" \
    -c$3
}


#-------------------------------------------------------------
#	Check to see if the control file for the Full, Month-End
#   Run or Non Cash Run are present and set the exists flag to Y,
# 	else End the FundEarnings extract process
#-------------------------------------------------------------
if [ $RUNTYPE = "FR" ]
then
	controlFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
	if [ $controlFileExists -ne 1 ] 
	then 
        errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Full Run Control File does not exist."
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "FR Control File"    

	 	exit 1
	else
		#------------------------------------------------------------------------------
		# read the control file for approval and date params i.e. from Date and to Date.
		# fromDate and toDate should always be in MMDDYYYY format as desired by GOSOS instance
		#------------------------------------------------------------------------------
		runFlag=`head -1 $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME | cut -c1`		
		fromDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME | cut -c15-18`
		fromYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME | cut -c11-14` 		
		toDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME | cut -c23-26`
		toYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$FR_CONTROL_FILE_NAME | cut -c19-22`
		
		if [ $runFlag = "N" ]
		then 
            errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Run Flag set to N. " 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
			notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "FR Run Flag"
		fi
	fi
elif [ $RUNTYPE = "ME" ]
then
	triggerFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_TRIGGER_FILE_NAME|wc|awk '{print($1)}'`
	if [ $triggerFileExists -ne 1 ] 
	then  
	 	exit 0
	fi

	controlFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
	if [ $controlFileExists -ne 1 ] 
	then 
        errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Month End Control File does not exist." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "ME Control File"    

	 	exit 1
	else
		#------------------------------------------------------------------------------
		# read the control file for approval and date params i.e. from Date and to Date.
		# fromDate and toDate should always be in MMDDYYYY format as desired by GOSOS instance
		#------------------------------------------------------------------------------
		runFlag=`head -1 $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME | cut -c1`		
		fromDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME | cut -c15-18`
		fromYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME | cut -c11-14` 		
		toDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME | cut -c23-26`
		toYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$ME_CONTROL_FILE_NAME | cut -c19-22`
		if [ $runFlag = "N" ]
		then 
            errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Run Flag set to N. " 
	 		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
			notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "ME Run Flag"    

		 	exit 1
	 	fi
	fi
elif [ $RUNTYPE = "NC" ]
then
	controlFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME|wc|awk '{print($1)}'`
	if [ $controlFileExists -ne 1 ] 
	then 
        errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Non Cash Run Control File does not exist." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "NC Control File"    

	 	exit 1
	else
		#------------------------------------------------------------------------------
		# read the control file for approval and date params i.e. from Date and to Date.
		# fromDate and toDate should always be in MMDDYYYY format as desired by GOSOS instance		
		#------------------------------------------------------------------------------
		runFlag=`head -1 $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME | cut -c1`		
		fromDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME | cut -c15-18`
		fromYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME | cut -c11-14` 		
		toDate=`head -1 $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME | cut -c23-26`
		toYear=`head -1 $CONTROL_DATA_FOLDER_NAME/$NC_CONTROL_FILE_NAME | cut -c19-22`
		if [ $runFlag = "N" ]
		then 
            errorMessage=" EDB - the Fund earnings Extract Process cannot be started. Run Flag set to N. " 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
			notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
                "NC Run Flag"    

		 	exit 1
		fi
	fi
fi
#-------------------------------------------------------------
#  	Check to see if the Fund Earnings Extract from Gosos interface
#  	is present, else extract the Fund earnings Data from Global1 
#	instance
#-------------------------------------------------------------
extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME |wc|awk '{print($1)}'`
#-------------------------------------------------------------
#  	If the Fund Earnings extract from global one does not 
#	already exist, extract the data.
#	Date Range should be in MMDDYYYY format  
#-------------------------------------------------------------
if [ $extractFileExists -ne 1 ] 
then 

	$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_GOSOS_EXTRACT_SCRIPT \
	$ENV \
	$extractName \
	$fromDate$fromYear \
	$toDate$toYear	

	#-----------------------------------------------------------------------
	#  Capture exit code from running the extract
	#-----------------------------------------------------------------------
	exitCode=$?    
	if [ $exitCode -ne 0 ] 
	then
        errorMessage=" EDB - the Gosos Extract Process failed." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""    

	 	exit 1
	fi
	
	#-----------------------------------------------------------------------
	#  Copy the extract to destination folder
	#-----------------------------------------------------------------------
	#datafilename=`ls -alt $CFG_VAR_GLOBAL1_DATA_DIR/$IOFILES_DATA_FILE_NAME | head -1 |cut -c92-103`
	cp $CFG_VAR_GLOBAL1_DATA_DIR/$IOFILES_DATA_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME		

	#-----------------------------------------------------------------------
	#  Capture exit code from copy command execution
	#-----------------------------------------------------------------------
	exitCode=$?    
	if [ $exitCode -ne 0 ] 
	then
		errorMessage=" EDB - the Gosos Extract Process failed. Error in copying the extract folder from iofiles to destination folder." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
            "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
            ""    

	 	exit 1
	fi
fi

#---------------------------------------------------------------------------
#  Call validate script to check the extracted Fund Earnings data
#---------------------------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_FUNDEARNINGS_DIR/$VALIDATE_FUNDEARNINGS_EXTRACT_SCRIPT \
$ENV \
$RUNTYPE \
$fromYear$fromDate \
$toYear$toDate 
	
exitCode=$?
if [ $exitCode -ne 0 ] 
then 
    errorMessage=" EDB - Fund Earnings data file failed the Validate Process. The extracted Fund Earnings data is not in valid format." 
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
	notifyMicromuse "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL\
        "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
        "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        ""    
 	exit 1
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
