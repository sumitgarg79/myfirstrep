#!/bin/bash
set -x
set -v
#------------------------------------------------------------------------------
#  File Name      : validateFundEarningsExtract.sh
#  Author         : Geetika Nim
#  Date Created   : July 17, 2006
#  Last Revised   : September 26, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#------------------------------------------------------------------------------
#
#  Description    : This script validates Fund Earnings Extract file 
#					recieved from GOSOS interface. Its perform 
#					following operations
#
#					a) Check, If Extract File Exists.
#					b) Check, If Extract File has detail records.
#					c) Check, If Extract File has valid date range.
#					d) It also validate Top 10 Records for following fields
#						1) Activity Date
#						2) Effective Date
#						3) Loan Value
#						4) Days Open
#						5) Management Percentage
#						6) Investment Yield		
#	Param 1		  : Environment
#	Param 2		  : Run Type
#	Param 3		  : From Date
#	Param 4		  : To Date
#
#------------------------------------------------------------------------------
#------------------------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#------------------------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg		

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=validateFundEarningsExtract.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/fundearnings
DATA_EXTRACT_FILE_NAME=FUNDEARNINGS.DAT

#-------------------------------------------------------------
#  Local static variables recieved from control files
#-------------------------------------------------------------
RUNTYPE=$2
FROMDATE=$3
TODATE=$4
maxLine=`expr $CFG_VAR_ETL_FUNDEARNINGS_VALIDATE_RECORD_COUNT + 1`
# This variable will not treat blank space as a field separator
# during validation of  records 
IFS=$'\t\n'

#------------------------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#------------------------------------------------------------------------------
noOflines=0
rectype=0
exitCode=0
fe_Extract_fromDate=0
fe_Extract_toDate=0
fe_Extract_ACT_DATE=0
fe_Extract_EFF_DATE=0
fe_Extract_LNVAL=0
fe_Extract_DYS_OPEN=0
fe_Extract_MAN_PERC=0
fe_Extract_INV_YLD=0
noDigits=0
number=0
lineCount=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : Process ends with  exit  code 
#-------------------------------------------------------------
notifyMicromuse(){


    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnExtr*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/fundearnings/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FEarnExtr*.`date +%y%m%d`.log"
    fi 
    	
}

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/fundearnings/Comm.log" \
    -c$3
}

#-------------------------------------------------------------
# Function Name : validDateRange
# Description   : Valid date range will check if the date range 
#				  in the Fund earnings extract file is valid or not.
#				  Get the from-date and to-date from control file 
#			      and check it against the extract file header.
# Parameters    : none
# Return        : none
#-------------------------------------------------------------

validDateRange(){
	fe_Extract_fromDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | cut -c26-33`
	fe_Extract_toDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | cut -c34-41`

	if [ "$FROMDATE" = "$fe_Extract_fromDate" ]  &&  [ "$TODATE" = "$fe_Extract_toDate" ] 
	then
		return 0
	else
		errorMessage=" EDB - Error in Error in Validate Fund Earnings Extract Data. Date Range of Fund Earnings extract is invalid." \
   		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				
		notifyMicromuse "$errorMessage" \
		    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
		    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "Date Range"

	    exit 1
	fi
}

#-------------------------------------------------------------
# Function Name : hasDetailRecords
# Description   : This function check if the Fund Earnings Extract 
#				  has at least 1 detail record to upload the data.
#				  a) The number of row in the extract are more than "2"
#				  b) Checks if any of the row starts with "1" 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
hasDetailRecords () {
	
	if [ `cat $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | wc -l` -gt 2 ]
	then
    	if [ `head -2 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | tail -1 | cut -c1`  -ne  1 ]
	    then
	        errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Fund Earnings Extract file does not have any detail records." \
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            	"Detail Records > 2"

		    exit 1
    	fi 
	else 
	    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Fund Earnings Extract file does not have any detail records."
   		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
		    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
		    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "Detail Records > 1"

	    exit 1
	fi 
}


#-------------------------------------------------------------
# Function Name : isValidInt
# Description   : Validate integer input and doesn't allow any 
#				  negative integer. 
# Parameters    : String with integer value e.g. "1".
# Return        :  0 for success, 1 for failure.
#-------------------------------------------------------------
isValidInt(){
	number=$1;		
	noDigits="$(echo $number | sed 's/[[:digit:]]//g')"	

	if [ ! -z $noDigits ]
	then
	  	echo "Invalid number format! Only digits, no commas, spaces, etc."
		return 1
	fi
return 0
}

#-------------------------------------------------------------
# Function Name : isValidFloat
# Description   : Validate whether a number is a valid floating 
#				  point value. Note that this cannot accept 
#				  scientific (1.304e5)notation.To test whether 
#				  an entered value is a valid floating point 
#				  number, we need to split the value at the 
#				  decimal point,then test the first part to see
#				  if it's a valid integer, then the second part
#				  to see if it's a  valid >=0 integer, doesn't 
#				  allow any negative  values  
# Parameters    : String with integer value e.g. "1".
# Return        : 0 for success, 1 for failure.
#-------------------------------------------------------------
isValidFloat(){
  	fvalue="$1" 
    decimalPart="$(echo $fvalue | cut -d. -f1)"
    fractionalPart="$(echo $fvalue | cut -d. -f2)"  
    
    if [ ! -z $decimalPart ]  
    then  
        isValidInt $decimalPart        
        if  [ $? -eq 1 ]
        then
          	return 1
       	fi 
    fi 
    
    if [ "$fractionalPart" != "" ] 
    then    
        isValidInt $fractionalPart             
        if  [ $? -eq 1 ]
        then 
          	return 1
        fi       
    fi    
return 0
}

#-------------------------------------------------------------
# Function Name : validateRecords
# Description   : Validate various fields among top 10 detail
#				  records from Fund Earnings Extract file.Skip the
#				  first record as 1st record is having header data.
#				  Various tested Fields are		
#						1) Activity Date
#						2) Effective Date
#						3) Loan Value
#						4) Days Open
#						5) Management Percentage
#						6) Investment Yield		
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateRecords ()
{
exec 3<$DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME
while read  FUNDEARNINGSRECORD <&3
do
let "lineCount+=1"
	if [ $lineCount  -gt 1 ] &&  [ $lineCount  -le $maxLine ]
	  then 

		fe_Extract_ACT_DATE=`echo $FUNDEARNINGSRECORD | cut -c49-56`
		fe_Extract_EFF_DATE=`echo $FUNDEARNINGSRECORD | cut -c57-64` 
		fe_Extract_LNVAL=`echo $FUNDEARNINGSRECORD | cut -c110-124` 
		fe_Extract_DYS_OPEN=`echo $FUNDEARNINGSRECORD | cut -c138-143` 
		fe_Extract_MAN_PERC=`echo $FUNDEARNINGSRECORD | cut -c174-179`
		fe_Extract_INV_YLD=`echo $FUNDEARNINGSRECORD | cut -c180-189`
		
		# Remove -ve sign from the value if available before validation. -ve values/earnings are acceptable
		fe_Extract_LNVAL="$(echo $fe_Extract_LNVAL | sed 's/-//g')"
		fe_Extract_MAN_PERC="$(echo $fe_Extract_MAN_PERC | sed 's/-//g')"
		fe_Extract_INV_YLD="$(echo $fe_Extract_INV_YLD | sed 's/-//g')"
		
		#-------------------------------------------------------------------------
		#	Check Effective Date for Integer Value
		#-------------------------------------------------------------------------
		isValidInt $fe_Extract_EFF_DATE
		exitCode=$?
		if [ $exitCode != 0 ]       
		then
			echo "RECORD NO. $i -- INVALID EFF_DATE FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Effective Date data is invalid."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Effective Date"

		    exit 1
		fi
		
		#-------------------------------------------------------------------------
		#	Check Activity Date for Integer Value
		#-------------------------------------------------------------------------
		isValidInt $fe_Extract_ACT_DATE
		exitCode=$?
		if  [ $exitCode != 0 ]       
		then
			echo "RECORD NO. $i -- INVALID ACT_DATE FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Activity Date data field is not a valid date."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Activity Date"

		    exit 1
		fi
		   
		#-------------------------------------------------------------------------
		#	Check Days Open for Integer Value
		#-------------------------------------------------------------------------
		isValidInt $fe_Extract_DYS_OPEN
		exitCode=$?
		if [ $exitCode != 0 ]      
		then
			echo "RECORD NO. $i -- INVALID DYS_OPEN FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Days Open data field is not a valid number."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Days Open"

		    exit 1
		fi
		
		#-------------------------------------------------------------------------
		#	Check Loan Value for Float Value
		#-------------------------------------------------------------------------
		isValidFloat $fe_Extract_LNVAL
		exitCode=$?
		if  [ $exitCode != 0 ]       
		then
			echo "RECORD NO. $i -- INVALID LOANVALUE  FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Loan Value data field is not a valid number."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Loan Value"

		    exit 1
		fi
		
		#-------------------------------------------------------------------------
		#	Check Investment Yield for Float Value
		#-------------------------------------------------------------------------
		isValidFloat $fe_Extract_INV_YLD
		exitCode=$?
		if  [ $exitCode != 0 ]       
		then
			echo "RECORD NO. $i -- INVALID INVESTMENT YIELD  FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Investment Yield data field is not a valid number."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Inv. Yield"

		    exit 1
		fi
		      
		#-------------------------------------------------------------------------
		#	Check Management Percentage for Float Value
		#-------------------------------------------------------------------------
		isValidFloat $fe_Extract_MAN_PERC
		exitCode=$?    
		if [ $exitCode != 0 ]       
		then
			echo "RECORD NO. $i -- INVALID MANAGEMENT PERCENTAGE  FIELD." 
		    errorMessage=" EDB - Error in Validate Fund Earnings Extract Data. Management Percentage data field is not a valid number."
	   		notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Mgmt. Pct"

		    exit 1
		fi
	else
		if [ $lineCount  -gt $maxLine ]
	    then
			  break 
	   fi 
	fi	      
done
}

#-------------------------------------------------------------
# Function Name : isFilePresent
# Description   : This function checks if the Fund Earnings Extract 
#				  file exists in findersfee data directory 
#				  to upload the data.
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
isFilePresent( )
{   
	extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME|wc|awk '{print($1)}'`

	if [ $extractFileExists -ne 1 ]
	then 

		errorMessage=" EDB - Error in Fund Earnings ETL process. Fund Earnings Extract file does not exists at load location."
   		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
		
		notifyMicromuse "$errorMessage" \
		    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
		    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		    ""

	    exit 1
	fi                                
}

#-------------------------------------------------------------
#  Main function to validate the extract file for 10 records
#-------------------------------------------------------------
#---------------------------------------------------------------------------
#  Check If Extract File Exists
#---------------------------------------------------------------------------
isFilePresent
#---------------------------------------------------------------------------
#  Check If Extract File has detail records
#---------------------------------------------------------------------------
hasDetailRecords  
#---------------------------------------------------------------------------
#  Check If Extract File has valid date range
#---------------------------------------------------------------------------
validDateRange 
#---------------------------------------------------------------------------
#  Validate Top 10 Records for various fields
#---------------------------------------------------------------------------
validateRecords 
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
