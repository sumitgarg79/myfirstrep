#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loadFinderFee.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : July 17, 2006
#  Last Revised   : October 03, 2006
#  
#  Last Revised   : Sumit Garg (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#  Last Revised   : Saurabh Gupta (Keane Inc.)
#  Date Revised   : Mar 31, 2007
#  Why Revised    : Added new code for graceful exit when ME 
#					job is not required.
#-------------------------------------------------------------
#
#  Description    : This script loads FinderFee data   
#                   used from Global One to be further used in
#                   processing Fund Earnings and Distributions,
#                   within GPL Workbench. 
#    Param 1      : Environment
#    Param 2      : Run Type
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg                    

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=loadFinderFee.sh
DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/findersfee
DATA_FILE_NAME=FINDERFEE.DAT
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.findersfee.LoadFinderFeeAction
BUSINESS_ENTITY=earnings/findersfee
RUNTYPE=$2
CONTROL_DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/controletl
ME_TRIGGER_FILE_NAME=ME_FLAG_`date +%y%m%d`.DAT
#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
batchContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/findersfee/Batch.log"
autosysContactName="Log File - /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FFeeLoad*"

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -e$ENV \
        -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
        -m"$1" \
        -l$2 \
        -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/findersfee/Comm.log" \
        -c$3
}

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

if [ $RUNTYPE = "ME" ]
then
#------------------------------------------------------------------------------
#	If Trigger file is not available then ME run is not required. Exit with 0
#------------------------------------------------------------------------------
	triggerFileExists=`ls -alt $CONTROL_DATA_FOLDER_NAME/$ME_TRIGGER_FILE_NAME|wc|awk '{print($1)}'`
	if [ $triggerFileExists -ne 1 ] 
	then
		exit 0
	fi
fi
#-------------------------------------------------------------
#  Check to see if the Finder Fee GOSOS Extract is present
#-------------------------------------------------------------
extractFileExists=`ls -alt $DATA_FOLDER_NAME/$DATA_FILE_NAME|wc|awk '{print($1)}'`

if [ $extractFileExists -ne 1 ] 
then 
    errorMessage=" EDB - Error in Finder Fee Load Process. The Finder Fee Gosos Extract is not available for Upload."
    
    notifyChatChannel "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID

    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the extract 
    #-------------------------------------------------------------

    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
        -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
        -e$ENV \
        -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        -k$SHELL_SCRIPT_NAME \
        -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
        -t"$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_FILE_DIR" \
        -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/findersfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FFeeLoad*.`date +%y%m%d`.log"
    
    exit 1
fi

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Load process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY \
    $RUNTYPE
    
exitCode=$?
if [ $exitCode -ne 0 ]
then 
    errorMessage=" EDB - Error in Finder Fee Load Process." 
    
    notifyChatChannel "$errorMessage" \
        $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
        $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the Finder Fee Load 
    #-------------------------------------------------------------
  
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
        -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
        -e$ENV \
        -g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
        -k$SHELL_SCRIPT_NAME \
        -l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
        -m"$errorMessage $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
        -t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
        -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/findersfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/findersfee/Batch.log"
    
    exit 1
fi
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode