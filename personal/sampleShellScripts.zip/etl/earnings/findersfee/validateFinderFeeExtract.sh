#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : validateFinderFeeExtract.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : July 15, 2006
#  Last Revised   :	September 26, 2006
#
#  Last Revised   : Abhishek Sharma (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script validates Finder Fee Extract file 
#					recieved from GOSOS interface. Its perform 
#					following operations
#
#					a) Check, If Extract File Exists.
#					b) Check, If Extract File has detail records.
#					c) Check, If Extract File has valid date range.
#					d) It also validate Top 10 Records for following fields
#						1) Minimum Fee
#						2) Rate 
#	Param 1		  : Environment
#	Param 2		  : Run Type
#                   
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg			

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=validateFinderFeeExtract.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/findersfee
DATA_EXTRACT_FILE_NAME=FINDERFEE.DAT

#-------------------------------------------------------------
#  Setup static local variables to be used in this script
#-------------------------------------------------------------
RUNTYPE=$2
maxLine=`expr $CFG_VAR_ETL_FINDERSFEE_VALIDATE_RECORD_COUNT + 1`
# This variable will not treat blank space as a field separator
# during validation of  records 
IFS=$'\t\n'

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0
lineCount=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){

    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/findersfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FFeeExtr*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/findersfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/"$RUNTYPE"_FFeeExtr*.`date +%y%m%d`.log"
    fi 
        
   }

#-------------------------------------------------------------
# Function Name : notifyChatChannel
# Description   : Notify Interchange Chat that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity, Chat Channel
# Return        : 0 if successful
#-------------------------------------------------------------
notifyChatChannel(){
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
   	-m"$1" \
   	-l$2 \
   	-f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/findersfee/Comm.log" \
    -c$3
}

#-------------------------------------------------------------
# Function Name : isValidInt
# Description   : Validate integer input and doesn't allow any 
#				  negative integer. 
# Parameters    : String with integer value e.g. "1".
# Return        :  0 for success, 1 for failure.
#-------------------------------------------------------------
isValidInt()
{   
  number="$1"      
      
  nodigits="$(echo $number | sed 's/[[:digit:]]//g')" 
  nodigits="$(echo $nodigits | sed 's/[-]//g')"
 
  if [ ! -z $nodigits ] 
  then
  	echo "Invalid number format! Only digits, no commas, spaces, etc."
    return 1
  fi
  
 return 0 
 }  

#-------------------------------------------------------------
# Function Name : isValidFloat
# Description   : Validate whether a number is a valid floating 
#				  point value. Note that this cannot accept 
#				  scientific (1.304e5)notation.To test whether 
#				  an entered value is a valid floating point 
#				  number, we need to split the value at the 
#				  decimal point,then test the first part to see
#				  if it's a valid integer, then the second part
#				  to see if it's a  valid >=0 integer, doesn't 
#				  allow any negative  values  
# Parameters    : String with integer value e.g. "1".
# Return        : 0 for success, 1 for failure.
#-------------------------------------------------------------
isValidFloat()
{
	fvalue="$1" 
    decimalPart="$(echo $fvalue | cut -d. -f1)"
    fractionalPart="$(echo $fvalue | cut -d. -f2)"  
    
    if [ ! -z $decimalPart ]  
    then  
        isValidInt $decimalPart        
        if  [ $? -eq 1 ]
        then
          	return 1
       	fi 
    fi 
    
    if [ "$fractionalPart" != "" ] 
    then    
        isValidInt $fractionalPart             
        if  [ $? -eq 1 ]
        then 
        	return 1
        fi       
    fi    
return 0
}

#-------------------------------------------------------------
# Function Name : validateRecords
# Description   : Validate minimum fee and rate field
#				  among top 10 detail records from Finder Fee 
#				  Extract file.Calls isValidFloat function with 
#				  minimum fee and rate as parameters. Skip the
#				  first record as 1st record is having header data.	
# Parameters    : none
# Return        : none
#-------------------------------------------------------------

validateRecords (){ 
exec 3<$DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME
while read  FINDERFEERECORD <&3
do
let "lineCount+=1"
	 if [ $lineCount  -gt 1 ] &&  [ $lineCount  -le $maxLine ]
	 then
	 
 	   ff_Extract_MINFEE=`echo $FINDERFEERECORD | cut  -c48-62`
   		 ff_Extract_RATE=`echo $FINDERFEERECORD | cut  -c38-47`
  
  		# Remove -ve sign from the value if available before validation. -ve values/earnings are acceptable
		ff_Extract_MINFEE="$(echo $ff_Extract_MINFEE | sed 's/-//g')"
		ff_Extract_RATE="$(echo $ff_Extract_RATE | sed 's/-//g')"
  
		isValidFloat $ff_Extract_MINFEE
		exitCode=$?
		if  [ $exitCode -ne 0 ]
		then 
			errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Minimum Fee data is invalid."
		
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
		 	notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
                "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
                "Minimum Fee"
    			
		   	exit 1
		   	
		fi  
 		isValidFloat $ff_Extract_RATE
 		exitCode=$?
		if  [ $exitCode -ne 0 ]
		then 
			errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Rate data is invalid."

			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            	"Rate"

	   	     exit 1
		fi
	 
	else
	if [ $lineCount  -gt $maxLine ]
	then
	  	break 
	fi 
fi	 
done    
}

#-------------------------------------------------------------
# Function Name : validDateRange
# Description   : Validate the date range of the Finder Fee Extract
#				  data. If From Date and To Date is equals to 
#				  Current Date	
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validDateRange(){ 
	currentDate=`date +%Y%m%d` 
	ff_Extract_fromDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME  | cut -c26-33` 
	ff_Extract_toDate=`head -1 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME    | cut -c34-41`   

	if [   $currentDate  -ne $ff_Extract_fromDate ]  ||  [ $currentDate  -ne $ff_Extract_toDate  ]
	then 
		errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Date Range of Finder Fee extract is invalid." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
	 	notifyMicromuse "$errorMessage" \
		    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
		    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "Date Range"

		exit 1
	fi  
}  

#-------------------------------------------------------------
# Function Name : hasDetailRecords
# Description   : This function check if the Finder Fee Extract 
#				  has at least 1 detail record to upload the data.
#				  a) The number of row in the extract are more than "2"
#				  b) Checks if any of the row starts with "1" 
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
hasDetailRecords(){ 
	if [ `cat $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | wc -l` -gt 2 ]
	then
    	if [ `head -2 $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME | tail -1 | cut -c1`  -ne  1 ]
	    then
        	errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Finder Fee Extract file does not have any detail records." 
			notifyChatChannel "$errorMessage" \
			$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
			$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
			notifyMicromuse "$errorMessage" \
			    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
			    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
			    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
			    "Detail Records > 2"

		   	exit 1
    	fi 
	else 
        errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Finder Fee Extract file does not have any detail records." 
		notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
				 
	 	notifyMicromuse "$errorMessage" \
		    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
		    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            "Detail Records > 1"

		exit 1
	fi 
}
#-------------------------------------------------------------
# Function Name : isFilePresent
# Description   : This function checks if the Finder Fee Extract 
#				  file exists in findersfee data directory 
#				  to upload the data.
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
isFilePresent( )
{   
extractFileExists=`ls -alt $DATA_EXTRACT_FOLDER_NAME/$DATA_EXTRACT_FILE_NAME|wc|awk '{print($1)}'`

if [ $extractFileExists -ne 1 ]
then 
	errorMessage=" EDB - Error in Validate Finder Fee Extract Data. Finder Fee Extract file does not exists at load location." 
	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
			 
	notifyMicromuse "$errorMessage" \
	    $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	    "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
	    "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
        "" 

	exit 1
fi                                
 }
 
#-------------------------------------------------------------
#  Main function to validate the extract file for 10 records
#-------------------------------------------------------------
#---------------------------------------------------------------------------
#  Check If Extract File Exists
#---------------------------------------------------------------------------
  isFilePresent  
#---------------------------------------------------------------------------
#  Check If Extract File has detail records
#---------------------------------------------------------------------------
  hasDetailRecords  
#---------------------------------------------------------------------------
#  Check If Extract File has valid date range
#---------------------------------------------------------------------------
  validDateRange 
#---------------------------------------------------------------------------
#  Validate Top 10 Records for various fields
#---------------------------------------------------------------------------
  validateRecords 
#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
