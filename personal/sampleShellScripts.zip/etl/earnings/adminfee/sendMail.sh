

#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : sendMail.sh
#  Author         : Sumit Garg  (Keane Inc.)
#  Date Created   : Aug 20, 2007
#
#-------------------------------------------------------------
#
#  Description    : TODO
#
#    Param 1      : Environment
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg        

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=sendMail.sh
DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/adminfee

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0
extractFileExists=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){ 
    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/adminfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/AdminFee*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag    
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/adminfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/AdminFee*.`date +%y%m%d`.log"
    fi        
} 

#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
        -e$ENV \
        -d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
        -m"$1" \
        -l$2 \
        -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/adminfee/Comm.log" \
        -c$3 
} 

#-------------------------------------------------------------
# Function Name : loadAdminFeeData
# Description   : This function calls the  script to load 
#                  Admin fee Data from Collateral Management
#                  System into earnings database 
#                  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
loadAdminFeeData( )
{
    
    $CFG_VAR_HUFS_PKG_SCRIPTS_ADMIN_DIR/$LOAD_ADMIN_FEE_SCRIPT $ENV 
    exitCode=$?
    if [ $exitCode -ne 0 ] 
    then 
        errorMessage=" EDB - Load Admin Fee Data Failed." 
        
        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID 
        
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""
        
        exit 1 
    fi
    exit $exitCode
}

#-------------------------------------------------------------
# Function Name : validateAdminFeeDataFile
# Description   : This function calls the  script to validate 
#                  Admin Fee data File , if  Data File is not
#                  valid it exits  with  exit code        
#                  
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
validateAdminFeeDataFile( )
{
    
    $CFG_VAR_HUFS_PKG_SCRIPTS_ADMIN_DIR/$VALIDATE_ADMIN_FEE_SCRIPT $ENV 
    exitCode=$?
    if [ $exitCode -ne 0 ] 
    then 
        errorMessage=" EDB - Validate Admin Fee Data Failed." 
        
        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
        
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_MISSING_INVALID_DATA" \
            "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
            ""

        exit 1
    fi    
}


#-------------------------------------------------------------
# Function Name : isFilePresent
# Description   : This function checks if the Admin Fee Data File  exists in global1 
#                  directory,if exist it copies into destination folder to load the data.
#                  Otherwise notify micromuse,send message to GPL Workbench support 
#                  and terminate the process      
# Parameters    : none
# Return        : none
#-------------------------------------------------------------
isFilePresent( )
{   
#-------------------------------------------------------------
#  Check to see if the Admin fee data file is present in 
#  work folder of global1 
#-------------------------------------------------------------
    extractFileExists=`ls -alt $CFG_VAR_CMS_DATA_FILE_DIR/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME|wc|awk '{print($1)}'`
    if [ $extractFileExists -ne 1 ] 
    then
        # TODO send message to Gpl work bench support 
        errorMessage=" EDB - Extract Admin Fee Data Failed. Admin Fee data file not present" 
            
        notifyChatChannel "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
            $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID 
        
        notifyMicromuse "$errorMessage" \
            $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
            "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
            $CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA \
            ""
        
        exit 1 
    else
        #-----------------------------------------------------------------------
        #  Copy the extract folder from /golbal1/work  to destination folder
        #-----------------------------------------------------------------------
        cp $CFG_VAR_CMS_DATA_FILE_DIR/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME $DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME        
        #-----------------------------------------------------------------------
        #  Capture exit code from copy command execution
        #-----------------------------------------------------------------------
        exitCode=$?    
        if [ $exitCode -ne 0 ] 
        then
             # TODO send message to Gpl work bench support 
            errorMessage=" EDB - Load Admin Fee Data Failed. Error in copying Admin Fee data file" 
        
            notifyChatChannel "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
                $CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID 
        
            notifyMicromuse "$errorMessage" \
                $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
                "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
                $CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS \
                ""

            exit 1 
        fi
    fi
}


#-------------------------------------------------------------
#  Main function 
#-------------------------------------------------------------
# Check If Extract File Exists
    isFilePresent  
    
# Call validate script to check the extracted Admin Fee data
    validateAdminFeeDataFile
    
# Call script to load Admin Fee data
    loadAdminFeeData

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------    
    exit $exitCode
    
    
    