#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : loadAdminFee.sh
#  Author         : Sumit Garg (Keane Inc.)
#  Date Created   : Jan 17, 2006
#
#  Last Revised   : Sumit Garg (Keane Inc.)
#  Date Revised   : Mar 9, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#
#-------------------------------------------------------------
#
#  Description    : This script loads AdminFee data   
#                   used from Global One to be further used in
#                   processing Fund Earnings and Distributions,
#                   within GPL Workbench. 
#	Param 1		  : Environment
#	Param 2		  : Run Type
#-------------------------------------------------------------
#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg					

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=loadAdminFee.sh
DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_EARNINGS_DIR/adminfee
ARCHIVE_DATA_EXTRACT_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_EARNINGS_DIR/adminfee
LOAD_ACTION_CLASS_NAME=com.ubs.gplw.action.earnings.adminfee.LoadAdminFeeAction
BUSINESS_ENTITY=earnings/adminfee
RUNTYPE=$2

#-------------------------------------------------------------
#  Setup dynamic local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
# Function Name : notifyMicromuse
# Description   : Notify MicroMuse that the process did not
#                 complete successfully.
# Parameters    : Error Message, Severity
# Return        : 0 if successful
#-------------------------------------------------------------
notifyMicromuse(){ 
   
    if [ -z $5]; then
        # Call batchLogger WITHOUT the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/adminfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/AdminFee*.`date +%y%m%d`.log"
    else
        # Call batchLogger WITH the -q flag
        $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
            -a$CFG_VAR_MMNETCOOL_APPMODULE_EARNINGS \
            -d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
            -e$ENV \
            -g"$4" \
            -k$SHELL_SCRIPT_NAME \
            -l$2 \
            -m"$1 $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
            -q"$5" \
            -t"$3" \
            -u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/earnings/adminfee/$SHELL_SCRIPT_NAME. Logs: /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/autosys/AdminFee*.`date +%y%m%d`.log"
    fi            
          
} 

#------------------------------------------------------------- 
# Function Name : notifyChatChannel 
# Description   : Notify Interchange Chat that the process did not 
#                 complete successfully. 
# Parameters    : Error Message, Severity, Chat Channel 
# Return        : 0 if successful 
#------------------------------------------------------------- 
notifyChatChannel(){ 
    $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
    -e$ENV \
   	-d$CFG_VAR_BATCH_LOGGER_DEST_CHAT \
    -m"$1" \
    -l$2 \
    -f"/sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/earnings/adminfee/Comm.log" \
    -c$3
} 


#-------------------------------------------------------------
#  Check to see if the Admin Fee Extract is present
#-------------------------------------------------------------
extractFileExists=`ls -alt $DATA_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME|wc|awk '{print($1)}'`

if [ $extractFileExists -ne 1 ] 
then 
    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the extract 
    #------------------------------------------------------------
		
  	errorMessage=" EDB - Error in Admin Fee Load Process. The Admin Fee Extract is not available for Upload." 
		
  	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
	
	notifyMicromuse "$errorMessage" \
	  $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	  "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_EXTR" \
      "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA"\
      ""

	exit 1  
fi

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the Load process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $LOAD_ACTION_CLASS_NAME \
    $BUSINESS_ENTITY \
    $RUNTYPE
    
exitCode=$?
if [ $exitCode -ne 0 ]
then 
    #-------------------------------------------------------------
    #  Notify Micromuse that the there is some problem with the Admin Fee Load 
    #-------------------------------------------------------------
		
  	errorMessage=" EDB - Error in Admin Fee Load Process." 
		
  	notifyChatChannel "$errorMessage" \
	$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
	notifyMicromuse "$errorMessage" \
	 $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
	 "$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
	 "$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA"\
     ""

	 exit 1

fi
#-------------------------------------------------------------
#  					CleanUp process 
#-------------------------------------------------------------
#-------------------------------------------------------------
#  	Move the Admin Fee data file to respective ARCHIVE Folders
#-------------------------------------------------------------

fileExists=`ls -alt $DATA_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME|wc|awk '{print($1)}'`
if [ $fileExists -eq 1 ]
then
   	mv $DATA_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME $ARCHIVE_DATA_EXTRACT_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME.`date +%Y%m%d`
   	exitCode=$?
	if [ $exitCode -ne 0 ]
	then	    
		
		errorMessage=" EDB - Error occured while copying $DATA_FOLDER_NAME/$CFG_VAR_ETL_CMS_ADMINFEE_FILE_NAME to $ARCHIVE_DATA_EXTRACT_FOLDER_NAME folder." 
		
	  	notifyChatChannel "$errorMessage" \
		$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
	  	$CFG_VAR_BATCH_LOGGER_CHAT_CHANNEL_USER_ID
	
	    notifyMicromuse "$errorMessage" \
		  $CFG_VAR_BATCH_LOGGER_LOG_LEVEL_FATAL \
		  "$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
	      "$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS"\
          ""

	    exit 1
	 
	fi	
fi

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode