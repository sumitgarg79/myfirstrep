#!/bin/bash
set -x
set -v
#-------------------------------------------------------------
#  File Name      : mapToG1Location.sh
#  Author         : Adam Elkins
#  Date Created   : April 28, 2005
#
#  Last Revised   : Priti Goyal (Keane Inc.)
#  Date Revised   : Mar 12, 2007
#  Why Revised    : Added new parameters to the micromuse notification
#                   script for de-duplication feature.
#-------------------------------------------------------------
#
#  Description    : This script maps a source location reference
#                   with the global one location reference
#-------------------------------------------------------------

#-------------------------------------------------------------
#  Setup GPL Workbench Configuration Variables
#-------------------------------------------------------------
ENV=$1
. /sbcimp/dyn/data/ALG/ALGWB/$ENV/config/gplwb_$ENV.cfg

#-------------------------------------------------------------
#  Local configuration variables to be used in this script
#-------------------------------------------------------------
SHELL_SCRIPT_NAME=mapToG1Location.sh
DATA_FILE_NAME=G1HOLD.DAT
DATA_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ETL_DIR/settlementlocation
DATA_ARCHIVE_FOLDER_NAME=$CFG_VAR_HUFS_DATA_ARCHIVE_ETL_DIR/settlementlocation
ACTION_CLASS_NAME=com.ubs.gplw.action.settlementlocation.SettlementLocationAction
BUSINESS_ENTITY=settlementlocation

#-------------------------------------------------------------
#  Setup local variables to be used in this script
#-------------------------------------------------------------
exitCode=0

#-------------------------------------------------------------
#  Copy the file since the output file will be the original
#  file's name.
#-------------------------------------------------------------
cp $CFG_VAR_GLOBAL1_DATA_DIR/$DATA_FILE_NAME $DATA_FOLDER_NAME/${DATA_FILE_NAME}.orig
exitCode=$?

#----------------------------------------------------------
#  Call the generic Batch Runner script with the appropriate
#  parameters to start the location mapping process.
#----------------------------------------------------------
$CFG_VAR_HUFS_PKG_SCRIPTS_COMMON_DIR/$CFG_VAR_GPLWB_BATCH_LOAD_SCRIPT \
    $ENV \
    $ACTION_CLASS_NAME \
    $BUSINESS_ENTITY
    
#-----------------------------------------------------------------------
#  Capture exit code from invoking the common batchRunner.sh script
#-----------------------------------------------------------------------
exitCode=$?

if [ $exitCode -ne 0 ] 
then
    #---------------------------------------------------------------------------
    #  Notify MicroMuse that the process did not complete successfully.
    #---------------------------------------------------------------------------
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_DATA" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The Process Failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_DATA_LOAD" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/settlementlocation/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/settlementlocation/Batch.log"
else
    #---------------------------------------------------------------------------
    #  Backup the mapped file to the archive folder
    #---------------------------------------------------------------------------
    cp $DATA_FOLDER_NAME/$DATA_FILE_NAME $DATA_ARCHIVE_FOLDER_NAME
    exitCode=$?
        
    if [ $exitCode -ne 0 ]
    then 
        #---------------------------------------------------------------------------
        #  Notify MicroMuse that the backup of the file failed.
        #---------------------------------------------------------------------------
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The backup of the file failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-q"Archive" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/settlementlocation/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/settlementlocation/Batch.log"

    else
	#---------------------------------------------------------------------------
	#  Copy the remapped file back to the original location
	#---------------------------------------------------------------------------
	cp $DATA_FOLDER_NAME/$DATA_FILE_NAME $CFG_VAR_GLOBAL1_DATA_DIR/$DATA_FILE_NAME 
	exitCode=$?

	if [ $exitCode -ne 0 ]
	then 
	   #-----------------------------------------------------------------------------
	   #  Notify MicroMuse that the backup of the file failed.
	   #---------------------------------------------------------------------------
     $CFG_VAR_BATCH_LOGGER_SCRIPT_NAME \
		-a$CFG_VAR_MMNETCOOL_APPMODULE_AUTOBORROWS \
		-d$CFG_VAR_BATCH_LOGGER_DEST_MMNETCOOL \
		-e$ENV \
		-g"$CFG_VAR_MMNETCOOL_ALERT_GROUP_OPERATIONS" \
		-k$SHELL_SCRIPT_NAME \
		-l$CFG_VAR_BATCH_LOGGER_LOG_LEVEL_ERROR \
		-m"The backup of the file failed. $CFG_VAR_MMNETCOOL_USERDATA_COMMON_TEXT" \
		-q"Copy" \
		-t"$CFG_VAR_MMNETCOOL_FAILTYPE_PROCESSING" \
		-u"Script: /sbcimp/run/pkgs/ALG/ALGWB/$ENV/bin/etl/settlementlocation/$SHELL_SCRIPT_NAME. Logs:  /sbcimp/dyn/logfiles/ALG/ALGWB/$ENV/etl/settlementlocation/Batch.log"

	fi
	rm -f $DATA_FOLDER_NAME/$DATA_FILE_NAME 
    fi
fi

#-------------------------------------------------------------
#  Remove temporary file
#-------------------------------------------------------------
rm -f $DATA_FOLDER_NAME/${DATA_FILE_NAME}.orig

#---------------------------------------------------------------------------
#  Exit the script with the proper exitcode.
#---------------------------------------------------------------------------
exit $exitCode
